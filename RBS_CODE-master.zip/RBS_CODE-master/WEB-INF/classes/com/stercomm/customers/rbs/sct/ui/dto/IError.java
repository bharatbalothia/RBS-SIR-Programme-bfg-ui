package com.stercomm.customers.rbs.sct.ui.dto;

public interface IError {

	/**
	 * @return the code
	 */
	public abstract String getCode();

	/**
	 * @param code the code to set
	 */
	public abstract void setCode(String code);
	
	/**
	 * @return the name
	 */
	public abstract String getName();

	/**
	 * @param name the name to set
	 */
	public abstract void setName(String name);

	/**
	 * @return the description
	 */
	public abstract String getDescription();

	/**
	 * @param description the description to set
	 */
	public abstract void setDescription(String description);

	/**
	 * @return the action
	 */
	public abstract String getAction();

	/**
	 * @param action the action to set
	 */
	public abstract void setAction(String action);

	/**
	 * @return the logfile
	 */
	public abstract String getLogfile();

	/**
	 * @param logfile the logfile to set
	 */
	public abstract void setLogfile(String logfile);

}