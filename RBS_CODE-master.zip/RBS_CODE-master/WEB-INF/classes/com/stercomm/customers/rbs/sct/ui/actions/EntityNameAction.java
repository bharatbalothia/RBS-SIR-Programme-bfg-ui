/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.MessageResources;

import com.stercomm.customers.rbs.sct.ui.Utils;
import com.stercomm.customers.rbs.sct.ui.dao.EntityDAO;
import com.stercomm.customers.rbs.sct.ui.dao.RequestTypeDAO;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.forms.EntityForm;


/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unused", "unchecked"})
public class EntityNameAction extends BaseEntityWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(EntityNameAction.class);

	public ActionForward next(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		if(validateForm(form, request)){
			return super.next(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
	}

	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.save(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request,form);
			return mapping.findForward("viewForm");
		}


	}

	public ActionForward entityCDDetails(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.entityCDDetails(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request,form);
			return mapping.findForward("viewForm");
		}


	}
	public ActionForward entityMQDetails(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.entityMQDetails(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request,form);
			return mapping.findForward("viewForm");
		}


	}
	public ActionForward entityScheduleList(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.entityScheduleList(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request,form);
			return mapping.findForward("viewForm");
		}


	}
	public ActionForward entitySwift(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.entitySwift(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request,form);
			return mapping.findForward("viewForm");
		}

	}
	public ActionForward confirm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.confirm(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request,form);
			return mapping.findForward("viewForm");
		}

	}
	/*
	 * Can't get ValidatorForm to work so doing it manually (MB)
	 */
	private boolean validateForm(ActionForm form, HttpServletRequest request){

		EntityForm entityForm = (EntityForm)form;
		ActionMessages messages = new ActionMessages();
		MessageResources messageResources = getResources(request);
		boolean rtn=true;
		String entityValidate = "";
		String entityMessage = "";
		if(entityForm.getService().equalsIgnoreCase("GPL") || entityForm.getService().equalsIgnoreCase("TRD")){
			entityValidate = "sct.validate.entity.entityBIC11";
			entityMessage ="sct.msgs.entity.entity.invalidBIC11";
		} else {
			entityValidate = "sct.validate.entity.entity";
			entityMessage ="sct.msgs.entity.entity.invalid";
		}


		log.debug("Validating Entity[Name] form.");

		//Entity Check
		if(entityForm.getEntity()==null || entityForm.getEntity().equalsIgnoreCase("")){
			log.debug("Entity is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.entity.required" ));
			rtn=false;
		} else {

			log.debug("Validating [" + entityForm.getEntity() + "] against ["+ messageResources.getMessage(entityValidate)+ "]");
			if(!entityForm.getEntity().matches(messageResources.getMessage(entityValidate))){
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(entityMessage ));
				log.debug("Validation of Entity [" + entityForm.getEntity() + "] failed");
				rtn=false;
			}


			//check the entity/service are not duplicated for new creations
			Entity entity = (Entity)request.getSession().getAttribute("entityBean");
			if( entity.isNewBean() ) {
				log.debug("Validating if entity [" + entityForm.getEntity() + "] and service  [" + entityForm.getService() + "] are duplicated.");
				EntityDAO entityDAO = new EntityDAO(getHibernateSession());
				if( entityDAO.isDuplicateEntity( entityForm.getEntity(), entityForm.getService() ) ) {
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.entity.duplicate" ));
					log.debug("Entity is duplicate [" + entityForm.getEntity() + " / " + entityForm.getService() + "]");
					rtn=false;

				}
			}

			//check SCT DB Constraints will not be violated
			if( ! entity.isDeleteBean()) {
				log.debug("Validating the SCT Entity DB Constraints [" + entityForm.getEntity() + "]");
				int eid=0;
				if(!entity.isCreateBean()){
					eid = entity.getEntityId();
				}
				EntityDAO entityDAO = new EntityDAO(getHibernateSession());
				if( entityDAO.isSCTConstraintMQViolation(entityForm.getMqQueueOut(), eid) ) {
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.entity.queueexists" ));
					log.debug("MQQueueOut exists [" + entityForm.getMqQueueOut() + "]");
					rtn=false;

				}
				if( entityDAO.isSCTConstraintMbxViolation(entityForm.getMailboxPathOut(), eid) ) {
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.entity.mbxexists" ));
					log.debug("MailboxPathOut exists [" + entityForm.getMailboxPathOut() + "]");
					rtn=false;

				}
			}

		}

		//SCT Only
		if(entityForm.getService()!=null && entityForm.getService().equalsIgnoreCase("SCT")){

			//Max Bulks
			if(entityForm.getMaxBulksPerFile()==null || entityForm.getMaxBulksPerFile().equalsIgnoreCase("")){
				log.debug("MaxBulksPerFile is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.maxbulks.required" ));
				rtn=false;
			} else {
				log.debug("Validating [" + entityForm.getMaxBulksPerFile() + "] against ["+ messageResources.getMessage("sct.validate.entity.maxbulks")+ "]");
				if(!entityForm.getMaxBulksPerFile().matches(messageResources.getMessage("sct.validate.entity.maxbulks"))){
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.maxbulks.invalid" ));
					log.debug("Validation of Max Bulks [" + entityForm.getMaxBulksPerFile() + "] failed");
					rtn=false;
				}
			}

//			Max Trans
			if(entityForm.getMaxTransferBulk()==null || entityForm.getMaxTransferBulk().equalsIgnoreCase("")){
				log.debug("MaxTransPerBulk is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.maxtrans.required" ));
				rtn=false;
			} else {
				log.debug("Validating [" + entityForm.getMaxTransferBulk() + "] against ["+ messageResources.getMessage("sct.validate.entity.maxtrans")+ "]");
				if(!entityForm.getMaxTransferBulk().matches(messageResources.getMessage("sct.validate.entity.maxtrans"))){
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.maxtrans.invalid" ));
					log.debug("Validation of Max Trans [" + entityForm.getMaxTransferBulk() + "] failed");
					rtn=false;
				}
			}

//			Start Of Day
			if(entityForm.getStartOfDay()==null || entityForm.getStartOfDay().equalsIgnoreCase("")){
				log.debug("StartofDay is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.startofday.required" ));
				rtn=false;
			} else {
				log.debug("Validating [" + entityForm.getStartOfDay() + "] against ["+ messageResources.getMessage("sct.validate.entity.startofday")+ "]");
				if(!entityForm.getStartOfDay().matches(messageResources.getMessage("sct.validate.entity.startofday"))){
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.startofday.invalid" ));
					log.debug("Validation of Start Of Day [" + entityForm.getStartOfDay() + "] failed");
					rtn=false;
				}
			}

//			End Of Day
			if(entityForm.getEndOfDay()==null || entityForm.getEndOfDay().equalsIgnoreCase("")){
				log.debug("EndOfDay is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.endofday.required" ));
				rtn=false;
			} else {
				log.debug("Validating [" + entityForm.getEndOfDay() + "] against ["+ messageResources.getMessage("sct.validate.entity.endofday")+ "]");
				if(!entityForm.getEndOfDay().matches(messageResources.getMessage("sct.validate.entity.endofday"))){
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.endofday.invalid" ));
					log.debug("Validation of End Of Day [" + entityForm.getEndOfDay() + "] failed");
					rtn=false;
				}
			}

//			Inbound Mailbox
			if(entityForm.getMailboxPathIn()==null || entityForm.getMailboxPathIn().equalsIgnoreCase("")){
				log.debug("InboundMailbox is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mbxin.required" ));
				rtn=false;
			}

//			Outbound Mailbox
			if(entityForm.getMailboxPathOut()==null || entityForm.getMailboxPathOut().equalsIgnoreCase("")){
				log.debug("OutboundMailbox is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mbxout.required" ));
				rtn=false;
			}

//			Inbound MQ
//			if(entityForm.getMqQueueIn()==null || entityForm.getMqQueueIn().equalsIgnoreCase("")){
//				log.debug("Inbound MQ Queue is required. Validation failed.");
//				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqin.required" ));
//				rtn=false;
//			}

//			Outbound MQ
//			if(entityForm.getMqQueueOut()==null || entityForm.getMqQueueOut().equalsIgnoreCase("")){
//				log.debug("Outbound MQ Queue is required. Validation failed.");
//				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqout.required" ));
//				rtn=false;
//			}

//			Direct Participant
			if((entityForm.getDirectParticipant()==null || entityForm.getDirectParticipant().equalsIgnoreCase("")) && entityForm.getEntityParticipantType().equals("INDIRECT") ){
				log.debug("Direct Participant is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.directparticipant.required" ));
				rtn=false;
			}

		}

		/*
		 * GPL validation
		 */
		if(entityForm.getService()!=null && entityForm.getService().equalsIgnoreCase("GPL")){

			if(entityForm.getRouteInbound().equalsIgnoreCase("on")){

				if(entityForm.getInboundRequestorDN()==null || entityForm.getInboundRequestorDN().equalsIgnoreCase("")){
					log.debug("Inbound Requestor DN is required. Validation failed.");
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("gpl.msgs.entity.InboundRequestorDN.required" ));
					rtn=false;
				}
				if(entityForm.getInboundResponderDN()==null || entityForm.getInboundResponderDN().equalsIgnoreCase("")){
					log.debug("Inbound Responder DN is required. Validation failed.");
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("gpl.msgs.entity.InboundResponderDN.required" ));
					rtn=false;
				}
				if(entityForm.getInboundService()==null || entityForm.getInboundService().equalsIgnoreCase("")){
					log.debug("Inbound Service is required. Validation failed.");
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("gpl.msgs.entity.InboundService.required" ));
					rtn=false;
				}

				/*parse the SWIFT DNs so we know we can read them*/
				if(!Utils.parseSWIFTDN(entityForm.getInboundRequestorDN(), entityForm.getInboundResponderDN())){
					log.debug("SWIFT DN are invalid. Validation failed.");
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("gpl.msgs.entity.SWIFTDN.invalid" ));
					rtn=false;
				}

				int requestTypeLength = entityForm.getInboundRequestType().length;
				entityForm.setInboundType("");
				for( int i=0; i < requestTypeLength; i++){

					entityForm.setInboundType(entityForm.getInboundRequestType()[i] + "|" + entityForm.getInboundType());

//					if (entityForm.getInboundRequestType()[i].equals("pain.fin.mt101")){
//					entityForm.setInboundType("MT101" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.fin.mt102")){
//					entityForm.setInboundType("MT102" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.fin.mt103")){
//					entityForm.setInboundType("MT103" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.fin.mt198")){
//					entityForm.setInboundType("MT198" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.fin.mt202")){
//					entityForm.setInboundType("MT202" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.fin.mt900")){
//					entityForm.setInboundType("MT900" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.fin.mt910")){
//					entityForm.setInboundType("MT910" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.fin.mt940")){
//					entityForm.setInboundType("MT940" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.fin.mt942")){
//					entityForm.setInboundType("MT942" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.xxx.fisp.PTAIR")){
//					entityForm.setInboundType("PTAIR" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.xxx.bacs")){
//					entityForm.setInboundType("STD18" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.xxx.fisp.bpaym")){
//					entityForm.setInboundType("BPAYM" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.xxx.fisp.propt")){
//					entityForm.setInboundType("PROPT" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pacs.008.001.01")){
//					entityForm.setInboundType("PACS8" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pacs.004.001.01")){
//					entityForm.setInboundType("PACS4" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pacs.xxx.iso8583")){
//					entityForm.setInboundType("I8583" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.xxx.bai2")){
//					entityForm.setInboundType("BAI2" + "|" + entityForm.getInboundType());
//					}
//					if (entityForm.getInboundRequestType()[i].equals("pain.xxx.fisp.cadlm")){
//					entityForm.setInboundType("CADLM" + "|" + entityForm.getInboundType());
//					}


				}

				if(entityForm.getInboundType()==null || entityForm.getInboundType().equalsIgnoreCase("") || entityForm.getInboundRequestType()==null || entityForm.getInboundRequestType().length==0){
					log.debug("Inbound Request Type is required. Validation failed.");
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("gpl.entity.wizform.InboundType" ));
					rtn=false;
				}
			}
		}

		/*
		 * ROI validation
		 */
		if(entityForm.getService()!=null && entityForm.getService().equalsIgnoreCase("ROI")){
			if(entityForm.getInboundRequestorDN()==null || entityForm.getInboundRequestorDN().equalsIgnoreCase("")){
				log.debug("Inbound Requestor DN is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("roi.msgs.entity.InboundRequestorDN.required" ));
				rtn=false;
			}
			if(entityForm.getInboundResponderDN()==null || entityForm.getInboundResponderDN().equalsIgnoreCase("")){
				log.debug("Inbound Responder DN is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("roi.msgs.entity.InboundResponderDN.required" ));
				rtn=false;
			}
			if(entityForm.getInboundService()==null || entityForm.getInboundService().equalsIgnoreCase("")){
				log.debug("Inbound Service is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("roi.msgs.entity.InboundService.required" ));
				rtn=false;
			}

			//if(entityForm.getIrishStep2().equalsIgnoreCase("ON")){
			//	if(entityForm.getInboundType()==null || entityForm.getInboundType().equalsIgnoreCase("")){
			//		log.debug("Inbound Request Type is required. Validation failed.");
			//		messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("roi.msgs.entity.InboundType.required" ));
			//		rtn=false;
			//	}
			//}

			/*parse the SWIFT DNs so we know we can read them*/
			if(!Utils.parseSWIFTDN(entityForm.getInboundRequestorDN(), entityForm.getInboundResponderDN())){
				log.debug("SWIFT DN are invalid. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("gpl.msgs.entity.SWIFTDN.invalid" ));
				rtn=false;
			}

		}
		/*
		 * TRD validation
		 */
		if(entityForm.getService()!=null && entityForm.getService().equalsIgnoreCase("TRD")){
			if(entityForm.getInboundRequestorDN()==null || entityForm.getInboundRequestorDN().equalsIgnoreCase("")){
				log.debug("Inbound Requestor DN is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("trd.msgs.entity.InboundRequestorDN.required" ));
				rtn=false;
			}
			if(entityForm.getInboundResponderDN()==null || entityForm.getInboundResponderDN().equalsIgnoreCase("")){
				log.debug("Inbound Responder DN is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("trd.msgs.entity.InboundResponderDN.required" ));
				rtn=false;
			}
			if(entityForm.getInboundService()==null || entityForm.getInboundService().equalsIgnoreCase("")){
				log.debug("Inbound Service is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("trd.msgs.entity.InboundService.required" ));
				rtn=false;
			}

			/*parse the SWIFT DNs so we know we can read them*/
			if(!Utils.parseSWIFTDN(entityForm.getInboundRequestorDN(), entityForm.getInboundResponderDN())){
				log.debug("SWIFT DN are invalid. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("gpl.msgs.entity.SWIFTDN.invalid" ));
				rtn=false;
			}

			int requestTypeLength = entityForm.getInboundRequestType().length;
			entityForm.setInboundType("");
			for( int i=0; i < requestTypeLength; i++){
				entityForm.setInboundType(entityForm.getInboundRequestType()[i] + "|" + entityForm.getInboundType());
			}

			if(entityForm.getInboundType()==null || entityForm.getInboundType().equalsIgnoreCase("") || entityForm.getInboundRequestType()==null || entityForm.getInboundRequestType().length==0){
				log.debug("Inbound Request Type is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("gpl.entity.wizform.InboundType" ));
				rtn=false;
			}
		}

		saveMessages(request, messages);
		return rtn;
	}

	private ActionForm setDefaults(ActionForm form, HttpServletRequest request){


		Entity entity = (Entity)request.getSession().getAttribute("entityBean");
		String service = entity.getService();
		EntityForm entityForm=(EntityForm)form;
		log.debug("Checking defaults for service[" + service + "]");

		if(service!=null && service.equalsIgnoreCase("SDD")){
			log.debug("Setting SDD defaults for mailbox and MQ fields.");
			entityForm.setMailboxPathIn(entityForm.getEntity() + "_SDD");
			log.debug("entityForm.setMailboxPathIn: "+ entity.getMailboxPathIn()  );
			if(entity.isNewBean()){
				entityForm.setMailboxPathOut(entityForm.getEntity() + "_SDD");
			} else {
				entityForm.setMailboxPathOut(entity.getMailboxPathOut());
			}
			entityForm.setMqQueueIn(entityForm.getEntity() + "_SDD");
			entityForm.setMqQueueOut(entityForm.getEntity() + "_SDD");
			entityForm.setStartOfDay("00:00");
			entityForm.setEndOfDay("00:00");
			entityForm.setMaxTransferBulk("0");
			entityForm.setMaxBulksPerFile("0");
		}

		if(service!=null && service.equalsIgnoreCase("GPL")){
			log.debug("Setting GPL defaults for mailbox MQ and SWIFT fields.");
			entityForm.setMailboxPathIn(entityForm.getEntity() + "_GPL");
			entityForm.setMailboxPathOut(entityForm.getEntity() + "_GPL");
			entityForm.setMqQueueIn(entityForm.getEntity() + "_GPL");
			entityForm.setMqQueueOut(entityForm.getEntity() + "_GPL");
			entityForm.setStartOfDay("00:00");
			entityForm.setEndOfDay("00:00");
			entityForm.setMaxTransferBulk("0");
			entityForm.setMaxBulksPerFile("0");
		}
		if(service!=null && service.equalsIgnoreCase("ROI")){
			log.debug("Setting ROI defaults for mailbox MQ and SWIFT fields.");
			entityForm.setMailboxPathIn(entityForm.getEntity() + "_ROI");
			entityForm.setMailboxPathOut(entityForm.getEntity() + "_ROI");
			entityForm.setMqQueueIn(entityForm.getEntity() + "_ROI");
			entityForm.setMqQueueOut(entityForm.getEntity() + "_ROI");
			entityForm.setStartOfDay("0");
			entityForm.setEndOfDay("0");
			entityForm.setMaxTransferBulk("0");
			entityForm.setMaxBulksPerFile("0");
			//entityForm.setRequestType("DAT|REP|ACK");
			if(!entityForm.getIrishStep2().equalsIgnoreCase("ON")){
				entityForm.setRequestType("DAT|REP|ACK");
			} else {
				entityForm.setMailboxPathOut(entityForm.getEntity() + "_ROI_STEP2");
				entityForm.setRequestType("SBF|VBF|DRR");
				//if(entityForm.getRequestType().equalsIgnoreCase("DAT|REP|ACK")){
				//	entityForm.setRequestType("");
				//}
			}
			//String[] irt ={"DAT", "|REP", "|ACK"};
			//entityForm.setInboundRequestType(irt);
		}

		if(service!=null && service.equalsIgnoreCase("TRD")){
			log.debug("Setting TRD defaults for mailbox MQ and SWIFT fields.");
			entityForm.setMailboxPathIn(entityForm.getEntity() + "_TRD");
			entityForm.setMailboxPathOut(entityForm.getEntity() + "_TRD");
			entityForm.setMqQueueIn(entityForm.getEntity() + "_TRD");
			entityForm.setMqQueueOut(entityForm.getEntity() + "_TRD");
			entityForm.setStartOfDay("00:00");
			entityForm.setEndOfDay("00:00");
			entityForm.setMaxTransferBulk("0");
			entityForm.setMaxBulksPerFile("0");

		}
		return (ActionForm)entityForm;
	}

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		setCustom(request, form);
		return super.viewForm(mapping, form, request, response);
	}

	private void setCustom(HttpServletRequest request, ActionForm form){

		Entity entity = (Entity)request.getSession().getAttribute("entityBean");
		String service = entity.getService();
		//EntityForm entityForm=(EntityForm)form;
		log.debug("Checking defaults for service[" + service + "]");
		if(service!=null && service.equalsIgnoreCase("GPL")){
			Map formVars = new HashMap();
			//Method getInstance updated to incorporate TRD changes
			RequestTypeDAO rtDAO =RequestTypeDAO.getInstance("GPL");
			List rtypes = new ArrayList(rtDAO.getInboundRequestTypes().values());
			formVars.put("reqtypes", rtypes);
			request.setAttribute("formVars", formVars);

			//If inbound settings are null then assume 'routeinbound' is off
			if(!entity.isNewBean()){
				if(entity.getInboundRequestorDN()==null
						|| entity.getInboundRequestorDN().equalsIgnoreCase("")
						|| entity.getInboundResponderDN()==null
						|| entity.getInboundResponderDN().equalsIgnoreCase("")
				){
					entity.setRouteInbound(Boolean.FALSE);

				}
			}
		}
		//MTD Tactical: code added for TRD service type
		if(service!=null && service.equalsIgnoreCase("TRD")){
			Map formVars = new HashMap();
			RequestTypeDAO rtDAO =RequestTypeDAO.getInstance("TRD");
			List rtypes = new ArrayList(rtDAO.getInboundRequestTypes().values());
			formVars.put("reqtypes", rtypes);
			request.setAttribute("formVars", formVars);
		}

		if(service!=null && service.equalsIgnoreCase("ROI")){
			if(!entity.isNewBean()){
				if(entity.isIrishStep2()){
					entity.setIrishStep2(Boolean.TRUE);
				} else {
					entity.setIrishStep2(Boolean.FALSE);
				}
			}
		}

	}

}

