/**
 * 
 */
package com.stercomm.customers.webapps.taglibs;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
/**
 * @author Ravi K Patel
 * created Feb 17, 2006
 */
public class PageSelectorTag extends TagSupport {
	private static final long serialVersionUID = 1;
	
	private Log logger = LogFactory.getLog(PageSelectorTag.class);
	
	private int currentPage;
	private int pageSize;
	private int totalResults;
	private String itemLabel;
	private String baseURL="";
	
	private int getTotalPages(){
		return (int)Math.ceil((double)totalResults/pageSize);
	}
	
	public int doStartTag() throws JspException {
		logger.debug("currentPage="+currentPage);
		logger.debug("pageSize="+pageSize);
		logger.debug("totalResults="+totalResults);
		logger.debug("itemLabel="+itemLabel);

		int totalPages = getTotalPages();
		
		JspWriter out = pageContext.getOut();
		try {
			StringBuffer outStr = new StringBuffer();
			if (totalPages < 10){
				for (int i=1; i<=totalPages; i++){
					appendLink(i, outStr);
					outStr.append(" ");
				}
			}
			
			else{ //we need to limit the pages we show
				if (currentPage < 6){
					for (int i=1; i<7; i++){
						appendLink(i, outStr);
						outStr.append(" ");
					}
					outStr.append("...");
					appendLink(totalPages, outStr);
				}
				
				
				else {
					appendLink(1, outStr);
					outStr.append("...");
					
					if (currentPage < totalPages-5){
						
						for (int i=currentPage-1; i<currentPage+5; i++){
							appendLink(i, outStr);
							outStr.append(" ");
						}
						outStr.append("...");
						appendLink(totalPages, outStr);
					}
					else {
						for (int i=totalPages-6; i<totalPages+1; i++){
							appendLink(i, outStr);
							outStr.append(" ");
						}
					}
				}
			}
			out.print(outStr.toString().trim());

		}
		catch (IOException e){
			logger.fatal("IOException while writing to jsp", e);
			throw new JspException(e);
		}
		return EVAL_BODY_INCLUDE;
	}

	private void appendLink(int page, final StringBuffer out){
		int startItem = (pageSize * (page-1))+1;
		int endItem = (pageSize * (page));
		endItem = endItem>totalResults?totalResults:endItem;
		
		if (page == getCurrentPage()){
			out.append(Integer.toString(page));
		}
		else {
			out.append("<a title='Page "+page+": "+itemLabel+" "+startItem+"-"+endItem+"' href=\"");
			out.append(baseURL);
			int indexPoint = baseURL.lastIndexOf('?');
			if (indexPoint==-1)out.append('?');
			else if (indexPoint!=baseURL.length()-1 && baseURL.charAt(baseURL.length()-1)!='&') out.append('&');
			//else {}// baseURL contains parameters, and already ends with a '&'
			out.append("pageSize="+pageSize+"&page="+page+"\">"+page+"</a>");
		}

	}
	public String getBaseURL() {
		return baseURL;
	}
	public void setBaseURL(String baseURL) {
		this.baseURL = baseURL;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public String getItemLabel() {
		return itemLabel;
	}
	public void setItemLabel(String itemLabel) {
		this.itemLabel = itemLabel;
	}
	public int getPageSize() {
		return pageSize;
	}
	public int getTotalResults() {
		return totalResults;
	}
	public void setTotalResults(int totalResults) {
		this.totalResults = totalResults;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
