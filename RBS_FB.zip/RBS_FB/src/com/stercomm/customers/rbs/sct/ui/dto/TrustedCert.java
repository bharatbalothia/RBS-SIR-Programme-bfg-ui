/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dto;

import java.io.IOException;
import java.util.LinkedList;

import com.sterlingcommerce.security.kcapi.TrustedCertificateInfo;
import javax.security.cert.X509Certificate;


/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
public interface TrustedCert extends BaseHibernateBean {
	
	public String getCertificateId();
	public void setCertificateId(String certificateId);
	public String getCertificateName();
	public void setCertificateName(String certificateName);
	//public FormFile getCertificateFile() ;
	//public void setCertificateFile(FormFile certificateFile);
	public String getChangerComments();
	public void setChangerComments(String changerComments);
	public X509Certificate getX509Certificate();
	public void setX509Certificate(X509Certificate cert);
	public String getSubjectRDNData(String tag);
	public String getIssuerRDNData(String tag);
	public String parseRDNData(String tag, String data);
	public String getSerialNumber();
	public String getThumbprint();
	//public void setThumbprint(String thumbprint);
	public String getStartDate();
	public String getEndDate();
	public boolean isValid();
	public boolean isValid(boolean bCheckUnique);
	public String checkValidity();
	public String checkValidity(boolean bCheckUnique);
	public TrustedCertificateInfo getTrustedCertificate() throws Exception;
	public LinkedList<TrustedCertificateInfo> getTrustedCertificates() throws Exception;
	public String getAuthChainReport();
	public byte[] getObjectBytes() throws IOException;
	public String getChangeID();
	public void setChangeID(String changeID);
}
