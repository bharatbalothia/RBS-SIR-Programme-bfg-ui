/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings("unchecked")
public class ResultMetaImpl implements ResultMeta {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(ResultMetaImpl.class);
	
	
	
	private List resultsList;
	private int totalResults;
	private int currentPage;
	private int pageSize;
	private int totalPages;
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#getResultsList()
	 */
	public List getResultsList() {
		return resultsList;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#setResultsList(java.util.List)
	 */
	public void setResultsList(List resultsList) {
		this.resultsList = resultsList;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#getTotalResults()
	 */
	public int getTotalResults() {
		return totalResults;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#setTotalResults(int)
	 */
	public void setTotalResults(int totalResults) {
		this.totalResults = totalResults;
		log.debug("set total results :"+totalResults);
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#setTotalResults(Integer)
	 */
	public void setTotalResults(Integer totalResults) {
		this.totalResults = totalResults.intValue();
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#getCurrentPage()
	 */
	public int getCurrentPage() {
		return currentPage;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#setCurrentPage(int)
	 */
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#getPageSize()
	 */
	public int getPageSize() {
		return pageSize;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#setPageSize(int)
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#getTotalPages()
	 */
	public int getTotalPages() {
		return totalPages;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#setTotalPages(int)
	 */
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#getFirstResult()
	 */
	public int getFirstResult() {
		int ps = getPageSize();
		int cp = getCurrentPage();
		
		int fr = ((cp-1)*ps)+1;
		return fr;
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.ipsl.ui.dto.ResultMetaInterface#getLastResult()
	 */
	public int getLastResult() {
		int lr = (getFirstResult()-1)+getResultsList().size();
		return lr;
	}
	
	
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	
	
}
