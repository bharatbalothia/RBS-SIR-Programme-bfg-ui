/**
 * 
 */
package ic2.ui.beans.reports;

import java.io.Serializable;

/**
 * @author Ravi K Patel
 * created May 4, 2006
 */
public class ReportSettingsBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private String id;
	private String name;
	private String sql;
	private String authorization;
	private String usedates;
	private String output;
	
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAuthorization() {
		return authorization;
	}
	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSql() {
		return sql;
	}
	public void setSql(String sql) {
		this.sql = sql;
	}
	public void setUsedates(String usedates){
		this.usedates=usedates;
	}
	public String getUsedates(){
		return usedates;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	
	
}
