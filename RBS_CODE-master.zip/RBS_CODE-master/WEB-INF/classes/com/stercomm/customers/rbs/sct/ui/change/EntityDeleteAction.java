package com.stercomm.customers.rbs.sct.ui.change;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.stercomm.customers.rbs.sct.ui.dao.EntityDAO;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.sterlingcommerce.woodstock.ui.SWIFTNetRoutingRuleObj;

@SuppressWarnings({"unchecked", "unused", "deprecation"})
public class EntityDeleteAction extends EntityAction implements ChangeAction {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(EntityDeleteAction.class);

	public EntityDeleteAction(Entity entity){
		super(entity);
	}

	public void commit() throws Exception {

		log.debug("Committing the Entity delete action");

		String origService = entity.getService();

		//change these values so we don't get DB constraint violations
		entity.setDeleted(Boolean.TRUE);
		entity.setService("DEL_" + entity.getEntityId() + "_" + entity.getService());
		entity.setMailboxPathOut("DEL_" + entity.getEntityId() + "_" + entity.getMailboxPathOut());
		entity.setMqQueueOut("DEL_" + entity.getEntityId() + "_" + entity.getMqQueueOut());

		EntityDAO dao = new EntityDAO(getHibernateSession());
		dao.commit(entity);
		log.debug("saved entity to DB");

		boolean ok = true;
		//delete the routing rules because PostUpdateAction won't
		if(origService!=null && origService.equalsIgnoreCase("GPL")){
			SWIFTNetRoutingRuleObj srroList = new SWIFTNetRoutingRuleObj();
			String ruleQuery = "GPL_" + entity.getEntity() + "_%";
			ArrayList rulesList = srroList.listByName(ruleQuery, 0, 200, true);

			if(rulesList!=null){
				Iterator itrExisting = rulesList.iterator();
				while(itrExisting.hasNext()){
					HashMap hm = (HashMap)itrExisting.next();
					String hmid = (String)hm.get("objectID");

					SWIFTNetRoutingRuleObj srrDelete = new SWIFTNetRoutingRuleObj();
					srrDelete.setobjectID(hmid);
					boolean srrOK = false;
					log.debug("Deleting SRR Object with ID: "+hmid);
					try{
						srrOK = srrDelete.saveSWIFTNetRoutingRule(SWIFTNetRoutingRuleObj.DELETE_ACTION);
					}catch (Exception e){
						log.error("Caught exception deleting the SWIFTNet Routing Rule: " + e.getMessage());
						ok=false;
					}
					if(!srrOK){
						//do something here
						log.warn("Could not delete the SWIFTNet Routing Rule: " + hmid);
						ok=false;
					}



				}

			}
		}
		if(ok){
			ok = firePostUpdateActions();
		} else {
			throw new Exception("An error occuring deleting some or all of the SWIFTNet Routing Rules.");
		}
		if(!ok){
			throw new Exception("An error occuring running a UI business process. Check Current Processes on the Admin Console.");
		}
		adminAudit();
	}




}
