package ic2.ui.exception;

public class IC2UIDataExpiredException extends IC2UIRuntimeException {

	private static final long serialVersionUID = 1L;

	public IC2UIDataExpiredException() {
		super();
	}

	public IC2UIDataExpiredException(String message, Throwable cause) {
		super(message, cause);
	}

	public IC2UIDataExpiredException(String message) {
		super(message);
	}

	public IC2UIDataExpiredException(Throwable cause) {
		super(cause);
	}

}
