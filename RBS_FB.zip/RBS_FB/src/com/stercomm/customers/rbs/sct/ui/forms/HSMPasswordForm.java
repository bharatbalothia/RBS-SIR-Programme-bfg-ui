
package com.stercomm.customers.rbs.sct.ui.forms;

import org.apache.log4j.Logger;


/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
public class HSMPasswordForm extends BaseValidatorActionForm {
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private static final Logger log = Logger.getLogger(HSMPasswordForm.class);
	
	private String password1;
	private String password2;
	private boolean enabled;
	
	public String getPassword1() {
		return password1;
	}
	public void setPassword1(String password1) {
		this.password1 = password1;
	}
	public String getPassword2() {
		return password2;
	}
	public void setPassword2(String password2) {
		this.password2 = password2;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	
	
}
