package com.stercomm.customers.rbs.sct.ui.change;

import java.util.List;

@SuppressWarnings({"unchecked"})
public interface ChangeViewer {
	
	public abstract ChangeControl getChange();
	public abstract String getObjectType();
	public abstract void setChange(ChangeControl change);
	public abstract String getBeforeChangeLink();
	public abstract String getAfterChangeLink();
	public abstract String getDifferencesLink();
	public abstract List getDifferences();

}
