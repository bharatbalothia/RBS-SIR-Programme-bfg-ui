/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.log4j.Logger;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.change.ChangeControl;
import com.stercomm.customers.rbs.sct.ui.change.ChangeViewer;
import com.stercomm.customers.rbs.sct.ui.dao.ChangeDAO;
import com.stercomm.customers.rbs.sct.ui.dao.EntityDAO;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 * 
 */
public class EntityListAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	//private static final Logger log = Logger.getLogger(EntityListAction.class);

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionErrors errors = new ActionErrors();


		int pageNo;
		int pageSize;
		{
			String pg_s = request.getParameter("page");
			String ps_s = request.getParameter("pageSize");
			pageNo = pg_s==null?1:Integer.parseInt(pg_s);
			pageSize = ps_s==null?10:Integer.parseInt(ps_s);
		}

		EntityDAO entityDAO = new EntityDAO(getHibernateSession());
		ResultMeta rm;
		//String entityName = request.getParameter("entityName");
		//String entityService = request.getParameter("serviceName");
		String entityName = (String)request.getSession().getAttribute("entityName");
		String entityService = (String)request.getSession().getAttribute("serviceName");
		Boolean changePending = (Boolean)request.getSession().getAttribute("changePending");
		Boolean byService = (Boolean)request.getSession().getAttribute("byService");

		if(changePending!=null && changePending.booleanValue()==true){
			EntityDAO entitydao = new EntityDAO(getHibernateSession());
			rm = entitydao.getPendingChangeEntities(pageNo, pageSize);
		} else if(byService!=null && byService.booleanValue()==true){
			EntityDAO entitydao = new EntityDAO(getHibernateSession());
			rm = entitydao.getEntitiesByService(pageNo, pageSize, entityService); 
		} else {
			if (entityName==null||entityName.equals("")){
				rm = entityDAO.getEntities(pageNo, pageSize);
			}else{
				rm = entityDAO.getEntities(pageNo, pageSize, entityName);
			}
		}



		if (rm.getTotalResults()>0){
			request.setAttribute("resultMeta", rm);
			return super.viewForm(mapping, form, request, response);
		}
		else {
			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.errors.entitySearch.noResults"));
			saveErrors(request, errors);
			return mapping.findForward("noResults");
		}


	}


//	public ActionForward add(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
//	Schedule schedule = new ScheduleImpl();
//	schedule.setNewBean(true);
//	schedule.setCreateBean(true);
//	request.getSession().setAttribute("scheduleBean", schedule);

//	return mapping.findForward("addNewSchedule");
//	}



	public ActionForward edit(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		int id = Integer.parseInt(request.getParameter("id"));
		EntityDAO dao = new EntityDAO(getHibernateSession());
		Entity entity= dao.getEntity(id);
		request.getSession().setAttribute("entityBean", entity);
		return mapping.findForward("editEntity");
	}

	public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		int id = Integer.parseInt(request.getParameter("id"));
		EntityDAO dao = new EntityDAO(getHibernateSession());
		Entity entity= dao.getEntity(id);
		entity.setDeleteBean(true);
		request.getSession().setAttribute("entityBean", entity);
		return mapping.findForward("deleteEntity");
	}

	public ActionForward transmit(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("entityTransmit");
	}

	public ActionForward entityReturn(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("entityReturn");
	}

	public ActionForward changeApprove(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String changeID = request.getParameter("id");

		try {
			ChangeDAO changeDAO = new ChangeDAO(getHibernateSession());
			ChangeControl cc = changeDAO.getChange(changeID);
			ChangeViewer cview = (ChangeViewer) Class.forName(cc.getObjectType()).newInstance();   
			cview.setChange(cc);
			request.setAttribute("changeviewer", cview);
		} catch (Exception e) {
			e.printStackTrace();
			return mapping.findForward("notfound");	
		}		
		return mapping.findForward("changeApprove");
	}


}
