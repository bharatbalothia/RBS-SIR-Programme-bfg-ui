package com.stercomm.customers.rbs.sct.ui.dto;

import java.util.Date;


public interface MQTransfer {
	
	/**
	 * When (status==2)
	 */
	public static final int STATUS_GREEN = 1;
	/**
	 * When (status >=0 && !(status==2)
	 * (ie not ERROR or GREEN_
	 */
	public static final int STATUS_RUNNING = 2;
	/**
	 * When status < 0
	 */
	public static final int STATUS_ERROR = 3;
	
	//public static final int STATUS_GREEN_TRXERROR = 4;
	

	/**
	 * Returns an execution status code, based on the status code
	 * @return
	 */
	public int getExecutionStatus();
	
	public abstract String getCorrelationid();
	public abstract String getProducer();
	public abstract String getConsumer();
	public abstract String getFilename();
	public abstract Date getExpires();
	public abstract Integer getStatus();
	public abstract Boolean isAlerted();
	public abstract Boolean isArchived();
	public abstract Integer getMetawfid();
	public abstract Integer getAckwfid();
	public abstract Integer getFilewfid();
	public abstract String getDocid();
	public abstract Integer getDataflowid();
	public abstract Date getCreated();
	public abstract Date getLastmodified();
	public abstract String getDeliverykey();
	
	public abstract void setCorrelationid(String correlationid);
	public abstract void setProducer(String producer);
	public abstract void setConsumer(String consumer);
	public abstract void setFilename(String filename);
	public abstract void setExpires(Date expires);
	public abstract void setStatus(Integer status);
	public abstract void setAlerted(Boolean alerted);
	public abstract void setArchived(Boolean archived);
	public abstract void setMetawfid(Integer metawfid);
	public abstract void setAckwfid(Integer ackwfid);
	public abstract void setFilewfid(Integer ackwfid);
	public abstract void setDocid(String docid);
	public abstract void setDataflowid(Integer dataflowid);
	public abstract void setCreated(Date created);
	public abstract void setLastmodified(Date lastmodified);
	public abstract void setDeliverykey(String deliverykey);
	

}