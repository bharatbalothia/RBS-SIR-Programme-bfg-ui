package com.stercomm.customers.rbs.sct.ui;

import java.util.Date;

public interface FileSearchCriteria extends SearchCriteria{

	/**
	 * @return the entityId
	 */
	public abstract Integer getEntityId();

	/**
	 * @param entityId the entityId to set
	 */
	public abstract void setEntityId(Integer entityId);
	
	
	/**
	 * @return the service
	 */
	public abstract String getService();

	/**
	 * @param service the service to set
	 */
	public abstract void setService(String service);

	/**
	 * @return the direction
	 */
	public abstract String getDirection();

	/**
	 * @param direction the direction to set
	 */
	public abstract void setDirection(String direction);

	/**
	 * @return the fileStatus
	 */
	public abstract String getFileStatus();

	/**
	 * @param fileStatus the fileStatus to set
	 */
	public abstract void setFileStatus(String fileStatus);

	/**
	 * @return the bpState
	 */
	public abstract String getBpState();

	/**
	 * @param bpState the bpState to set
	 */
	public abstract void setBpState(String bpState);

	/**
	 * @return the filename
	 */
	public abstract String getFilename();

	/**
	 * @param filename the filename to set
	 */
	public abstract void setFilename(String filename);

	/**
	 * @return the reference
	 */
	public abstract String getReference();

	/**
	 * @param reference the reference to set
	 */
	public abstract void setReference(String reference);

	/**
	 * @return the type
	 */
	public abstract String getType();

	/**
	 * @param type the type to set
	 */
	public abstract void setType(String type);

	/**
	 * @return the fromDate
	 */
	public abstract Date getFromDate();

	/**
	 * @param fromDate the fromDate to set
	 */
	public abstract void setFromDate(Date fromDate);

	/**
	 * @return the toDate
	 */
	public abstract Date getToDate();

	/**
	 * @param toDate the toDate to set
	 */
	public abstract void setToDate(Date toDate);
	
	/**
	 * @return the minDiff
	 */
	public abstract String getMinDiff();

	/**
	 * @param minDiff the minDiff to set
	 */
	public abstract void setMinDiff(String minDiff);

}