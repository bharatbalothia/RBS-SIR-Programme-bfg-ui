/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.log4j.Logger;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.MessageResources;
import com.stercomm.customers.rbs.sct.ui.change.ChangeAction;
import com.stercomm.customers.rbs.sct.ui.change.ChangeConstants;
import com.stercomm.customers.rbs.sct.ui.change.ChangeControl;
import com.stercomm.customers.rbs.sct.ui.change.ChangeViewer;
import com.stercomm.customers.rbs.sct.ui.change.TrustedCertViewer;
import com.stercomm.customers.rbs.sct.ui.forms.ChangeApproveForm;
import com.sterlingcommerce.woodstock.dmi.visibility.event.AFCDmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.ExceptionLevel;
import com.sterlingcommerce.woodstock.util.BaseUtil;

/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
public class ChangeApproveAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	//private static final Logger log = Logger.getLogger(ChangeApproveAction.class);
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		try {
			ChangeViewer cv = (ChangeViewer)request.getAttribute("changeviewer");
			ChangeControl cc = cv.getChange();
			if(cc.getChanger().equalsIgnoreCase(this.getGisUsername(request))){
				request.setAttribute("SameUser", "true");
			} else {
				request.setAttribute("SameUser", "false");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return mapping.findForward("notfound");	
		}
		return super.viewForm(mapping, form, request, response);
	}

	public ActionForward approve(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		ActionMessages messages = new ActionMessages();

		@SuppressWarnings("unused")
		MessageResources messageResources = getResources(request);

		try{
			
			ChangeControl cc = this.getChangeRecord(form, request);
			if(cc.getStatus()!=ChangeConstants.STATUS_PENDING){
				throw new Exception("Status is not pending and therefore no action can be taken");
			}
			/*
			 * Perform the actual update
			 */
			byte[] bActionObj = cc.getActionObject();
			ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bActionObj)); 
			ChangeAction caction = (ChangeAction)in.readObject(); 
			caction.commit();
			
			/*
			 * commit the status in FB_CHANGE_CONTROL
			 */
			
			cc.accept(this.getGisUsername(request), cc.getApproverNotes());
			
			AFCDmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, BaseUtil.createGUID(), System.currentTimeMillis(), getGisUsername(request), cc.getShortType() + ": " + cc.getOperation(), "Change Approved", cc.getChangeID(), cc.getResultMeta1());
		
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.change.approved" ));
			saveMessages(request, messages);
		}catch (Exception e){
			//should really set the change status as FAILED here - leaving as is so that the user can just reject the change
			e.printStackTrace();
			ActionErrors errors = new ActionErrors();
			errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("setup.msgs.change.approved.failure"));
			saveErrors(request, errors);		
		}

		return mapping.findForward("finish");
	}
	
	public ActionForward reject(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		ActionMessages messages = new ActionMessages();
		@SuppressWarnings("unused")
		MessageResources messageResources = getResources(request);

		try{
			ChangeControl cc = this.getChangeRecord(form, request);
			if(cc.getStatus()!=ChangeConstants.STATUS_PENDING){
				throw new Exception("Status is not pending and therefore no action can be taken");
			}
			cc.reject(this.getGisUsername(request), cc.getApproverNotes());
			AFCDmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, BaseUtil.createGUID(), System.currentTimeMillis(), getGisUsername(request), cc.getShortType() + ": " + cc.getOperation(), "Change Rejected", cc.getChangeID(), cc.getResultMeta1());
			
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.change.rejected" ));
			saveMessages(request, messages);
		}catch (Exception e){
			ActionErrors errors = new ActionErrors();
			errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("setup.msgs.change.rejected.failure"));
			saveErrors(request, errors);		
		}

		return mapping.findForward("finish");
	}
	
	public ActionForward cancel(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		String objtype = request.getParameter("objecttype");
		if(objtype.equalsIgnoreCase(TrustedCertViewer.OBJECT_TYPE)){
			return mapping.findForward("cancelCerts");
		} else {
			return mapping.findForward("cancel");
		}

	}
	
	private ChangeControl getChangeRecord(ActionForm form, HttpServletRequest request) throws Exception{
		ChangeApproveForm caf = (ChangeApproveForm)form;
		String comments = caf.getApproverComments();
		if(comments==null){
			comments="";
		}

		String changeID = request.getParameter("changeID");
		ChangeControl cc = new ChangeControl(changeID);
		cc.setApproverNotes(comments);
		return cc;
		
	}
	
}
