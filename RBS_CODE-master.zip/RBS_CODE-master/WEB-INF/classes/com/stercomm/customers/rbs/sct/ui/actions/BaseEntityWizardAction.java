/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.forms.EntityForm;
import com.stercomm.customers.rbs.sct.ui.forms.adapters.EntityAdapter;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings("unchecked")
public abstract class BaseEntityWizardAction extends BaseWizardAction{

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger
			.getLogger(BaseEntityWizardAction.class);
	
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		Entity entity = getEntity(request);
		//changed 2007-08-23
		
		EntityForm entityForm = (EntityForm)form;
		Entity efa = new EntityAdapter(entityForm);
		copyBeanProperties(entity, efa);
		
		return super.viewForm(mapping, form, request, response);
	}
	
	
	public ActionForward next(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return super.next(mapping, form, request, response);
	}
	
	public ActionForward back(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return super.back(mapping, form, request, response);
	}
	
	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return super.save(mapping, form, request, response);
	}
	
	
	
	public ActionForward entityName(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("entityName");
	}
	public ActionForward entityCDDetails(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("entityCDDetails");
	}
	public ActionForward entityMQDetails(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("entityMQDetails");
	}
	public ActionForward entityScheduleList(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("entityScheduleList");
	}
	public ActionForward entitySwift(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("entitySwift");
	}
	public ActionForward confirm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("confirm");
	}
	
	public void saveForm2Bean(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		Entity entity = getEntity(request);
		
		//temp save data that is not in the form
		Integer entityId = entity.getEntityId();
		List schedules = entity.getSchedules();
		List deletedSchedules = entity.getDeletedSchedules();
		boolean createBean = entity.isCreateBean();
		boolean newBean = entity.isNewBean();
		boolean updated = entity.isUpdated();
		boolean deleted = entity.isDeleteBean();
		
		//copy data from the form to the bean
		EntityForm entityForm = (EntityForm)form;
		Entity efa = new EntityAdapter(entityForm);
		copyBeanProperties(efa, entity);
		
		//copy the temp data back to the bean
		entity.setEntityId(entityId);
		entity.setSchedules(schedules);
		entity.setDeletedSchedules(deletedSchedules);
		entity.setCreateBean(createBean);
		entity.setNewBean(newBean);
		entity.setUpdated(updated);
		entity.setDeleteBean(deleted);
	}
	
	
	protected Entity getEntity(HttpServletRequest request){
		Entity entity = (Entity)request.getSession().getAttribute("entityBean");
		log.debug("got Entity from Session: "+entity);
		return entity;
	}
}
