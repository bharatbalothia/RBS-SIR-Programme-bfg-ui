package com.stercomm.customers.rbs.sct.ui.change;

public class DiffViewer {
	
	private String field;
	private String beforeValue;
	private String afterValue;
	private boolean isDifferent;
	
	public DiffViewer(String field, String before, String after){
		setField(field);
		setBeforeValue(before);
		setAfterValue(after);
		compare();
	}
	
	public DiffViewer(String field, int before, int after){
		setField(field);
		setBeforeValue(String.valueOf(before));
		setAfterValue(String.valueOf(after));
		compare();
	}
	public DiffViewer(String field, Integer before, Integer after){
		setField(field);
		setBeforeValue(String.valueOf(before));
		setAfterValue(String.valueOf(after));
		compare();
	}
	public DiffViewer(String field, boolean before, boolean after){
		setField(field);
		setBeforeValue(String.valueOf(before));
		setAfterValue(String.valueOf(after));
		compare();
	}
	public DiffViewer(String field, Boolean before, Boolean after){
		setField(field);
		setBeforeValue(String.valueOf(before));
		setAfterValue(String.valueOf(after));
		compare();
	}
//	public DiffViewer(String field, String[] befores, String[] afters){
//		setField(field);
//		if(befores!=null)
//		setBeforeValue(arrayToString(befores));
//		setAfterValue(arrayToString(afters));
//		compare();
//	}
//	private String arrayToString(String[] arr){
//		
//		if(arr!=null){
//			StringBuffer sb = new StringBuffer();
//			for(int i=0;i<arr.length;i++){
//				try {
//					sb.append(arr[i]);
//					sb.append("/");
//				} catch (RuntimeException e) {
//					sb.append("null");
//					sb.append("/");
//				}
//			}
//			return sb.toString();
//		} else {
//			return null;
//		}
//	}
	
	public String getAfterValue() {
		return afterValue;
	}
	public void setAfterValue(String afterValue) {
		this.afterValue = afterValue;
	}
	public String getBeforeValue() {
		return beforeValue;
	}
	public void setBeforeValue(String beforeValue) {
		this.beforeValue = beforeValue;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public boolean isDifferent(){
		return isDifferent;
	}
	public void compare(){
		if((getBeforeValue()==null || getBeforeValue().equalsIgnoreCase("")) && (getAfterValue()==null || getAfterValue().equalsIgnoreCase(""))){
			isDifferent=false;
		}else{
			isDifferent = !getBeforeValue().equals(getAfterValue());
		}
	}
	
	

}
