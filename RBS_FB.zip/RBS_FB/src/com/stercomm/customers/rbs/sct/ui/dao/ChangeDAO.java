/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   $Revision: $
 * Date/time:  $Date: $
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dao;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import org.hibernate.Session;

import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.ResultMetaImpl;
import com.stercomm.customers.rbs.sct.ui.change.ChangeControl;
/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
@SuppressWarnings({"unused", "unchecked"})
public class ChangeDAO extends BaseHibernateDAO {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(ChangeDAO.class);


	/**
	 * @param hibSession
	 */
	@SuppressWarnings("deprecation")
	public ChangeDAO(Session hibSession) {
		super(hibSession);
	}


	/**
	 * Saves the Entity object to the database
	 * @param entity
	 */
	public void commit(ChangeControl cc, HttpServletRequest request){

		//		log.debug("trying to save entity :"+entity);
		//		
		//		Session session = getHibernateSession();
		//		
		//		Transaction transaction = session.beginTransaction();
		//		
		//		
		//		
		//		
		//		try {
		//			if (entity.isCreateBean()){
		//				session.save(entity);
		//				log.debug("saved entity: "+entity);
		//			}
		//			else{
		//				session.update(entity);
		//			}
		//			session.flush();
		//			
		//			List deletedSchedules = entity.getDeletedSchedules();
		//			for (int i=0; i<deletedSchedules.size(); i++){
		//				Schedule deletedSchedule = (Schedule)deletedSchedules.get(i);
		//				if (!deletedSchedule.isCreateBean()){
		//					session.delete(deletedSchedule);
		//					log.debug("deleted schedule: "+deletedSchedule);
		//				}
		//				else{
		//					log.debug("schedule to delete has not been inserted yet...nothing to delete..skipping");
		//				}
		//			}
		//			
		//			
		//			
		//			
		//			List schedules = entity.getSchedules();
		//			
		//			for(int i=0; i<schedules.size(); i++){
		//				Schedule schedule = (Schedule)schedules.get(i);
		//				Date nextRun = Utils.minToDate(schedule.getTimestart());
		//				
		//				schedule.setNextRun(nextRun);
		//				log.debug("setting transaction next runtime to : "+nextRun.toString());
		//				
		//				//Date nextRun = schedule.getNextRun();
		//				if (schedule.isCreateBean()){
		//					log.debug("inserting new schedule: "+schedule);
		//					schedule.setEntity(entity);
		//					session.save(schedule);
		//					
		//				}
		//				else if (schedule.isUpdated()){
		//					log.debug("updating schedule: "+schedule);
		//					session.update(schedule);
		//				}
		//			}
		//			
		//			Utils.adminAudit(request, entity);
		//			
		//			transaction.commit();
		//			log.debug("entity save-update transaction committed");
		//		} catch (HibernateException e) {
		//			String msg = "failed to save entity to database";
		//			log.debug(msg, e);
		//			e.printStackTrace();
		//			transaction.rollback();
		//			throw e;
		//			
		//		}

	}

/*	*//**
	 * @return a List of Entity objects
	 *//*
	public List<?> getTrustedCerts(){
		//		Session session = getHibernateSession();
		//		String key = "dao.entity.list";
		//		Query query = session.getNamedQuery(key);
		//		List list = query.list();
		//		return list;
		return null;
	}*/

	/**
	 * @return a List of Entity objects
	 */
//	public List<?> getEntities(String service){
//		//		Session session = getHibernateSession();
//		//		//String key;
//		//		if(service!=null && !service.equalsIgnoreCase("") && !service.equalsIgnoreCase("ALL")){
//		//			String key = "dao.entity.list.ByService";
//		//			Query query = session.getNamedQuery(key);
//		//			query.setString("service", service);
//		//			List list = query.list();
//		//			return list;
//		//		} else {
//		//			return getEntities();
//		//		}
//
//
//		return null;
//	}
	/**
	 * Returns the Entity object identified by entityId
	 * @param entityId
	 * @return the Entity Object
	 */
	public ChangeControl getChange(String changeId) throws Exception{
		ChangeControl cc = new ChangeControl(changeId);
		return cc;
	}


	//	public Entity getEntity(Integer entityId){
	//		return getEntity(entityId.intValue()); 
	//	}

	//	public boolean isDuplicateEntity(String entityName, String service){
	//		Session session = getHibernateSession();
	//		Query query = session.createQuery("from EntityImpl ent where ent.entity=:entity and ent.service=:service");
	//		query.setString("entity", entityName);
	//		query.setString("service", service);
	//		
	//		if(query.list().size()>0){
	//			return true;
	//		} else {
	//			return false;
	//		}
	//	
	//	}

	
	
	public ResultMeta getChanges(String objectType, int pageNo, int pageSize){
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();
		
		List results = null;
		
		if(results!=null){
			rm.setResultsList(results);
			rm.setTotalResults(results.size());
		}
		return rm;
	}


	//	public ResultMeta getEntities(int pageNo, int pageSize){
	//		ResultMeta rm = new ResultMetaImpl();
	//		rm.setCurrentPage(pageNo);
	//		rm.setPageSize(pageSize);
	//		
	//		int firstResult = rm.getFirstResult();
	//		
	//		Session session = getHibernateSession();
	//		Query query = session.getNamedQuery("dao.entity.list");
	//		query.setFirstResult(firstResult-1); //zero indexed
	//		query.setMaxResults(pageSize);
	//		
	//		List results = query.list();
	//		rm.setResultsList(results);
	//		
	//		
	//		query = session.getNamedQuery("dao.entity.list.size");
	//		Integer totalResults = (Integer)query.uniqueResult();
	//		rm.setTotalResults(totalResults);
	//		
	//		
	//		return rm;
	//	}



	//	public ResultMeta getEntities(int pageNo, int pageSize, String entityName){
	//		ResultMeta rm = new ResultMetaImpl();
	//		rm.setCurrentPage(pageNo);
	//		rm.setPageSize(pageSize);
	//		
	//		int firstResult = rm.getFirstResult();
	//		
	//		Session session = getHibernateSession();
	//		Query query = session.getNamedQuery("dao.entity.list.byEntityName");
	//		query.setFirstResult(firstResult-1); //zero indexed
	//		query.setMaxResults(pageSize);
	//		query.setString("entityName", entityName+"%");
	//		
	//		List results = query.list();
	//		rm.setResultsList(results);
	//		
	//		
	//		query = session.getNamedQuery("dao.entity.list.size.byEntityName");
	//		query.setString("entityName", entityName+"%");
	//		Integer totalResults = (Integer)query.uniqueResult();
	//		
	//		rm.setTotalResults(totalResults);
	//		
	//		
	//		return rm;
	//	}


	

	
	

	


}
