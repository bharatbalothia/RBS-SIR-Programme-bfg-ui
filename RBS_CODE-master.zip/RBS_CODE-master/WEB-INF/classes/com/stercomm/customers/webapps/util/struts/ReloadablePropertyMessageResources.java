/**
 * 
 */
package com.stercomm.customers.webapps.util.struts;

import org.apache.struts.util.MessageResourcesFactory;
import org.apache.struts.util.PropertyMessageResources;

/**
 * @author Ravi K Patel
 * created Apr 25, 2006
 */
public class ReloadablePropertyMessageResources extends	PropertyMessageResources {

	private static final long serialVersionUID = 1L;

	public ReloadablePropertyMessageResources(MessageResourcesFactory arg0, String arg1, boolean arg2) {
		super(arg0, arg1, arg2);
	}

	public ReloadablePropertyMessageResources(MessageResourcesFactory arg0, String arg1) {
		super(arg0, arg1);
	}

	
	public synchronized void reload() {
	    locales.clear();
	    messages.clear();
	    formats.clear();
	 }
	
}
