/**
 * 
 */
package ic2.ui.beans.reports;

import java.io.Serializable;
import java.util.List;

/**
 * @author Ravi K Patel
 * created May 4, 2006
 */
@SuppressWarnings({"unchecked"})
public class ReportDataBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private List reportColumns;
	private byte[] pdfdocbuffer;
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public List getReportColumns() {
		return reportColumns;
	}
	public void setReportColumns(List reportColumns) {
		this.reportColumns = reportColumns;
	}
	
	public ReportDataBean(){
		
	}
	
	public ReportDataBean(byte[] b){
		setDocBuffer(b);
	}
	
	public void setDocBuffer(byte[] b)
	{
		this.pdfdocbuffer = b;
	}
	
	public byte[] getDocBuffer(){
		return pdfdocbuffer;
	}
	
}
