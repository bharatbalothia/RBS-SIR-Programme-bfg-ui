/**
 * 
 */
package ic2.ui.struts.actions;

import ic2.ui.SessionVarConstants;
import ic2.ui.beans.bp.BPSubmitObject;
import ic2.ui.struts.forms.IC2UIForm;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.util.MessageResources;
import org.w3c.dom.Document;

import com.stercomm.customers.webapps.resources.Constants;
import com.sterlingcommerce.woodstock.security.User;

/**
 * @author Ravi K Patel
 * created Apr 10, 2006
 */
@SuppressWarnings({"unchecked"})
public class IC2UIAction extends DispatchAction {

	private static final Logger logger = Logger.getLogger(IC2UIAction.class);

	
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return super.execute(mapping, form, request, response);
	}
	protected ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return super.unspecified(mapping, form, request, response);
	}
	
	public ActionErrors validate(ActionMapping mapping, IC2UIForm form, HttpServletRequest request){
		ActionErrors errors = new ActionErrors();
		return errors;
	}
	
	/**
	 * public accessor to org.apache.struts.action.Action.getResources(HttpServletRequest, String)
	 * @param request
	 * @param resourceName
	 * @return
	 */
	public MessageResources getMessageResources(HttpServletRequest request, String resourceName) {
		return super.getResources(request, resourceName);
	}
	
	/**
	 * Returns the User object for the currently logged on User, or null if no User is logged on
	 * @param request
	 * @return the User object
	 */
	protected User getGISUserObject(HttpServletRequest request){
		
		HttpSession session =  request.getSession();
		return session==null?null:(User)session.getAttribute(Constants.GIS_USER_OBJECT);
	}

	/**
	 * Returns the username of the currently logged in user, or null if no user is logged in.
	 * @param request
	 * @return
	 */
	protected String getGISUsername(HttpServletRequest request){
		User user = getGISUserObject(request);
		return user==null?null:user.getUserName();
		
	}
	
	/**
	 * returns true if a User is currently logged on, and they have permission <code>permissionName</code>.
	 * If no user is logged on, the method returs false.
	 * @param permissionName
	 * @param request
	 * @return
	 */
	protected boolean hasPermission(String permissionName, HttpServletRequest request){
		User user = getGISUserObject(request);
		return user==null?false:user.hasPermission(permissionName);
	}
	
	
	public static final Integer ALL_LOCKS = new Integer(1);
	private static final String ALL_LOCKS_STR = "ALL_LOCKS";
	public static final Integer IGNORE_USER_LOCKS = new Integer(2);
	public static final String IGNORE_USER_LOCKS_STR = "IGNORE_USER_LOCKS";
	public static final Integer IGNORE_ALL_LOCKS = new Integer(3);
	public static final String IGNORE_ALL_LOCKS_STR = "IGNORE_ALL_LOCKS";
	
	private static Integer lockBehaviour = null;
	private static final Object LOCK_BEHAVIOUR_SYNCH_OBJ = new Object();
	protected Integer getLockBehaviour(HttpServletRequest request){
		if (lockBehaviour ==null) {
			synchronized (LOCK_BEHAVIOUR_SYNCH_OBJ){
				if (lockBehaviour ==null) {
					String lockBehaviour = getIC2Constants(request).getMessage("lockBehavior");
					if (!(lockBehaviour == null || lockBehaviour.length()==0)){
					
						if (lockBehaviour.equals(ALL_LOCKS_STR))
							IC2UIAction.lockBehaviour = ALL_LOCKS;
						else if (lockBehaviour.equals(IGNORE_USER_LOCKS_STR))
							IC2UIAction.lockBehaviour = IGNORE_USER_LOCKS;
						else if (lockBehaviour.equals("IGNORE_ALL_LOCKS"))
							IC2UIAction.lockBehaviour = IGNORE_ALL_LOCKS;
					}
					if (IC2UIAction.lockBehaviour == null){
						IC2UIAction.lockBehaviour = IGNORE_USER_LOCKS;
					}
				}
			}
		}

		
		return IC2UIAction.lockBehaviour;
	}
	
	
//	/**
//	 * @param request
//	 * @return
//	 * 
//	 * @deprecated
//	 */
//	protected PermissionManager getPermissionManager(HttpServletRequest request){
//		HttpSession session =  request.getSession();
//		return (PermissionManager)session.getAttribute("GIS_LOGGED_IN_USER_PERMISSIONS");
//	}
	
	
	/**
	 * Returns the MessageResource bundle defined by the key 'strutsSql'. This is equivilent to 
	 * calling <code>getResources(request, "strutsSql")</code>
	 * @param request
	 * @return
	 */
	public MessageResources getSqlStatements(HttpServletRequest request){
		MessageResources statements = getResources(request, "strutsSql");
		return statements;
	}
	
	
	
	/**
	 * Returns the environment name. Equivilent to getIC2Settings(request).getMessage("environment");
	 * @param request
	 * @return the Environment name or 'Unknown' if no environment key is found.
	 * @see getIC2Settings(HttpServletRequest)
	 */
	public String getEnvironment(HttpServletRequest request){
		String environment = getIC2Settings(request).getMessage("environment");
		if (environment==null)environment = "Unknown";
		return environment;
	}
	
	/**
	 * Returns the version name. Equivilent to getIC2Settings(request).getMessage("version");
	 * @param request
	 * @return the Version name or 'Unknown' if no version key is found.
	 * @see getIC2Settings(HttpServletRequest)
	 */
	public String getVersion(HttpServletRequest request){
		String version = getIC2Settings(request).getMessage("version");
		if (version==null)version = "Unknown";
		return version;
	}
	
	
	/**
	 * Returns the MessageResources bundle defined by the key "ic2settings", 
	 * equivilent to getResources(request, "ic2settings");
	 * @param request
	 * @return
	 */
	protected MessageResources getIC2Settings(HttpServletRequest request){
		MessageResources settings = getResources(request, "ic2settings");
		return settings;
	}
	
	/**
	 * Returns the MessageResources bundle defined by the key "ic2uiConstants", 
	 * equivilent to getResources(request, "ic2uiConstants");
	 * @param request
	 * @return
	 */
	protected MessageResources getIC2Constants(HttpServletRequest request){
		MessageResources constants = getResources(request, "ic2uiConstants");
		return constants;
	}
	
	protected Object getContextObject(String name, HttpServletRequest request){
		return request.getSession().getServletContext().getAttribute(name);
	}
	
	
	/**
	 * Searches all scopes for an object <code>beanName</code>. Returns the first object it encounters.<br/>
	 * Scopes are searched in the order: request, session, servletcontext.
	 * @param beanName
	 * @param request
	 * @return the object, or null if no object was found
	 */
	protected Object findBean(String beanName, HttpServletRequest request){
		Object bean = request.getAttribute(beanName);
		if (bean==null) bean = request.getSession().getAttribute(beanName);
		if (bean==null) bean = request.getSession().getServletContext().getAttribute(beanName);
		return bean;
	}
	
	
	
	/**
	 * A wrapper for org.apache.commons.beanUtils.PropertyUtils.copyProperties(Object, Object), logging any errors that are thrown
	 * @param sourceBean
	 * @param targetBean
	 */
	protected void copyBeanProperties(Object sourceBean, Object targetBean){
		try {
			PropertyUtils.copyProperties(targetBean, sourceBean);
		} catch (IllegalAccessException e) {
			logger.debug("IllegalAccessException while copying form["+sourceBean+"] properties to bean["+targetBean+"]", e);
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			logger.debug("InvocationTargetException while copying form["+sourceBean+"] properties to bean["+targetBean+"]", e);
			throw new RuntimeException(e);
		} catch (NoSuchMethodException e) {
			logger.debug("NoSuchMethodException while copying form["+sourceBean+"] properties to bean["+targetBean+"]", e);
			throw new RuntimeException(e);
		}
		
	}
	
	/**
	 *  A wrapper for org.apache.commons.beanUtils.PropertyUtils.copyProperties(Object, Object), logging any errors that are thrown
	 * @param sourceForm
	 * @param targetBean
	 */
	protected void copyBeanProperties(ActionForm sourceForm, Object targetBean){
		try {
			PropertyUtils.copyProperties(targetBean, sourceForm);
		} catch (IllegalAccessException e) {
			logger.debug("IllegalAccessException while copying form["+sourceForm+"] properties to bean["+targetBean+"]", e);
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			logger.debug("InvocationTargetException while copying form["+sourceForm+"] properties to bean["+targetBean+"]", e);
			throw new RuntimeException(e);
		} catch (NoSuchMethodException e) {
			logger.debug("NoSuchMethodException while copying form["+sourceForm+"] properties to bean["+targetBean+"]", e);
			throw new RuntimeException(e);
		}
		
	}
	
	/**
	 *  A wrapper for org.apache.commons.beanUtils.PropertyUtils.copyProperties(Object, Object), logging any errors that are thrown
	 * @param sourceBean
	 * @param targetForm
	 */
	protected void copyBeanProperties(Object sourceBean, ActionForm targetForm){
		try {
				PropertyUtils.copyProperties(targetForm, sourceBean);
		}
		catch (NullPointerException e){
			logger.fatal("NullPointerException while copying bean["+sourceBean+"] properties to form["+targetForm+"]", e);
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			logger.fatal("IllegalAccessException while copying bean["+sourceBean+"] properties to form["+targetForm+"]", e);
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			logger.fatal("InvocationTargetException while copying bean["+sourceBean+"] properties to form["+targetForm+"]", e);
			throw new RuntimeException(e);
		} catch (NoSuchMethodException e) {
			logger.fatal("NoSuchMethodException while copying bean["+sourceBean+"] properties to form["+targetForm+"]", e);
			throw new RuntimeException(e);
		}
		
	}
	
	
	/**
	 * Returns the waitKeyMap from session scope
	 * @param request
	 * @return
	 */
	protected Map getWaitKeyMap (HttpServletRequest request){
		Map waitKeyMap =  (Map)request.getSession().getAttribute(SessionVarConstants.WAIT_KEY_MAP);
		return waitKeyMap;
	}	
	
	
	/**
	 * Creates a bpRunner object from the parameters, resolving the bpName from resource file 'bpMap'
	 * Adds the generated bpObject to the request under 'bpObject'.
	 * Adds the generated waitKey to the request under 'waitKey'.
	 * @param bpKey the key used to look up the business process name
	 * @param header The wizard header
	 * @param subHeader The wizard subheader
	 * @param msgName The wizard message
	 * @param doc document that will be submitted to the bpProcess
	 * @param mapping ActionMapping for the current (calling) Action class
	 * @param request the request.
	 * @return
	 */
	protected BPSubmitObject getBPObject(String bpKey, Document doc, ActionMapping mapping, HttpServletRequest request ){
		String bpName = getResources(request, "bpMap").getMessage(bpKey);
		BPSubmitObject bpObj = new BPSubmitObject(bpName, doc);
		bpObj.setSuccessForward(mapping.findForward("bpSuccess"));
		bpObj.setFailureForward(mapping.findForward("bpFailure"));
		
		getWaitKeyMap(request).put(bpObj.getWaitKey(), bpObj);
		
		request.setAttribute("bpObject", bpObj);
		request.setAttribute("waitKey", bpObj.getWaitKey());
		
		return bpObj;
		
	}

}
