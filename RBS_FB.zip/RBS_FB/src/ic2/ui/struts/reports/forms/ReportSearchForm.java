/**
 * 
 */
package ic2.ui.struts.reports.forms;


import ic2.ui.struts.forms.IC2UIForm;

import java.util.Calendar;

/**
 * @author Ravi K Patel
 * created May 3, 2006
 */
public class ReportSearchForm extends IC2UIForm {
	private static final long serialVersionUID = 1L;
	
	private String reportType;
	private String reportStartDate;
	private String reportEndDate;
	
	public ReportSearchForm() {
		reportStartDate=getYesterday();
		reportEndDate=getTomorrow();
	}
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getReportEndDate() {
		return reportEndDate;
	}
	public void setReportEndDate(String reportEndDate) {
		this.reportEndDate = reportEndDate;
	}
	public String getReportStartDate() {
		return reportStartDate;
	}
	public void setReportStartDate(String reportStartDate) {
		this.reportStartDate = reportStartDate;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
	
	private String getYesterday(){
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -7);
		StringBuffer yesterday = new StringBuffer();
		yesterday.append(cal.get(Calendar.DAY_OF_MONTH));
		yesterday.append("/");
		yesterday.append(cal.get(Calendar.MONTH)+1);
		yesterday.append("/");
		yesterday.append(cal.get(Calendar.YEAR));
		return yesterday.toString();
	}
	private String getTomorrow(){
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		StringBuffer tomorrow = new StringBuffer();
		tomorrow.append(cal.get(Calendar.DAY_OF_MONTH));
		tomorrow.append("/");
		tomorrow.append(cal.get(Calendar.MONTH)+1);
		tomorrow.append("/");
		tomorrow.append(cal.get(Calendar.YEAR));
		return tomorrow.toString();
	}
	
	
}
