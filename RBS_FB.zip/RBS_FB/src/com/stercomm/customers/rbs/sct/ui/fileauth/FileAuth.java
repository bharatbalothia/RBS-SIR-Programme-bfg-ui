package com.stercomm.customers.rbs.sct.ui.fileauth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import com.sterlingcommerce.woodstock.services.XLogger;
import com.sterlingcommerce.woodstock.util.frame.jdbc.Conn;

public class FileAuth extends FileAuthConstants {

	private int fileAuthID; //pkey for the record

	private String action; //auth operation - REPLAY,REDELIVER,REVIEW,UNREVIEW
	private int status; //status of change - REQUESTED(0), REJECTED(1), APPROVED(2), COMPLETED(5), EXPIRED(99), FAILED(-1)

	private String requestor;
	private String authoriser;
	private String actioner;
	private String requestorComments;
	private String authoriserComments;
	private Date dateRequested;
	private Date dateAuthorised;
	private Date dateActioned;

	private String fileKey;
	private Date dateExpired;
	
	private boolean loaded;


	private static XLogger log;

	public FileAuth() throws Exception{
		init(true, false);
	}
	public FileAuth(int faid) throws Exception{
		this.setFileAuthID(faid);
		init(false, true);
	}

	private void init(boolean isNew, boolean load) throws Exception{
		log = new XLogger("FileAuth", "FileAuth");
		loaded=false;
		if(isNew){
			this.setPrimaryKey();
			this.setStatus(FileAuth.STATUS_REQUESTED);
		} else {
			if(load){
				load();
			}
		}
	}

	public void load() throws Exception{

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "SELECT REQUESTOR, REQ_COMMENTS, REQ_DATE, AUTHORISER, AUTH_COMMENTS, AUTH_DATE, ACTION, STATUS, ACTIONER, ACTION_DATE, FILE_KEY, EXPIRY_DATE FROM FB_FILE_AUTH WHERE FILE_AUTH_ID=?";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setInt(1, this.getFileAuthID());

			rs= spstmt.executeQuery();
			boolean bOne=false;
			while(rs.next()){
				if(bOne==true){
					throw new Exception("Fatal FileAuth load() error. The primary key has been violated.");
				}
				this.setRequestor(rs.getString(1));
				this.setRequestorComments(rs.getString(2));
				this.setDateRequested(rs.getTimestamp(3));
				this.setAuthoriser(rs.getString(4));
				this.setAuthoriserComments(rs.getString(5));
				this.setDateAuthorised(rs.getTimestamp(6));
				this.setAction(rs.getString(7));
				this.setStatus(rs.getInt(8));
				this.setActioner(rs.getString(9));
				this.setDateActioned(rs.getTimestamp(10));
				this.setFileKey(rs.getString(11));
				this.setDateExpired(rs.getTimestamp(12));
				loaded=true;
				bOne=true;
			}

		} catch (SQLException sqle) {
			log.logException("SQL Error loading the FB_FILE_AUTH record", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error loading the FB_FILE_AUTH record", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

	}

	protected void updateStatus() throws Exception {

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "UPDATE FB_FILE_AUTH SET STATUS=?, AUTH_COMMENTS=?, AUTH_DATE=?, AUTHORISER=?, ACTIONER=?, ACTION_DATE=?, LAST_MODIFIED=sysdate WHERE FILE_AUTH_ID=?";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setInt(1, this.getStatus());
			spstmt.setString(2, this.getAuthoriserComments());
			spstmt.setTimestamp(3, getTimestamp(this.getDateAuthorised()));
			spstmt.setString(4, this.getAuthoriser());
			spstmt.setString(5, this.getActioner());
			spstmt.setTimestamp(6, getTimestamp(this.getDateActioned()));
			spstmt.setInt(7, this.getFileAuthID());

			int i = spstmt.executeUpdate();
			if(i<1){
				log.logError("No FileAuth records updated for "+ this.getFileAuthID());
			}

		} catch (SQLException sqle) {
			log.logException("SQL Error updating the FB_FILE_AUTH status", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error updating the FB_FILE_AUTH status", e);
			throw e;
		} finally {
			try {
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

	}

	public void insert() throws Exception {

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "INSERT INTO FB_FILE_AUTH ( FILE_AUTH_ID, REQUESTOR, REQ_COMMENTS, REQ_DATE, ACTION, STATUS, FILE_KEY, EXPIRY_DATE, CREATED, LAST_MODIFIED) VALUES (?,?,?,?,?,?,?,?,sysdate,sysdate)";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setInt(1, this.getFileAuthID());
			spstmt.setString(2, this.getRequestor());
			spstmt.setString(3, this.getRequestorComments());
			spstmt.setTimestamp(4, getTimestamp(this.getDateRequested()));
			spstmt.setString(5, this.getAction());
			spstmt.setInt(6, this.getStatus());
			spstmt.setString(7, this.getFileKey());
			spstmt.setTimestamp(8, getTimestamp(this.getDateExpired()));


			@SuppressWarnings("unused")
			int i = spstmt.executeUpdate();

		} catch (SQLException sqle) {
			log.logException("SQL Error persisting the FB_FILE_AUTH record", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error persisting the FB_FILE_AUTH record", e);
			throw e;
		} finally {
			try {
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

	}
	
	public void failed() throws Exception{
		this.setStatus(FileAuth.STATUS_FAILED);
		this.updateStatus();
	}
	
	public void complete(String user) throws Exception{
		this.setActioner(user);
		this.setDateActioned(this.getTime());
		this.setStatus(FileAuth.STATUS_COMPLETED);
		this.updateStatus();
	}

	public void approve(String user, String comments) throws Exception{
		this.setAuthoriser(user);
		this.setAuthoriserComments(comments);
		this.setDateAuthorised(this.getTime());
		this.setStatus(FileAuth.STATUS_APPROVED);
		this.updateStatus();
	}
	
	public void reject(String user, String comments) throws Exception{
		this.setAuthoriser(user);
		this.setAuthoriserComments(comments);
		this.setDateAuthorised(this.getTime());
		this.setStatus(FileAuth.STATUS_REJECTED);
		this.updateStatus();
	}
	
	public void expire() throws Exception{
		this.setStatus(FileAuth.STATUS_EXPIRED);
		this.updateStatus();
	}


	public String getStatusText(){
		if(getStatus()==FileAuth.STATUS_REQUESTED){
			return FileAuth.STATUS_REQUESTED_TEXT;
		} else if(getStatus()==FileAuth.STATUS_REJECTED){
			return FileAuth.STATUS_REJECTED_TEXT;
		} else if(getStatus()==FileAuth.STATUS_APPROVED){
			return FileAuth.STATUS_APPROVED_TEXT;
		} else if(getStatus()==FileAuth.STATUS_COMPLETED){
			return FileAuth.STATUS_COMPLETED_TEXT;
		} else if(getStatus()==FileAuth.STATUS_EXPIRED){
			return FileAuth.STATUS_EXPIRED_TEXT;
		} else if(getStatus()==FileAuth.STATUS_FAILED){
			return FileAuth.STATUS_FAILED_TEXT;
		} else {
			return FileAuth.STATUS_UNKNOWN_TEXT;
		}
	}
	
	public static String validateStatus(int status){
		if(status==FileAuth.STATUS_REQUESTED){
			return FileAuth.STATUS_REQUESTED_TEXT;
		} else if(status==FileAuth.STATUS_REJECTED){
			return FileAuth.STATUS_REJECTED_TEXT;
		} else if(status==FileAuth.STATUS_APPROVED){
			return FileAuth.STATUS_APPROVED_TEXT;
		} else if(status==FileAuth.STATUS_COMPLETED){
			return FileAuth.STATUS_COMPLETED_TEXT;
		} else if(status==FileAuth.STATUS_EXPIRED){
			return FileAuth.STATUS_EXPIRED_TEXT;
		} else if(status==FileAuth.STATUS_FAILED){
			return FileAuth.STATUS_FAILED_TEXT;
		} else {
			return FileAuth.STATUS_UNKNOWN_TEXT;
		}
	}
	
	public static int validateStatus(String status){
		if(status.equalsIgnoreCase(FileAuth.STATUS_REQUESTED_TEXT)){
			return FileAuth.STATUS_REQUESTED;
		} else if(status.equalsIgnoreCase(FileAuth.STATUS_APPROVED_TEXT)){
			return FileAuth.STATUS_APPROVED;
		} else if(status.equalsIgnoreCase(FileAuth.STATUS_REJECTED_TEXT)){
			return FileAuth.STATUS_REJECTED;
		} else if(status.equalsIgnoreCase(FileAuth.STATUS_COMPLETED_TEXT)){
			return FileAuth.STATUS_COMPLETED;
		} else if(status.equalsIgnoreCase(FileAuth.STATUS_EXPIRED_TEXT)){
			return FileAuth.STATUS_EXPIRED;
		} else if(status.equalsIgnoreCase(FileAuth.STATUS_FAILED_TEXT)){
			return FileAuth.STATUS_FAILED;
		} else {
			return FileAuth.STATUS_UNKNOWN;
		}
	}

	public boolean isRequested(){
		return this.getStatus()==FileAuth.STATUS_REQUESTED;
	}
	public int getFileAuthID() {
		return fileAuthID;
	}
	protected void setFileAuthID(int fileAuthID) {
		this.fileAuthID = fileAuthID;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getRequestor() {
		return requestor;
	}
	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}
	public String getAuthoriser() {
		return authoriser;
	}
	public void setAuthoriser(String authoriser) {
		this.authoriser = authoriser;
	}
	public String getActioner() {
		return actioner;
	}
	public void setActioner(String actioner) {
		this.actioner = actioner;
	}
	public String getRequestorComments() {
		return requestorComments;
	}
	public void setRequestorComments(String requestorComments) {
		this.requestorComments = requestorComments;
	}
	public String getAuthoriserComments() {
		return authoriserComments;
	}
	public void setAuthoriserComments(String authoriserComments) {
		this.authoriserComments = authoriserComments;
	}
	public Date getDateRequested() {
		return dateRequested;
	}
	public void setDateRequested(Date dateRequested) {
		this.dateRequested = dateRequested;
	}
	public Date getDateAuthorised() {
		return dateAuthorised;
	}
	public void setDateAuthorised(Date dateAuthorised) {
		this.dateAuthorised = dateAuthorised;
	}
	public Date getDateActioned() {
		return dateActioned;
	}
	public void setDateActioned(Date dateActioned) {
		this.dateActioned = dateActioned;
	}
	public String getFileKey() {
		return fileKey;
	}
	public void setFileKey(String fileKey) {
		this.fileKey = fileKey;
	}

	public Date getDateExpired() {
		return dateExpired;
	}
	public void setDateExpired(Date dateExpired) {
		this.dateExpired = dateExpired;
	}

	public static String validateAction(String action) throws Exception{
		if(action==null){
			throw new Exception("Invalid FileAuth Action value: " + action);
		}
		if(action.equalsIgnoreCase(FileAuth.ACTION_REPLAY)){
			return FileAuth.ACTION_REPLAY;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_REDELIVER)){
			return FileAuth.ACTION_REDELIVER;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_REVIEW)){
			return FileAuth.ACTION_REVIEW;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_UNREVIEW)){
			return FileAuth.ACTION_UNREVIEW;
		} else {
			throw new Exception("Invalid FileAuth Action value: " + action);
		}


	}

	public static String getActionPermission(String action) throws Exception{
		if(action==null){
			throw new Exception("Invalid FileAuth Action value: " + action);
		}
		if(action.equalsIgnoreCase(FileAuth.ACTION_REPLAY)){
			return FileAuth.ACTION_REPLAY_PERM;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_REDELIVER)){
			return FileAuth.ACTION_REDELIVER_PERM;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_REVIEW)){
			return FileAuth.ACTION_REVIEW_PERM;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_UNREVIEW)){
			return FileAuth.ACTION_UNREVIEW_PERM;
		} else {
			throw new Exception("Invalid FileAuth Action value: " + action);
		}
	}

	public static String getApprovePermission(String action) throws Exception{
		if(action==null){
			throw new Exception("Invalid FileAuth Action value: " + action);
		}
		if(action.equalsIgnoreCase(FileAuth.ACTION_REPLAY)){
			return FileAuth.APPROVE_REPLAY_PERM;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_REDELIVER)){
			return FileAuth.APPROVE_REDELIVER_PERM;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_REVIEW)){
			return FileAuth.APPROVE_REVIEW_PERM;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_UNREVIEW)){
			return FileAuth.APPROVE_UNREVIEW_PERM;
		} else {
			throw new Exception("Invalid FileAuth Action value: " + action);
		}		
	}

	public static String getRequestPermission(String action) throws Exception{
		if(action==null){
			throw new Exception("Invalid FileAuth Action value: " + action);
		}
		if(action.equalsIgnoreCase(FileAuth.ACTION_REPLAY)){
			return FileAuth.REQUEST_REPLAY_PERM;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_REDELIVER)){
			return FileAuth.REQUEST_REDELIVER_PERM;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_REVIEW)){
			return FileAuth.REQUEST_REVIEW_PERM;
		} else if(action.equalsIgnoreCase(FileAuth.ACTION_UNREVIEW)){
			return FileAuth.REQUEST_UNREVIEW_PERM;
		} else {
			throw new Exception("Invalid FileAuth Action value: " + action);
		}		
	}

	private void setPrimaryKey() throws Exception{
		//SELECT FB_FILE_AUTH_ID_SEQ.NEXTVAL FROM DUAL
		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "SELECT FB_FILE_AUTH_ID_SEQ.NEXTVAL FROM DUAL";
			spstmt = conn.prepareStatement(ssqlStr);

			rs= spstmt.executeQuery();
			boolean bOne=false;
			while(rs.next()){
				if(bOne==true){
					throw new Exception("Fatal FileAuth setPrimaryKey() error.");
				}
				this.setFileAuthID(rs.getInt(1));
				bOne=true;
			}

		} catch (SQLException sqle) {
			log.logException("SQL Error generating the FB_FILE_AUTH primay key", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error generating the FB_FILE_AUTH primay key", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}


	}

	private Timestamp getTimestamp(Date dte){

		if(dte==null){
			return null;
		} else {
			return new java.sql.Timestamp(dte.getTime());
		}

	}
	
	private Date getTime(){
		Calendar cal = Calendar.getInstance();
		return new Date(cal.getTime().getTime());	
	}
	public boolean isLoaded() {
		return loaded;
	}

}
