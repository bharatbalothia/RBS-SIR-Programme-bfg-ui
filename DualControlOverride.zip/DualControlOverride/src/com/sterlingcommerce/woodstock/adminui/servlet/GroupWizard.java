/*
 * (C) Copyright 2001 - 2008 Sterling Commerce, Inc. ALL RIGHTS RESERVED
 *
 * ** Trade Secret Notice **
 *
 * This software, and the information and know-how it contains, is
 * proprietary and confidential and constitutes valuable trade secrets
 * of Sterling Commerce, Inc., its affiliated companies or its or
 * their licensors, and may not be used for any unauthorized purpose
 * or disclosed to others without the prior written permission of the
 * applicable Sterling Commerce entity. This software and the
 * information and know-how it contains have been provided
 * pursuant to a license agreement which contains prohibitions
 * against and/or restrictions on its copying, modification and use.
 * Duplication, in whole or in part, if and when permitted, shall
 * bear this notice and the Sterling Commerce, Inc. copyright
 * legend. As and when provided to any governmental entity,
 * government contractor or subcontractor subject to the FARs,
 * this software is provided with RESTRICTED RIGHTS under
 * Title 48 CFR 52.227-19.
 * Further, as and when provided to any governmental entity,
 * government contractor or subcontractor subject to DFARs,
 * this software is provided pursuant to the customary
 * Sterling Commerce license, as described in Title 48
 * CFR 227-7202 with respect to commercial software and commercial
 * software documentation.
 */
package com.sterlingcommerce.woodstock.adminui.servlet;

import com.sterlingcommerce.rbs.filebroker.dualcontrol.DualControlUtil;
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import java.io.IOException;
import java.io.IOException;

//java stuff
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import com.sterlingcommerce.woodstock.ui.security.*;
import com.sterlingcommerce.woodstock.dmi.visibility.event.DmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.ExceptionLevel;
import com.sterlingcommerce.woodstock.event.InvalidEventException;
import com.sterlingcommerce.woodstock.security.*;
import com.sterlingcommerce.woodstock.util.frame.log.Logger;
import com.sterlingcommerce.woodstock.ui.Wizard;
import com.sterlingcommerce.woodstock.ui.BaseUIGlobals;
import com.sterlingcommerce.woodstock.ui.jspbean.LangBean;
import com.sterlingcommerce.woodstock.util.Util;
import com.sterlingcommerce.woodstock.util.NameValuePairs;
import com.sterlingcommerce.woodstock.util.NameValue;
import com.sterlingcommerce.woodstock.ui.SessionInfo;
import com.sterlingcommerce.woodstock.ui.servlet.WizardBase;

import com.sterlingcommerce.woodstock.util.frame.cache.CacheManager;

/**
 * The RoleWizard class extends the ServletBase class.
 * Contains all the business logic related to handling the Role
 * related tasks.
 *
 * @version 1.0
 * @since Woodstock2.0
 */
@SuppressWarnings({ "unused", "serial" })
public class GroupWizard extends WizardBase{
    /**
     * Returns a String describing what the Servlet does.
     * @return String
     */
    public String getServletInfo () {
        return  "GroupWizard";
    }

    /**
     * Method for handling all the HttpRequests
     *
     * @param req
     * @param res
     * @exception javax.servlet.ServletException
     */

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
        HttpSession session = req.getSession(false);
        SessionInfo userinfo = null;

        if(session != null){
            userinfo = (SessionInfo)session.getAttribute("SessionInfo");
        }
try { req.setCharacterEncoding("UTF8"); } catch (Exception e) {  Util.noop();  /* try/catch to resolve jetty not wanting to reopen the stream */}
        if(!verifySession(session, userinfo, req, res)){
            return;
        }

        boolean debug=false;

        if(BaseUIGlobals.out.debug){
            BaseUIGlobals.out.logDebug(" [GroupWizard] START");
	    debug=true;
        }

        Wizard wiz = initWizard(req, session);
	int action = wiz.getActivity(req);

	Group grp = (Group)wiz.editObj();

	synchronized (wiz.editObj()) {
	    switch (action) {
	    default: // the edit
		        if(!updateGroup(wiz, req, grp)){
					  action = -1;
				}
		        break;
	    case -1: // Ignore
		     break;
	    case Wizard.COMMITPAGE:
		     break;
	    case Wizard.FINISHPAGE:
	    	
	    	/*
	    	 * DUAL CONTROL START
	    	 */
//		     if( grp.getGroupid().equals("super") && !grp.getTmpPerms().contains("ACCOUNTS") && !grp.getTmpPermsAdd().contains("ACCOUNTS"))
//			    grp.tmpAddAddPerm("ACCOUNTS");
//
//		     if (wiz.commitObj() == null){
//				if(debug) BaseUIGlobals.out.logDebug("CURRENT WIZARD STATS "  + wiz.toString());
//				wiz.setCommitObj(new SaveGroup(wiz));
//		     }
//		    break;
	    	
	    	boolean doFinish = false;
			String dcUser = req.getParameter("DUAL_CONTROL_USER");
			String dcPass = req.getParameter("DUAL_CONTROL_PASSWORD");
			String dcCurrentUser = (String)session.getAttribute("username");
			String dcCurrentUserPass = req.getParameter("DUAL_CONTROL_C_PASSWORD");
			BaseUIGlobals.out.logDebug("Entering Dual Control.");
			DualControlUtil dcu = new DualControlUtil();
			doFinish = dcu.isDualControlAuthorized("DUAL_CONTROL_GROUP_APPROVER", dcUser, dcPass, dcCurrentUser, dcCurrentUserPass, session);
			if(doFinish)
			{
				try
				{
					DmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, Util.createGUID(), System.currentTimeMillis(), dcCurrentUser, "GROUP_APPROVAL", "Group", grp.getGroupName(), dcUser);
				}
				catch(InvalidEventException e)
				{
					BaseUIGlobals.out.logError("Groups Dual Control Admin Audit Event Error" + e);
				}
				//ORIGINAL CODE - START
				if( grp.getGroupid().equals("super") && !grp.getTmpPerms().contains("ACCOUNTS") && !grp.getTmpPermsAdd().contains("ACCOUNTS"))
					grp.tmpAddAddPerm("ACCOUNTS");

				if (wiz.commitObj() == null){
					if(debug) BaseUIGlobals.out.logDebug("CURRENT WIZARD STATS "  + wiz.toString());
					wiz.setCommitObj(new SaveGroup(wiz));
				}
				//				ORIGINAL CODE - END
			} else
			{
				action = 10;
				session.setAttribute("DUAL_CONTROL_MESSAGE", dcu.getMessage(true));
				if(dcu.isChangerLocked())
				{
					session.setAttribute("AccountLocked", "AccountLocked");
					req.setAttribute("badpage", "page.authofailure");
					gotoPage("page.badframe", req, res);
					session.invalidate();
				}
			}

			break;
			
			/*
			 * DUAL CONTROL END
			 */
	    case Wizard.CANCELPAGE:
		     /* reload the bugger */
//		     BaseUIGlobals.securityMgr.reloadGroup( grp.getGroupid() );
                    // changed the reloadGroup to removeGroupFromCache.  If you cancelled out of an 'edit',
                    // the group and permission list wasn't reverting back to the old values
                    BaseUIGlobals.securityMgr.removeGroupFromCache( grp.getGroupid() );
                    grp.doneLocking = true;
		    undoWizard( req );
   		    break;

	    }
	}

        setupNextPage(req, res, session, wiz, action);

        if(debug) BaseUIGlobals.out.logDebug(" [RoleWizard] END");
    }

    /**
     * Method for updating the role object
     *
     * @param req
     * @param res
     * @param theRole
     */
    @SuppressWarnings({ "unchecked", "static-access" })
	private boolean updateGroup(Wizard wiz, HttpServletRequest req, Group grp){

          HttpSession session = req.getSession(false); //added for fix #4105 session is needed to post error msg.
          //added for DMI admin audit event
          SessionInfo sessionInfo = (SessionInfo)session.getAttribute("SessionInfo");
          grp.setPrincipal(sessionInfo.getUserName());

          String s = req.getParameter("GROUP_groupid");
	  if (s!=null && s.length() >0) {
	      grp.setGroupid( s );
	  }

          boolean dupeUser = true;
          boolean dupeGroupId = true;
          boolean dupeGroupName = true;
          if (wiz.action == wiz.ADD) {
              //check for an existing groupid, or a user with the same user_id.
              if (s != null && s.length() > 0) {
                  User u = (User)CacheManager.get("UserCache", s); // checks for existing user.
                  if (u == null) {
                    dupeUser = false;
                  } else {
                    if (u.getStatus() == 0)
                        dupeUser = false; // the group will be valid if a user exists, but is disabled.
                  }

                  dupeGroupId = Group.doesGroupIdExist(s); // checks for duplicate groupid
                  if (!dupeGroupId) {
                        dupeGroupId = false;
                  } else {
                        Group g = (Group)CacheManager.get("GroupCache", s);
                        if (!g.isEnabled()) {
                            Group.remove(s);
                            dupeGroupId = false;
                            grp.setNewGroup(true);
                            //grp.setNewGroup(false);
                            //grp.enable();
                        }
                  }

                  if(dupeUser || dupeGroupId){ //if we have the duplicate
                      LangBean lang = (LangBean)session.getAttribute("langbean");
                      req.setAttribute("msg", lang.getValue("images.errorbutton") + Util.replaceString(lang.getValue("DuplicateAuthoAndGroupGrp"),"&NAME;", s));
                      return false;
                  }
              }
          }

	  s = req.getParameter("GROUP_groupname");
	  if (s!=null && s.length() >0) {
	      grp.setGroupName( s );
	  }

          //check for an existing groupname.
          if (wiz.action == wiz.ADD) {
              if (s != null && s.length() > 0) {
                  dupeGroupName = Group.checkExistence(s); // checks for duplicate groupname
                  if (!dupeGroupName) {
                    dupeGroupName = false;
                  } else {
                        String gid = Group.getGroupIdFromName(s);
                        Group g = (Group)CacheManager.get("GroupCache", gid);
                        if (!g.isEnabled()) {
                            Group.remove(gid); // (SR1354450) removes disabled group to avoid unique constraint violation
                            grp.setNewGroup(true); //TD#17575. Group save() - the SQL was doing an update and the record doesn't exists since we just removed it.  Setting the flag cause the SQL to do an insert.
//                            g.updateGroupNameToGuid(); //changes group name of disabled group so unique constraint isnt violated.
//                            g.save();
                            dupeGroupName = false;
                        }
                  }

                  if(dupeGroupName){ //if we have the duplicate
                      LangBean lang = (LangBean)session.getAttribute("langbean");
                      req.setAttribute("msg", lang.getValue("images.errorbutton") + Util.replaceString(lang.getValue("DuplicateGroupName"),"&NAME;", s));
                      return false;
                  }
              }
          }
          else if (wiz.action == wiz.EDIT) {
              if (s != null && s.length() > 0) {
            	  boolean groupNameExist = Group.checkExistence(s); // checks for duplicate groupname
                  if (!groupNameExist) {
                    dupeGroupName = false;
                  } else {
                	  //The group name exists.  Check if the name is the same as the Group Id's Name, or if it is a duplicate.
                        String gid = Group.getGroupIdFromName(s);
                        if(gid.equalsIgnoreCase(grp.getGroupid())){
                            dupeGroupName = false;
                        }
                  }

                  if(dupeGroupName){ //if we have the duplicate
                      LangBean lang = (LangBean)session.getAttribute("langbean");
                      req.setAttribute("msg", lang.getValue("images.errorbutton") + Util.replaceString(lang.getValue("DuplicateGroupName"),"&NAME;", s));
                      return false;
                  }
              }
          }
	  s = req.getParameter("GROUP_groupowner");
	  if (s!=null && s.length() >0) {
	      grp.setGroupOwnerid( s );
	  }

	  s = req.getParameter("GROUP_entityid");
	  if (s!=null && s.length() >0 && !s.equals(" ")) {
	      grp.setEntityid( s );
	  }

	  if(wiz.getStep().pageType.equals("SUBGROUPS")){
		  boolean returnBool = true;
		  if( wiz.getActivity(req) == Wizard.SEARCHPAGE ) {
			String name = req.getParameter( "groupname" );
                if ( name != null && name.trim().length() > 0){
				    grp.setSubGroupFilter(name);
                }else grp.setSubGroupFilter("");
				returnBool = false;
          }
		  if( wiz.getActivity(req) != Wizard.BACKPAGE ) {
            String[] subGroupIds = req.getParameterValues("assignlist");
            grp.removeTmpPerm();
            //grp.setAvailablePermissions(null);
            grp.setPositionValue(0);
            grp.removeTmpGroup();
            grp.removeTmpSubGroup();
            grp.initTmpGroups();
            String subGroupId ;
            if( subGroupIds != null && subGroupIds.length > 0 ){
                HashSet permSet = new HashSet(); // Faster contains than on vector
                for( int i =0; i< subGroupIds.length ; i++){
                        subGroupId = subGroupIds[i];
                     if ( !grp.hasSubGroup(subGroupId) ) { // queries to see if subgroup creates circular reference.
                        grp.tmpAddGroup( subGroupId );
                        grp.refreshGroupsForGroupWizard( subGroupId );
                        String grpPerms[] = BaseUIGlobals.securityMgr.listPermissionsForGroup( subGroupId);
                        if (grpPerms != null && grpPerms.length > 0) {
                            for (int j=0; j<grpPerms.length; j++) {
                                if ( ! permSet.contains(grpPerms[j]) ) {
                                    permSet.add(grpPerms[j]);
                                    grp.getTmpPerms().add(grpPerms[j]);
                                }
                            }
                        }
                    } else if ( wiz.getActivity(req) == Wizard.NEXTPAGE ) {
                        LangBean lang = (LangBean)session.getAttribute("langbean");
                        req.setAttribute("msg", lang.getValue("images.errorbutton") + Util.replaceString(lang.getValue("CircularReferenceGroup"),"&NAME;", subGroupId));
                        returnBool = false;
                    }

                }
            }
            Vector vGrp = grp.getTmpGroups();
            Vector vSubGrp = grp.getTmpSubGroups();
            grp.removeTmpSubPermWithRights(); // this removes old values so newly posted values don't create dupes
            Group g = null;
            if (vGrp!=null) {
                NameValuePairs nvp = null;
                for(int a=0;a<vGrp.size();a++) {
                    g = BaseUIGlobals.securityMgr.getGroup( (String)vGrp.elementAt(a) );
                    nvp = g.getPermIDsWithRightsForGroup();
                    if (nvp!=null) {
                        NameValue nv = null;
                        Collection cl = new ArrayList();
                        for(int c=0;c<nvp.numEntries();c++) {
                            nv = nvp.getElement(c);
                            if ( grp.getTmpSubPermsWithRights().get(nv.name) == null ) {
                                cl.add(nv);
                            }
                        }
                        grp.getTmpSubPermsWithRights().addAll(cl);
                    }
                }
            }
            if (vGrp!=null) {
                NameValuePairs nvp = null;
                for(int b=0;b<vSubGrp.size();b++) {
                    g = BaseUIGlobals.securityMgr.getGroup( (String)vSubGrp.elementAt(b) );
                    nvp = g.getPermIDsWithRightsForGroup();
                    if (nvp!=null) {
                        NameValue nv = null;
                        Collection cl = new ArrayList();
                        for(int d=0;d<nvp.numEntries();d++) {
                            nv = nvp.getElement(d);
                            if ( grp.getTmpSubPermsWithRights().get(nv.name) == null ) {
                                cl.add(nv);
                            }
                        }
                        grp.getTmpSubPermsWithRights().addAll(cl);
                    }
                }
            }
          }
		  return returnBool ;
	  }else if(wiz.getStep().pageType.equals("PERMS")){
		    boolean returnBool = true;

		    String singleArrowRight = null;
		    
		    if(req.getParameter("left_transfer") != null &&
		    		req.getParameter("left_transfer").equals("true"))  
		    {
				String value;
				StringTokenizer selectvalues;
				List selectPermissions = null;
				
				grp.setlefttransfer(true); 
		 		value = req.getParameter("select_side");
				selectvalues = new StringTokenizer(value,",");
				selectPermissions = new ArrayList();

		    	int counter = 0;
		    	while (selectvalues.hasMoreTokens()) 
		    	{
		    		String token = selectvalues.nextToken();
		    		selectPermissions.add(counter, token);
		            ++counter;
		        }
		    	grp.deleteSelectedPermissionsString( selectPermissions );  
				
		    	returnBool = false;
		    }
		    else
		    {
		    	grp.setlefttransfer(false); 
		    }

		    if(req.getParameter("direct_select2avail_transfer") != null &&
		    		req.getParameter("direct_select2avail_transfer").equals("true"))
		    
		    {
				grp.setdirect_select2avail_transfer(true); 
				
		    	List convertedPermissions = new ArrayList();
		     	List selectedPerms = grp.getSelectedPermissions();
		    	int entryNumber = 0; 
		    	int limit = 0;
		      	
		    	if ((grp.getSelectBoxNumberValue() + grp.getSelectBoxPositionValue()) > selectedPerms.size())
		    	{
		    		limit = selectedPerms.size();
		    	}
		    	else
		    	{
		    		limit = grp.getSelectBoxNumberValue() + grp.getSelectBoxPositionValue();
		    	}                       	
		    	

		        for(int j = grp.getSelectBoxPositionValue(); j < limit ; j++) 
		        {
		        	NameValue name_value = (NameValue)selectedPerms.get(j);
		            convertedPermissions.add(entryNumber, name_value);
		            ++entryNumber;
		        }
		        grp.deleteSelectedPermissionsNV( convertedPermissions );                   		

		        returnBool = false;
		    }
		    else
		    {
		    	grp.setdirect_select2avail_transfer(false);  
		    }
		    
		    if(req.getParameter("direct_avail2select_transfer") != null &&
		    		req.getParameter("direct_avail2select_transfer").equals("true"))
		    {
		    	grp.setdirect_avail2select_transfer(true); 
		    	List convertedPermissions = new ArrayList();
		    	int entryNumber = -1;
		    	
//		    	NameValuePairs permissions = theRemoteAutho.getFilteredPermissions();
		    	NameValuePairs permissions = grp.getAvailablePermissionsAsNVP();
		    	  	
		    	int limit = 0;
		    	          	
		    	if ((grp.getNumberValue() + grp.getPositionValue())> permissions.size())
		    	{
		    		limit = permissions.size();
		    	}
		    	else
		    	{
		    		limit = grp.getNumberValue() + grp.getPositionValue();
		    	}
		        for(int j = grp.getPositionValue(); j < limit ; j++) 
		        {
		        	NameValue name = (NameValue)permissions.getElement(j);
		        	convertedPermissions.add(++entryNumber, name.name);
		        }
		        grp.setNewSelectedPermissionsID(convertedPermissions);
		    
		        returnBool = false;
		   	}
		    else
		    {
		    	grp.setdirect_avail2select_transfer(false);  
		    }
		    String window = req.getParameter("window");
		    if(window != null && ! "".equals(window))
		    {
		    	
		    	if(window.equals("available"))
		    	{
		    		
		    		grp.setWindowType("available");
		    		grp.setPositionValue(Integer.parseInt(req.getParameter("pos")));  
		    		grp.setNumberValue(Integer.parseInt(req.getParameter("num")));     
		    		
		    	}
		    	else if(window.equals("select"))
		    	{
		    		
		    		grp.setWindowType("select");
		    		grp.setSelectBoxPositionValue(Integer.parseInt(req.getParameter("pos")));  
		    		grp.setSelectBoxNumberValue(Integer.parseInt(req.getParameter("num")));     
		    		
		    	}
		    	
		    	returnBool = false;
		    }
		  
		    if((singleArrowRight = req.getParameter("right_transfer"))!= null &&
		    		singleArrowRight.equals("true"))
		    {
		    	grp.setRightTransfer(true);  
		   	}
		    else
		    {
		    	grp.setRightTransfer(false);  
		    }

		    String rightavailside = null;
		    List rightavailPermissions = null;
		    StringTokenizer rightavail;
		    int counter = 0;

		    if(grp.getRightTransfer()== true)
		    {
		    	rightavailside = req.getParameter("avail_side");
		    	rightavail = new StringTokenizer(rightavailside,",");
		    	rightavailPermissions = new ArrayList();

		    	counter = 0;
		    	while (rightavail.hasMoreTokens()) 
		    	{
		    		String token = rightavail.nextToken();
		    		rightavailPermissions.add(counter,token);
		            ++counter;
		        }
		    	grp.setNewSelectedPermissionsID(rightavailPermissions);
		        returnBool = false;
		   	
		    }

//		    stringParam = request.getParameter("mboxMsgPattern");
//		    theRemoteAutho.setMessagePattern(stringParam);

		    
		    
//		 executes the search page and resets the filters    
		    if( wiz.getActivity(req) == Wizard.SEARCHPAGE && returnBool) 
		    {
		        returnBool = false;
		        grp.setWindowType("available");
		   		grp.setPositionValue(0); 
		        String name = req.getParameter( "permname" );
		        if ( name != null && name.trim().length() > 0) 
		        {
		        	grp.setPermNameFilter(name);
		        } 
		        else 
		        	grp.setPermNameFilter("");
		        String type = req.getParameter( "permtype" );
		        if ( type != null && type.trim().length() > 0) 
		        {
		        	grp.setPermTypeFilter(type);
		        }
		        else 
		        {
		        	grp.setPermTypeFilter("");
		        }
		        grp.setAvailablePermissions(null);
		    }
//		 this section executes the next button and actually saves all of the selected permissions to the user.
		    else if( wiz.getActivity(req) != Wizard.BACKPAGE && returnBool)
		    {
//		        String[] permNames = request.getParameterValues("assignlist");
		        ArrayList permNames = (ArrayList) grp.getSelectedPermissions();
		        grp.removeTmpPermAdd();
		        NameValue permName ;

		        NameValuePairs nvp2 = new NameValuePairs();
		        if( permNames != null && permNames.size() > 0 ) 
		        {
		            Permission p = null;
		            NameValuePairs nvp = grp.getTmpPermsAddWithRights();
		            NameValue nv = null;
		            Iterator mboxIter = permNames.iterator();
		            while (mboxIter.hasNext()) 
		            {
		            	permName = (NameValue)mboxIter.next();
		            	grp.tmpAddAddPerm( permName.name );
//		            	grp.tmpAddPerm( permName.name );
		                nv = nvp.get( permName.name );
		                if ( nv==null )// if  a new perm is added to the assigned list. It will be 
		                { 
		                	p = BaseUIGlobals.securityMgr.getPermission( permName.name );
		                    nvp2.addElement( permName.name, new Integer(p.getRight()) );
		                } 
		                else 
		                {
		                    nvp2.addElement( nv.name, nv.value );
		                }
		            }
		            grp.setTmpPermAddWithRightsFromWizard( nvp2 );
		         }
		        else if( (grp.getTmpGroups() == null || 
		        			grp.getTmpGroups().size() == 0) && 
		        			wiz.getActivity(req) != Wizard.BACKPAGE && 
		        			wiz.getActivity(req) != Wizard.SEARCHPAGE)
		        {
		            LangBean lang = (LangBean)session.getAttribute("langbean");
		            req.setAttribute("msg", lang.getValue("images.errorbutton") + lang.getValue("NoPermAssigned"));
		            returnBool = false;
		        }
		    }
		    return returnBool ;
		  
//		  boolean returnBool = true;
//
//		  if( wiz.getActivity(req) == Wizard.SEARCHPAGE ) {
//			returnBool = false;
//			String name = req.getParameter( "permname" );
//                if ( name != null && name.trim().length() > 0){
//				    grp.setPermNameFilter(name);
//                }else grp.setPermNameFilter("");
//			String type = req.getParameter( "permtype" );
//                if ( type != null && type.trim().length() > 0){
//				    grp.setPermTypeFilter(type);
//                }else grp.setPermTypeFilter("");
//
//          }
//		  if(wiz.getActivity(req) != Wizard.BACKPAGE){
//                        String[] permNames = req.getParameterValues("assignlist");
//			grp.removeTmpPermAdd();
//                        grp.initTmpAddPerms();
//			String permName ;
//			boolean bAccount = false;
//
//			if( permNames != null && permNames.length > 0 ){
//                            Permission p = null;
//                            NameValuePairs nvp = grp.getTmpPermsAddWithRights();
//                            NameValuePairs nvp2 = new NameValuePairs();
//                            Collection cl = new ArrayList();
//                            NameValue nv = null;
//                            for( int i=0; i< permNames.length ; i++){
//                                permName = permNames[i];
//                                if( permName != null && permName.trim().length() > 0 ) {
//                                    grp.tmpAddAddPerm( permName );
//                                    nv = nvp.get( permName );
//                                    if ( nv==null ) { // if  a new perm is added to the assigned list. It will be
//                                        p = BaseUIGlobals.securityMgr.getPermission( permName );
//                                        cl.add(new NameValue(permName, new Integer(p.getRight())));
//                                    } else {
//                                        cl.add(new NameValue(nv.name, nv.value));
//                                    }
//                                    if( permName.equals("ACCOUNTS")) bAccount = true;
//                                }
//                            }
//                            nvp2.addAll(cl);
//                            grp.setTmpPermAddWithRightsFromWizard( nvp2 );
//		        }
//			if ( grp.getGroupid().equals("super") && !bAccount && !grp.getTmpPerms().contains("ACCOUNTS")) { // if super group, ACCOUNTS ADMIN sub group should be selected or ACCOUNTS perm selected
//				    grp.tmpAddAddPerm("ACCOUNTS");
//                   LangBean lang = (LangBean)session.getAttribute("langbean");
//                   req.setAttribute("msg", lang.getValue("images.errorbutton") + Util.replaceString(lang.getValue("CannotRemoveAcctFromSuper"),"&NAME;", "UI Accounts" ));
//                   returnBool = false;
//            }
//
//          }
//		  return returnBool ;
        } else if(wiz.getStep().pageType.equals("RIGHTS")) {

            boolean returnBool = true;

            String name = req.getParameter( "PERM_NAME0" );
            if (name != null && name.trim().length() >1) {
                grp.removeTmpPermAddWithRights(); // this removes old values so newly posted values don't create dupes
                int cntr = 0;
                String r = "";
                String w = "";
                String x = "";
                String d = "";
                int rightValue = 0;
                while ( name!=null && name.trim().length() >1 ) {
                    x = req.getParameter( "PERMExecute"+cntr );
                    if (x.equals("1")) rightValue += 1;
                    w = req.getParameter( "PERMWrite"+cntr );
                    if (w.equals("1")) rightValue += 2;
                    r = req.getParameter( "PERMRead"+cntr );
                    if (r.equals("1")) rightValue += 4;
                    d = req.getParameter( "PERMDelete"+cntr );
                    if (d.equals("1")) rightValue += 8;
                    grp.tmpPermsAddWithRights( name, rightValue );
                    cntr++;
                    rightValue = 0;
                    name = req.getParameter( "PERM_NAME"+cntr );
                }
            }
            return returnBool ;
        }
      return true;
    }

}
