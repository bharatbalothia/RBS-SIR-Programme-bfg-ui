/**
 * 
 */
package ic2.ui.exception;

/**
 * @author Ravi K Patel
 * created Apr 20, 2006
 * 
 * IC2UIUnauthorizedAccessException is thrown when the user has requested a resource they do not have permission to access
 */
public class IC2UIUnauthorizedException extends IC2UIRuntimeException {
	private static final long serialVersionUID = 1L;

	public IC2UIUnauthorizedException() {
		super();
	}

	public IC2UIUnauthorizedException(String message, Throwable cause) {
		super(message, cause);
	}

	public IC2UIUnauthorizedException(String message) {
		super(message);
	}

	public IC2UIUnauthorizedException(Throwable cause) {
		super(cause);
	}

}
