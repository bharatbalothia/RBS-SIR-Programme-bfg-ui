/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui;
import java.util.Date;

import org.apache.log4j.Logger;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class MQTransferSearchCriteriaImpl implements MQTransferSearchCriteria {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(MQTransferSearchCriteriaImpl.class);
	
	private String correlationid;
	private String producer;
	private String consumer;
	private String filename;
	private String transferstate;
	private String alerted;
	private Integer dataflowid;
	private Date fromDate;
	private Date toDate;

	
	
	public String getCorrelationid() {
		return correlationid;
	}
	public void setCorrelationid(String correlationid) {
		this.correlationid = correlationid;
	}
	public String getProducer() {
		return producer;
	}
	public void setProducer(String producer) {
		this.producer = producer;
	}
	public String getConsumer() {
		return consumer;
	}
	public void setConsumer(String consumer) {
		this.consumer = consumer;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getTransferState() {
		return transferstate;
	}
	public void setTransferState(String transferstate) {
		this.transferstate = transferstate;
	}
	public String getAlerted() {
		return alerted;
	}
	public void setAlerted(String alerted) {
		this.alerted = alerted;
	}
	public Integer getDataflowid() {
		return dataflowid;
	}
	public void setDataflowid(Integer dataflowid) {
		this.dataflowid = dataflowid;
	}
	public Date getFromdate() {
		return fromDate;
	}
	public void setFromdate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getTodate() {
		return toDate;
	}
	public void setTodate(Date toDate) {
		this.toDate = toDate;
	}

	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}

	
}
