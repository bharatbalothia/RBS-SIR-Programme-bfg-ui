package com.stercomm.customers.rbs.sct.ui;

import java.util.Date;

public interface PaymentSearchCriteria extends SearchCriteria{

	/**
	 * @return the entityId
	 */
	public abstract Integer getEntityId();

	/**
	 * @param entityId the entityId to set
	 */
	public abstract void setEntityId(Integer entityId);

	/**
	 * @return the service
	 */
	public abstract String getService();

	/**
	 * @param service the service to set
	 */
	public abstract void setService(String service);

	/**
	 * @return the direction
	 */
	public abstract String getDirection();

	/**
	 * @param direction the direction to set
	 */
	public abstract void setDirection(String direction);

	/**
	 * @return the transactionStatus
	 */
	public abstract String getTransactionStatus();

	/**
	 * @param transactionStatus the transactionStatus to set
	 */
	public abstract void setTransactionStatus(String transactionStatus);

	/**
	 * @return the reference
	 */
	public abstract String getReference();

	/**
	 * @param reference the reference to set
	 */
	public abstract void setReference(String reference);

	/**
	 * @return the transactionId
	 */
	public abstract String getTransactionId();

	/**
	 * @param transactionId the transactionId to set
	 */
	public abstract void setTransactionId(String transactionId);

	//CHG_UI_IBM_RJ_001
	public abstract String getPaymentBIC();
	
	public abstract void setPaymentBIC(String paymentBIC);
	/**
	 * @return the type
	 */
	public abstract String getType();

	/**
	 * @param type the type to set
	 */
	public abstract void setType(String type);

	/**
	 * @return the settlementDateFrom
	 */
	public abstract Date getSettlementDateFrom();

	/**
	 * @param settlementDateFrom the settlementDateFrom to set
	 */
	public abstract void setSettlementDateFrom(Date settlementDateFrom);

	/**
	 * @return the settlementDateTo
	 */
	public abstract Date getSettlementDateTo();

	/**
	 * @param settlementDateTo the settlementDateTo to set
	 */
	public abstract void setSettlementDateTo(Date settlementDateTo);

	/**
	 * @return the minDiff
	 */
	public abstract String getMinDiff();

	/**
	 * @param minDiff the minDiff to set
	 */
	public abstract void setMinDiff(String minDiff);
	

	/**
	 * @return the docId
	 */
	public abstract String getDocId();

	/**
	 * @param type the type to set
	 */
	public abstract void setDocId(String docId);

}