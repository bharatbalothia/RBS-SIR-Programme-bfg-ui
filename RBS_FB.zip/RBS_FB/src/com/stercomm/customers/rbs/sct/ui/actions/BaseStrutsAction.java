/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import java.lang.reflect.InvocationTargetException;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.apache.struts.util.MessageResources;

import com.stercomm.customers.webapps.util.struts.actions.BaseAction;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class BaseStrutsAction extends BaseAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(BaseWizardAction.class);
	/**
	 *  A wrapper for org.apache.commons.beanUtils.PropertyUtils.copyProperties(Object, Object), logging any errors that are thrown
	 * @param sourceBean
	 * @param targetForm
	 */
	protected void copyBeanProperties(Object sourceBean, Object targetBean) throws Exception{
		try {
				PropertyUtils.copyProperties(targetBean, sourceBean);
		}
		catch (NullPointerException e){
			log.fatal("NullPointerException while copying bean["+sourceBean+"] properties to form["+targetBean+"]", e);
			throw new RuntimeException(e);
		} catch (IllegalAccessException e) {
			log.fatal("IllegalAccessException while copying bean["+sourceBean+"] properties to form["+targetBean+"]", e);
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			log.fatal("InvocationTargetException while copying bean["+sourceBean+"] properties to form["+targetBean+"]", e);
			throw new RuntimeException(e);
		} catch (NoSuchMethodException e) {
			log.fatal("NoSuchMethodException while copying bean["+sourceBean+"] properties to form["+targetBean+"]", e);
			throw new RuntimeException(e);
		}
		
	}
	
	
	/**
	 * Returns the MessageResources bundle defined by the key "bpNames", 
	 * equivilent to getResources(request, "bpNames");
	 * @param request
	 * @return
	 */
	protected MessageResources getBPNames(HttpServletRequest request){
		MessageResources bpNames = getResources(request, "bpNames");
		return bpNames;
	}
	
}
