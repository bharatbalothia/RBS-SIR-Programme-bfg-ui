function validate(){

	var textFields = new Array(12);
	
	//fields[n][0]=textAreaField; fields[n][1]=maxLength
	textFields[0] = [document.getElementById('routerAddressSender'), 8];
	//textFields[1] = [document.routerAddressDesination, 8];
	//textFields[2] = [document.mailboxSender, 50];
	//textFields[3] = [document.mailboxDestination, 50];
	//textFields[4] = [document.fileReferenceIncoming, 50];
	//textFields[5] = [document.fileReferenceOutgoing, 50];
	//textFields[6] = [document.userIdIncoming, 20];
	//textFields[7] = [document.userIdOutgoing, 20];
	//textFields[8] = [document.primaryFilenameIncoming, 100];
	//textFields[9] = [document.dataFilenameIncoming, 100];
	//textFields[10] = [document.primaryFilenameOutgoing, 100];
	//textFields[11] = [document.dataFilenameOutgoing, 100];
	
	for (var i in textFields){
		if (! validate_TextAreaLength(textFields[i][0], textFields[i][1], false)){
			return false;
		}
	}
	return true;
	//validate_TextAreaLength(, 8, false)
}