package com.stercomm.customers.rbs.sct.ui.dto;

import java.util.Date;

public interface WFInstS {

	/**
	 * @return the workflowId
	 */
	public abstract Long getWorkflowId();

	/**
	 * @param workflowId the workflowId to set
	 */
	public abstract void setWorkflowId(Long workflowId);

	/**
	 * @return the status
	 */
	public abstract Integer getStatus();

	/**
	 * @param status the status to set
	 */
	public abstract void setStatus(Integer status);

	/**
	 * @return the initialWFContext
	 */
	public abstract String getInitialWFContext();

	/**
	 * @param initialWFContext the initialWFContext to set
	 */
	public abstract void setInitialWFContext(String initialWFContext);

	/**
	 * @return the startTime
	 */
	public abstract Date getStartTime();

	/**
	 * @param startTime the startTime to set
	 */
	public abstract void setStartTime(Date startTime);

	/**
	 * @return the endTime
	 */
	public abstract Date getEndTime();

	/**
	 * @param endTime the endTime to set
	 */
	public abstract void setEndTime(Date endTime);

}