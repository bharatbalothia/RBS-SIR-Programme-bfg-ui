package com.stercomm.customers.rbs.sct.ui.dto;

import java.util.Date;

public interface Schedule extends BaseHibernateBean{

	/**
	 * @return the active
	 */
	public abstract Boolean getActive();

	/**
	 * @param active the active to set
	 */
	public abstract void setActive(Boolean active);

	/**
	 * @return the entity
	 */
	public abstract Entity getEntity();

	/**
	 * @param entity the entity to set
	 */
	public abstract void setEntity(Entity entity);

	/**
	 * @return the isWindow
	 */
	public abstract Boolean getIsWindow();

	/**
	 * @param isWindow the isWindow to set
	 */
	public abstract void setIsWindow(Boolean isWindow);

	/**
	 * @return the lastRun
	 */
	public abstract Date getLastRun();

	/**
	 * @param lastRun the lastRun to set
	 */
	public abstract void setLastRun(Date lastRun);

	/**
	 * @return the nextRun
	 */
	public abstract Date getNextRun();

	/**
	 * @param nextRun the nextRun to set
	 */
	public abstract void setNextRun(Date nextRun);

	/**
	 * @return the scheduleId
	 */
	public abstract Long getScheduleId();

	/**
	 * @param scheduleImpl the scheduleId to set
	 */
	public abstract void setScheduleId(Long scheduleId);

	/**
	 * @return the timestart
	 */
	public abstract Integer getTimestart();

	/**
	 * @param timestart the timestart to set
	 */
	public abstract void setTimestart(Integer timestart);

	/**
	 * @return the transThreshold
	 */
	public abstract Integer getTransThreshold();

	/**
	 * @param transThreshold the transThreshold to set
	 */
	public abstract void setTransThreshold(Integer transThreshold);

	/**
	 * @return the windowEnd
	 */
	public abstract Integer getWindowEnd();

	/**
	 * @param windowEnd the windowEnd to set
	 */
	public abstract void setWindowEnd(Integer windowEnd);

	/**
	 * @return the windowInterval
	 */
	public abstract Integer getWindowInterval();

	/**
	 * @param windowInterval the windowInterval to set
	 */
	public abstract void setWindowInterval(Integer windowInterval);
	
	/**
	 * @return the updated flag
	 */
	public abstract boolean isUpdated();

	/**
	 * @param updated the updated flag to set
	 */
	public abstract void setUpdated(boolean updated);

	/**
	 * @return the filetype
	 */
	
	public abstract String getFiletype();

	/**
	 * @param filetype the filetype to set
	 */
	public abstract void setFiletype(String filetype);	

}