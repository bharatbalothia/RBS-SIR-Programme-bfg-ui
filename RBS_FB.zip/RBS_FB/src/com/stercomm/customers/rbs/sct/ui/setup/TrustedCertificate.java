package com.stercomm.customers.rbs.sct.ui.setup;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.ResultMetaImpl;

@SuppressWarnings({"unused", "unchecked"})
public class TrustedCertificate implements Serializable {

	private String certificateId;
	private String certificateName;
	private String certificateThumbprint;
	
	public TrustedCertificate(){
		
	}
	
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(TrustedCertificate.class);
	
	public String getCertificateId() {
		return certificateId;
	}
	public void setCertificateId(String certificateId) {
		this.certificateId = certificateId;
	}
	public String getCertificateName() {
		return certificateName;
	}
	public void setCertificateName(String certificateName) {
		this.certificateName = certificateName;
	}
	public String getCertificateThumbprint() {
		return certificateThumbprint;
	}
	public void setCertificateThumbprint(String certificateThumbprint) {
		this.certificateThumbprint = certificateThumbprint;
	}
	
	public ResultMeta listByName(String name, int pageNo, int pageSize){
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();
		
		TrustedCertificate tc = new TrustedCertificate();
		tc.setCertificateId("X123");
		tc.setCertificateName("Test Certificate 123");
		tc.setCertificateThumbprint("AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA");
		List<TrustedCertificate> results = new ArrayList<TrustedCertificate>();
		results.add(tc);
		tc = new TrustedCertificate();
		tc.setCertificateId("X456");
		tc.setCertificateName("Test Certificate 1456");
		tc.setCertificateThumbprint("BB:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA:AA");
		results.add(tc);
		rm.setResultsList(results);
		rm.setTotalResults(results.size());

		return rm;
		
	}
	
	
	
}
