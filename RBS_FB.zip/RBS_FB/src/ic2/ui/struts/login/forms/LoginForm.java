/**
 * 
 */
package ic2.ui.struts.login.forms;

import org.apache.struts.action.ActionForm;

/**
 * @author Ravi K Patel
 * created Mar 29, 2006
 */
public class LoginForm extends ActionForm {
	private static final long serialVersionUID = 1L;
	
	
	private String username;
	private String password;
	private String targetURL;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTargetURL() {
		return targetURL;
	}
	public void setTargetURL(String targetURL) {
		this.targetURL = targetURL;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	
}
