/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;
import com.stercomm.customers.rbs.sct.ui.dao.EntityDAO;
import com.stercomm.customers.rbs.sct.ui.dao.StatusDAO;
import com.stercomm.customers.rbs.sct.ui.forms.TransactionSearchForm;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unused", "unchecked"})
public class TransactionSearchAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	//private static final Logger log = Logger.getLogger(TransactionSearchAction.class);

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		TransactionSearchForm tsf = (TransactionSearchForm)form;


		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		cal.roll(Calendar.MONTH, false);

		Date dateFrom = cal.getTime();


		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String lastMonth = sdf.format(dateFrom);

		tsf.setSettlementDateFrom(lastMonth);
		tsf.setSettlementDateTo("");


		Session session = getHibernateSession();
		EntityDAO entityDAO = new EntityDAO(session);
		Map formVars = new HashMap();

		List entities;
		boolean isSCT = tsf.getService().equalsIgnoreCase("SCT");

		if(isSCT){
			entities = entityDAO.getEntities(tsf.getService());
		}else {
			entities = entityDAO.getEntities();
		}


		formVars.put("entities", entities);
		request.setAttribute("formVars", formVars);

		//if the status has been set then change the direction
		if(isSCT){
			if(tsf!=null && tsf.getTransactionStatus()!=null && !tsf.getTransactionStatus().equalsIgnoreCase("ALL")){

				StatusDAO statusDAO = StatusDAO.getInstance();

				if(statusDAO.getFilteredTrxDirection(tsf.getTransactionStatus()).equalsIgnoreCase("INBOUND") && (tsf.getDirection().equalsIgnoreCase("OUTBOUND"))){
					tsf.setTransactionStatus("ALL");
				} else if(statusDAO.getFilteredTrxDirection(tsf.getTransactionStatus()).equalsIgnoreCase("OUTBOUND") && (tsf.getDirection().equalsIgnoreCase("INBOUND"))){
					tsf.setTransactionStatus("ALL");
				} else {
					tsf.setDirection(statusDAO.getFilteredTrxDirection(tsf.getTransactionStatus()));
				}

				//List transactionStatuses = new ArrayList(statusDAO.getFilteredStatus(tsf.getService(), tsf.getDirection()).values());
				List transactionStatuses = new ArrayList(statusDAO.getFilteredTrxStatus(tsf.getService(), tsf.getDirection()).values());
				// List transactionStatuses = new ArrayList(statusDAO.getAllTransactionStatuses().values());
				Collections.sort(transactionStatuses);

				request.setAttribute("transactionStatuses", transactionStatuses);

			} else {

				StatusDAO statusDAO = StatusDAO.getInstance();

				//List transactionStatuses = new ArrayList(statusDAO.getFilteredStatus(tsf.getService(), tsf.getDirection()).values());
				List transactionStatuses = new ArrayList(statusDAO.getFilteredTrxStatus(tsf.getService(), tsf.getDirection()).values());
				// List transactionStatuses = new ArrayList(statusDAO.getAllTransactionStatuses().values());
				Collections.sort(transactionStatuses);

				request.setAttribute("transactionStatuses", transactionStatuses);

			}
		}

		return super.viewForm(mapping, form, request, response);
	}

	public ActionForward viewResults(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("searchResults");
	}

}
