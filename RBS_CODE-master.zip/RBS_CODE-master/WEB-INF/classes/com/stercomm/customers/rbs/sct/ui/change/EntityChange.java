package com.stercomm.customers.rbs.sct.ui.change;


import java.util.LinkedList;



@SuppressWarnings({"unused", "unchecked"})
public class EntityChange extends ChangeControl {

	public final static String OBJECT_TYPE="com.stercomm.customers.rbs.sct.ui.change.EntityViewer";

	public EntityChange() throws Exception{
		super();
		this.setObjectType(OBJECT_TYPE);
	}

	public EntityChange(String cid) throws Exception{
		super(cid);
		this.setObjectType(OBJECT_TYPE);
	}

	public static boolean isNameUnique(String value) throws Exception{
		return isPendingMetaUnique(1, OBJECT_TYPE, value);
	}

	public static boolean isThumbprintUnique(String value) throws Exception{
		return isPendingMetaUnique(2, OBJECT_TYPE, value);
	}

	public static LinkedList listPendingByName(String name) throws Exception{
		return search("RESULT_META1", name, OBJECT_TYPE, ChangeControl.STATUS_PENDING);
	}
	public static LinkedList listPendingByService(String service) throws Exception{
		return search("RESULT_META2", service, OBJECT_TYPE, ChangeControl.STATUS_PENDING);
	}
}
