<script language="JavaScript" src="<c:url value='/scripts/ic2ui/struts.js'/>"></script>
function validate(){
	toUpperCase('userId');
	var userIdRegEx = /<bean:message key="userId" bundle="validationRules" />/;
	var passwdRegEx = /<bean:message key="userPassword" bundle="validationRules" />/;
	
	var userId = document.getElementById('userId');
	if (!userId.value.match(userIdRegEx))
	{
		window.alert('User ID is invalid.\n<bean:message key="userId.message" bundle="validationRules" />');
		return false;
	}

	var password1 = document.getElementById('password1');
	var password2 = document.getElementById('password2');
	
	
	if (!password1.value ==password2.value)  {
		window.alert("Password and Password Confirmation do not match");
		return false;
	}
	if (!password1.value.match(passwdRegEx))
	{
		window.alert('Password is invalid.\n<bean:message key="userPassword.message" bundle="validationRules" />');
		return false;
	}

	
	return true;
}