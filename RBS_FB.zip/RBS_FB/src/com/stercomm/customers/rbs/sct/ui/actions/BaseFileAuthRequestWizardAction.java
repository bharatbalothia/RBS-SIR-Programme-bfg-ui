/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   $Revision: $
 * Date/time:  $Date: $
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.stercomm.customers.rbs.sct.ui.dto.FileAuthRequest;
import com.stercomm.customers.rbs.sct.ui.fileauth.FGFile;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuth;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuthUser;
import com.stercomm.customers.rbs.sct.ui.forms.FileAuthRequestForm;
import com.stercomm.customers.rbs.sct.ui.forms.adapters.FileAuthRequestAdapter;


public abstract class BaseFileAuthRequestWizardAction extends BaseWizardAction{

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger
	.getLogger(BaseFileAuthRequestWizardAction.class);


	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		FileAuthRequest far = getFileAuthRequest(request);

		FileAuthRequestForm farf = (FileAuthRequestForm)form;
		FileAuthRequest fara = new FileAuthRequestAdapter(farf);
		copyBeanProperties(far, fara);

		return super.viewForm(mapping, form, request, response);
	}


	public ActionForward next(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		//System.out.println("****Base-next()****");
		saveForm2Bean(mapping, form, request, response);
		return super.next(mapping, form, request, response);
	}

	public ActionForward back(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return super.back(mapping, form, request, response);
	}

	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return super.save(mapping, form, request, response);
	}
	
	public ActionForward approve(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("approve");
	}
	
	public ActionForward reject(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("reject");
	}
	
	public ActionForward complete(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("complete");
	}

	public void saveForm2Bean(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		FileAuthRequest far = getFileAuthRequest(request);

		//temp save data that is not in the form
		boolean createBean = far.isCreateBean();
		boolean newBean = far.isNewBean();
		boolean updated = far.isUpdated();
		boolean deleteBean = far.isDeleteBean();
		FGFile fgFile = far.getFgFile();
		FileAuth fileAuth = far.getFileAuth();
		List<FileAuthUser> fileAuthUsers = far.getFileAuthUsers();

		//copy data from the form to the bean
		FileAuthRequestForm farf = (FileAuthRequestForm)form;
		FileAuthRequest fara = new FileAuthRequestAdapter(farf);

		copyBeanProperties(fara, far);

		//copy the temp data back to the bean
		far.setCreateBean(createBean);
		far.setNewBean(newBean);
		far.setUpdated(updated);
		far.setDeleteBean(deleteBean);
		far.setFgFile(fgFile);
		far.setFileAuth(fileAuth);
		far.setFileAuthUsers(fileAuthUsers);
	}


	protected FileAuthRequest getFileAuthRequest(HttpServletRequest request){
		FileAuthRequest far = (FileAuthRequest)request.getSession().getAttribute("fileAuthRequestBean");
		log.debug("got FileAuthRequest from Session: "+far);
		return far;
	}
}
