/*
 * (C) Copyright 2001 - 2010 Sterling Commerce, Inc. ALL RIGHTS RESERVED
 *
 * ** Trade Secret Notice **
 *
 * This software, and the information and know-how it contains, is
 * proprietary and confidential and constitutes valuable trade secrets
 * of Sterling Commerce, Inc., its affiliated companies or its or
 * their licensors, and may not be used for any unauthorized purpose
 * or disclosed to others without the prior written permission of the
 * applicable Sterling Commerce entity. This software and the
 * information and know-how it contains have been provided
 * pursuant to a license agreement which contains prohibitions
 * against and/or restrictions on its copying, modification and use.
 * Duplication, in whole or in part, if and when permitted, shall
 * bear this notice and the Sterling Commerce, Inc. copyright
 * legend. As and when provided to any governmental entity,
 * government contractor or subcontractor subject to the FARs,
 * this software is provided with RESTRICTED RIGHTS under
 * Title 48 CFR 52.227-19.
 * Further, as and when provided to any governmental entity,
 * government contractor or subcontractor subject to DFARs,
 * this software is provided pursuant to the customary
 * Sterling Commerce license, as described in Title 48
 * CFR 227-7202 with respect to commercial software and commercial
 * software documentation.
 */
package com.sterlingcommerce.woodstock.adminui.servlet;

import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import java.io.IOException;

import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.Collection;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.http.*;

import com.sterlingcommerce.woodstock.ui.UserAutho;
import com.sterlingcommerce.woodstock.ui.Wizard;
import com.sterlingcommerce.woodstock.ui.servlet.WizardBase;
import com.sterlingcommerce.woodstock.ui.Role;
import com.sterlingcommerce.woodstock.ui.BaseUIGlobals;
import com.sterlingcommerce.woodstock.ui.EntityAutho;
import com.sterlingcommerce.woodstock.ui.EntityObject;
import com.sterlingcommerce.woodstock.ui.jspbean.LangBean;
import com.sterlingcommerce.woodstock.ui.SessionInfo;
import com.sterlingcommerce.woodstock.adminui.ISecurityFieldValidator;

import com.sterlingcommerce.woodstock.security.AuthenticationProps;
import com.sterlingcommerce.woodstock.security.Group;
import com.sterlingcommerce.woodstock.security.User;
import com.sterlingcommerce.woodstock.security.Permission;
import com.sterlingcommerce.woodstock.util.frame.cache.CacheManager;
import com.sterlingcommerce.woodstock.security.PwdPolicy;

import com.sterlingcommerce.woodstock.util.NameValuePairs;
import com.sterlingcommerce.woodstock.util.NameValue;
import com.sterlingcommerce.woodstock.util.PasswordUtil;
import com.sterlingcommerce.woodstock.util.CommonUtil;

import com.sterlingcommerce.rbs.filebroker.dualcontrol.DualControlUtil;
import com.sterlingcommerce.woodstock.dmi.visibility.event.DmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.ExceptionLevel;
import com.sterlingcommerce.woodstock.event.InvalidEventException;

/**
 * The AccountWizard class extends the ServletBase class.
 * Contains all the business logic related to handling the Account
 * related tasks.
 *
 * @version 1.0
 * @since Woodstock2.0
 */
@SuppressWarnings({"unchecked", "unused", "static-access", "serial"})
public class AccountWizard extends WizardBase
{


   /**
     * Returns a String describing what the Servlet does.
     * @return String
     */
    public String getServletInfo () {
        return  "AccountWizard: manages Woodstock Accounts";
    }

    /**
     * Method for handling all the HttpRequests
     *
     * @param req
     * @param res
     * @exception javax.servlet.ServletException
     */

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {
try { req.setCharacterEncoding("UTF8"); } catch (Exception e) {  Util.noop();  /* try/catch to resolve jetty not wanting to reopen the stream */}
        HttpSession session = req.getSession(false);
        SessionInfo userinfo = null;
        if(session != null){
            userinfo = (SessionInfo)session.getAttribute("SessionInfo");
        }
        if(!verifySession(session, userinfo, req, res)){
            return;
        }

        if(BaseUIGlobals.out.debug)
        {
                BaseUIGlobals.out.logDebug(" [AccountWizard] START" +
                                debugRequest( req ));
        }


        Wizard wiz = initWizard(req, session);
            int action = wiz.getActivity(req);
            EntityAutho usrAutho = (EntityAutho)wiz.editObj();

            synchronized (wiz.editObj())
            {
                switch (action)
                {

                    default: // the edit
                        if(!updateAccount(req,usrAutho.theAutho, usrAutho, wiz)){
                            action = Wizard.EDITPAGE;
                        }
                            break;

                 case -1: // Ignore
                            break;
                 case Wizard.COMMITPAGE:
                    break;

                     case Wizard.FINISHPAGE:

                 		/*
         				 * DUAL CONTROL START
         				 */
         				 //
         				 //                            if (wiz.commitObj() == null)
         				//                            {
         				//                                    if(BaseUIGlobals.out.debug)
         				//                                    {
         				//                                         BaseUIGlobals.out.logDebug("CURRENT WIZARD STATS "  + wiz.toString());
         				//                                    }
         				//                                    wiz.setCommitObj(new SaveAccount(wiz));
         				//                            }
         				//                            break;

         				boolean doFinish = false;
         				String dcUser = req.getParameter("DUAL_CONTROL_USER");
         				String dcPass = req.getParameter("DUAL_CONTROL_PASSWORD");
         				String dcCurrentUser = (String)session.getAttribute("username");
         				String dcCurrentUserPass = req.getParameter("DUAL_CONTROL_C_PASSWORD");
         				BaseUIGlobals.out.logDebug("Entering Dual Control.");
         				DualControlUtil dcu = new DualControlUtil();
         				doFinish = dcu.isDualControlAuthorized("DUAL_CONTROL_USER_APPROVER", dcUser, dcPass, dcCurrentUser, dcCurrentUserPass, session);
         				if(doFinish)
         				{
         					try
         					{
         						DmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, Util.createGUID(), System.currentTimeMillis(), dcCurrentUser, "USER_APPROVAL", "User Account", usrAutho.theAutho.getUserName(), dcUser);
         					}
         					catch(InvalidEventException e)
         					{
         						BaseUIGlobals.out.logError("User Account Dual Control Admin Audit Event Error" + e);
         					}
         					//ORIGINAL CODE - START

         					if (wiz.commitObj() == null)
         					{
         						if(BaseUIGlobals.out.debug)
         						{
         							BaseUIGlobals.out.logDebug("CURRENT WIZARD STATS "  + wiz.toString());
         						}
         						wiz.setCommitObj(new SaveAccount(wiz));
         					}
         					//ORIGINAL CODE - END
         				} else
         				{
         					action = 10;
         					session.setAttribute("DUAL_CONTROL_MESSAGE", dcu.getMessage(true));
         					if(dcu.isChangerLocked())
         					{
         						session.setAttribute("AccountLocked", "AccountLocked");
         						req.setAttribute("badpage", "page.authofailure");
         						gotoPage("page.badframe", req, res);
         						session.invalidate();
         					}


         				}

         				break;

         				/*
         				 * DUAL CONTROL end
         				 */


                    case Wizard.CANCELPAGE:
                        // restore any changes to objects, only if it is  edit/delete
                        //remote object in AuthoEntity will be set if id is edit/delete
                        //but if it is new, then we will not set it, we will call create() on home interface directly
                        if(wiz.action != Wizard.ADD)
                            {
                                usrAutho.restore();
                                CommonUtil.handleCacheUpdate("UserCache", usrAutho.theAutho.getUserName());
                            }


                    break;

                }
            }

            setupNextPage(req, res, session, wiz, action);
        if(BaseUIGlobals.out.debug)
        {
            BaseUIGlobals.out.logDebug(" [AccountWizard] END");
        }



    }


    /**
     * Method for handling update of the Account object
     *
     * @param request
     * @param response
     * @param usrAccount UserAutho object to be updated
     * @exception javax.servlet.ServletException
     */

    private boolean updateAccount(HttpServletRequest request,
                  UserAutho usrAccount, EntityAutho theRemoteAutho, Wizard wiz) throws ServletException, IOException
        {

            HttpSession ses = request.getSession();
            String s = "";
            EntityObject entityObj =  (EntityObject)ses.getAttribute("EntityObject");
        // added to distinguish between the GIS admin (who can only create uccnet_admin accounts for uccnet edition)
        // and the uccnet_admin account (who can only create users for uccnet edition)
        SessionInfo sessionInfo = (SessionInfo)ses.getAttribute("SessionInfo");
        //added for DMI admin audit event
        usrAccount.setPrincipal(sessionInfo.getUserName());

        boolean isUCCnetAdmin = false;
        if (sessionInfo != null && sessionInfo.getAutho() != null) {
            isUCCnetAdmin = sessionInfo.getAutho().hasExplicitPermission("UCCNETADMIN");
        } else {
            BaseUIGlobals.out.log("[AccountWizard.updateAccount] Either getSession or getAutho method calls returned null");
        }

            if(wiz.getStep().pageType.equals("NAMING")){
                    String s1 = request.getParameter("ACCOUNT_userName");
                    String bkpName = usrAccount.getBkpUserName();
                    if(bkpName == null) bkpName = "";
                    boolean error = true; //assume that we will be able to find the autho with given name
                    //which would mean we are having duplicate
                    boolean dupeGroup = true;
                    if (s1 != null && s1.length() > 0) {
                    if(!s1.equals(bkpName)){
                    try{
                    if(entityObj != null){
                        if(theRemoteAutho.isNameUnique(s1)){
                            if(BaseUIGlobals.out.debug)
                                BaseUIGlobals.out.logDebug("[AccountWizard] name is unique!");
                            usrAccount.setUserName(s1);
                            error = false; //we did not find a user, can use the given name
                        }
                    }
                    User u = (User)CacheManager.get("UserCache", s1);
                    if (u == null) {
                      if(BaseUIGlobals.out.debug)
                          BaseUIGlobals.out.logDebug("[AccountWizard] name is unique!");
                      usrAccount.setUserName(s1);
                      error = false;
                    } else {
                        if (u.getStatus() == 0) {
                          if(BaseUIGlobals.out.debug)
                              BaseUIGlobals.out.logDebug("[AccountWizard] name is unique!");
                          usrAccount.setUserName(s1);
                          usrAccount.setStatus(User.ENABLED);
                          usrAccount.setNewUser(false);
                          usrAccount.setBkpUserName(s1);
                          error = false; // the group will be valid if a user exists, but is disabled.
                        }
                    }
                    //added following 2 lines to check if a group with the same name exists.
                    dupeGroup = Group.doesGroupIdExist(s1);
                    if (!dupeGroup) {
                        dupeGroup = false;
                    } else {
                        Group g = (Group)CacheManager.get("GroupCache", s1);
                        if (!g.isEnabled()) {
                            dupeGroup = false;
                        }
                    }
                }
                catch(Exception e){
                 BaseUIGlobals.out.logException(" [AccountWizard] " , e);
                }
                if(error || dupeGroup){ //if we have the duplicate
                    LangBean lang = (LangBean)ses.getAttribute("langbean");
                    request.setAttribute("msg", lang.getValue("images.errorbutton") + Util.replaceString(lang.getValue("DuplicateAuthoAndGroup"),"&NAME;", s1));
                    return false;
                }
            }
          }

          s = request.getParameter("ACCOUNT_AuthType");
          if (s != null){
            if (Integer.parseInt(s)==User.LOCAL_AUTHENTICATION) {
                usrAccount.setLocallyAuthenticated();
            } else {
                String tmp_s = request.getParameter("ACCOUNT_authhost");
                if ((tmp_s != null) && (tmp_s.length() > 0)) {
                    usrAccount.setLDAPAuthenticated(Integer.parseInt(tmp_s));
                } else {
                    usrAccount.setLDAPAuthenticated(AuthenticationProps.DEFAULT_LDAP_AUTHENTICATION);
                }
            }
          }

          s = request.getParameter("ACCOUNT_PolicyID");
          if (s != null){
            usrAccount.setPolicyID(s);
          }

/*
          s = request.getParameter("ACCOUNT_RemoteUserKey");
          if (s != null){
            usrAccount.setRemoteUserKey(s);
          }
*/


        s = request.getParameter("ACCOUNT_userPass");
        if ( (s == null || s.trim().length() == 0) && wiz.action == wiz.ADD ) // added this to get password on an ADD in case the 'BACK' button is hit and a policy is assigned
            s = usrAccount.getUnHashedPassword();

        if (s != null && s.length() > 0) {
            LangBean lang = (LangBean)ses.getAttribute("langbean");
            ISecurityFieldValidator theValidator = (ISecurityFieldValidator)ses.getAttribute("Validator");
            if(theValidator != null){
                if(!theValidator.validateInput(s, usrAccount.getUserName())){
//			LangBean lang = (LangBean)ses.getAttribute("langbean");
                    request.setAttribute("msg", lang.getValue("images.errorbutton") +
                                         lang.getValue(theValidator.errorMsg()));
                    return false;
                }

            }
             // added for PwdPolicy
            //moved to top of method.  Need some of it information elsewhere
        //SessionInfo sessionInfo = (SessionInfo)ses.getAttribute("SessionInfo");
            String usrLoggedIn = sessionInfo.getAutho().getUserName();
            String usrBeingEdited = usrAccount.getUserName();
            boolean usrEditedSuper = usrAccount.hasGroup("super");
            boolean usrLoggedInSuper = sessionInfo.getAutho().hasGroup("super");

            if (wiz.action == wiz.EDIT) { // we don't need to validate against old passwords for a new rec
                boolean oldPassMatch = true;
                String dbPass = null;
                String dbPassSalt = null;
                if ( usrAccount.getOldPassword() == null ) {
                    dbPass = usrAccount.getUserPassword();
                    dbPassSalt = usrAccount.getUserPasswordSalt();
                } else {
                    dbPass = usrAccount.getOldPassword();
                    dbPassSalt = usrAccount.getOldSalt();
                }

                if ( usrLoggedIn.equals( usrBeingEdited ) || ( !usrLoggedInSuper && usrEditedSuper ) ) {
                    String accOldPass = request.getParameter("ACCOUNT_userOldPass");
                    oldPassMatch = PasswordUtil.passwordsMatch(accOldPass, dbPass, dbPassSalt);
                    if (!oldPassMatch) {
                        request.setAttribute("msg", lang.getValue("images.errorbutton") + lang.getValue("IncorrectOldPassword"));
                        return false;
                    }
                } else {
                    oldPassMatch = PasswordUtil.passwordsMatch(s, dbPass, dbPassSalt);
                    if (oldPassMatch) {
                        request.setAttribute("msg", lang.getValue("images.errorbutton") + lang.getValue("OldNewPasswordSame2"));
                        return false;
                    }
                }
                usrAccount.setOldPassword( dbPass );  // stores old password in case the PwdPolicy is enabled and we need to save PwdHistory
                usrAccount.setOldSalt( dbPassSalt );
            }

            String policyid = usrAccount.getPolicyID();
            if ( policyid != null && policyid.length() > 0 ) {
                 PwdPolicy pwdPol = BaseUIGlobals.securityMgr.getPwdPolicy( policyid );

                 if ( pwdPol != null ) {
                    // the return value: 'str' is the name of the prop in login_en.properties. The prop translates into the error msg.
                    String str = pwdPol.validateNewPassword( usrBeingEdited, s );
                    if ( str != null ) {
                        if (BaseUIGlobals.out.debug) BaseUIGlobals.out.logDebug( "[AccountWizard] The new password did not pass validation for the account [ "+usrBeingEdited+" ]. [ "+str+" ]");

                        request.setAttribute("msg", lang.getValue("images.errorbutton") + lang.getValue( str ));
                        return false;
                    }
                 } else {
                    if (BaseUIGlobals.out.debug) BaseUIGlobals.out.logDebug( "[AccountWizard] Cannot find PwdPolicy [ "+pwdPol+" ].");
                 }

            } // end pwdpolicy
            java.sql.Date d = new java.sql.Date(System.currentTimeMillis());
            if ( wiz.action == wiz.ADD )
                usrAccount.setUnHashedPassword( s );  // we won't hash password until we save.  this is in case the scroll back and apply a pwdpolicy
            
            byte[] newSalt = PasswordUtil.getSalt();
            usrAccount.setUserPassword( PasswordUtil.hashPassword(s, newSalt) );
            usrAccount.setUserPasswordSalt( PasswordUtil.getEncodedSalt(newSalt) );

            usrAccount.setOldPasswordDate( d );
//            if (wiz.action == wiz.EDIT && usrAccount.getPwdModDate() == null) // we don't set the pwdModDate for a new user.
            if (wiz.action == wiz.EDIT) // we don't set the pwdModDate for a new user.
                usrAccount.setPwdModDate( d );

        } else {
            usrAccount.setOldPassword( null );
            usrAccount.setOldSalt( null );
        }

        s = request.getParameter("ACCOUNT_userRole");
        Role theRole = new Role();

        if (s != null && s.length() > 0) {
          int sepIndex = s.indexOf('+', 0);
          String rolePerms = s.substring(0, sepIndex);
          String roleName = s.substring(sepIndex+1);
          theRole.setRoleName(roleName);
          theRole.setRolePermission(Integer.parseInt(rolePerms));
        }
        int access = 1 ;
        if( wiz.action == Wizard.ADD ){
            s = request.getParameter("ACCOUNT_access");
            if( s!=null ){

                try{
                    access = Integer.parseInt( s );
                }catch(Exception ex){
                    access = 1;
                }

                if( theRemoteAutho.getAccessibility() != access){
                       theRemoteAutho.setAccessibility(access) ;
                       usrAccount.removeTmpGroup();
                   usrAccount.removeTmpPerm();
                               usrAccount.initTmpGroups();
                                usrAccount.setSuper(false);
                }

           }
        }else { //during edit
            access = theRemoteAutho.getAccessibility();

        }

        BaseUIGlobals.logDebug("[AccountWizard] access="+access);
        switch( access ) {

		    case 1:  usrAccount.tmpAddPerm("WebAppAdminPermission");
			     usrAccount.tmpAddPerm("PLTADM30");
			     wiz.setActiveStatus("GROUPS",true);
			     wiz.setActiveStatus("PERMS",true);	
			     break;
                    case 2:  usrAccount.tmpAddGroup( "as2admin" );
			     // wiz.setActiveStatus("SSHUserKey", true);
                             /* TD 166501 */
                             usrAccount.tmpAddPerm("WebAppAdminPermission");
                             usrAccount.tmpAddPerm("PLTADM30");
                             wiz.setActiveStatus("GROUPS", false);
                             wiz.setActiveStatus("PERMS", true);
                             break;
                    /* TD 166510
                    case 3:  if( wiz.action == Wizard.ADD ) usrAccount.tmpAddGroup( (isUCCnetAdmin ? "uccnetuser" : "uccnetadmin") );
			     // wiz.setActiveStatus("SSHUserKey", true);
                             wiz.setActiveStatus("GROUPS", false);
                             wiz.setActiveStatus("PERMS", false);
                             break;*/
                    case 4:  usrAccount.tmpAddGroup( "dashboardUsers" );
                             usrAccount.tmpAddPerm("Dashboard");
			     // wiz.setActiveStatus("SSHUserKey", true);
                             /* TD 166501 */
                             usrAccount.tmpAddPerm("WebAppAdminPermission");
                             usrAccount.tmpAddPerm("PLTADM30");
                             wiz.setActiveStatus("GROUPS", true);
                             wiz.setActiveStatus("PERMS", true);
                             break;
                    case 5:  usrAccount.tmpAddGroup( "cdsp_user" );
                             if(usrAccount.hasGroup("cdsp_admin"))
                             	usrAccount.tmpAddGroup( "cdsp_admin" );
                             boolean isCDSPAdmin = sessionInfo.getAutho().hasGroup(BaseUIGlobals.CDSP_USER);
                             if( isCDSPAdmin ){
                                 wiz.setActiveStatus("GROUPS", false);
                                 wiz.setActiveStatus("PERMS", false);
                             }
                             else {
                                 wiz.setActiveStatus("GROUPS", true);
                                 wiz.setActiveStatus("PERMS", true);
                             }
                             break;
                    
                        default: wiz.setActiveStatus("GROUPS", true);
			 // wiz.setActiveStatus("SSHUserKey", true);
                         wiz.setActiveStatus("PERMS", true);
        }

        int theme = -1 ;
        s = request.getParameter("ACCOUNT_theme");
            if( s!=null ){
                try{
                    theme = Integer.parseInt( s );
                }catch(Exception ex){
                    theme = -1;
                }

                if( theRemoteAutho.getTheme() != theme){
                    theRemoteAutho.setTheme(theme) ;
                }
                usrAccount.removeTmpPerm("THEME_OPER");
                usrAccount.removeTmpPerm("THEME_PPT");
                usrAccount.removeTmpPerm("THEME_PPTSPR");
                usrAccount.removeTmpPerm("THEME_SPR");
                usrAccount.removeTmpPerm("THEME_AFT");

                switch( theme ) {
                        case 1 : usrAccount.tmpAddPerm("THEME_OPER");  break ;
                        case 2:  usrAccount.tmpAddPerm("THEME_PPT");  break ;
                        case 3:  usrAccount.tmpAddPerm("THEME_PPTSPR");  break ;
                        case 4:  usrAccount.tmpAddPerm("THEME_SPR");  break ;
                        case 5:  usrAccount.tmpAddPerm("THEME_AFT"); break;
                        default:  break ;
               }
        }

    }
 	// call extension update
	boolean bExtFlag = updateAccountExt ( request, usrAccount, wiz );
	if ( !bExtFlag ) {
	    return false;
	}

 if(wiz.getStep().pageType.equals("GROUPS")){

    boolean returnBool = true;
    boolean bAccount = false;
    if( wiz.getActivity(request) == Wizard.SEARCHPAGE ) {
        String name = request.getParameter( "groupname" );
        if ( name != null && name.trim().length() > 0){
        usrAccount.setGroupFilter(name);
        } else usrAccount.setGroupFilter("");
        returnBool = false;
        }
        if( wiz.getActivity(request) != Wizard.BACKPAGE ){
            String[] groupNames = request.getParameterValues("assignlist");
            //usrAccount.removeTmpPerm();
            theRemoteAutho.setAvailablePermissions(null);
            theRemoteAutho.setPositionValue(0);
            usrAccount.removeTmpGroup();
            usrAccount.initTmpGroups();
            usrAccount.removeTmpSubGroups();
            String groupName ;
            if( groupNames != null && groupNames.length > 0 ){
                for( int i =0; i< groupNames.length ; i++){
                    groupName = groupNames[i];
                    usrAccount.refreshGroupsForGroupWizard( groupName );
                    if ( groupName.equals("super") ) { bAccount = true; }
                    usrAccount.tmpAddGroup( groupName );
                }

            }
            if( bAccount ) usrAccount.setSuper(true);
            else usrAccount.setSuper(false);
            
            int tmp_page = wiz.getActivity(request);
            if (((tmp_page == Wizard.NEXTPAGE) || (tmp_page == Wizard.CONFIRMPAGE)) && usrAccount.getUserName().equals("admin") && !bAccount ) { // if admin then super group should be assigned
        	usrAccount.refreshGroupsForGroupWizard("super");
        	usrAccount.tmpAddGroup("super");
                LangBean lang = (LangBean)ses.getAttribute("langbean");
                request.setAttribute("msg", lang.getValue("images.errorbutton") + Util.replaceString(lang.getValue("CannotRemoveSuperFromAdmin"),"&NAME;", "Sterling Integrator Admin" ));
                returnBool = false;
            }
            Vector vGrp = usrAccount.getTmpGroups();
            Vector vSubGrp = usrAccount.getTmpSubGroups();
            usrAccount.removeTmpSubPermWithRights(); // this removes old values so newly posted values don't create dupes
            Group g = null;
            if (vGrp!=null) {
                NameValuePairs nvp = null;
                for(int a=0;a<vGrp.size();a++) {
                    g = BaseUIGlobals.securityMgr.getGroup( (String)vGrp.elementAt(a) );
                    nvp = g.getPermIDsWithRightsForGroup();
                    if (nvp!=null) {
                        NameValue nv = null;
                        Collection cl = new ArrayList();
                        for(int c=0;c<nvp.numEntries();c++) {
                            nv = nvp.getElement(c);
                            if ( usrAccount.getTmpSubPermsWithRights().get(nv.name) == null) {
                                cl.add(nv);
                            }
                        }
                        usrAccount.getTmpSubPermsWithRights().addAll(cl);
                    }
                }
            }

            if (vGrp!=null) {
                NameValuePairs nvp = null;
                Collection cl = new ArrayList();
                for(int b=0;b<vSubGrp.size();b++) {
                    g = BaseUIGlobals.securityMgr.getGroup( (String)vSubGrp.elementAt(b) );
                    nvp = g.getPermIDsWithRightsForGroup();
                    if (nvp!=null) {
                        NameValue nv = null;
                        for(int d=0;d<nvp.numEntries();d++) {
                            nv = nvp.getElement(d);
                            if ( usrAccount.getTmpSubPermsWithRights().get(nv.name) == null ) {
                                cl.add(nv);
                            }
                        }
                    }
                    usrAccount.getTmpSubPermsWithRights().addAll(cl);
                }
            }
        }
    return returnBool ;
 } else if(wiz.getStep().pageType.equals("PERMS")){

    boolean returnBool = true;

    String singleArrowRight = null;

    if(request.getParameter("left_transfer") != null &&
    	request.getParameter("left_transfer").equals("true"))
    {
		String value;
		StringTokenizer selectvalues;
		List selectPermissions = null;

		theRemoteAutho.setlefttransfer(true);
 		value = request.getParameter("select_side");
		selectvalues = new StringTokenizer(value,",");
		selectPermissions = new ArrayList();

    	int counter = 0;
    	while (selectvalues.hasMoreTokens())
    	{
    		String token = selectvalues.nextToken();
    		selectPermissions.add(counter, token);
            ++counter;
        }
    	theRemoteAutho.deleteSelectedPermissionsString( selectPermissions );

    	returnBool = false;
    }
    else
    {
    	theRemoteAutho.setlefttransfer(false);
    }

    if(request.getParameter("direct_select2avail_transfer") != null &&
    	request.getParameter("direct_select2avail_transfer").equals("true"))

    {
		theRemoteAutho.setdirect_select2avail_transfer(true);

    	List convertedPermissions = new ArrayList();
     	List selectedPerms = theRemoteAutho.getSelectedPermissions();
    	int entryNumber = 0;
    	int limit = 0;

    	if ((theRemoteAutho.getSelectBoxNumberValue() + theRemoteAutho.getSelectBoxPositionValue()) > selectedPerms.size())
    	{
    		limit = selectedPerms.size();
    	}
    	else
    	{
    		limit = theRemoteAutho.getSelectBoxNumberValue() + theRemoteAutho.getSelectBoxPositionValue();
    	}


        for(int j = theRemoteAutho.getSelectBoxPositionValue(); j < limit ; j++)
        {
        	NameValue name_value = (NameValue)selectedPerms.get(j);
            convertedPermissions.add(entryNumber, name_value);
            ++entryNumber;
        }
        theRemoteAutho.deleteSelectedPermissionsNV( convertedPermissions );

        returnBool = false;
    }
    else
    {
    	theRemoteAutho.setdirect_select2avail_transfer(false);
    }

    if(request.getParameter("direct_avail2select_transfer") != null &&
    	request.getParameter("direct_avail2select_transfer").equals("true"))
    {
		theRemoteAutho.setdirect_avail2select_transfer(true);
    	List convertedPermissions = new ArrayList();
    	int entryNumber = -1;
    	NameValuePairs permissions = theRemoteAutho.getAvailablePermissionsAsNVP();
    	int limit = 0;

    	if ((theRemoteAutho.getNumberValue() + theRemoteAutho.getPositionValue())> permissions.size())
    	{
    		limit = permissions.size();
    	}
    	else
    	{
    		limit = theRemoteAutho.getNumberValue() + theRemoteAutho.getPositionValue();
    	}
        for(int j = theRemoteAutho.getPositionValue(); j < limit ; j++)
        {
        	NameValue name = (NameValue)permissions.getElement(j);
        	convertedPermissions.add(++entryNumber, name.name);
        }
        theRemoteAutho.setNewSelectedPermissionsID(convertedPermissions);

        returnBool = false;
   	}
    else
    {
   		theRemoteAutho.setdirect_avail2select_transfer(false);
    }
    String window = request.getParameter("window");
    if(window != null && ! "".equals(window))
    {

    	if(window.equals("available"))
    	{

    		theRemoteAutho.setWindowType("available");
    		theRemoteAutho.setPositionValue(Integer.parseInt(request.getParameter("pos")));
    		theRemoteAutho.setNumberValue(Integer.parseInt(request.getParameter("num")));

    	}
    	else if(window.equals("select"))
    	{

    		theRemoteAutho.setWindowType("select");
    		theRemoteAutho.setSelectBoxPositionValue(Integer.parseInt(request.getParameter("pos")));
    		theRemoteAutho.setSelectBoxNumberValue(Integer.parseInt(request.getParameter("num")));

    	}

    	returnBool = false;
    }

    if((singleArrowRight = request.getParameter("right_transfer"))!= null &&
    		singleArrowRight.equals("true"))
    {
   		theRemoteAutho.setRightTransfer(true);
   	}
    else
    {
    	theRemoteAutho.setRightTransfer(false);
    }

    String rightavailside = null;
    List rightavailPermissions = null;
    StringTokenizer rightavail;
    int counter = 0;

    if(theRemoteAutho.getRightTransfer()== true)
    {
    	rightavailside = request.getParameter("avail_side");
    	rightavail = new StringTokenizer(rightavailside,",");
    	rightavailPermissions = new ArrayList();

    	counter = 0;
    	while (rightavail.hasMoreTokens())
    	{
    		String token = rightavail.nextToken();
    		rightavailPermissions.add(counter,token);
            ++counter;
        }
    	theRemoteAutho.setNewSelectedPermissionsID(rightavailPermissions);
        returnBool = false;

    }

//    stringParam = request.getParameter("mboxMsgPattern");
//    theRemoteAutho.setMessagePattern(stringParam);



// executes the search page and resets the filters
    if( wiz.getActivity(request) == Wizard.SEARCHPAGE && returnBool)
    {
        returnBool = false;
   		theRemoteAutho.setWindowType("available");
   		theRemoteAutho.setPositionValue(0);
        String name = request.getParameter( "permname" );
        if ( name != null && name.trim().length() > 0)
        {
            usrAccount.setPermNameFilter(name);
        }
        else
        	usrAccount.setPermNameFilter("");
        String type = request.getParameter( "permtype" );
        if ( type != null && type.trim().length() > 0)
        {
            usrAccount.setPermTypeFilter(type);
        }
        else
        {
        	usrAccount.setPermTypeFilter("");
        }
        theRemoteAutho.setAvailablePermissions(null);
    }
// this section executes the next button and actually saves all of the selected permissions to the user.
    else if( wiz.getActivity(request) != Wizard.BACKPAGE && returnBool)
    {
//        String[] permNames = request.getParameterValues("assignlist");
        ArrayList permNames = (ArrayList) theRemoteAutho.getSelectedPermissions();
        usrAccount.removeTmpPerm();
        NameValue permName ;

        NameValuePairs nvp2 = new NameValuePairs();
        if( permNames != null && permNames.size() > 0 )
        {
            Permission p = null;
            NameValuePairs nvp = usrAccount.getTmpPermsAddWithRights();
            NameValue nv = null;
            Iterator mboxIter = permNames.iterator();
            while (mboxIter.hasNext())
            {
            	permName = (NameValue)mboxIter.next();
                usrAccount.tmpAddPerm( permName.name );
                nv = nvp.get( permName.name );
                if ( nv==null )// if  a new perm is added to the assigned list. It will be
                {
                	p = BaseUIGlobals.securityMgr.getPermission( permName.name );
                    nvp2.addElement( permName.name, new Integer(p.getRight()) );
                }
                else
                {
                    nvp2.addElement( nv.name, nv.value );
                }
            }
            usrAccount.setTmpPermAddWithRightsFromWizard( nvp2 );
         }
        else if( (usrAccount.getTmpGroups() == null ||
        			usrAccount.getTmpGroups().size() == 0) &&
        			wiz.getActivity(request) != Wizard.BACKPAGE &&
        			wiz.getActivity(request) != Wizard.SEARCHPAGE)
        {
            LangBean lang = (LangBean)ses.getAttribute("langbean");
            request.setAttribute("msg", lang.getValue("images.errorbutton") + lang.getValue("NoPermAssigned"));
            returnBool = false;
        }
    }
    return returnBool ;
 } else if(wiz.getStep().pageType.equals("RIGHTS")) {

            boolean returnBool = true;

            String name = request.getParameter( "PERM_NAME0" );
            if (name != null && name.trim().length() >1) {
                usrAccount.removeTmpPermAddWithRights(); // this removes old values so newly posted values don't create dupes
                int cntr = 0;
                String r = "";
                String w = "";
                String x = "";
                String d = "";
                int rightValue = 0;
                while ( name!=null && name.trim().length() >1 ) {
                    x = request.getParameter( "PERMExecute"+cntr );
                    if (x.equals("1")) rightValue += 1;
                    w = request.getParameter( "PERMWrite"+cntr );
                    if (w.equals("1")) rightValue += 2;
                    r = request.getParameter( "PERMRead"+cntr );
                    if (r.equals("1")) rightValue += 4;
                    d = request.getParameter( "PERMDelete"+cntr );
                    if (d.equals("1")) rightValue += 8;
                    usrAccount.tmpPermsAddWithRights( name, rightValue );
                    cntr++;
                    rightValue = 0;
                    name = request.getParameter( "PERM_NAME"+cntr );
                }
            }
            return returnBool ;
        }


    s = request.getParameter("ACCOUNT_EntityID");
    if (s != null && s.length() > 0) {
        usrAccount.setEntityID(s);
    }

        s = request.getParameter("ACCOUNT_FName");
        if (s != null && s.length() > 0) {
            usrAccount.setFName(s);
        }
        s = request.getParameter("ACCOUNT_LName");
        if (s != null && s.length() > 0) {
            usrAccount.setLName(s);
        }
        s = request.getParameter("ACCOUNT_Email");
        if (s != null) {
            usrAccount.setEmail(s);
        }
        s = request.getParameter("ACCOUNT_Pager");
        if (s != null){
            usrAccount.setPager(s);
        }
        s = request.getParameter("ACCOUNT_EntityID");
        if (s != null){
            usrAccount.setEntityID(s);
        }
        s = request.getParameter("ACCOUNT_ParentID");
        if (s != null){
            usrAccount.setParentID(s);
        }
        // moved this up top so a new user's password can be validated.
//        s = request.getParameter("ACCOUNT_PolicyID");
//        if (s != null){
//            usrAccount.setPolicyID(s);
//        }
    s = request.getParameter("parentID");
        if (s != null){
            usrAccount.setAccountParentID(s);
        }
        s = request.getParameter("lang");
        if (s != null && s.length() > 0){
            usrAccount.setLang(s);
        }else{
            usrAccount.setLang(usrAccount.getLang());
        }

    s = request.getParameter("ACCOUNT_timeout");
    if (s!=null) {
        int t;
        try {
        t = Integer.parseInt(s);
        } catch (NumberFormatException ne) {
        t = 0;
        }
        if (t>0)
        t = t * 60;

        usrAccount.setTimeout( t );
    }

        return true;
    }


    /**
     * calling extension class for sshkey in asset clump
     * extended class will overwrite the method
     **/
    protected boolean updateAccountExt ( HttpServletRequest request, UserAutho usrAccount, Wizard wiz ) {
	return true;
    }

}
