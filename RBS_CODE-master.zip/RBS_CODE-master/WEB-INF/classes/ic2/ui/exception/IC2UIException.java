/**
 * 
 */
package ic2.ui.exception;

/**
 * @author Ravi K Patel
 * created Mar 12, 2006
 */
public class IC2UIException extends Exception {
	private static final long serialVersionUID = 1L;

	public IC2UIException() {
		super();
	}

	public IC2UIException(String message, Throwable cause) {
		super(message, cause);
	}

	public IC2UIException(String message) {
		super(message);
	}

	public IC2UIException(Throwable cause) {
		super(cause);
	}

}
