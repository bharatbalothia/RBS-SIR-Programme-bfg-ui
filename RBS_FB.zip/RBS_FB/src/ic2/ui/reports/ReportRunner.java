/**
 * 
 */
package ic2.ui.reports;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import ic2.ui.beans.reports.ReportDataBean;
import ic2.ui.beans.reports.ReportRunnerBean;
import ic2.ui.exception.IC2UBPTimedOutException;

import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

//import com.stercomm.customers.webapps.resources.Constants;
//import com.sterlingcommerce.woodstock.security.User;
import com.sterlingcommerce.woodstock.webx.xforms.plug.si.BusinessProcessResolver;

/**
 * @author Ravi K Patel
 * created May 4, 2006
 */
public class ReportRunner implements Runnable {
	private static final Logger logger = Logger.getLogger(ReportRunner.class);
	
	public static final int WAITING = 0;
	public static final int SUCCESS = 1;
	public static final int FAILURE = 2;
	public static final int RUNNING = 3;
	
	
	private ReportDataBean reportDataBean;
	private int status = WAITING;
	private ReportRunnerBean reportRunnerBean;
	@SuppressWarnings("unused")
	private HttpServletRequest request;
	private String username;
	
	
	
	public ReportRunnerBean getReportRunnerBean() {
		return reportRunnerBean;
	}

	public void setReportRunnerBean(ReportRunnerBean reportRunnerBean) {
		this.reportRunnerBean = reportRunnerBean;
	}

	public ReportRunner(final ReportRunnerBean reportRunnerBean, HttpServletRequest request, String username) {
		this.reportRunnerBean = reportRunnerBean;
		this.request = request;
		this.username=username;
	}
	
	public void run() {
		try{
				
			if(reportRunnerBean.getReportSettings().getOutput().equalsIgnoreCase("pdf")
			|| reportRunnerBean.getReportSettings().getOutput().equalsIgnoreCase("html")	
			|| reportRunnerBean.getReportSettings().getOutput().equalsIgnoreCase("csv")
			){
				
				//HttpSession session =  request.getSession();
				//User u = (User)session.getAttribute(Constants.GIS_USER_OBJECT);
				
				String bpSQL= reportRunnerBean.getReportSettings().getSql();
				String bpName = bpSQL.replaceAll("BP:", "");
				logger.debug("BP: "+ bpName);
				String processData = "bp="+bpName+"&auth="+reportRunnerBean.getReportSettings().getAuthorization() + "&id="+reportRunnerBean.getReportSettings().getId() + "&output="+reportRunnerBean.getReportSettings().getOutput();
				if(reportRunnerBean.getReportStartDate()!=null){
					processData=processData+"&reportstart="+formatReportDate(reportRunnerBean.getReportStartDate());
				}
				if(reportRunnerBean.getReportEndDate()!=null){
					processData=processData+"&reportend="+formatReportDate(reportRunnerBean.getReportEndDate());
				}
				logger.debug("PData: " + processData);
				
				byte[] primaryDocumentBuffer = null;
				BusinessProcessResolver bpResolver = new BusinessProcessResolver();
				try {
					//primaryDocumentBuffer = bpResolver.resolve(bpName, processData, u.getUserName());
					primaryDocumentBuffer = bpResolver.resolve(bpName, processData, username);
				} catch (Exception e) {
					//TODO: make this better
					if (e.getClass().getName().equals("com.sterlingcommerce.woodstock.workflow.WorkFlowException")){
						if (e.getMessage().indexOf("request timed out")>-1){
							throw new IC2UBPTimedOutException(e);
						}
						else {
							logger.error("error while executing ReportBP", e);
						}
					}
					else{
						logger.error("error while executing ReportBP", e);
					}
					//throw e;
				}
				
				
				//logger.debug("returned PDoc: "+primaryDocumentBuffer);
				ReportDataBean reportDataBean = new ReportDataBean(primaryDocumentBuffer);
				setReportDataBean(reportDataBean);
				
			}
//			else {
//			
//				
//				
//				ReportsDBUtils dbutils = new ReportsDBUtils();
//				ReportDataBean reportDataBean = dbutils.getReport(reportRunnerBean, request);
//				setReportDataBean(reportDataBean);
//			}
			
			this.status = SUCCESS;
		}
		catch (Exception e){
			logger.debug("caught exception, storing and setting status to FAILURE");
			this.exception = e;
			this.status = FAILURE;
		}
	}

	
	
	
	
	
	private Exception exception;
	public Exception getException() {
		return exception;
	}
	public void setException(Exception exception) {
		this.exception = exception;
	}
	public ReportDataBean getReportDataBean() {
		return reportDataBean;
	}
	public void setReportDataBean(ReportDataBean reportDataBean) {
		this.reportDataBean = reportDataBean;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	private String formatReportDate(String dte) throws Exception{
		
		DateFormat dfin = new SimpleDateFormat("dd/MM/yyyy");
		DateFormat dfout = new SimpleDateFormat("yyyy-MM-dd");
		Date datein = dfin.parse(dte);
		return dfout.format(datein);
		
		
	}
}
