package ic2.ui.struts.forms;


import ic2.ui.struts.actions.IC2UIAction;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


public class IC2UIForm extends ActionForm {
	private static final long serialVersionUID = 1L;

	public ActionErrors validate(ActionMapping mapping, IC2UIAction action, HttpServletRequest request){
		ActionErrors errors = new ActionErrors();
		return errors;
	}
}
