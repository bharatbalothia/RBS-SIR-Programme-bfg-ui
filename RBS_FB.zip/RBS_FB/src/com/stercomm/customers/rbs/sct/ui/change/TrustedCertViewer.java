package com.stercomm.customers.rbs.sct.ui.change;

import com.sterlingcommerce.refactor.util.URLEncoder;

public class TrustedCertViewer implements ChangeViewer {

	private ChangeControl change;
	public final static String OBJECT_TYPE="Trusted Certificate";

	public TrustedCertViewer(){
	}

	//public TrustedCertViewer(ChangeControl cc){
	//	setChange(cc);
	//}

	public String getObjectType(){
		return OBJECT_TYPE;
	}

	public ChangeControl getChange() {
		return change;
	}

	public void setChange(ChangeControl change) {
		this.change = change;
	}

	public String getBeforeChangeLink(){
		String ret = "<a>None</a>";

		try {
			if(getChange()!=null && getChange().getObjectKey()!=null){
				//No before link for CREATE operation
				if(getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_DELETE) || getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_UPDATE)){
					StringBuffer sb = new StringBuffer();
					sb.append("<a href=\"javascript:openInfoWin(\'./trustedCertsView.do?id=");
					sb.append(URLEncoder.encode(getChange().getObjectKey()));
					sb.append("\', 850, 600);\" onmouseover=\"window.status=\'View Trusted Certificate Information\'; return true;\" onmouseout=\"window.status=\'\'; return true;\">");
					sb.append(getChange().getResultMeta1());
					sb.append("</a>");
					ret = sb.toString();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			ret = "<a>Error displaying link</a>";
		}
		return ret;
	}

	public String getAfterChangeLink(){
		String ret = "<a>None</a>";

		try {
			if(getChange()!=null && getChange().getChangeID()!=null){
				//if operation is DELETE then there are no objects afterwards
				if(getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_CREATE) || getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_UPDATE)){
					StringBuffer sb = new StringBuffer();
					sb.append("<a href=\"javascript:openInfoWin(\'./trustedCertsView.do?change=true&id=");
					sb.append(URLEncoder.encode(getChange().getChangeID()));
					sb.append("\', 850, 600);\" onmouseover=\"window.status=\'View Trusted Certificate Information\'; return true;\" onmouseout=\"window.status=\'\'; return true;\">");
					sb.append(getChange().getResultMeta1());
					sb.append("</a>");
					ret = sb.toString();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			ret = "<a>Error displaying link</a>";
		}
		return ret;
	}



}
