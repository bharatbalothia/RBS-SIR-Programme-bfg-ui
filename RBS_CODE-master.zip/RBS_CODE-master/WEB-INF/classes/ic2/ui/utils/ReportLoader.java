/**
 * 
 */
package ic2.ui.utils;

import ic2.ui.beans.reports.ReportSettingsBean;
import ic2.ui.exception.IC2UIException;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.TreeMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * @author Ravi K Patel
 * created May 4, 2006
 */
@SuppressWarnings({"unchecked"})
public class ReportLoader {

	private static final Logger logger = Logger.getLogger(ReportLoader.class);
	
	
	private static Map reports;
	
	protected ReportLoader(){}
	
	
	public static Map getReports() throws IC2UIException{
		if (reports==null){
			logger.debug("reports is null");
			synchronized (ReportLoader.class) {
				if (reports==null){
					logger.debug("reports is null (syncronized)");
					logger.debug("getting xml from resource '/ic2/ui/resources/ic2Reports.xml'");
					InputStream reportxml = ReportLoader.class.getResourceAsStream("/ic2/ui/resources/ic2Reports.xml");
					
					
					Document reportDoc;
					try {
						DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
						DocumentBuilder db = dbf.newDocumentBuilder();
						reportDoc = db.parse(reportxml);
					} catch (FactoryConfigurationError e) {
						String message = "FactoryConfigurationError reading xml file for Reports";
						logger.fatal(message, e);
						throw new IC2UIException(message, e);
					} catch (ParserConfigurationException e) {
						String message = "ParserConfigurationException reading xml file for Reports";
						logger.fatal(message, e);
						throw new IC2UIException(message, e);
					} catch (SAXException e) {
						String message = "SAXException reading xml file for Reports";
						logger.fatal(message, e);
						throw new IC2UIException(message, e);
					} catch (IOException e) {
						String message = "IOException reading xml file for Reports";
						logger.fatal(message, e);
						throw new IC2UIException(message, e);
					}
					
					NodeList reportNodes = reportDoc.getElementsByTagName("report");
					
					reports = new TreeMap();
					for (int i=0; i<reportNodes.getLength(); i++){
						ReportSettingsBean reportBean = new ReportSettingsBean();
						Node reportNode = reportNodes.item(i);
						processRecursive(reportNode, reportBean);
						reports.put(reportBean.getId(), reportBean);
					}
					
				}
			}
		}
		return reports;
	}
	
	public static void clearReports(){
		synchronized (ReportLoader.class) {
			reports = null;
		}
	}
	
	private static void processRecursive(Node node, ReportSettingsBean reportBean){
		if (node.getNodeName().equals("report")){
			processReportNode(node, reportBean);
		}
		
		
		if(node.getNodeName().equals("name")){
			processNameNode(node, reportBean);
		}
		else if(node.getNodeName().equals("authorization")){
			processAuthorizationNode(node, reportBean);
		}
		else if(node.getNodeName().equals("sql")){
			processSqlNode(node, reportBean);
		}
		else if(node.getNodeName().equals("usedates")){
			processUseDatesNode(node, reportBean);
		}
		else if(node.getNodeName().equals("output")){
			processOutputNode(node, reportBean);
		}
		else {
			NodeList childNodes = node.getChildNodes();
			for (int i=0; i<childNodes.getLength(); i++){
				processRecursive(childNodes.item(i), reportBean);
			}
		}
	}
	
	private static String getChildText(Node node){
		NodeList nodes =  node.getChildNodes();
		StringBuffer text = new StringBuffer();
		for (int i=0; i<nodes.getLength(); i++){
			Node child = nodes.item(i);
			if (child.getNodeType() == Node.TEXT_NODE){
				text.append(child.getNodeValue());
			}
		}
		return text.toString();
	}
	
	private static void processReportNode(Node node, ReportSettingsBean reportBean) {
		logger.debug("processing 'report' node");
		Node idAttrib = node.getAttributes().getNamedItem("id");
		reportBean.setId(idAttrib.getNodeValue());
		logger.debug("report id set to:"+reportBean.getId());
	}
	
	private static void processNameNode(Node node, ReportSettingsBean reportBean) {
		logger.debug("processing 'name' node");
		reportBean.setName(getChildText(node));
		logger.debug("report name set to:"+reportBean.getName());
	}
	
	private static void processAuthorizationNode(Node node, ReportSettingsBean reportBean) {
		logger.debug("processing 'authorization' node");
		reportBean.setAuthorization(getChildText(node));
		logger.debug("report authorization set to:"+reportBean.getAuthorization());
	}
	
	private static void processSqlNode(Node node, ReportSettingsBean reportBean) {
		logger.debug("processing 'sql' node");
		reportBean.setSql(getChildText(node));
		logger.debug("report sql set to:"+reportBean.getSql());
	}

	private static void processUseDatesNode(Node node, ReportSettingsBean reportBean) {
		logger.debug("processing 'usedates' node");
		reportBean.setUsedates(getChildText(node));
		logger.debug("report Use Dates set to:"+reportBean.getUsedates());
	}
	
	private static void processOutputNode(Node node, ReportSettingsBean reportBean) {
		logger.debug("processing 'output' node");
		reportBean.setOutput(getChildText(node));
		logger.debug("report Output set to:"+reportBean.getOutput());
	}

	

}
