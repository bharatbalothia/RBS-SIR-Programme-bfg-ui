/***************************************************************************
                                                        Version 4 Menu ARRAYS
***************************************************************************/

/**************************/
/* Business Process Menu */
/*************************/

HM_Array1 = [
[116,           // menu width
172,            // left_position
78,                    // top_position
"#E9E9E9",      // font_color
"#3A3A3A",   // mouseover_font_color
"#787CB9",   // background_color
"#A1A5DF",    // mouseover_background_color
"#606060",     // border_color
"#606060",    // separator_color
0,          // top_is_permanent
0,          // top_is_horizontal
0,          // tree_is_horizontal
1,          // position_under
1,          // top_more_images_visible
1,          // tree_more_images_visible
"null",     // evaluate_upon_tree_show
"null",     // evaluate_upon_tree_hide
],          //right-to-left
["Manager","./Page?next=page.processbuilder",1,0,0],
["Monitor","",1,0,2]
]

HM_Array1_2 = [
[],
["Advanced Search","",1,0,1],
["Central Search","javascript:addTimeZone('./CentralSearch?next=page.displayxform&templateName=CentralSearch')",1,0,0],
["Current Processes","./BPMonitor?action=search&summaryPageType=curproc&next=page.bpmonitorsummary&bad=page.bpmonitorprocerr&where=live&autoRefresh=1",1,0,0],
["Current Activities","./Page?next=page.svcmonitorsearch",1,0,0]
]


HM_Array1_2_1 = [
[],
["BPSS Correlation","./BPSSCorrelationSearch?next=page.displayxform&templateName=BPSSCorrelationSearch",1,0,0],
["ebXML Correlation","./ebXMLCorrelationSearch?next=page.displayxform&templateName=ebXMLCorrelationSearch",1,0,0],
["Business Processes","./BPMonitor?next=page.bpsearch&where=live",1,0,0],
["Correlation","./CorrelationSearch?next=page.displayxform&templateName=CorrelationSearch",1,0,0],
["Documents","./DocMonitor?next=page.docsearch&where=live",1,0,0],
["EDI Correlation","./EDICorrelationSearch?next=page.displayxform&templateName=EDICorrelationSearch",1,0,0],
["EDIINT","./Page?next=page.ediinttransactionsearch",1,0,0],
["GENTRAN:Server for UNIX","./GSSearch?templateName=GSAdvanceSearch",1,0,0]
]



/**************************/
/* Trading Partners menu  */
/**************************/

HM_Array2 = [
[116,           // menu width
289,            // left_position
78,                    // top_position
"#E9E9E9",      // font_color
"#3A3A3A",   // mouseover_font_color
"#CE8A2C",   // background_color
"#D2AC55",    // mouseover_background_color
"#606060",     // border_color
"#606060",    // separator_color
0,          // top_is_permanent
0,          // top_is_horizontal
0,          // tree_is_horizontal
0,          // position_under
1,          // top_more_images_visible
1,          // tree_more_images_visible
"null",     // evaluate_upon_tree_show
"null",     // evaluate_upon_tree_hide
],          //right-to-left

["Setup","",1,0,1],
["Digital Certificates","",1,0,2],
["Document Envelopes","",1,0,3],
["Contracts","./Page?next=page.contractsearch",1,0,0],
//["ebXML CPA","./Page?next=page.cpa",1,0,0],
["Code Lists","./Page?next=page.codelistsearch",1,0,0],
["SSH","",1,0,4]
]

HM_Array2_1 = [
[],
["Basic","./Page?next=page.partner",1,0,0],
["Advanced","",1,0,2],
["AS2","./Page?next=page.as2",1,0,0]
//["ebXML CPP","./Page?next=page.cpp",1,0,0]
]


HM_Array2_1_2 = [
[],
["Identities","./Page?next=page.entitysearch",1,0,0],
["Transports","./Page?next=page.transportsearch",1,0,0],
["Document Exchange","./Page?next=page.exchangesearch",1,0,0],
["Delivery Channels","./Page?next=page.deliverysearch",1,0,0],
["Packaging","./Page?next=page.packagingsearch",1,0,0],
["Profiles","./Page?next=page.profilesearch",1,0,0]
]

HM_Array2_2 = [
[],
["CA","./Page?next=page.cacertsearch",1,0,0],
["Trusted","./Page?next=page.certsearch",1,0,0],
["System","./Page?next=page.systemcertsearch",1,0,0]
]

HM_Array2_3 = [
[],
["Envelopes","./Page?next=page.envelopesearch",1,0,0],
["Control Numbers","./Page?next=page.numsearch",1,0,0],
["Transaction Register","./Page?next=page.tsregsearch",1,0,0],
["Control Number History","./Page?next=page.cnhsearch",1,0,0],
["EDI Sequence Check Queue","./Page?next=page.ediseqcheck",1,0,0]
]


HM_Array2_4 = [
[],
["Remote Profiles","./Page?next=page.sftp",1,0,0],
["Known Host Key","./Page?next=page.remotehostkeysearch",1,0,0],
["User Identity Key","./Page?next=page.localuserkeysearch",1,0,0],
["Authorized User Key","./Page?next=page.remoteuserkeysearch",1,0,0]
]

/*********************************************************/
/* Deployment Menu when Trading Profiles are in the system*/
/********************************************************/
HM_Array3 = [
[116,           // menu width
406,           //left_position
78,           //  top_position
"#E9E9E9",      // font_color
"#3A3A3A",   // mouseover_font_color
"#4F8888",   // background_color
"#75ABA1",    // mouseover_background_color
"#606060",     // border_color
"#606060",    // separator_color
0,          // top_is_permanent
0,          // top_is_horizontal
0,          // tree_is_horizontal
1,          // position_under
1,          // top_more_images_visible
1,          // tree_more_images_visible
"null",     // evaluate_upon_tree_show
"null",     // evaluate_upon_tree_hide
],          //right-to-left
["Services","",1,0,1],
["Schedules","./Page?next=page.schedulemgmt",1,0,0],
["Maps","./Page?next=page.mapmanagement",1,0,0],
["XSLT","./Page?next=page.xsltmgmt",1,0,0],
["Mailboxes","",1,0,4],
["EBXML","",1,0,8],
["Web Extensions","",1,0,5],
["Schemas","./Page?next=page.schemamgmt",1,0,0],
["Resource Manager","",1,0,7],
["Adapter Utilities","",1,0,6],
["PGP Profile Manager","./Page?next=page.pgpmgmt",1,0,0],
["SSH Host Identity Key","./Page?next=page.lclhostkey",1,0,0],
["Web Services","",1,0,9]
]



HM_Array3_1 = [
[],
["Installation/Setup","./Page?next=page.servicesetupsearch",1,0,0],
["Configuration","./Page?next=page.searchservices",1,0,0]
]

HM_Array3_4 = [
[],
["Configuration","./Page?next=page.mbconfigmgmt",1,0,0],
["Virtual Roots","./Page?next=page.mbvirtualrootmgmt",1,0,0],
["Routing Rules","./Page?next=page.mbrrmgmt",1,0,0],
["Messages","./Page?next=page.mbmessagemgmt",1,0,0]
]

HM_Array3_5 = [
[],
["Web Templates","./Page?next=page.webxmapmanagement",1,0,0],
["Web Resources","./Page?next=page.wrmgmt",1,0,0],
["Utilities","./Page?next=page.webxdownloads",1,0,0]
]

HM_Array3_6 = [
[],
["SAP Suite Builder","./Page?next=page.sapwiz",1,0,0], 
["SAP Routes","",1,0,1],
["Sync Engine","",1,0,2],
["BEA Tuxedo","./Page?next=page.webtuxedomgmt",1,0,0],
["Service SDK","./Page?next=page.sdkconfig",1,0,0]
]

HM_Array3_6_1 = [
[],
["SAP Routes","./Page?next=page.saproutesearch",1,0,0],
["SAP Route X-REF","./Page?next=page.saproutexref",1,0,0]
]

HM_Array3_6_2 = [
[],
["Trading Partners","./Page?next=page.syncenginetp",1,0,0],
["Data Pool Profile","./Page?next=page.dppmgmt",1,0,0],
["Perimeter Services","./Page?next=page.psconfig",1,0,0]
]

HM_Array3_7 = [
[],
["Resource Tags","./Page?next=page.tagmgmt",1,0,0],
["Import/Export","./Page?next=page.impexp",1,0,0]
]


HM_Array3_8 = [
[],
["BPSS","./Page?next=page.bpssmgmt",1,0,0],
["BPSS Extension","./Page?next=page.bpssext",1,0,0],
["CPA","./Page?next=page.cpamgmt",1,0,0]
]


HM_Array3_9 = [
[],
["Manager","./Page?next=page.webservicesmgmt",1,0,0],
["Schema Mappings","./Page?next=page.bpschemamgmt",1,0,0],
["WSDL Check In","./Page?next=page.wsdlmgmt",1,0,0]
]

/***********************************************************/
/* Operations Menu  when Trading Profiles are in the System*/
/***********************************************************/
HM_Array4 = [
[116,           // menu width
523,            // left_position
78,             // top_position
"#E9E9E9",      // font_color
"#3A3A3A",   // mouseover_font_color
"#975F98",   // background_color
"#BD94BE",    // mouseover_background_color
"#606060",     // border_color
"#606060",    // separator_color
0,          // top_is_permanent
0,          // top_is_horizontal
0,          // tree_is_horizontal
0,          // position_under
1,          // top_more_images_visible
1,          // tree_more_images_visible
"null",     // evaluate_upon_tree_show
"null",     // evaluate_upon_tree_hide
],          //right-to-left
["System","",1,0,1],
["Reports","./Page?next=page.reportmanager",1,0,0],
["Thread Monitor","./SystemOps?next=page.actmonitor&autorefresh=true",1,0,0],
["Archive Manager","./Page?next=page.archivemanager",1,0,0],
["Lock Manager","./Page?next=page.lockmanager",1,0,0],
["Sequence Manager","./Page?next=page.sequencesearch&name=all&where=all",1,0,0],
["Message Monitor","./Page?next=page.msgmonitor",1,0,0],
["Federated Systems","./Page?next=page.peermgmt",1,0,0],
["Perimeter Servers","./Page?next=page.pservermgmt",1,0,0]

]


HM_Array4_1 = [
[],
["Troubleshooter","./SystemOps?next=page.operations",1,0,0],
["Performance","", 1,0,2],
["Support Tools","./Page?next=page.keysearch",1,0,3],
["Logs","./SystemOps?next=page.systemlogs",1,0,0],
["Licenses","./Page?next=page.keysearch",1,0,0],
["Cluster","",1,0,4]
]

HM_Array4_1_2 = [
[],
["Tuning","./Page?next=page.performancetune",1,0,0],
["Statistics","./Page?next=page.perfstatistic",1,0,0]
]

HM_Array4_1_3 = [
[],
["SQL Manager","./Page?next=page.sqltool",1,0,0],
["Support Case","./getsuppcase?WizardAction=add",1,0,0]
]

HM_Array4_1_4 = [
[],
["Node Status","./Page?next=page.nodeinfo",1,0,0]
]

/***************************************************/
/* Accounts menu - Trading Partners - Admin access */
/***************************************************/
HM_Array5 = [
[116,           // menu width
640,            // left_position
78,                    // top_position
"#E9E9E9",      // font_color
"#3A3A3A",   // mouseover_font_color
"#A26854",   // background_color
"#C9917D",    // mouseover_background_color
"#606060",     // border_color
"#606060",    // separator_color
0,          // top_is_permanent
0,          // top_is_horizontal
0,          // tree_is_horizontal
0,          // position_under
1,          // top_more_images_visible
1,          // tree_more_images_visible
"null",     // evaluate_upon_tree_show
"null",     // evaluate_upon_tree_hide
],          //right-to-left
["Groups","./Page?next=page.groupmgmt",1,0,0],
["Permissions","./Page?next=page.permmgmt",1,0,0],
["User Accounts","./Page?next=page.usermgmt",1,0,0],
["Password Policy","./Page?next=page.pwdmgmt",1,0,0],
["User News","./Page?next=page.usermsgsearch",1,0,0],
["My Account","./Page?next=page.myaccount",1,0,0]
]


/*********************************************************/
/* Accounts menu  NO Admin access */
/*********************************************************/
HM_Array6 = [
[116,           // menu width
640,            // left_position
78,                    // top_position
"#E9E9E9",      // font_color
"#3A3A3A",   // mouseover_font_color
"#A26854",   // background_color
"#C9917D",    // mouseover_background_color
"#606060",     // border_color
"#606060",    // separator_color
0,          // top_is_permanent
0,          // top_is_horizontal
0,          // tree_is_horizontal
0,          // position_under
1,          // top_more_images_visible
1,          // tree_more_images_visible
"null",     // evaluate_upon_tree_show
"null",     // evaluate_upon_tree_hide
],          //right-to-left
["My Account","./Page?next=page.myaccount",1,0,0]
]

















