package ic2.ui;


/**
 * @author Ravi K Patel
 * created Apr 3, 2006
 */

/**
 * Wait keys (token is probably a better term) are unique interger (returned as a String) references.
 * They can be used with the WaitKeyMap to store references to objects accross Http Requests, instead of placing the object into
 * User Session. By using the WaitKey, several transactions can take place in the same session, whereas the Session variable may be overwritten
 * 
 */
public class WaitKey {

	private static int nextWaitKey = 0;
	
	private WaitKey(){}
	
	public static synchronized String getWaitKey(){
		return Integer.toString(nextWaitKey++);
	}
	
}
