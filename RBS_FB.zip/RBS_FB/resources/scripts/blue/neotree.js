addEvent(window, "load", makeTreesC);

function makeTreesC() {
    if (!document.createElement) return;
    
    uls = document.getElementsByTagName("ul");
    for (uli=0;uli<uls.length;uli++) {
        ul = uls[uli];
        if (ul.nodeName == "UL" && ul.className == "neotree") {
            processULELC(ul);
        }
    }
}

function processULELC(ul) {
    if (!ul.childNodes || ul.childNodes.length == 0) return;
    for (var itemi=0;itemi<ul.childNodes.length;itemi++) {
        var item = ul.childNodes[itemi];
        if (item.nodeName == "LI") {
            // Iterate things in this LI
            var a;
            var subul;
	    subul = "";
            for (var sitemi=0;sitemi<item.childNodes.length;sitemi++) {
                var sitem = item.childNodes[sitemi];
                switch (sitem.nodeName) {
                    case "A": a = sitem; break;
                    case "UL": subul = sitem; 
                               processULELC(subul);
                               break;
                }
            }
            if (subul) {
                associateELC(a,subul);
            } else {
                a.parentNode.className = "menubullet";
            }
        }
    }
}

function associateELC(a,ul) {
    if (a.parentNode.className.indexOf('menuopen') == -1)
      a.parentNode.className = 'menuclosed';
    a.onclick = function () {
        this.parentNode.className = (this.parentNode.className=='menuopen') ? "menuclosed" : "menuopen";
        return false;
    }
}

function addEvent(obj, evType, fn){
  if (obj.addEventListener){
    obj.addEventListener(evType, fn, true);
    return true;
  } else if (obj.attachEvent){
	var r = obj.attachEvent("on"+evType, fn);
    return r;
  } else {
	return false;
  }
}
