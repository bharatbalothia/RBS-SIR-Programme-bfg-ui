/*
 * (C) Copyright 2001 - 2008 Sterling Commerce, Inc. ALL RIGHTS RESERVED
 *
 * ** Trade Secret Notice **
 *
 * This software, and the information and know-how it contains, is
 * proprietary and confidential and constitutes valuable trade secrets
 * of Sterling Commerce, Inc., its affiliated companies or its or
 * their licensors, and may not be used for any unauthorized purpose
 * or disclosed to others without the prior written permission of the
 * applicable Sterling Commerce entity. This software and the
 * information and know-how it contains have been provided
 * pursuant to a license agreement which contains prohibitions
 * against and/or restrictions on its copying, modification and use.
 * Duplication, in whole or in part, if and when permitted, shall
 * bear this notice and the Sterling Commerce, Inc. copyright
 * legend. As and when provided to any governmental entity,
 * government contractor or subcontractor subject to the FARs,
 * this software is provided with RESTRICTED RIGHTS under
 * Title 48 CFR 52.227-19.
 * Further, as and when provided to any governmental entity,
 * government contractor or subcontractor subject to DFARs,
 * this software is provided pursuant to the customary
 * Sterling Commerce license, as described in Title 48
 * CFR 227-7202 with respect to commercial software and commercial
 * software documentation.
 */
package com.sterlingcommerce.woodstock.adminui.jspbean;

// Java stuff

import com.sterlingcommerce.rbs.filebroker.dualcontrol.DualControlUtil;
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Properties;

// stercomm
import com.sterlingcommerce.woodstock.util.Util;
import com.sterlingcommerce.woodstock.util.NameValuePairs;
import com.sterlingcommerce.woodstock.util.NameValue;
import com.sterlingcommerce.woodstock.security.Permission;
import com.sterlingcommerce.woodstock.ui.*;
import com.sterlingcommerce.woodstock.ui.jspbean.*;
import com.sterlingcommerce.woodstock.util.frame.Manager;


/**
 * The PermBean class is a bean used in the Woodstock administration
 * system to provide configuration for a account management.
 */
@SuppressWarnings({"unchecked", "unused", "static-access"})
public class PermBean extends WizardBeanBase implements WizardBean {
    private com.sterlingcommerce.woodstock.security.Permission perm = null;

    public void init(LangBean lb, Permission p) {
	perm = p;
	setLang(lb);
    }

    public String getTitle() {
	if (perm!=null) {
	    return perm.getPermission();
	} else {
	    return langbean.getValue("unavailable");
	}
    }

    /**
     * Method for retrieving the Wizard header
     * @return theHeader String
     *
     */
    public String getHeader() {

        if (perm == null)
	    perm = (Permission)wiz.editObj();

	String name = null;

	if(perm != null) {
	    name = perm.getPermission();
	} else {
	    name = langbean.getValue("PERM.newPermission");
	}

	if (page!=null && !page.pageType.equals("FINISH")) {
	    if (name != null && name.length() > 0)
		return name +": " +  super.getHeader();
	}
	return name;
    }

    /**
     * Method for retrieving the javascript validators
     * specific to the wizard pages
     * @return validatorFunctions String
     */
    public String getValidator() {
        StringBuffer s = new StringBuffer();
        s.append("");
        if (page.activity.equals("permNameEdit")) {
            addValidCharsTest(s, "PERM_permname",  langbean.getValue("PERM.permName"), "1");
            if (wiz.action == Wizard.ADD){
	        addValidCharsTest(s, "PERM_permid", langbean.getValue("PERM.permID"), "1");
            }
	}

	if (page.activity.equals("permAccConfirmDelete")) {
	    addImgRadioTest(s, "PERM_permname", langbean.getValue("PERM.permName"));
	}

        return s.toString();
    }



    /**
     * Method for building the html inputs
     * @return html String
     */
    public String getInputs() {
        StringBuffer s = new StringBuffer();
        s.append("");
        perm = (Permission)wiz.editObj();

        //this is for editing
        if (page.activity.equals("permNameEdit")) { //Perm name
            buildPermName(s);
	} else if (page.activity.equals("permPermissionEdit")) { // perm
            buildPermissionEdit(s);
	} else if (page.activity.equals("permAccQuestion")) {
            buildAccQuestion(s);
	} else if (page.activity.equals("permConfirmEdit") || page.activity.equals("permConfirmDelete")) {
            buildConfirm(s);
	}

        return s.toString();
    }


    /**
     * Method for building the confirm question for user deletion
     * and the list of available permission groups to move the users to
     *
     * @param buf StringBuffer to append to
     */
    @SuppressWarnings("unchecked")
	private void  buildAccQuestion(StringBuffer buf){

	buf.append("<table>");
	String theName = "";
	boolean val = false;

	if(perm != null){
	    val = true;
	    theName = perm.getPermission();
	}
	Enumeration enum2 = null;

	String s = "";

	buf.append("<tr class=\"WizardInputText\">");
	buf.append("<td>");
	makeImage(buf, "images.spacer", null, "2", null);
	buf.append(langbean.getValue("PERM.permUsers"));
	buf.append(": ");

	buf.append("<tr class=\"className\">");
	buf.append("<td>");

	if(enum2 != null){
	    while (enum2.hasMoreElements()) {
		s = (String)enum2.nextElement();
		makeImage(buf, "images.spacer", null, "2", null);
		buf.append(s);
		buf.append("<br>");
	    }
	} else {
	    makeImage(buf, "images.spacer", null, "2", null);
	    buf.append(langbean.getValue("PERM.noPermUsers"));
	}

	buf.append("</td></tr>\n</table>");
    }


    /**
     * Method for building the confirm question for user deletion
     * and the list of available permission groups to move the users to
     *
     * @param buf StringBuffer to append to
     */
//    private void buildPermissionList(StringBuffer buf){
//
//    }


    /**
     * Method for building the PermName input box
     *
     * @param buf StringBuffer to append to
     */
    private void buildPermName(StringBuffer buf) {
        String s = perm.getPermissionid();
        if(s == null) s = "";

        buf.append("<table><tr>");
        if (wiz.action == Wizard.ADD) {
            buildReqInputBox(buf, langbean.getValue("PERM.permID"), "PERM_permid", s, "32", "64");
        } else {
            buf.append("<td valign=\"bottom\" class=\"WizardAccountsText\">");
            buf.append(langbean.getValue("PERM.permID"));
            buf.append(":</td><td>");
            buf.append(BaseUIGlobals.processHTMLDisplayValue(s));
            buf.append("</td>");
        }

	s = perm.getPermission();
	if (s == null) s = "";

        buf.append("</tr><tr>");
        buildReqInputBox(buf, langbean.getValue("PERM.permName"), "PERM_permname", s, "32", "64");

        buf.append("</tr>");

        buildPermType( buf );

        buf.append("</tr></table>");
    }

    /**
     * generates the permission drop downs for the all availble and active
     * components in the system
     *
     * @param buf StringBuffer
     */
    private void buildPermissionEdit(StringBuffer buf) {
      if(BaseUIGlobals.out.debug)
        BaseUIGlobals.out.logDebug("PermBean - not implemented : " + buf.toString());
   }

    /**
     * generates the selected permission display for the all availble and active
     * components in the system
     *
     * @param buf StringBuffer
     */
    private void buildPermissionConfirm(StringBuffer sb) {
      if(BaseUIGlobals.out.debug)
        BaseUIGlobals.out.logDebug("PermBean - not implemented : " + sb.toString());
    }


    public String getPermDetails() {
        StringBuffer buf = new StringBuffer();
	String className = "grayStripe";

	if (perm!=null) {

	    buf.append("<table cellpadding=0 cellspacing=0 border=0 width=400 valign='top'>\n");

	    buf.append("<tr>");
	    startStripeCell(buf, "WizardInputText", "colspan=4");
	    buf.append(langbean.getValue("PermissionSettings"));
	    buf.append("</td>\n");
	    buf.append("</tr>\n");
	    addHSpace(buf, "4");
	    addHSpace(buf, "4", null, "1");
	    addHSpace(buf, "4");
	    spacerLine(buf);

	    buf.append("<tr>");
	    startStripeCell(buf, className, "width=240");
	    buf.append(langbean.getValue("PERM.permName"));
	    buf.append("</td>\n");
	    addVSpace(buf, "whitespacer", "1", null);
	    addVSpace(buf, className, "5", null);
	    startStripeCell(buf, className, null);
	    buf.append(BaseUIGlobals.processHTMLDisplayValue(perm.getPermission()));
	    buf.append("</td>");
	    buf.append("</tr>\n");


	    spacerLine(buf);
	    addHSpace(buf, "4", "whitespacer","1");
	    spacerLine(buf);

	    buf.append("<tr>");
	    startStripeCell(buf, className, "width=240");
	    buf.append(langbean.getValue("PERM.permID"));
	    buf.append("</td>\n");
	    addVSpace(buf, "whitespacer", "1", null);
	    addVSpace(buf, className, "5", null);
	    startStripeCell(buf, className, null);
	    buf.append(BaseUIGlobals.processHTMLDisplayValue(perm.getPermissionid()));
	    buf.append("</td>");
	    buf.append("</tr>\n");


	    spacerLine(buf);
	    addHSpace(buf, "4", "whitespacer","1");
	    spacerLine(buf);
	    buf.append("</table>");
	}

	return buf.toString();
    }


    /**
     * generates the view of the edited perm, containing all the info
     * like permName, ad chosen permissions/components.
     * @param buf StringBuffer
     */
    private void buildConfirm(StringBuffer buf) {


        buf.append("<table cellpadding=0 cellspacing=0 border=0 width=520>\n");
        String className = "whiteStripe";

        buf.append("<tr>");
        startStripeCell(buf, "WizardInputText", "colspan=4 ");
        buf.append(langbean.getValue("PermissionSettings"));
        buf.append("</td>\n");
        buf.append("</tr>\n");
        addHSpace(buf, "4");
        addHSpace(buf, "4", null, "1");
        addHSpace(buf, "4");
        spacerLine(buf, 2);

	buf.append("<tr>");
	startStripeCell(buf, className, "width=200");
	buf.append(langbean.getValue("PERM.permName"));
	buf.append("</td>\n");
	addVSpace(buf, "ltspacer", "1", null);
	addVSpace(buf, className, "5", null);
	startStripeCell(buf, className, null);
	buf.append(BaseUIGlobals.processHTMLDisplayValue(perm.getPermission()));
	buf.append("</td>");
	buf.append("</tr>\n");

	spacerLine(buf, 2);
	addHSpace(buf, "4", "ltspacer","1");
	spacerLine(buf, 2);

	buf.append("<tr>");
	startStripeCell(buf, className, "width=200");
	buf.append(langbean.getValue("PERM.permID"));
	buf.append("</td>\n");
	addVSpace(buf, "ltspacer", "1", null);
	addVSpace(buf, className, "5", null);
	startStripeCell(buf, className, null);
	buf.append(BaseUIGlobals.processHTMLDisplayValue(perm.getPermissionid()));
	buf.append("</td>");
	buf.append("</tr>\n");

	spacerLine(buf, 2);
	addHSpace(buf, "4", "ltspacer","1");
	spacerLine(buf, 2);

        Properties props = Manager.getProperties("ADMIN-UI");
        String type = "" ;
        if( props != null ) {
            type = props.getProperty("PERM.type."+String.valueOf( perm.getPermType() ));
            if ( type == null )
                type = langbean.getValue("Label.notspecified");
        }
        buf.append("<tr>");
	startStripeCell(buf, className, "width=200");
	buf.append(langbean.getValue("PERM.permType"));
	buf.append("</td>\n");
	addVSpace(buf, "ltspacer", "1", null);
	addVSpace(buf, className, "5", null);
	startStripeCell(buf, className, null);
	buf.append( type );
	buf.append("</td>");
	buf.append("</tr>\n");

        spacerLine(buf, 2);
        addHSpace(buf, "4");
        
        //Dual Control form - start
        DualControlUtil dcu = new DualControlUtil();
        buf.append(dcu.buildDualControlSection(wiz.session()));
        //Dual Control form -end
        
        addHSpace(buf, "4", null, "20");
        buf.append("</table>\n");
    }

    /**
     * Builds the listbox for permission types
     */
    @SuppressWarnings("unchecked")
	private void buildPermType( StringBuffer sb ) {
	sb.append("<tr><td valign=\"bottom\" class=\"WizardInputText\">");
	sb.append(langbean.getValue("PERM.permType"));
	sb.append(":</td><td>");

	if (perm != null) {
	    String s = perm.getPermType();
	    if (s == null) s = "";

	    NameValuePairs nvp = new NameValuePairs();
            Properties props = Manager.getProperties("ADMIN-UI");
            if( props != null ) {
            	// Since each clump now has its own allocated range of permission type
            	// numbers, the numbers won't be contiguous.
            	
            	// Iterator through and find the permission properties, making a
            	// list of the numbers so that we can sort them.
            	Iterator i = props.keySet().iterator();
            	ArrayList<Integer> numList = new ArrayList<Integer>(20);
            	String num;
            	String key;
            	while (i.hasNext()) {
            		key = (String)i.next();
            		if ((key.startsWith("PERM.type.")) && (!"PERM.type.99".equals(key))) {
            			num = key.substring(10);
            			numList.add(Integer.parseInt(num));
            		}
            	}
            	Collections.sort(numList);
            	Iterator<Integer> numIt = numList.iterator();
            	String numStr;
            	while (numIt.hasNext()) {
            		numStr = String.valueOf(numIt.next());
            		key = "PERM.type." + numStr;
        			nvp.addElement(props.getProperty(key), numStr);	
            	}

            	// Add in "Other".
            	String otherType = props.getProperty("PERM.type.99");
            	if (otherType != null) {
            		nvp.addElement(otherType, "99");
            	}
            }
	    buildSelectList( sb, "PERM_permtype", nvp, s, true );
	}
	sb.append("</td></tr>");
    }


    /**
     * Generates a String representation of the object.
     * @return String
     */
    public String toString() {
	StringBuffer s = new StringBuffer();
	s.append("Perm Object:\n");
	return s.toString();
    }


    public void spacerLine(StringBuffer buf) {
	spacerLine(buf,2);
    }




    /**
     * Builds the navigation buttons for the wizard page.
     * @return String
     */
    public String getActionButtons() {
        StringBuffer buffer = new StringBuffer();

	if (page.activity.equals("permAccQuestion") ||
	    (page.activity.equals("permAccConfirmDelete"))) {

	    // have to disable "delete" buttons here
	    buffer.append("<input type='hidden' name='pageno' value='");
	    buffer.append(pageno);
	    buffer.append("'>\n");

	    if (!page.pageType.startsWith("FINISH")) {
		if (wiz.currentPage != wiz.firstActivePage()) {
		    buffer.append("<a href=\"javascript:document.wizform.submit()\" ");
		    buffer.append("onClick=\"return isReady(document.wizform,'Back',");
		    buffer.append(pageno);
		    buffer.append(",'");
		    buffer.append("no");
		    buffer.append("');\"");
		    buffer.append(" onMouseover=\"chgButton('wizback','BackOver'); window.status='");
		    buffer.append(langbean.getValue("wizard.Back"));
		    buffer.append("'; return true;\"");
		    buffer.append(" onMouseout=\"chgButton('wizback','BackOff'); window.status=''; ");
		    buffer.append("return true;\"");
		    buffer.append(" onMouseDown=\"chgButton('wizback','BackDown'); return true;\"");
		    buffer.append(" onMouseUp=\"chgButton('wizback','BackOff'); return true;\">");
		    makeImage(buffer, "images.wiz.backoff", null, "23", "wizback", "align='top'");
		    buffer.append("</a>\n");

		}
		else {
		    makeImage(buffer,"images.wiz.backinact",null, "23", "wizback", "align='top'");
		    buffer.append("\n");
		}

		buffer.append("<a href=\"javascript:document.wizform.submit()\" ");
		buffer.append("onClick=\"return isReady(document.wizform,'Next',");
		buffer.append(pageno);
		buffer.append(",'');\"");
		buffer.append(" onMouseover=\"chgButton('wiznext','NextOver'); window.status='");
		buffer.append(langbean.getValue("wizard.Next"));
		buffer.append("'; return true;\"");
		buffer.append(" onMouseout=\"chgButton('wiznext','NextOff'); window.status=''; ");
		buffer.append("return true;\"");
		buffer.append(" onMouseDown=\"chgButton('wiznext','NextDown'); return true;\"");
		buffer.append(" onMouseUp=\"chgButton('wiznext','NextOff'); return true;\">");
		makeImage(buffer, "images.wiz.nextoff", null, "23", "wiznext", "align='top'");
		buffer.append("</a>\n");


		buffer.append("<a href=\"javascript:document.wizform.submit()\" ");
		buffer.append("onClick=\"return isReady(document.wizform,'Cancel',");
		buffer.append(pageno);
		buffer.append(",'no');\"");
		buffer.append(" onMouseover=\"chgButton('wizcancel','CancelOver'); window.status='");
		buffer.append(langbean.getValue("wizard.Cancel"));
		buffer.append("'; return true;\"");
		buffer.append(" onMouseout=\"chgButton('wizcancel', 'CancelOff'); window.status=''; ");
		buffer.append("return true;\"");
		buffer.append(" onMouseDown=\"chgButton('wizcancel','CancelDown'); return true;\"");
		buffer.append(" onMouseUp=\"chgButton('wizcancel','CancelOff'); return true;\">");

		makeImage(buffer, "images.wiz.canceloff", null, "23", "wizcancel", "align='top'");
		buffer.append("</a>\n");

		makeImage(buffer,"images.wiz.deleteinact",null, "23", "wizdelete", "align='top'");
		buffer.append("\n");
	    }

	    return buffer.toString();
	}
	else{
	    return super.getActionButtons();
	}
    }


    /**
     * Adds the available options for the current wizard.
     * @param wiz the Wizard object
     * @param wizCols the number of columns
     * @param selectedPage the page number for the current page.
     * @param currentLevel the current nesting level of the page.
     * @ param lastMain the last parent page
     */
    String getLinks(Wizard wiz,
                    int wizCols, int selectedPage, int currentLevel,
                    WizardStep lastMain, String displayName) {
        StringBuffer buffer = new StringBuffer(100);


        String environmentWidgets="";
        boolean showit=false;
        int blanks, colspan;
        int wizMaxCols = currentLevel+1;
        WizardStep p;
        WizardStep selectedWizParent;


        if (wizCols > 1) {
            buffer.append("\n<tr>");
            //            indentSection(1, buffer);
            indentSection(wizCols-1, buffer);
            buffer.append("<td class='navlinkfont' colspan='");
            buffer.append(String.valueOf(wizMaxCols+1));
            buffer.append("'>");
            // image for inactive?
            //      buffer.append("<img src='");
            //buffer.append(wiz.getStepWizard(selectedPage).location);
            //buffer.append("navinactive' border=\"0\"> ");
            //      if (wiz.add)
            //  buffer.append("Create new ");
            //else
            //  buffer.append("Edit ");
            buffer.append(langbean.getValue(displayName));
            buffer.append("</td></tr>\n");
        }

        selectedWizParent = (WizardStep)wiz.wizPages().elementAt(selectedPage);
        if (selectedWizParent.subOptionParent != null)
            selectedWizParent = selectedWizParent.subOptionParent;
        else
            selectedWizParent = null;
        for (int i=0; i<wiz.wizPages().size(); i++) {
            p = (WizardStep)wiz.wizPages().elementAt(i);
            if (p.active && !p.pageType.equals("CANCEL") &&
                !p.pageType.equals("FINISH") &&
                !p.pageType.equals("DELETE")) {

                showit=false;

                if (p.displayname != null) {
                    if (i == selectedPage || p.level == 0)
			showit=true;
                    else if (p.level < currentLevel) {
                        if (p.subOptionParent != null) {
                            if (p.isChild(lastMain))
                                showit=true;
                        }
                        else
                            showit=true;
                    }
                    else if (p.level == currentLevel) { // on the same level
                        if (selectedWizParent != null) {
                            if (p.isChild(selectedWizParent))
                                showit=true;
                        }
                        else
                            showit=true;
                    }

                }

                if (showit) {
                    buffer.append("\n<tr>");
		    //                indentSection(1, buffer);
                    if (wizCols > 1)
                        indentSection(wizCols, buffer);

                    colspan = wizMaxCols - p.level;
                    blanks = wizMaxCols - colspan;
                    indentSection(blanks, buffer);

                    // Selected one
                    if (i==selectedPage) {
                        buffer.append("\n<td class='navselected' colspan='");
                        buffer.append(String.valueOf(colspan));
                        buffer.append("'>");
			//                    buffer.append(">>");
			//                    buffer.append("<img src='");
			// buffer.append("./images/navon.gif' ");
			//buffer.append("selected' border=\"0\"> ");
                        makeImage(buffer, "images."+wiz.location+".navon");
                        buffer.append(" <b>");
                        buffer.append(langbean.getValue(p.displayname));
                        buffer.append("</b></td></tr>");
                    }
                    else {
                        buffer.append("\n<td class='navlinkfont' colspan='");
                        buffer.append(String.valueOf(colspan));


			if ((page.activity.equals("permAccQuestion") ||
			     (page.activity.equals("permAccConfirmDelete")))
			    && p.pageType.equals("CONFIRM")) {

			    super.addName(p, false, i, environmentWidgets, buffer);
			}
			else{
			    super.addName(p, wiz.linksActive, i, environmentWidgets, buffer);
			}
                        buffer.append("</td>\n</tr>\n");
                    }
                }
            }
        }
        return buffer.toString();
    }


    private void spacerLine(StringBuffer buf, int colNum) {

        if(colNum > 2) {

	    buf.append("<tr>\n");
	    buf.append("<td height='1'>\n");
	    makeImage(buf, "images.spacer", null, "1", null);
	    buf.append("</td>");

	    buf.append("<td height='1'>\n");
	    makeImage(buf, "images.spacer", null, "1", null);
	    buf.append("</td>\n</tr>\n");
	} else {

	    buf.append("<tr>\n");
	    buf.append("<td height='2'>\n");
	    makeImage(buf, "images.spacer", null, "2", null);
	    buf.append("</td>");
	    addVSpace(buf, "bodyspacer", "1", null);
	    addVSpace(buf, null, null, "4");
	    buf.append("<td height='2'>\n");
	    makeImage(buf, "images.spacer", null, "2", null);
	    buf.append("</td>\n</tr>\n");
	}
    }


}
