function openTrackingDetails(loc){
        var d = new Date();
        var winid = "Track"+"6o9ms";
        var width = 480;
        var height = 815;
        // RKP 2015-11-09: Add call below to add secure token to URL
        var locsecure = appendURL(loc);
        window.open(locsecure, winid , 'top=10,left=15,location=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width='+width+',height='+height).focus();
}


function openWin( loc, width, height){
        var d = new Date();
        var winid = "Info"+"6o9ms";
        // RKP 2015-11-09: Add call below to add secure token to URL
        var locsecure  = appendURL(loc);
        window.open(locsecure, winid , 'top=10,left=15,location=no,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width='+width+',height='+height).focus();
}


function openInfoWin( loc, width, height){
        var d = new Date();
        var winid = "Info"+d.getTime();
        // RKP 2015-11-09: Add call below to add secure token to URL
        var locsecure  = appendURL(loc);
        window.open(locsecure, winid , 'top=10,left=15,location=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width='+width+',height='+height).focus();
}


function refreshParentWindow(){

        if (opener != null && typeof(opener) != 'undefined'
                && opener.window != null && typeof(opener.window) != 'undefined'
                && opener.window.location != null && typeof(opener.window.location != 'undefined')) {
                opener.window.location.reload();
        }
}
