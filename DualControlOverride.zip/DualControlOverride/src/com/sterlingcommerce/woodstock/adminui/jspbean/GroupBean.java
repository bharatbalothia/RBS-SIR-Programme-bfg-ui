/****************************************************************************
 * IBM and Sterling Commerce Confidential
 *
 * OCO Source Materials
 *
 * Platform IFC version 1.3
 *
 * * (C) Copyright Sterling Commerce, an IBM Company 2007, 2011
 * 
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright Office.
 ****************************************************************************/

/*
 * (C) Copyright 2001 - 2010 Sterling Commerce, Inc. ALL RIGHTS RESERVED
 *
 * ** Trade Secret Notice **
 *
 * This software, and the information and know-how it contains, is
 * proprietary and confidential and constitutes valuable trade secrets
 * of Sterling Commerce, Inc., its affiliated companies or its or
 * their licensors, and may not be used for any unauthorized purpose
 * or disclosed to others without the prior written permission of the
 * applicable Sterling Commerce entity. This software and the
 * information and know-how it contains have been provided
 * pursuant to a license agreement which contains prohibitions
 * against and/or restrictions on its copying, modification and use.
 * Duplication, in whole or in part, if and when permitted, shall
 * bear this notice and the Sterling Commerce, Inc. copyright
 * legend. As and when provided to any governmental entity,
 * government contractor or subcontractor subject to the FARs,
 * this software is provided with RESTRICTED RIGHTS under
 * Title 48 CFR 52.227-19.
 * Further, as and when provided to any governmental entity,
 * government contractor or subcontractor subject to DFARs,
 * this software is provided pursuant to the customary
 * Sterling Commerce license, as described in Title 48
 * CFR 227-7202 with respect to commercial software and commercial
 * software documentation.
 */
package com.sterlingcommerce.woodstock.adminui.jspbean;

// Java stuff

import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import java.util.Enumeration;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;
import java.util.HashSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Hashtable;
import java.util.Arrays;

// stercomm
import com.sterlingcommerce.woodstock.util.NameValuePairs;
import com.sterlingcommerce.woodstock.util.NameValue;
import com.sterlingcommerce.woodstock.util.EntityUtil;
import com.sterlingcommerce.woodstock.security.Group;
import com.sterlingcommerce.woodstock.security.Permission;
import com.sterlingcommerce.woodstock.ui.*;
import com.sterlingcommerce.woodstock.ui.jspbean.*;
import com.sterlingcommerce.woodstock.util.frame.Manager;
import com.sterlingcommerce.woodstock.util.frame.cache.CacheManager;
import com.yantra.yfc.util.YFCCommon;

import com.sterlingcommerce.rbs.filebroker.dualcontrol.DualControlUtil;

/**
 * The GroupBean class is a bean used in the Woodstock administration
 * system to provide configuration for a account management.
 */
@SuppressWarnings({"unchecked", "unused", "static-access"})
public class GroupBean extends WizardBeanBase implements WizardBean {
    private com.sterlingcommerce.woodstock.security.Group grp = null;
    private Properties props = null;

    private static final String GROUP_STRING = "GROUP";
    private static final String PERM_STRING = "PERM";
    private static final String ENABLED_CHECKBOX = "images.Accounts.onbutton";
    private static final String DISABLED_CHECKBOX = "images.Accounts.inactiveButton";

    public void init(LangBean lb, Group p) {
    grp = p;
    setLang(lb);
    }

    public String getTitle() {
    if (grp!=null) {
        return grp.getGroupName();
    } else {
        return langbean.getValue("unavailable");
    }
    }

    /**
     * Method for retrieving the Wizard header
     * @return theHeader String
     *
     */
    public String getHeader() {

     grp = (Group)wiz.editObj();
     String name = null;
      if(grp != null) {
        name = grp.getGroupName();
        if (name == null) name = langbean.getValue("GROUP.newGroup");
     } else {
        name = langbean.getValue("GROUP.newGroup");
     }

    if (page!=null && !page.pageType.equals("FINISH")) {
        if (name != null && name.length() > 0)
        return name +": " +  super.getHeader();
    }
    return name;
    }

    /**
     * Method for retrieving the javascript validators
     * specific to the wizard pages
     * @return validatorFunctions String
     */
    public String getValidator() {
        StringBuffer s = new StringBuffer();
        s.append("");
        if (page.activity.equals("groupNameEdit")) {
            addValidCharsNoSlashTest(s, "GROUP_groupname",  langbean.getValue("GROUP.groupName"), "1");
            if (wiz.action == Wizard.ADD){
            addValidCharsNoSlashTest(s, "GROUP_groupid", langbean.getValue("GROUP.groupID"), "1");
            }
        }
        if (page.activity.equals("groupAccConfirmDelete")) {
           addImgRadioTest(s, "GROUP_groupname", langbean.getValue("GROUP.groupName"));
        }
        if (page.activity.equals("groupGroupEdit")) {
            multiPickerValidator(s, "assignlist");
        }
//        if (page.activity.equals("groupPermEdit")) 
//        {
//            multiPickerValidator(s, "assignlist");
//            
//        }
        return s.toString();
    }



    /**
     * Method for building the html inputs
     * @return html String
     */
    public String getInputs() {
        StringBuffer s = new StringBuffer();
        s.append("");
        grp = (Group)wiz.editObj();

        //this is for editing
        if (page.activity.equals("groupNameEdit")) { //Perm name
            buildGroupName(s);
    } else if (page.activity.equals("groupPermEdit")) {
        buildPermSelect(s);
    } else if (page.activity.equals("groupGroupEdit")) {
        buildGroupSelect(s);
        } else if (page.activity.equals("groupRightsEdit")) { // perms
            buildRightsSelect(s);
    } else if (page.activity.equals("groupAccQuestion")) {
            buildAccQuestion(s);
    } else if (page.activity.equals("groupConfirmEdit") || page.activity.equals("groupConfirmDelete")) {
            buildConfirm(s);
    }

        return s.toString();
    }

    private void buildGroupSelect(StringBuffer sb) {
        Vector selected_gids = new Vector();
        Vector allgroups  = new Vector();
        Vector groups  = new Vector();
        NameValuePairs fromList = new NameValuePairs();
        NameValuePairs toList = new NameValuePairs();
        String filter = "";

        if( props == null) props = Manager.getProperties("ADMIN-UI");
        String maxGroups = props.getProperty("maxGroupList");
        int imaxGroups= 1000;
        try { imaxGroups = Integer.parseInt(maxGroups); }
        catch( Exception ex ) { imaxGroups = 1000 ; }

        try {
              filter = grp.getSubGroupFilter();
              grp.removeTmpPerm();
              selected_gids = grp.getTmpGroups(); //BaseUIGlobals.securityMgr.listGroupsForUser( usrAccount.theAutho.getUserName() );
              allgroups = BaseUIGlobals.securityMgr.listAllGroups();
              if( filter == null ) filter = "";
              if( filter.trim().length() > 0 ) groups = BaseUIGlobals.securityMgr.listGroups(filter);
              else                             groups = allgroups ;

              Group _grp = null;

              SessionInfo sessionInfo = (SessionInfo)wiz.session().getAttribute("SessionInfo"); 
              boolean editingUserIsSuper = sessionInfo.getAutho().getSuper(); 

              for (int j=0; j< groups.size(); j++) {
            	  _grp = (Group)groups.elementAt(j);
            	  if (!_grp.getGroupid().equals( grp.getGroupid())){
            		  if( wiz.action != wiz.EDIT || !grp.hasSubGroup(_grp.getGroupid())) {
            			  if(!selected_gids.contains(_grp.getGroupid()))
            			  {
            				  if(_grp.getGroupid().equalsIgnoreCase("super") && !editingUserIsSuper){ 
            					  continue;  //we don't want to display the super user group for none super users. 
            				  } 
            			      fromList.addElement( _grp.getGroupid() , _grp.getGroupName());
            			  }
            		  }else {
            			  if( BaseUIGlobals.out.debug ) BaseUIGlobals.logDebug("[GroupBean] Ommiting group for circular reference:"+_grp.getGroupid());
            		  }
            	  }
              }
             for (int j=0; j< allgroups.size(); j++) {
                _grp = (Group)allgroups.elementAt(j);
                if(selected_gids.contains(_grp.getGroupid()))
                    toList.addElement(_grp.getGroupid(), _grp.getGroupName());
             }

            fromList.sort(false);
            toList.sort(false);
        }catch (Exception ex) {
              BaseUIGlobals.out.logException("[GroupBean]", ex);
        }

        boolean usingNS = false ;
        int i_ns = -1;

        if (wiz.session() != null) {
           Integer iv = (Integer)wiz.session().getAttribute("NS4Browser");
           if (null != iv) {           
           		i_ns = iv.intValue();
           	}
        }

        if( i_ns == 1 ) usingNS = true;

        buildMultiPicker( sb, fromList , toList, imaxGroups,
                          "filterdata", "byname", "groupname", filter,
                          "SelectGroups", "available", "assigned", "availlist", "assignlist", usingNS);
        buildMultiPickerJScript( sb );


    }

    private void buildPermSelect(StringBuffer sb) {

    	
    	if (grp.getAvailablePermissions() == null)
    	{
    		grp.initAvailableSelectedPermissions();
    	}
    	NameValuePairs fromList = grp.getAvailablePermissionsAsNVP();
        NameValuePairs toList = grp.getSelectedPermissionsAsNVP();
        NameValuePairs permTypes = new NameValuePairs();
        String nameFilter = "";
        String typeFilter = "";
        int selectedSize = toList.size();
        for(int i=0; i<selectedSize; i++){
        	NameValue elem = (NameValue)toList.get(i);
            String id = elem.name;
            if(fromList.getValue(id) != null){
            	fromList.removeElement(id);
            }
        }
        try {
            nameFilter = grp.getPermNameFilter();
            typeFilter = grp.getPermTypeFilter();
            String strGrp = null;
            Permission perm = null;

            Properties props = Manager.getProperties("ADMIN-UI");
            String type = "" ;
            permTypes.addElement( "" , "" );
            if( props != null ) {
            	// Since each clump now has its own allocated range of permission type
            	// numbers, the numbers won't be contiguous.
            	
            	// Iterator through and find the permission properties, making a
            	// list of the numbers so that we can sort them.
            	Iterator i = props.keySet().iterator();
            	ArrayList<Integer> numList = new ArrayList<Integer>(20);
            	String num;
            	String key;
            	while (i.hasNext()) {
            		key = (String)i.next();
            		if ((key.startsWith("PERM.type.")) && (!"PERM.type.99".equals(key))) {
            			num = key.substring(10);
            			numList.add(Integer.parseInt(num));
            		}
            	}
            	Collections.sort(numList);
            	Iterator<Integer> numIt = numList.iterator();
            	String numStr;
            	while (numIt.hasNext()) {
            		numStr = String.valueOf(numIt.next());
            		key = "PERM.type." + numStr;
            		permTypes.addElement(props.getProperty(key), numStr);	
            	}

            	// Add in "Other".
            	String otherType = props.getProperty("PERM.type.99");
            	if (otherType != null) {
            		permTypes.addElement(otherType, "99");
            	}
            }



    }catch( Exception ex ){
        BaseUIGlobals.out.logException("[GroupBean] build permissions", ex);
    }

    boolean usingNS = false ;
        int i_ns = -1;
				
				if (wiz.session() != null) {
					Integer iv = (Integer)wiz.session().getAttribute("NS4Browser");
					if (null != iv) {           
						i_ns = iv.intValue();
					}
				}
				
        if( i_ns == 1 ) usingNS = true;

        buildVMPickerHiddenFormData(sb);
        buildFilter(sb, "filterdata", "byname", "permname" , nameFilter, "bytype", "permtype",
        			typeFilter, permTypes, 25);
        buildMboxMultiPicker(sb, fromList, toList);
        
//        buildMultiPicker( sb, fromList , toList, imaxPerms ,
//                          "filterdata", "byname", "permname", nameFilter,
//                          "bytype","permtype",typeFilter,permTypes,
//                          "SelectPerm", "available", "assigned", "availlist", "assignlist", usingNS);
//        buildMultiPickerJScript( sb );


    	
    }

    private void buildRightsSelect(StringBuffer buf) {
        buf.append("<table cellpadding=0 cellspacing=0 border=0 width=520>\n");
        String className = "whiteStripe";
        String val = "";
        
        NameValuePairs nvpSubPerms = grp.getSubPermNVPForWizard();
        NameValuePairs nvpPerms = grp.getTmpPermsAddWithRights();

        buildRightsRow( buf , "", className, "ACCOUNT.userPerm", nvpPerms, ENABLED_CHECKBOX, PERM_STRING, true );
        spacerLine(buf);
        addHSpace(buf, "5");
        addHSpace(buf, "5", null, "20");
        buildRightsRow( buf , "", className, "ACCOUNT.userGroupPerm", nvpSubPerms, DISABLED_CHECKBOX, GROUP_STRING, true );
        spacerLine(buf);
        addHSpace(buf, "5");
        addHSpace(buf, "5", null, "20");

        buf.append("</table>");
    }

    public void buildRightsRow(StringBuffer buf , String width, String className, String label, NameValuePairs val, String img, String accType, boolean addSpacer ){

        if (accType.equals(PERM_STRING)) {
            buf.append("<tr><td colspan=5>");
            buf.append(langbean.getValue("ACCOUNT.RWXD"));
            buf.append("</td>\n<tr>\n");
        }
        buf.append("<tr><td>");
        buf.append(langbean.getValue("ACCOUNT.R"));
        buf.append("</td>\n<td>\n");
        buf.append(langbean.getValue("ACCOUNT.W"));
        buf.append("</td>\n<td>\n");
        buf.append(langbean.getValue("ACCOUNT.X"));
        buf.append("</td>\n<td>\n");
        buf.append(langbean.getValue("ACCOUNT.D"));
        buf.append("</td>\n<td>\n");
        buf.append(langbean.getValue(label));
        buf.append("</td>\n</tr>\n");

        addHSpace(buf, "5");
        addHSpace(buf, "5", null, "1");
        addHSpace(buf, "5");
        spacerLine(buf);

        Vector vRead = new Vector();
        Vector vWrite = new Vector();
        Vector vExecute = new Vector();
        Vector vDelete = new Vector();

        if ( val==null || val.size() < 1) {
            buf.append("<tr>\n<td colspan=5>\n");
            buf.append(langbean.getValue("Label.notspecified"));
            buf.append("</td>\n</tr>\n");
        } else {
            boolean b = (wiz.action == Wizard.ADD);
            boolean flag = false;
            NameValue nv = null;
            Integer right = null;
            Permission p = null;
            val.sortStringValue(false);
            for (int i=0;i<val.numEntries();i++) {
                nv = val.getElement(i);
                buf.append("<tr>\n<td>\n");
                right = (Integer)nv.value;

                flag = grp.checkRight(right.intValue(), Permission.READ);
                buildImgCheckbox(buf, i, accType+"Read", "","1", "0",  flag?"1":"0","WizardInputText", img);
                vRead.addElement(flag?"1":"0");

                buf.append("</td>\n");
                buf.append("<td>\n");

                flag = grp.checkRight(right.intValue(), Permission.WRITE);
                buildImgCheckbox(buf, i, accType+"Write", "","1", "0", flag?"1":"0","WizardInputText", img);
                vWrite.addElement(flag?"1":"0");

                buf.append("</td>\n");
                buf.append("<td>\n");

                flag = grp.checkRight(right.intValue(), Permission.EXECUTE);
                buildImgCheckbox(buf, i, accType+"Execute", "","1", "0", flag?"1":"0","WizardInputText", img);
                vExecute.addElement(flag?"1":"0");

                buf.append("</td>\n");
                buf.append("<td>\n");

                flag = grp.checkRight(right.intValue(), Permission.DELETE);
                buildImgCheckbox(buf, i, accType+"Delete", "","1", "0", flag?"1":"0","WizardInputText", img);
                vDelete.addElement(flag?"1":"0");

                p = BaseUIGlobals.securityMgr.getPermission( nv.name );
                buf.append("</td>\n");
                buf.append("<td>\n");
                buf.append(p.getPermission());
                buf.append("</td>\n");
                buf.append("</tr>\n");
            }
        }

        buf.append("<input type='hidden' name='PERM_SIZE' value='");
        buf.append(val.size());
        buf.append("'>\n");

        if (accType.equals(PERM_STRING)) {
            NameValue nv = null;
            for (int j=0; j<val.numEntries(); j++) {
                nv = val.getElement(j);
                buf.append("<input type='hidden' name='");
                buf.append("PERM_NAME");
                buf.append(j);
                buf.append("' value='");
                buf.append( nv.name );
                buf.append("'>\n");
            }

            imageCheckboxJavascript(buf, accType+"Read", vRead, val.numEntries());
            imageCheckboxJavascript(buf, accType+"Write", vWrite, val.numEntries());
            imageCheckboxJavascript(buf, accType+"Execute", vExecute, val.numEntries());
            imageCheckboxJavascript(buf, accType+"Delete", vDelete, val.numEntries());
        }
    }

    /**
     * Method for building the confirm question for user deletion
     * and the list of available permission groups to move the users to
     *
     * @param buf StringBuffer to append to
     */
    private void  buildAccQuestion(StringBuffer buf){

    buf.append("<table>");
    String theName = "";
    boolean val = false;

    if(grp != null){
        val = true;
        theName = grp.getGroupName();
    }
    Enumeration enum2 = null;

    String s = "";

    buf.append("<tr class=\"WizardInputText\">");
    buf.append("<td>");
    makeImage(buf, "images.spacer", null, "2", null);
    buf.append(langbean.getValue("GROUP.groupUsers"));
    buf.append(": ");

    buf.append("<tr class=\"className\">");
    buf.append("<td>");

    if(enum2 != null){
        while (enum2.hasMoreElements()) {
        s = (String)enum2.nextElement();
        makeImage(buf, "images.spacer", null, "2", null);
        buf.append(s);
        buf.append("<br>");
        }
    } else {
        makeImage(buf, "images.spacer", null, "2", null);
        buf.append(langbean.getValue("GROUP.noGroupUsers"));
    }

    buf.append("</td></tr>\n</table>");
    }


    /**UNUSED
     * Method for building the confirm question for user deletion
     * and the list of available permission groups to move the users to
     *
     * @param buf StringBuffer to append to
     */
    /*    private void buildGroupList(StringBuffer buf){

    }
    */


    /**
     * Method for building the PermName input box
     *
     * @param buf StringBuffer to append to
     */
    private void buildGroupName(StringBuffer buf) {
        String s = grp.getGroupid();
        if(s == null || s.equals("null")) s = "";
        buf.append("<table><tr>");
        if (wiz.action == Wizard.ADD) {
        buildReqInputBox(buf, langbean.getValue("GROUP.groupID"), "GROUP_groupid", s, "32", "25");
        } else {
            buf.append("<td valign=\"bottom\" class=\"WizardAccountsText\">");
            buf.append(langbean.getValue("GROUP.groupID"));
            buf.append(":</td><td>");
            buf.append(s);
            buf.append("</td>");
        }

     s = grp.getGroupName();
    if (s == null || s.equals("null")) s = "";

        buf.append("</tr><tr>");
        buildReqInputBox(buf, langbean.getValue("GROUP.groupName"), "GROUP_groupname", s, "32", "50");

    s = grp.getGroupOwnerid();
    if (s == null || s.equals("null")) s = "";

        buf.append("</tr><tr>");
    buildInputBox(buf, langbean.getValue("GROUP.groupOwner"), "GROUP_groupowner", s, "32", "64");

    buf.append("</tr>");

    buildIdentity( buf );

        buf.append("</tr></table>");
        
        
        Vector v = grp.getTmpGroups();

        int size = v.size();
        String strGrp = null;
        for (int h=0; h<size; h++) {
            strGrp = (String)v.elementAt(h);
            if(strGrp == null || strGrp.equals("null") || strGrp.length() == 0){
            	//skip permission lookup
            }
            else{
	            String grpPerms[] = BaseUIGlobals.securityMgr.listPermissionsForGroup( strGrp );
	            if (grpPerms != null && grpPerms.length > 0) 
	            {
	                for (int i=0; i<grpPerms.length; i++) 
	                {
	                    grp.tmpAddPerm(grpPerms[i]);
	                }
	            }
            }
        }
        strGrp = grp.getGroupid();
        // Defect 204899: Don't try to get the permissions when we're creating a new group.
        if (!YFCCommon.isVoid(strGrp)) {
	        String grpPerms[] = BaseUIGlobals.securityMgr.listPermissionsForGroup( strGrp );
	        if (grpPerms != null && grpPerms.length > 0) 
	        {
	        	for (int i=0; i<grpPerms.length; i++) 
	            {
	                grp.tmpAddAddPerm(grpPerms[i]);
	            }
	        }
        }
    }

    //UNUSED
    /*private void buildAuthos( StringBuffer sb ) {
	//for building a list rather than a simple input box!

	sb.append("<tr><td valign=\"bottom\" class=\"Wizard"+wiz.location+"Text\">");
	sb.append(langbean.getValue("ACCOUNT.userEntity"));
	sb.append(":</td><td>");

	Vector v = BaseUIGlobals.securityMgr.listAllUsers();
	if (v!=null) {

	} else {

	}
	if (grp != null) {

	    Object maps[] = null;
	    try {
		ArrayList arr = tpmgr.listAll(WizardObject.ENTITY,0,0,true);
		maps = arr.toArray();
	    } catch (Exception ex) {
		BaseUIGlobals.out.logException("[AccountBean.buildIdentity]",ex);
	    }

	    String s = grp.getEntityid();
	    if (s == null) s = "";

	    NameValuePairs nvp = new NameValuePairs();



    }
    */


    private void buildIdentity( StringBuffer sb ) {
    sb.append("<tr><td valign=\"bottom\" class=\"WizardInputText\">");
    sb.append(langbean.getValue("ACCOUNT.userEntity"));
    sb.append(":</td><td>");

    if (grp != null) {

        Object maps[] = null;
        try {
        ArrayList arr = EntityUtil.listAll(0, 0, true);
        maps = arr.toArray();
        } catch (Exception ex) {
        BaseUIGlobals.out.logException("[AccountBean.buildIdentity]",ex);
        }

        String s = grp.getEntityid();
        if (s == null) s = "";

        NameValuePairs nvp = new NameValuePairs();
        nvp.addElement( " ", " " );
        if (maps!=null && maps.length > 0) {
        Map m = null;

        for (int i=0; i<maps.length; i++) {
            m = (Map)maps[i];
            //nvp.addElement( (String)m.get( "OBJECT_NAME" ), (String)m.get( "OBJECT_ID" ) );
            nvp.addElement( (String)m.get( "ORGANIZATION_NAME" ), (String)m.get( "ORGANIZATION_KEY" ) );
        }
        }

        buildSelectList( sb, "GROUP_entityid", nvp, s, true );
    }
    sb.append("</td></tr>");
    }

    /**UNUSED
     * generates the selected permission display for the all availble and active
     * components in the system
     *
     * @param buf StringBuffer
     */
    /* private void buildPermissionConfirm(StringBuffer sb) {

    }
    */


    public String getGroupDetails() {
        StringBuffer buf = new StringBuffer();
    String className = "grayStripe";

    if (grp!=null) {

        buf.append("<table cellpadding=0 cellspacing=0 border=0 width=400 valign='top'>\n");

        buf.append("<tr>");
        startStripeCell(buf, "WizardInputText", "colspan=4");
        buf.append(langbean.getValue("GroupSettings"));
        buf.append("</td>\n");
        buf.append("</tr>\n");
        addHSpace(buf, "4");
        addHSpace(buf, "4", null, "1");
        addHSpace(buf, "4");
        spacerLine(buf);

        buf.append("<tr>");
        startStripeCell(buf, className, "width=240");
        buf.append(langbean.getValue("GROUP.groupName"));
        buf.append("</td>\n");
        addVSpace(buf, "whitespacer", "1", null);
        addVSpace(buf, className, "5", null);
        startStripeCell(buf, className, null);
        buf.append(BaseUIGlobals.processHTMLDisplayValue(grp.getGroupName()));
        buf.append("</td>");
        buf.append("</tr>\n");


        spacerLine(buf);
        addHSpace(buf, "4", "whitespacer","1");
        spacerLine(buf);

        buf.append("<tr>");
        startStripeCell(buf, className, "width=240");
        buf.append(langbean.getValue("GROUP.groupID"));
        buf.append("</td>\n");
        addVSpace(buf, "whitespacer", "1", null);
        addVSpace(buf, className, "5", null);
        startStripeCell(buf, className, null);
        buf.append(BaseUIGlobals.processHTMLDisplayValue(grp.getGroupid()));
        buf.append("</td>");
        buf.append("</tr>\n");


        spacerLine(buf);
        addHSpace(buf, "4", "whitespacer","1");
        spacerLine(buf);

            String s = grp.getGroupOwnerid();
            if(s == null || s.length() == 0)
            {
                s = langbean.getValue("Label.notspecified");
            }

        buf.append("<tr>");
        startStripeCell(buf, className, "width=240");
        buf.append(langbean.getValue("GROUP.groupOwner"));
        buf.append("</td>\n");
        addVSpace(buf, "whitespacer", "1", null);
        addVSpace(buf, className, "5", null);
        startStripeCell(buf, className, null);
        buf.append(BaseUIGlobals.processHTMLDisplayValue(s));
        buf.append("</td>");
        buf.append("</tr>\n");


        spacerLine(buf);
        addHSpace(buf, "4", "whitespacer","1");
        spacerLine(buf);

            s = grp.getEntityid();
            if(s == null || s.trim().length() == 0)
            {
                s = langbean.getValue("Label.notspecified");
            } 

        buf.append("<tr>");
        startStripeCell(buf, className, "width=240");
        buf.append(langbean.getValue("ACCOUNT.EntityID"));
        buf.append("</td>\n");
        addVSpace(buf, "whitespacer", "1", null);
        addVSpace(buf, className, "5", null);
        startStripeCell(buf, className, null);
        buf.append(BaseUIGlobals.processHTMLDisplayValue(s));
        buf.append("</td>");
        buf.append("</tr>\n");

            spacerLine(buf);
            addHSpace(buf, "4");
            addHSpace(buf, "4", null, "20");

        buf.append("</table>");
    }

    return buf.toString();
    }


    /**
     * generates the view of the edited perm, containing all the info
     * like permName, ad chosen permissions/components.
     * @param buf StringBuffer
     */
    private void buildConfirm(StringBuffer buf) {


        buf.append("<table cellpadding=0 cellspacing=0 border=0 width=520>\n");
        String className = "whiteStripe";

        buf.append("<tr>");
        startStripeCell(buf, "WizardInputText", "colspan=4 ");
//        buf.append(langbean.getValue("GroupSettings"));
        buf.append(langbean.getValue("GROUP.groupID"));
        buf.append("</td>\n");
        buf.append("</tr>\n");
        addHSpace(buf, "4");
        addHSpace(buf, "4", null, "1");
        addHSpace(buf, "4");
        spacerLine(buf, 2);

    buf.append("<tr>");
    startStripeCell(buf, className, "width=200");
    buf.append(langbean.getValue("GROUP.groupName"));
    buf.append("</td>\n");
    addVSpace(buf, "ltspacer", "1", null);
    addVSpace(buf, className, "5", null);
    startStripeCell(buf, className, null);
    buf.append(BaseUIGlobals.processHTMLDisplayValue(grp.getGroupName()));
    buf.append("</td>");
    buf.append("</tr>\n");

    spacerLine(buf, 2);
    addHSpace(buf, "4", "ltspacer","1");
    spacerLine(buf, 2);

    buf.append("<tr>");
    startStripeCell(buf, className, "width=200");
    buf.append(langbean.getValue("GROUP.groupID"));
    buf.append("</td>\n");
    addVSpace(buf, "ltspacer", "1", null);
    addVSpace(buf, className, "5", null);
    startStripeCell(buf, className, null);
    buf.append(BaseUIGlobals.processHTMLDisplayValue(grp.getGroupid()));
    buf.append("</td>");
    buf.append("</tr>\n");

        spacerLine(buf, 2);
    addHSpace(buf, "4", "ltspacer","1");
    spacerLine(buf, 2);

        String s = grp.getGroupOwnerid();
        if(s == null || s.length() == 0)
        {
            s = langbean.getValue("Label.notspecified");
        }

    buf.append("<tr>");
    startStripeCell(buf, className, "width=200");
    buf.append(langbean.getValue("GROUP.groupOwner"));
    buf.append("</td>\n");
    addVSpace(buf, "ltspacer", "1", null);
    addVSpace(buf, className, "5", null);
    startStripeCell(buf, className, null);
    buf.append(BaseUIGlobals.processHTMLDisplayValue(s));
    buf.append("</td>");
    buf.append("</tr>\n");

        spacerLine(buf, 2);
    addHSpace(buf, "4", "ltspacer","1");
    spacerLine(buf, 2);

        s = grp.getEntityid();
        if(s == null || s.length() == 0)
        {
            s = langbean.getValue("Label.notspecified");
        } 

    buf.append("<tr>");
    startStripeCell(buf, className, "width=200");
    buf.append(langbean.getValue("ACCOUNT.userEntity"));
    buf.append("</td>\n");
    addVSpace(buf, "ltspacer", "1", null);
    addVSpace(buf, className, "5", null);
    startStripeCell(buf, className, null);
    buf.append(BaseUIGlobals.processHTMLDisplayValue(s));
    buf.append("</td>");
    buf.append("</tr>\n");


        spacerLine(buf, 2);
    addHSpace(buf, "4", "ltspacer","1");
    spacerLine(buf, 2);

        buf.append("<tr>");
        startStripeCell(buf, className, "width=140");
        buf.append(langbean.getValue("GROUP.subGroup"));
        buf.append("</td>\n");
        addVSpace(buf, "ltspacer", "1", null);
        addVSpace(buf, className, "5", null);
        startStripeCell(buf, className, null);

        grp.removeTmpSubGroup();
        Vector v = grp.getTmpGroups();

        if (v!=null && v.size() > 0) {
            int z = v.size();
            String g;
            for (int i=0; i<z; i++) {
                g = (String)v.elementAt(i);
                if (!g.equals("false")) {
                    grp.refreshGroupsForGroupWizard( g );
                }
            }
            Vector v2 = grp.getTmpSubGroups();
            for (int c=0; c<v2.size(); c++) {
                if ( v.contains( (String)v2.elementAt(c) ) ) {
                    v.remove( (String)v2.elementAt(c) );
                    grp.removeTmpGroup( (String)v2.elementAt(c) );
                }
            }

            for (int i=0; i<v.size(); i++) {
                g = (String)v.elementAt(i);

                if (!g.equals("false")) {
                    Group tmpgrp = BaseUIGlobals.securityMgr.getGroup( g );
                    if( tmpgrp!= null ){
                        buf.append(BaseUIGlobals.processHTMLDisplayValue(tmpgrp.getGroupName()));
                        buf.append(", ");
                    }
                }
            }
            buf = buf.deleteCharAt( buf.length()-2 );
        } else {
            buf.append(langbean.getValue("Label.notspecified"));
        }

        buf.append("</td>");
        buf.append("</tr>\n");

        spacerLine(buf, 2);
        addHSpace(buf, "4", "ltspacer","1");
        spacerLine(buf, 2);

// comment this for Permission Rights begin-1a
        buf.append("<tr>");
        startStripeCell(buf, className, "width=140");
        buf.append(langbean.getValue("GROUP.subGroupPerms"));
        buf.append("</td>\n");
        addVSpace(buf, "ltspacer", "1", null);
        addVSpace(buf, className, "5", null);
        startStripeCell(buf, className, null);
// comment end-1a
        
/*//   uncomment for Permission Rights begin-1b
        NameValuePairs nvpSub = grp.getTmpSubPermsWithRights(); 
*///   comment end-1b
        
// comment this for Permission Rights begin-2a
        grp.refreshSubGroupPerms();
        Vector a = grp.getTmpPerms();
        if ( a!=null && a.size() > 0 ) {
            int z = a.size();
            Permission prm = null;
            String p;

            if ( z > 10 ) { // More than 10 database calls in a loop = TOO SLOW
                Hashtable allPermissions = BaseUIGlobals.securityMgr.listAllPermissionsHash();
                for ( Iterator it = a.iterator(); it.hasNext(); ) {
                    p = (String) it.next();
                    if (! p.equals("false")) {
                        buf.append(BaseUIGlobals.processHTMLDisplayValue(allPermissions.get(p).toString())); // Get the permission name, based on the ID
                        buf.append(", ");
                    }
                }
            } else {
                for (int i=0; i<z; i++) {
                    p = (String)a.elementAt(i);
                    if (!p.equals("false")) {
                        prm = BaseUIGlobals.securityMgr.getPermission( p );
                        buf.append(BaseUIGlobals.processHTMLDisplayValue(prm.getPermission()));
                        buf.append(", ");
                   }
                }
            }
            buf = buf.deleteCharAt( buf.length()-2 );
        } else {
            buf.append(langbean.getValue("Label.notspecified"));
        }
// comment end-2a
/*//   uncomment for Permission Rights begin-2b
        buildConfirmPermRow( buf , "140", className, "GROUP.subGroupPerms", nvpSub, true );  
*///   comment end-2b
        buf.append("</td>");
        buf.append("</tr>\n");

        spacerLine(buf, 2);
        addHSpace(buf, "4", "ltspacer","1");
        spacerLine(buf, 2);

// comment this for 3.3 Permission Rights begin-3a
        buf.append("<tr>");
        startStripeCell(buf, className, "width=140");
        buf.append(langbean.getValue("GROUP.groupPerms"));
        buf.append("</td>\n");
        addVSpace(buf, "ltspacer", "1", null);
        addVSpace(buf, className, "5", null);
        startStripeCell(buf, className, null);
        
         Vector b = grp.getTmpPermsAdd();
         int size = b.size();
         String ConfirmPerm =Integer.toString(size);
         
         if(size <= 0) {
           ConfirmPerm = langbean.getValue("Label.NoneProvided");
         }else {
            ConfirmPerm = "<a href=\"javascript:selectedPermissionsList('./Page?next=page.selectedPermissionGroups')\" >"+ConfirmPerm+"</a>";
          }
        
          buf.append(ConfirmPerm);
        
// comment end-3a
/*//   uncomment for Permission Rights begin-3b        
        NameValuePairs nvp = grp.getTmpPermsAddWithRights();   
        buildConfirmPermRow( buf , "140", className, "ACCOUNT.userPerm", nvp, true );
*///   comment end-3b
        buf.append("</td>");
        buf.append("</tr>\n");

    /*
       spacerLine(buf, 2);
       addHSpace(buf, "4", "ltspacer","1");
       spacerLine(buf, 2);
     */

        spacerLine(buf, 2);
        addHSpace(buf, "4");
        
/*
* Dual Control - START
*/
         
          DualControlUtil dcu = new DualControlUtil();
          buf.append(dcu.buildDualControlSection(wiz.session()));
/*
* Dual Control - END
*/
                
        addHSpace(buf, "4", null, "20");
        buf.append("</table>\n");
    }

    private void buildConfirmPermRow( StringBuffer buf , String width, String className, String label, NameValuePairs nvp, boolean addSpacer ) {

    buf.append("<tr>");
    startStripeCell(buf, className, "width="+width);
    buf.append(langbean.getValue(label));
    buf.append("</td>\n");
    addVSpace(buf, "ltspacer", "1", null);
    addVSpace(buf, className, "5", null);
    startStripeCell(buf, className, null);
        if(nvp == null || nvp.numEntries() == 0) {
            buf.append(langbean.getValue("Label.notspecified"));
        } else {
            boolean flag = false;
            NameValue nv = null;
            Permission p = null;
            int right;
            for (int i=0; i<nvp.numEntries(); i++) {
                nv = nvp.getElement(i);
                p = (Permission)CacheManager.get("PermissionCache", nv.name);
                right = ((Integer)nv.value).intValue();
                buf.append("<table><tr>");
                startStripeCell(buf, className, "width=45");
                flag = grp.checkRight(right, Permission.READ);
                buf.append(flag?langbean.getValue("ACCOUNT.R"):"-");
                flag = grp.checkRight(right, Permission.WRITE);
                buf.append(flag?langbean.getValue("ACCOUNT.W"):"-");
                flag = grp.checkRight(right, Permission.EXECUTE);
                buf.append(flag?langbean.getValue("ACCOUNT.X"):"-");
                flag = grp.checkRight(right, Permission.DELETE);
                buf.append(flag?langbean.getValue("ACCOUNT.D"):"-");
                buf.append("</td><td>");
                buf.append(p.getPermission());
                buf.append("</td>\n</tr>\n</table>\n");
            }
        }
    buf.append("</td>");
    buf.append("</tr>\n");
    }


    /**
     * Generates a String representation of the object.
     * @return String
     */
    public String toString() {
    StringBuffer s = new StringBuffer();
    s.append("Group Object:\n");
    return s.toString();
    }


    public void spacerLine(StringBuffer buf) {
           spacerLine(buf,2);
    }




    /**
     * Builds the navigation buttons for the wizard page.
     * @return String
     */
    public String getActionButtons() {
        StringBuffer buffer = new StringBuffer();

    if (page.activity.equals("groupAccQuestion") ||
        (page.activity.equals("groupAccConfirmDelete"))) {

        // have to disable "delete" buttons here
        buffer.append("<input type='hidden' name='pageno' value='");
        buffer.append(pageno);
        buffer.append("'>\n");

        if (!page.pageType.startsWith("FINISH")) {
        if (wiz.currentPage != wiz.firstActivePage()) {
            buffer.append("<a href=\"javascript:document.wizform.submit()\" ");
            buffer.append("onClick=\"return isReady(document.wizform,'Back',");
            buffer.append(pageno);
            buffer.append(",'");
            buffer.append("no");
            buffer.append("');\"");
            buffer.append(" onMouseover=\"chgButton('wizback','BackOver'); window.status='");
            buffer.append(langbean.getValue("wizard.Back"));
            buffer.append("'; return true;\"");
            buffer.append(" onMouseout=\"chgButton('wizback','BackOff'); window.status=''; ");
            buffer.append("return true;\"");
            buffer.append(" onMouseDown=\"chgButton('wizback','BackDown'); return true;\"");
            buffer.append(" onMouseUp=\"chgButton('wizback','BackOff'); return true;\">");
            makeImage(buffer, "images.wiz.backoff", null, "23", "wizback", "align='top'");
            buffer.append("</a>\n");

        }
        else {
            makeImage(buffer,"images.wiz.backinact",null, "23", "wizback", "align='top'");
            buffer.append("\n");
        }

        buffer.append("<a href=\"javascript:document.wizform.submit()\" ");
        buffer.append("onClick=\"return isReady(document.wizform,'Next',");
        buffer.append(pageno);
        buffer.append(",'');\"");
        buffer.append(" onMouseover=\"chgButton('wiznext','NextOver'); window.status='");
        buffer.append(langbean.getValue("wizard.Next"));
        buffer.append("'; return true;\"");
        buffer.append(" onMouseout=\"chgButton('wiznext','NextOff'); window.status=''; ");
        buffer.append("return true;\"");
        buffer.append(" onMouseDown=\"chgButton('wiznext','NextDown'); return true;\"");
        buffer.append(" onMouseUp=\"chgButton('wiznext','NextOff'); return true;\">");
        makeImage(buffer, "images.wiz.nextoff", null, "23", "wiznext", "align='top'");
        buffer.append("</a>\n");


        buffer.append("<a href=\"javascript:document.wizform.submit()\" ");
        buffer.append("onClick=\"return isReady(document.wizform,'Cancel',");
        buffer.append(pageno);
        buffer.append(",'no');\"");
        buffer.append(" onMouseover=\"chgButton('wizcancel','CancelOver'); window.status='");
        buffer.append(langbean.getValue("wizard.Cancel"));
        buffer.append("'; return true;\"");
        buffer.append(" onMouseout=\"chgButton('wizcancel', 'CancelOff'); window.status=''; ");
        buffer.append("return true;\"");
        buffer.append(" onMouseDown=\"chgButton('wizcancel','CancelDown'); return true;\"");
        buffer.append(" onMouseUp=\"chgButton('wizcancel','CancelOff'); return true;\">");

        makeImage(buffer, "images.wiz.canceloff", null, "23", "wizcancel", "align='top'");
        buffer.append("</a>\n");

        makeImage(buffer,"images.wiz.deleteinact",null, "23", "wizdelete", "align='top'");
        buffer.append("\n");
        }

        return buffer.toString();
    }
    else{
        return super.getActionButtons();
    }
    }


    /**
     * Adds the available options for the current wizard.
     * @param wiz the Wizard object
     * @param wizCols the number of columns
     * @param selectedPage the page number for the current page.
     * @param currentLevel the current nesting level of the page.
     * @ param lastMain the last parent page
     */
    String getLinks(Wizard wiz,
                    int wizCols, int selectedPage, int currentLevel,
                    WizardStep lastMain, String displayName) {
        StringBuffer buffer = new StringBuffer(100);


        String environmentWidgets="";
        boolean showit=false;
        int blanks, colspan;
        int wizMaxCols = currentLevel+1;
        WizardStep p;
        WizardStep selectedWizParent;


        if (wizCols > 1) {
            buffer.append("\n<tr>");
            //            indentSection(1, buffer);
            indentSection(wizCols-1, buffer);
            buffer.append("<td class='navlinkfont' colspan='");
            buffer.append(String.valueOf(wizMaxCols+1));
            buffer.append("'>");
            // image for inactive?
            //      buffer.append("<img src='");
            //buffer.append(wiz.getStepWizard(selectedPage).location);
            //buffer.append("navinactive' border=\"0\"> ");
            //      if (wiz.add)
            //  buffer.append("Create new ");
            //else
            //  buffer.append("Edit ");
            buffer.append(langbean.getValue(displayName));
            buffer.append("</td></tr>\n");
        }

        selectedWizParent = (WizardStep)wiz.wizPages().elementAt(selectedPage);
        if (selectedWizParent.subOptionParent != null)
            selectedWizParent = selectedWizParent.subOptionParent;
        else
            selectedWizParent = null;
        for (int i=0; i<wiz.wizPages().size(); i++) {
            p = (WizardStep)wiz.wizPages().elementAt(i);
            if (p.active && !p.pageType.equals("CANCEL") &&
                !p.pageType.equals("FINISH") &&
                !p.pageType.equals("DELETE")) {

                showit=false;

                if (p.displayname != null) {
                    if (i == selectedPage || p.level == 0)
            showit=true;
                    else if (p.level < currentLevel) {
                        if (p.subOptionParent != null) {
                            if (p.isChild(lastMain))
                                showit=true;
                        }
                        else
                            showit=true;
                    }
                    else if (p.level == currentLevel) { // on the same level
                        if (selectedWizParent != null) {
                            if (p.isChild(selectedWizParent))
                                showit=true;
                        }
                        else
                            showit=true;
                    }

                }

                if (showit) {
                    buffer.append("\n<tr>");
            //                indentSection(1, buffer);
                    if (wizCols > 1)
                        indentSection(wizCols, buffer);

                    colspan = wizMaxCols - p.level;
                    blanks = wizMaxCols - colspan;
                    indentSection(blanks, buffer);

                    // Selected one
                    if (i==selectedPage) {
                        buffer.append("\n<td class='navselected' colspan='");
                        buffer.append(String.valueOf(colspan));
                        buffer.append("'>");
            //                    buffer.append(">>");
            //                    buffer.append("<img src='");
            // buffer.append("./images/navon.gif' ");
            //buffer.append("selected' border=\"0\"> ");
                        makeImage(buffer, "images."+wiz.location+".navon");
                        buffer.append(" <b>");
                        buffer.append(langbean.getValue(p.displayname));
                        buffer.append("</b></td></tr>");
                    }
                    else {
                        buffer.append("\n<td class='navlinkfont' colspan='");
                        buffer.append(String.valueOf(colspan));


            if ((page.activity.equals("groupAccQuestion") ||
                 (page.activity.equals("groupAccConfirmDelete")))
                && p.pageType.equals("CONFIRM")) {

                super.addName(p, false, i, environmentWidgets, buffer);
            }
            else{
                super.addName(p, wiz.linksActive, i, environmentWidgets, buffer);
            }
                        buffer.append("</td>\n</tr>\n");
                    }
                }
            }
        }
        return buffer.toString();
    }


    private void spacerLine(StringBuffer buf, int colNum) {

        if(colNum > 2) {

        buf.append("<tr>\n");
        buf.append("<td height='1'>\n");
        makeImage(buf, "images.spacer", null, "1", null);
        buf.append("</td>");

        buf.append("<td height='1'>\n");
        makeImage(buf, "images.spacer", null, "1", null);
        buf.append("</td>\n</tr>\n");
    } else {

        buf.append("<tr>\n");
        buf.append("<td height='2'>\n");
        makeImage(buf, "images.spacer", null, "2", null);
        buf.append("</td>");
        addVSpace(buf, "bodyspacer", "1", null);
        addVSpace(buf, null, null, "4");
        buf.append("<td height='2'>\n");
        makeImage(buf, "images.spacer", null, "2", null);
        buf.append("</td>\n</tr>\n");
    }
    }
    private void buildVMPickerHiddenFormData(StringBuffer buf){
    	
        //code addition Manish Joddar manish_joddar_tw@comm.com 01/10/2006   -----start
        buf.append("<input type='hidden' name='direct_avail2select_transfer' value='false'>\n");
        buf.append("<input type='hidden' name='direct_select2avail_transfer' value='false'>\n");
        buf.append("<input type='hidden' name='right_transfer' value='false'>\n");
        buf.append("<input type='hidden' name='left_transfer' value='false'>\n");
        buf.append("<input type='hidden' name='avail_side' value=''>\n");
        buf.append("<input type='hidden' name='select_side' value=''>\n");
        buf.append("<input type='hidden' name='UI_CHECK_FLAG' value=''>\n"); 
        buf.append("<input type='hidden' name='window' value=''>\n"); 
         //code addition Manish Joddar manish_joddar_tw@stercomm.com 01/10/2006   -----end       	
    }

    private void buildMboxMultiPicker(StringBuffer buf, NameValuePairs availablePermisions, NameValuePairs selectedPermissions) 
    {
		 Properties p = Manager.getProperties("ADMIN-UI");
        
	     int pos =  grp.getPositionValue();
	     int position = grp.getSelectBoxPositionValue();
     
	     String amb_height_val = p.getProperty("MAX_AVAILABLE_MAILBOX_HEIGHT"); 
  	     String smb_height_val = p.getProperty("MAX_SELECTED_MAILBOX_HEIGHT");
  	     int num = grp.getNumberValue(); 
	     int number =  grp.getSelectBoxNumberValue();
	     
	     String url = "./GroupWizard?wizType=UpdateGroup&wizObjType=0&action=groupPermEdit&wizardname=UpdateGroup&WizardAction=search";

	     super.buildVerticalMultiPicker(buf, pos, num, position, number, amb_height_val, smb_height_val, 
	    		 availablePermisions, selectedPermissions, BaseUIGlobals.MAX_MAILBOX_LIST_SIZE,"SelectPerm", "available", 
	        		"assigned", "availlist", "assignlist", url);
 
        buildMultiPickerJScript(buf);
    }
    private void buildFilter(StringBuffer s, String filterTitle, String filterLabel1, 
			 String filterName1, String filterValue1,
			 String filterLabel2, String filterName2, 
			 String filterValue2, NameValuePairs filter2Options,
			 int filterWidth)
    {

		if( filterTitle == null ) filterTitle = "";
		if( filterLabel1 == null ) filterLabel1 = "";
		if( filterName1 == null ) filterName1= "name";
		if( filterValue1 == null ) filterValue1 = "";
		if( filterLabel2 == null ) filterLabel2 = "";
		if( filterName2 == null ) filterName2= "type";
		if( filterValue2 == null ) filterValue2 = "";
		getVerticalFilterButtonsScript(s, true);
		s.append("<table width=\"70%\" border=\"0\" cellspacing=\"2\" cellpadding=\"0\" height=\"67\">");
		s.append("<tr>");
		s.append("<td height='1'><img src='./images/plc-holder.gif' border=0 height='1' ></td>");
		s.append("</tr>");
		
		s.append("<tr>");
		s.append("<td valign='top'>");
		s.append("<table border=0 cellpadding=0 cellspacing=0 valign='top' width=300>");
		
		//<!-- search -->
		if( filterTitle.trim().length() > 0 ){
		s.append("<tr><td colspan=3 nowrap class='WizardInputText' valign='bottom'>");
		s.append(langbean.getValue(filterTitle));
		s.append(":</td></tr>\n");
		}
		//s.append("<tr><td colspan=2 height=15><img src='./images/plc-holder.gif' height=15>&nbsp;</td></tr>\n");
		s.append("<tr>\n");
		s.append("<td  align='right'  valign='center'  nowrap>");
		s.append(langbean.getValue(filterLabel1));
		if( filterLabel1.trim().length() > 0 )
		s.append(":&nbsp;&nbsp;</td>\n");
		else s.append("&nbsp;&nbsp;</td>\n");
		s.append("<td align=left class=whiteStripe valign='bottom'><input type=text name='" + filterName1 + "' value='");
		s.append(BaseUIGlobals.processHTMLDisplayValue(filterValue1));
		// fix to Bug#7418
		s.append("' onKeyPress='submitFilter();'");
		s.append("' size='");
		s.append( filterWidth );
		s.append("' maxlength=249></td>\n");
		s.append("<TD align='right'  valign='center'  nowrap>&nbsp;</td></tr>");
		
		s.append("<tr>\n");
		s.append("<td  align='right'  valign='center'  nowrap>");
		s.append(langbean.getValue(filterLabel2));
		if( filterLabel2.trim().length() > 0 )
		s.append(":&nbsp;&nbsp;</td>\n");
		else s.append("&nbsp;&nbsp;</td>\n");
		s.append("<td align=left class=whiteStripe valign='bottom'>");
		buildSelectList(s,filterName2,filter2Options,filterValue2,true);
		s.append("</td>\n");
		s.append("<TD align=left class=whiteStripe >&nbsp;&nbsp;<A href=\"javascript:document.wizform.submit()\"");
		s.append("onClick=\"return isReady(document.wizform,'Search',");
		if( this.pageno != null )
		s.append(pageno);
		else s.append(1);
		
		s.append(",'');\"");
		
		s.append("onmouseover=\"chgButton('Filter','FilterOver'); window.status=''; return true;\"");
		s.append("onmouseout=\"chgButton('Filter','FilterOff'); window.status=''; return true;\"");
		s.append("onmousedown=\"chgButton('Filter','FilterDown'); return true;\">");
		makeImage(s, "images.filter", null, null, "Filter", "align='center'");
		s.append("</a></td></tr>");
		
		s.append("</table>\n");
		s.append("</td>\n");
		s.append("</tr>\n");
		
		//<!-- End of search -->
		
		
		s.append("<tr>");
		s.append("<td height='1'><img src='./images/plc-holder.gif' border=0 height='1' ></td>");
		s.append("</tr>");
		s.append("</table>");
	}

public StringBuffer retrieveGroupPermissions(){
	StringBuffer buf = new StringBuffer();
	 Vector b = grp.getTmpPermsAdd();
     if (b!=null && b.size() > 0) {
         int z = b.size();
//comment end-3

//     NameValuePairs nvp = grp.getTmpPermsAddWithRights();   // uncomment for 3.3 rights framework.

//comment this for 3.3 begin-4
         Permission prm = null;
         String p;
         for (int i=0; i<z; i++) {
             p = (String)b.elementAt(i);
             if (!p.equals("false")) {
                 prm = BaseUIGlobals.securityMgr.getPermission( p );
                 buf.append(BaseUIGlobals.processHTMLDisplayValue(prm.getPermission()));
                 buf.append(", ");
             }
         }
         buf = buf.deleteCharAt( buf.length()-2 );
     } else {
         buf.append(langbean.getValue("Label.notspecified"));
     }
     return buf;
}

}
