package com.stercomm.customers.rbs.sct.ui.dto;

import java.util.Date;

public interface Payment {

	/**
	 * @return the bundle
	 */
	public abstract Bundle getBundle();

	/**
	 * @param bundle the bundle to set
	 */
	public abstract void setBundle(Bundle bundle);

	/**
	 * @return the messageId
	 */
	public abstract Long getMessageId();

	/**
	 * @param messageId the messageId to set
	 */
	public abstract void setMessageId(Long messageId);

	/**
	 * @return the outbound
	 */
	public abstract Integer getOutbound();

	/**
	 * @param outbound the outbound to set
	 */
	public abstract void setOutbound(Integer outbound);

	/**
	 * @return the paymentId
	 */
	public abstract Long getPaymentId();

	/**
	 * @param paymentId the paymentId to set
	 */
	public abstract void setPaymentId(Long paymentId);

	/**
	 * @return the pTimestamp
	 */
	public abstract Date getPTimestamp();

	/**
	 * @param timestamp the pTimestamp to set
	 */
	public abstract void setPTimestamp(Date timestamp);

	/**
	 * @return the reference
	 */
	public abstract String getReference();

	/**
	 * @param reference the reference to set
	 */
	public abstract void setReference(String reference);

	/**
	 * @return the settleAmt
	 */
	public abstract Double getSettleAmt();

	/**
	 * @param settleAmt the settleAmt to set
	 */
	public abstract void setSettleAmt(Double settleAmt);

	/**
	 * @return the settleDate
	 */
	public abstract Date getSettleDate();

	/**
	 * @param settleDate the settleDate to set
	 */
	public abstract void setSettleDate(Date settleDate);

	/**
	 * @return the status
	 */
	public abstract Integer getStatus();

	/**
	 * @param status the status to set
	 */
	public abstract void setStatus(Integer status);

	/**
	 * @return the transactionId
	 */
	public abstract String getTransactionId();

	/**
	 * @param transactionId the transactionId to set
	 */
	public abstract void setTransactionId(String transactionId);

	//CHG_UI_IBM_RJ_003
	public String getPaymentBIC();
	
	public void setPaymentBIC(String paymentBIC);	
	
	/**
	 * @return the type
	 */
	public abstract String getType();

	/**
	 * @param type the type to set
	 */
	public abstract void setType(String type);

	/**
	 * @return the wfId
	 */
	public abstract Long getWfId();

	/**
	 * @param wfId the wfId to set
	 */
	public abstract void setWfId(Long wfId);
	//PM updated for DocId
	/**
     * @return the docId
     */
    public abstract String getDocId();

    /**
     * @param type the DocId to set
     */
    public abstract void setDocId(String docId);
    
    public abstract String getFormattedSettleAmt();


}