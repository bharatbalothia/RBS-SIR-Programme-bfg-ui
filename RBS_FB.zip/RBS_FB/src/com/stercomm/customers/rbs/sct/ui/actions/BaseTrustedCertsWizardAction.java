/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   $Revision: $
 * Date/time:  $Date: $
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.security.cert.CertificateException;
import javax.security.cert.X509Certificate;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;
import com.stercomm.customers.rbs.sct.ui.forms.TrustedCertsForm;
import com.stercomm.customers.rbs.sct.ui.forms.adapters.TrustedCertAdapter;

public abstract class BaseTrustedCertsWizardAction extends BaseWizardAction{

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger
	.getLogger(BaseTrustedCertsWizardAction.class);


	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		TrustedCert trustedCert = getTrustedCert(request);

		TrustedCertsForm trustedCertsForm = (TrustedCertsForm)form;
		TrustedCert tcfa = new TrustedCertAdapter(trustedCertsForm);
		copyBeanProperties(trustedCert, tcfa);

		return super.viewForm(mapping, form, request, response);
	}


	public ActionForward next(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		//System.out.println("****Base-next()****");
		saveForm2Bean(mapping, form, request, response);
		return super.next(mapping, form, request, response);
	}

	public ActionForward back(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return super.back(mapping, form, request, response);
	}

	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return super.save(mapping, form, request, response);
	}

	public ActionForward trustedCertsName(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("trustedCertsName");
	}

	public ActionForward trustedCertsDetails(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("trustedCertsDetails");
	}
	public ActionForward trustedCertsConfirm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		saveForm2Bean(mapping, form, request, response);
		return mapping.findForward("trustedCertsConfirm");
	}

	public void saveForm2Bean(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		TrustedCert trustedCert = getTrustedCert(request);

		//temp save data that is not in the form
		String certId = trustedCert.getCertificateId();
		boolean createBean = trustedCert.isCreateBean();
		boolean newBean = trustedCert.isNewBean();
		boolean updated = trustedCert.isUpdated();
		boolean deleteBean = trustedCert.isDeleteBean();

		//copy data from the form to the bean
		TrustedCertsForm trustedCertsForm = (TrustedCertsForm)form;
		TrustedCert tcfa = new TrustedCertAdapter(trustedCertsForm);
		FormFile file= null; 
		X509Certificate x509cert = null;
		if(trustedCert.isNewBean()){
			file= trustedCertsForm.getCertificateFile();
		} else {
			x509cert = trustedCert.getX509Certificate();
		}

		copyBeanProperties(tcfa, trustedCert);

		//copy the temp data back to the bean
		trustedCert.setCreateBean(createBean);
		trustedCert.setNewBean(newBean);
		trustedCert.setUpdated(updated);
		trustedCert.setDeleteBean(deleteBean);
		trustedCert.setCertificateId(certId);
		if(trustedCert.isNewBean()){
			if(file!=null && file.getFileData()!=null && trustedCert.getX509Certificate()==null)
			{		
				try {
					byte[] certData = file.getFileData();
					X509Certificate cert = X509Certificate.getInstance(certData);
					trustedCert.setX509Certificate(cert);
					//request.setAttribute("trustedCertBean", tc);
					//log.debug("Cert OK: " + cert.toString());
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (CertificateException e) {
					e.printStackTrace();
				}
			}
		} else {
			trustedCert.setX509Certificate(x509cert);
		}
	}


	protected TrustedCert getTrustedCert(HttpServletRequest request){
		TrustedCert trustedCert = (TrustedCert)request.getSession().getAttribute("trustedCertBean");
		log.debug("got TrustedCert from Session: "+trustedCert);
		return trustedCert;
	}
}
