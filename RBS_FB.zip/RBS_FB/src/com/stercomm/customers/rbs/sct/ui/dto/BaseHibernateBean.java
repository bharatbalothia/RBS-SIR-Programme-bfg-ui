package com.stercomm.customers.rbs.sct.ui.dto;

import java.io.Serializable;

public interface BaseHibernateBean extends Serializable{

	public boolean isNewBean();
	public void setNewBean(boolean newBean) ;
	public boolean isCreateBean() ;
	public void setCreateBean(boolean createBean);
	
	public boolean isDeleteBean() ;
	public void setDeleteBean(boolean deleteBean);
	
	public boolean isUpdated() ;
	public void setUpdated(boolean updated);
}
