
function clickretailer(form, which, onVal, offVal) {
 var item = "form."+"retailer"+which;

  if (eval(item).value == offVal) {
     eval(item).value = onVal;
     document.images['retailerCheckbox'+which].src = retailerdown.src;
   
     if(document.all){
          document.all.gln_id.style.visibility="visible";
	  document.all.gln_id1.style.visibility="visible";
	
	}else{
	  document.getElementById("gln_id").style.visibility="visible";
	  document.getElementById("gln_id1").style.visibility="visible";
	}
   }
   else {
     eval(item).value = offVal;
     document.images['retailerCheckbox'+which].src = retailerup.src;
     if(document.all){
          document.all.gln_id.style.visibility="hidden";
	 document.all.gln_id1.style.visibility="hidden";
	}else{
	  document.getElementById("gln_id").style.visibility="hidden";
	  document.getElementById("gln_id1").style.visibility="hidden";
	}
   }
}
function clicknewEnt(form, which, val) {

if(val == "1"){
	form.existEntity.disabled = 1;
	//form.inherit.disabled = 0;
	form.displayname.disabled = 0;
	form.identif.disabled = 0;
	form.address1.disabled = 0;
	form.city.disabled = 0;
	form.state.disabled = 0;	
	form.zip.disabled = 0;
	form.country.disabled = 0;

	if(document.all){//IE
	 document.all.existEntity_id.className = "WizardDisabledInputText";	
	
	 //document.all.inheritID.className = "WizardInputText";
	 document.all.displayname_id.className = "WizardTradingProfilesText";
	 document.all.identif_id.className = "WizardTradingProfilesText";
	 document.all.address1_id.className = "WizardTradingProfilesText";
	 document.all.city_id.className = "WizardTradingProfilesText";
	 document.all.state_id.className = "WizardInputText";
	 document.all.zip_id.className = "WizardTradingProfilesText";
	 document.all.country_id.className = "WizardTradingProfilesText";
	}else{//NS
	 document.getElementById("existEntity_id").className = "WizardDisabledInputText";	
	
	 //document.getElementById("inheritID").className = "WizardInputText";
	 document.getElementById("displayname_id").className = "WizardTradingProfilesText";
	 document.getElementById("identif_id").className = "WizardTradingProfilesText";
	 document.getElementById("address1_id").className = "WizardTradingProfilesText";
	 document.getElementById("city_id").className = "WizardTradingProfilesText";
	 document.getElementById("state_id").className = "WizardInputText";
	 document.getElementById("zip_id").className = "WizardTradingProfilesText";
	 document.getElementById("country_id").className = "WizardTradingProfilesText";
	}	
		   
}else{

	form.existEntity.disabled = 0;
	//form.inherit.disabled = 1;
	form.displayname.disabled = 1;
	form.identif.disabled = 1;
	form.address1.disabled = 1;
	form.city.disabled = 1;
	form.state.disabled = 1;
	form.zip.disabled = 1;
	form.country.disabled = 1;

	if(document.all){//IE
	 document.all.existEntity_id.className = "WizardTradingProfilesText";
	 //document.all.inheritID.className = "WizardDisabledInputText";
	 document.all.displayname_id.className = "WizardDisabledInputText";
	 document.all.identif_id.className = "WizardDisabledInputText";
	 document.all.address1_id.className = "WizardDisabledInputText";
	 document.all.city_id.className = "WizardDisabledInputText";
	 document.all.state_id.className = "WizardDisabledInputText";
	 document.all.zip_id.className = "WizardDisabledInputText";
	 document.all.country_id.className = "WizardDisabledInputText";
  	}else{//NS

	 document.getElementById("existEntity_id").className = "WizardTradingProfilesText";
	
	 //document.getElementById("inheritID").className = "WizardDisabledInputText";
	 document.getElementById("displayname_id").className = "WizardDisabledInputText";
	 document.getElementById("identif_id").className = "WizardDisabledInputText";
	 document.getElementById("address1_id").className = "WizardDisabledInputText";
	 document.getElementById("city_id").className = "WizardDisabledInputText";
	 document.getElementById("state_id").className = "WizardDisabledInputText";
	 document.getElementById("zip_id").className = "WizardDisabledInputText";
	 document.getElementById("country_id").className = "WizardDisabledInputText";
	}

}
  form.newEnt.value = val;
  if (document.images) {
     for (var j=0; j<2; j++) {
       if (j==which)
          document.images['newEntRadio'+j].src = newEntdown.src;
       else
          document.images['newEntRadio'+j].src = newEntup.src;
       }
   }
   else 
     alert('not supported');
}


function clicknewDel(form, which, val) {
if(val == "1"){
	
		form.delivery_id.disabled = 1;
		form.del_displayname.disabled = 0; 
		if(document.all){//IE
		 document.all.deliveryID.className = 'WizardDisabledInputText'; 
		 document.all.del_displayname_id.className = 'WizardTradingProfilesText'; 
		}else{//NS
		 document.getElementById("deliveryID").className = 'WizardDisabledInputText'; 
		 document.getElementById("del_displayname_id").className = 'WizardTradingProfilesText'; 
		}
}else{
		form.delivery_id.disabled = 0;
		form.del_displayname.disabled = 1;
		if(document.all){//IE
		 document.all.deliveryID.className = 'WizardTradingProfilesText'; 
		 document.all.del_displayname_id.className = 'WizardDisabledInputText';   
		}else{//NS
		 document.getElementById("deliveryID").className = 'WizardTradingProfilesText'; 
		 document.getElementById("del_displayname_id").className = 'WizardDisabledInputText';   
		}	 	
}
  form.newDel.value = val;
  if (document.images) {
     for (var j=0; j<2; j++) {
       if (j==which)
          document.images['newDelRadio'+j].src = newDeldown.src;
       else
          document.images['newDelRadio'+j].src = newDelup.src;
       }
   }
   else 
     alert('not supported');
}


function clicknewTrans(form, which, val) {
if(val == "1"){
	
		form.existTransport.disabled = 1;
		form.displayname.disabled = 0;   
		form.rec_protocol.disabled = 0;
		form.end_point.disabled = 0;
		form.end_point_ip.disabled = 0;
		form.end_point_port.disabled = 0;
		form.directory.disabled = 0;
		form.protocol_mode.disabled = 0;
		form.document.disabled = 0;
		form.mailbox.disabled = 0;
		form.mailfrom.disabled = 0;
		form.mailid.disabled = 0;
		form.user_id.disabled = 0;
		form.password.disabled = 0;

		if(document.all){//IE
		 document.all.existTransport_id.className = 'WizardDisabledInputText'; 

		 document.all.displayname_id.className = 'WizardTradingProfilesText'; 
		 document.all.sending_protocol_id.className = 'WizardTradingProfilesText';
		 document.all.end_point_id.className = 'WizardTradingProfilesText';
		 document.all.end_point_ip_id.className = 'WizardInputText';
		 document.all.end_point_port_id.className = 'WizardInputText';
		 document.all.directory_id.className = 'WizardInputText';
		 document.all.protocol_mode_id.className = 'WizardTradingProfilesText';
		 document.all.document_id.className = 'WizardInputText';
		 document.all.mailbox_id.className = 'WizardTradingProfilesText';
		 document.all.mailfrom_id.className = 'WizardTradingProfilesText';
		 document.all.mailid_id.className = 'WizardTradingProfilesText';
		 document.all.user_id_id.className = 'WizardTradingProfilesText';
		 document.all.password_id.className = 'WizardTradingProfilesText';
		}else{//NS

		 document.getElementById("existTransport_id").className = 'WizardDisabledInputText'; 

		 document.getElementById("displayname_id").className = 'WizardTradingProfilesText'; 
		 document.getElementById("sending_protocol_id").className = 'WizardTradingProfilesText';
		 document.getElementById("end_point_id").className = 'WizardTradingProfilesText';
		 document.getElementById("end_point_ip_id").className = 'WizardInputText';
		 document.getElementById("end_point_port_id").className = 'WizardInputText';
		 document.getElementById("directory_id").className = 'WizardInputText';
		 document.getElementById("protocol_mode_id").className = 'WizardTradingProfilesText';
		 document.getElementById("document_id").className = 'WizardInputText';
		 document.getElementById("mailbox_id").className = 'WizardTradingProfilesText';
		 document.getElementById("mailfrom_id").className = 'WizardTradingProfilesText';
		 document.getElementById("mailid_id").className = 'WizardTradingProfilesText';
		 document.getElementById("user_id_id").className = 'WizardTradingProfilesText';
		 document.getElementById("password_id").className = 'WizardTradingProfilesText';
		}

}else{
		form.existTransport.disabled = 0;
		form.displayname.disabled = 1;   
		form.rec_protocol.disabled = 1;
		form.end_point.disabled = 1;
		form.end_point_ip.disabled = 1;
		form.end_point_port.disabled = 1;
		form.directory.disabled = 1;
		form.protocol_mode.disabled = 1;
		form.document.disabled = 1;
		form.mailbox.disabled = 1;
		form.mailfrom.disabled = 1;
		form.mailid.disabled = 1;
		form.user_id.disabled = 1;
		form.password.disabled = 1;


		if(document.all){//IE
		 document.all.existTransport_id.className = 'WizardTradingProfilesText'; 

		 document.all.displayname_id.className = 'WizardDisabledInputText';  
		 document.all.sending_protocol_id.className = 'WizardDisabledInputText'; 
		 document.all.end_point_id.className = 'WizardDisabledInputText'; 
		 document.all.end_point_ip_id.className = 'WizardDisabledInputText'; 
		 document.all.end_point_port_id.className = 'WizardDisabledInputText'; 
		 document.all.directory_id.className = 'WizardDisabledInputText'; 
		 document.all.protocol_mode_id.className = 'WizardDisabledInputText'; 
		 document.all.document_id.className = 'WizardDisabledInputText'; 
		 document.all.mailbox_id.className = 'WizardDisabledInputText'; 
		 document.all.mailfrom_id.className = 'WizardDisabledInputText'; 
		 document.all.mailid_id.className = 'WizardDisabledInputText'; 
		 document.all.user_id_id.className = 'WizardDisabledInputText'; 
		 document.all.password_id.className = 'WizardDisabledInputText'; 
		}else{//NS

		 document.getElementById("existTransport_id").className = 'WizardTradingProfilesText'; 

		 document.getElementById("displayname_id").className = 'WizardDisabledInputText';  
		 document.getElementById("sending_protocol_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("end_point_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("end_point_ip_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("end_point_port_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("directory_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("protocol_mode_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("document_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("mailbox_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("mailfrom_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("mailid_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("user_id_id").className = 'WizardDisabledInputText'; 
		 document.getElementById("password_id").className = 'WizardDisabledInputText'; 
		}

}
  form.newTrans.value = val;
  if (document.images) {
     for (var j=0; j<2; j++) {
       if (j==which)
          document.images['newTransRadio'+j].src = newDeldown.src;
       else
          document.images['newTransRadio'+j].src = newTransup.src;
       }
   }
   else 
     alert('not supported');
}

function clicknewDoc(form, which, val) {
if(val == "1"){
	
		form.existDoc.disabled = 1;
		form.displayname.disabled = 0;   
		if(document.all){//IE
		 document.all.existDoc_id.className = 'WizardDisabledInputText';
		 document.all.displayname_id.className = 'WizardTradingProfilesText';
		}else{//NS
		 document.getElementById("existDoc_id").className = 'WizardDisabledInputText';
		 document.getElementById("displayname_id").className = 'WizardTradingProfilesText';
		}
}else{
		form.existDoc.disabled = 0;
		form.displayname.disabled = 1;   	
		if(document.all){//IE
		 document.all.existDoc_id.className = 'WizardTradingProfilesText';
		 document.all.displayname_id.className = 'WizardDisabledInputText';
		}else{//NS
		 document.getElementById("existDoc_id").className = 'WizardTradingProfilesText';
		 document.getElementById("displayname_id").className = 'WizardDisabledInputText';
		}
}
  form.newDoc.value = val;
  if (document.images) {
     for (var j=0; j<2; j++) {
       if (j==which)
          document.images['newDocRadio'+j].src = newDocdown.src;
       else
          document.images['newDocRadio'+j].src = newDocup.src;
       }
   }
   else 
     alert('not supported');
}


function clicknewPack(form, which, val) {
if(val == "1"){
	
		form.existPack.disabled = 1;
		form.displayname.disabled = 0;
		form.payload_type.disabled = 0; 
		form.mime_type.disabled = 0; 
		form.mime_subtype.disabled = 0;   

		if(document.all){//IE
		 document.all.existPack_id.className = 'WizardDisabledInputText';
		 document.all.displayname_id.className = 'WizardTradingProfilesText';
		 document.all.parsableID.className = 'WizardTradingProfilesText';
		 document.all.payload_type_id.className = 'WizardTradingProfilesText';
		 document.all.mime_type_id.className = 'WizardTradingProfilesText';
		 document.all.mime_subtype_id.className = 'WizardTradingProfilesText';
		}else{//NS

		 document.getElementById("existPack_id").className = 'WizardDisabledInputText';
		 document.getElementById("displayname_id").className = 'WizardTradingProfilesText';
		 document.getElementById("parsableID").className = 'WizardTradingProfilesText';
		 document.getElementById("payload_type_id").className = 'WizardTradingProfilesText';
		 document.getElementById("mime_type_id").className = 'WizardTradingProfilesText';
		 document.getElementById("mime_subtype_id").className = 'WizardTradingProfilesText';

		}
}else{
		form.existPack.disabled = 0;
		form.displayname.disabled = 1;
		form.payload_type.disabled = 1; 
		form.mime_type.disabled = 1; 
		form.mime_subtype.disabled = 1; 

		if(document.all){//IE
		 document.all.existPack_id.className = 'WizardTradingProfilesText';
		 document.all.displayname_id.className = 'WizardDisabledInputText';
	         document.all.parsableID.className ='WizardDisabledInputText';
		 document.all.payload_type_id.className = 'WizardDisabledInputText';
		 document.all.mime_type_id.className = 'WizardDisabledInputText';
		 document.all.mime_subtype_id.className = 'WizardDisabledInputText';
		}else{//NS

		 document.getElementById("existPack_id").className = 'WizardTradingProfilesText';
		 document.getElementById("displayname_id").className = 'WizardDisabledInputText';
	         document.getElementById("parsableID").className ='WizardDisabledInputText';
		 document.getElementById("payload_type_id").className = 'WizardDisabledInputText';
		 document.getElementById("mime_type_id").className = 'WizardDisabledInputText';
		 document.getElementById("mime_subtype_id").className = 'WizardDisabledInputText';


		}	
}
  form.newPack.value = val;
  if (document.images) {
     for (var j=0; j<2; j++) {
       if (j==which)
          document.images['newPackRadio'+j].src = newPackdown.src;
       else
          document.images['newPackRadio'+j].src = newPackup.src;
       }
   }
   else 
     alert('not supported');
}


function populateList(selected, val1, val2){

  if(selected.indexOf('next') != -1){
	  document.wizform.submit();
	}
}

 function populateEntity(selected) { 
   document.wizform.pupulateEntity.value = "yes";
   document.wizform.submit();
 }

 function  warnOnChange ( selected, previous, warning){
  if(selected != previous){
   alert(warning);
  }
}

newBPSSdown= new Image();
newBPSSdown.src= "./images/radio_btn_tra.gif";
newBPSSup= new Image();
newBPSSup.src= "./images/radio_btn_off.gif";
function clickUseBPSS(form, which, val) {

  if(val == "1"){
	form.BPSSName.disabled = 1;
	form.BPSSVersion.disabled = 1;
	form.BinaryCollab.disabled = 1;
	form.PPRole.disabled = 1;
	form.CPRole.disabled = 1;
	form.InitiatingRole.disabled = 0;
	form.RespondingRole.disabled = 0;
	form.Time2AckReceipt.disabled = 0;
	form.Time2AckAccept.disabled = 0;
	form.Time2Perform.disabled = 0;
	form.RetryCount.disabled = 0;
	
	if(document.all){//IE
	 document.all.bpssname_id.className = "WizardDisabledInputText";		
	 document.all.bpsversion_id.className = "WizardDisabledInputText";		
	 document.all.bc_id.className = "WizardDisabledInputText";		
	 document.all.bcrole_id.className = "WizardDisabledInputText";		
	 document.all.cprole_id.className = "WizardDisabledInputText";
	 
	 document.all.InitiatingRole_id.className = "WizardInputText";
	 document.all.RespondingRole_id.className = "WizardInputText";
	 document.all.Time2AckReceipt_id.className = "WizardInputText";
	 document.all.Time2AckAccept_id.className = "WizardInputText";
	 document.all.Time2Perform_id.className = "WizardInputText";
	 document.all.RetryCount_id.className = "WizardInputText";
	}else{//NS
	 document.getElementById("bpssname_id").className = "WizardDisabledInputText";	
	 document.getElementById("bpsversion_id").className = "WizardDisabledInputText";	
	 document.getElementById("bc_id").className = "WizardDisabledInputText";	
	 document.getElementById("bcrole_id").className = "WizardDisabledInputText";	
	 document.getElementById("cprole_id").className = "WizardDisabledInputText";	
	 
	 document.getElementById("InitiatingRole_id").className = "WizardInputText";
	 document.getElementById("RespondingRole_id").className = "WizardInputText";
	 document.getElementById("Time2AckReceipt_id").className = "WizardInputText";
	 document.getElementById("Time2AckAccept_id").className = "WizardInputText";
	 document.getElementById("Time2Perform_id").className = "WizardInputText";
	 document.getElementById("RetryCount_id").className = "WizardInputText";
	}	
  }
  else {
  	form.BPSSName.disabled = 0;
	form.BPSSVersion.disabled = 0;
	form.BinaryCollab.disabled = 0;
	form.PPRole.disabled = 0;
	form.CPRole.disabled = 0;
	form.InitiatingRole.disabled = 1;
	form.RespondingRole.disabled = 1;
	form.Time2AckReceipt.disabled = 1;
	form.Time2AckAccept.disabled = 1;
	form.Time2Perform.disabled = 1;
	form.RetryCount.disabled = 1;
  	
  	if(document.all){//IE
	 document.all.bpssname_id.className = "WizardInputText";		
	 document.all.bpsversion_id.className = "WizardInputText";		
	 document.all.bc_id.className = "WizardInputText";		
	 document.all.bcrole_id.className = "WizardInputText";		
	 document.all.cprole_id.className = "WizardInputText";
	 
	 document.all.InitiatingRole_id.className = "WizardDisabledInputText";
	 document.all.RespondingRole_id.className = "WizardDisabledInputText";
	 document.all.Time2AckReceipt_id.className = "WizardDisabledInputText";
	 document.all.Time2AckAccept_id.className = "WizardDisabledInputText";
	 document.all.Time2Perform_id.className = "WizardDisabledInputText";
	 document.all.RetryCount_id.className = "WizardDisabledInputText";
	}else{//NS
	 document.getElementById("bpssname_id").className = "WizardInputText";	
	 document.getElementById("bpsversion_id").className = "WizardInputText";	
	 document.getElementById("bc_id").className = "WizardInputText";	
	 document.getElementById("bcrole_id").className = "WizardInputText";	
	 document.getElementById("cprole_id").className = "WizardInputText";	
	 
	 document.getElementById("InitiatingRole_id").className = "WizardDisabledInputText";
	 document.getElementById("RespondingRole_id").className = "WizardDisabledInputText";
	 document.getElementById("Time2AckReceipt_id").className = "WizardDisabledInputText";
	 document.getElementById("Time2AckAccept_id").className = "WizardDisabledInputText";
	 document.getElementById("Time2Perform_id").className = "WizardDisabledInputText";
	 document.getElementById("RetryCount_id").className = "WizardDisabledInputText";
	}	
  }
  form.UseBPSS.value = val;
  if (document.images) {
     for (var j=0; j<2; j++) {
       if (j==which)
          document.images['UseBPSSRadio'+j].src = newBPSSdown.src;
       else
          document.images['UseBPSSRadio'+j].src = newBPSSup.src;
       }
   }
   else 
     alert('not supported');

}




