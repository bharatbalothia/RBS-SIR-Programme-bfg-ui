/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.webapps.taglibs.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;


import com.stercomm.customers.webapps.resources.Constants;
import com.sterlingcommerce.woodstock.security.User;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 * created Apr 24, 2006
 */
public class IfHasPermissionTag extends BodyTagSupport {
	private static final long serialVersionUID = 1L;
	//private static final Log log = LogFactory.getLog(IfHasPermissionTag.class);
	
	private String permission;
	private boolean not = false;
	private boolean all = false;
	private String[] permissionSet;
	
	public int doStartTag() throws JspException {
		boolean authorized = false;
		HttpSession session = ((HttpServletRequest)pageContext.getRequest()).getSession();
		User user = (User)session.getAttribute(Constants.GIS_USER_OBJECT);
		if (user !=null){
			if (permissionSet.length==1){
				authorized = user.hasPermission(permission);
				//logger.debug("1)checking if user has permission:"+permission+";"+authorized);
			}
			else {
				if (isAll()){
					authorized = true;
					for (int i=0; i<permissionSet.length; i++){
						if ((authorized = user.hasPermission(permissionSet[i])) == false){
							break;
						}
					}
				}
				else {
					for (int i=0; i<permissionSet.length; i++){
						if ((authorized = user.hasPermission(permissionSet[i])) == true){
							break;
						}
					}
				}
			}
		}
		//logger.debug("authorized:"+authorized+";not="+not+";returning:"+(not^authorized));
		//xor authorized with the NOT parameter
		return not^authorized?EVAL_BODY_INCLUDE:SKIP_BODY;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getNot() {
		return not?"true":"false";
	}

	public void setNot(String not) {
		this.not = not.equalsIgnoreCase("true")||not.equalsIgnoreCase("yes");
	}

	public String getPermission() {
		return permission;
	}

	public void setPermission(String permission) {
		this.permission = permission;
		permissionSet = permission.split(",");
	}

	public boolean isAll() {
		return all;
	}

	public void setAll(boolean all) {
		this.all = all;
	}

	public void setNot(boolean not) {
		this.not = not;
	}

	public boolean isNot(){
		return not;
	}
}

/**********************************************************************
*
* Revision History
* ================
*
* $Log: $
*/