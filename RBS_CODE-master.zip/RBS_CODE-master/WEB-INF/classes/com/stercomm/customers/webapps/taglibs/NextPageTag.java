/**
 * 
 */
package com.stercomm.customers.webapps.taglibs;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

/**
 * @author Ravi K Patel
 * created Feb 27, 2006
 */
public class NextPageTag extends BodyTagSupport {
	private static final long serialVersionUID = 1L;
	
	private static final int BACK=1;
	private static final int NEXT=2;
	private static final int ERROR=3;
	
	
	private int direction = NEXT;
	private int currentPage;
	private int totalResults;
	private int pageSize;
	
	private boolean printTag = true;
	private String baseURL="";
	
	private String img="";
	
	public int doStartTag() throws JspException {
		int totalPages = (int)Math.ceil(totalResults/(double)pageSize);
		printTag=true;
		try {
			switch (direction){
			case BACK: if (currentPage>1 && totalPages >0) {printStartTag(currentPage-1);}else printTag=false; break;
			case NEXT: if (currentPage<totalPages) {printStartTag(currentPage+1);}else printTag=false; break;
			default: printTag = false;
			
			}
		} catch (IOException e) {
			throw new JspException(e);
		}
		
		return super.doStartTag();
	}
	
	private void printStartTag(int toPage) throws IOException{
			StringBuffer out = new StringBuffer("<a href=\""); //open tag
			out.append(baseURL);
			int indexPoint = baseURL.lastIndexOf('?');
			if (indexPoint==-1)out.append('?');
			else if (indexPoint!=baseURL.length()-1 && baseURL.charAt(baseURL.length()-1)!='&') out.append('&');
			//else {}// baseURL contains parameters, and already ends with a '&'
			out.append("page=");//set gotoPage
			out.append(toPage); //set gotoPage
			out.append("\">");//close tag
			
			pageContext.getOut().print(out.toString());
	}
	
	
	private String wrapAttrib(String name, String value){
		return name+"=\""+value+"\"";
	}
	
	public int doEndTag() throws JspException {
		StringBuffer out = new StringBuffer();
		out.append("<img");
		out.append(wrapAttrib(" src", img));
		out.append(wrapAttrib(" border", "0"));
		if (printTag){
			int toPage = direction==NEXT?currentPage+1:currentPage-1;
			int nextPageResults = pageSize*toPage;
			nextPageResults = nextPageResults>totalResults?totalResults:nextPageResults;
			String alt = "Page " +toPage+": Results "+ (pageSize*(toPage-1)+1)+"-"+(nextPageResults);
			out.append(wrapAttrib("alt", alt));
			out.append(wrapAttrib("title", alt));
			//: Processes 11-20"
		}

		out.append("/>");
		if (printTag){
			out.append("</a>");
		}
		try {
			pageContext.getOut().print(out.toString());
		} catch (IOException e) {
			throw new JspException(e);
		}
		return super.doEndTag();
	}
	
	
	
	
	public String getDirection() {
		return Integer.toString(direction);
	}
	public void setDirection(String direction) {
		this.direction = direction.equalsIgnoreCase("BACK")?BACK:direction.equalsIgnoreCase("NEXT")?NEXT:ERROR;
	}
	public String getBaseURL() {
		return baseURL;
	}
	public void setBaseURL(String baseURL) {
		this.baseURL = baseURL;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getTotalResults() {
		return totalResults;
	}
	public void setTotalResults(int totalResults) {
		this.totalResults = totalResults;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
}
