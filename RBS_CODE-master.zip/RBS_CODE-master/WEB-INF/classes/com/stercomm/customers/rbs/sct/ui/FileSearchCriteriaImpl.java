/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui;

import java.util.Date;
import org.apache.log4j.Logger;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class FileSearchCriteriaImpl implements FileSearchCriteria {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(FileSearchCriteriaImpl.class);
	
	private Integer entityId;
	private String service;
	private String direction;
	private String fileStatus;
	private String bpState;
	private String filename;
	private String reference;
	private String type;
	private Date fromDate;
	private Date toDate;
	private String minDiff;
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getEntityId()
	 */
	public Integer getEntityId() {
		return entityId;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setEntityId(java.lang.Integer)
	 */
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getService()
	 */
	public String getService() {
		return service;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setService(java.lang.String)
	 */
	public void setService(String service) {
		this.service = service;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getDirection()
	 */
	public String getDirection() {
		return direction;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setDirection(java.lang.String)
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getFileStatus()
	 */
	public String getFileStatus() {
		return fileStatus;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setFileStatus(java.lang.String)
	 */
	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getBpState()
	 */
	public String getBpState() {
		return bpState;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setBpState(java.lang.String)
	 */
	public void setBpState(String bpState) {
		this.bpState = bpState;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getFilename()
	 */
	public String getFilename() {
		return filename;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setFilename(java.lang.String)
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getReference()
	 */
	public String getReference() {
		return reference;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setReference(java.lang.String)
	 */
	public void setReference(String reference) {
		this.reference = reference;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getType()
	 */
	public String getType() {
		return type;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setType(java.lang.String)
	 */
	public void setType(String type) {
		this.type = type;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getFromDate()
	 */
	public Date getFromDate() {
		return fromDate;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setFromDate(java.util.Date)
	 */
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getToDate()
	 */
	public Date getToDate() {
		return toDate;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setToDate(java.util.Date)
	 */
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getMinDiff()
	 */
	public String getMinDiff() {
		return minDiff;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setMinDiff(java.lang.String)
	 */
	public void setMinDiff(String minDiff) {
		this.minDiff = minDiff;
	}
	
}
