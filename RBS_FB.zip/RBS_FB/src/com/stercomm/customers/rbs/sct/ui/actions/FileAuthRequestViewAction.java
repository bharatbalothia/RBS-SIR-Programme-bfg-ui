package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.stercomm.customers.rbs.sct.ui.dao.FileAuthRequestDAO;
import com.stercomm.customers.rbs.sct.ui.dto.FileAuthRequest;
import com.stercomm.customers.rbs.sct.ui.fileauth.FGFile;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuth;



/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
@SuppressWarnings("unchecked")
public class FileAuthRequestViewAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(FileAuthRequestViewAction.class);

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		log.debug("FileAuthRequestViewAction.viewForm()");

		String reqFileAuthID = request.getParameter("id");
		String _fileKey=null;
		String _fileAction=null;
		FileAuth reqFA = null;

		ActionErrors errors = new ActionErrors();

		try {

			if(reqFileAuthID!=null &&  !reqFileAuthID.equalsIgnoreCase("")){
				int reqFAID=0;
				try {
					reqFAID = Integer.parseInt(reqFileAuthID);
				} catch (NumberFormatException e) {
					throw new Exception("Invalid FileAuthID parameter value: " +  reqFileAuthID);
				}
				reqFA = new FileAuth(reqFAID);
				if(!reqFA.isLoaded()){
					throw new Exception("Cannot load record from File Auth ID: "+ reqFAID);
				}

				_fileKey = reqFA.getFileKey();
				_fileAction = FileAuth.validateAction(reqFA.getAction());

			} else {
				throw new Exception("Invalid FileAuthID parameter value (null)");
			}


			FileAuthRequestDAO dao = new FileAuthRequestDAO(getHibernateSession());
			FileAuthRequest far = null;

			String arrivedFileKey = _fileKey;
			String deliveryKey = null;

			if(_fileAction.equalsIgnoreCase(FileAuth.ACTION_REDELIVER)){			
				deliveryKey = _fileKey;
				arrivedFileKey=FGFile.findAFKey(deliveryKey);
				if(arrivedFileKey==null){
					throw new Exception("Cannot find FGFile for DeliveryKey: " + deliveryKey);
				}
			}


			FGFile fgFile = new FGFile(arrivedFileKey);
			if(fgFile==null || fgFile.getArrivedFilename().length()==0){
				//no arrivedfile record
				throw new Exception("Cannot load FGFile with ArrivedFileKey: " + arrivedFileKey);
			}


			far = dao.getInstance(reqFA);
			far.setFgFile(fgFile);

			request.getSession().setAttribute("fileAuthRequestBean", far);
			return mapping.findForward("viewForm");

		} catch (Exception e){
			log.error("FileAuthRequestViewerror: " + e.getMessage());
			errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.view.error"));
			saveErrors(request, errors);	
			request.getSession().setAttribute("fileAuthRequestBean", null);
			String eMsg = e.getMessage()==null?"None":e.getMessage().trim();
			request.setAttribute("exceptionMessage", "Exception message: " + eMsg);
			return mapping.findForward("error");
		}
	}


}
