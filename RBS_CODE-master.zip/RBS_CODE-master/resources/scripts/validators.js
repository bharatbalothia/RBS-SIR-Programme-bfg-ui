////////////////////////////////////////////////////////////////////
// (C) Copyright 2001 - 2010 Sterling Commerce, Inc. ALL RIGHTS RESERVED
//
// ** Trade Secret Notice **
//
// This software, and the information and know-how it contains, is
// proprietary and confidential and constitutes valuable trade secrets
// of Sterling Commerce, Inc., its affiliated companies or its or
// their licensors, and may not be used for any unauthorized purpose
// or disclosed to others without the prior written permission of the
// applicable Sterling Commerce entity. This software and the
// information and know-how it contains have been provided
// pursuant to a license agreement which contains prohibitions
// against and/or restrictions on its copying, modification and use.
// Duplication, in whole or in part, if and when permitted, shall
// bear this notice and the Sterling Commerce, Inc. copyright
// legend. As and when provided to any governmental entity,
// government contractor or subcontractor subject to the FARs,
// this software is provided with RESTRICTED RIGHTS under
// Title 48 CFR 52.227-19.
// Further, as and when provided to any governmental entity,
// government contractor or subcontractor subject to DFARs,
// this software is provided pursuant to the customary
// Sterling Commerce license, as described in Title 48
// CFR 227-7202 with respect to commercial software and commercial
// software documentation.
/////////////////////////////////////////////////////////////////
/*
   Extension file that is meant to implement CSRF protection across the board by adding a hidden 
   variable to each form on every page that calls validators.js.  This Variable is then checked 
   against our CSRF filter that is controlled in ifcui_config.xml.
 */

//Global Variables

/* Token variables */
var TokenName = "";
var TokenValue = "";

/* The time to remove the loading display if the CSRF response never returns */
var loadingDisplayTimeout = 60000;

/* The time after the CSRF response returns to remove the loading image if it was displayed */
var removeLoadingImageDelay = 600;

/* The time after the CSRF response returns to remove the loading display */
var removeLoadingDisplayDelay = 0;

/* Image sizes to ensure that IE displays the image appropriately */
var loadingImageHeight = 16;
var loadingImageWidth = 16;

/* The time between attempts to add the loading display */
var addLoadingDisplayTimer = 0;

/* Maximum height of pixels to block */
var loadingDisplayBlockingHeight = 2000;

/* Time to delay loading the image to ensure a cleaner display */
var imageLoadingDelay = 350;

/* Number of pixels down the screen to display the loading image */
var loadingImageDisplayHeight = 190;

//Setup Definitions

/**
 *  Setup the loading display 
 */
function setupLoading() { 

  var blockDiv = document.createElement("div");
  blockDiv.id="blockDiv";
  blockDiv.style.display="block";
  blockDiv.style.height= loadingDisplayBlockingHeight + "px";
  blockDiv.style.width="100%";
  blockDiv.style.position="absolute";
  blockDiv.style.opacity="0";
  blockDiv.style.filter="alpha(opacity=0)";
  blockDiv.style.background="#ffffff";
  blockDiv.style.zIndex="100";

  var containingDiv = document.createElement("div");
  containingDiv.id="loadingDivContainer";
  containingDiv.style.width="100%";
  containingDiv.style.position="absolute";
  containingDiv.style.top= loadingImageDisplayHeight + "px";
  containingDiv.style.textAlign="center";
  containingDiv.style.zIndex="101";

  var loadingDiv = document.createElement("div");
  loadingDiv.id="loadingDiv";
  loadingDiv.style.margin="0 auto";
  loadingDiv.style.width="50%";
  loadingDiv.style.textAlign="left";
  loadingDiv.style.zIndex = "102";

  var image = document.createElement("IMG");
  var pathArray = window.location.pathname.split('/');
  var pathWebApp = pathArray[1];
  if (!pathWebApp){
    pathWebApp = ".";
  }
  else {
    pathWebApp = "/" + pathWebApp;
  }
  if(window.location.href.indexOf("/admin") > -1){
    image.src =  "./images/loading.gif";
  }
  else{
    image.src = pathWebApp + "/images/loading.gif";
  }
  image.width = loadingImageWidth;
  image.height = loadingImageHeight;
  containingDiv.appendChild(loadingDiv);

  setTimeout(function() { addLoadingDisplay(blockDiv, containingDiv, loadingDiv, image) }, 0);
}

/**
 *   Add the loading display 
 */
function addLoadingDisplay(blockDiv, containingDiv, loadingDiv, image) { 
  var loadingRemoved = document.getElementById("loadingRemoved");
  if(loadingRemoved == null) { 
    var setup = false;
    if(document.body != null) { 
      if(document.getElementById("addedLoadingDisplay") == null) { 
        if (document.body.firstChild) {
          var firstChild = document.body.firstChild;
          document.body.insertBefore(blockDiv, firstChild);
          document.body.insertBefore(containingDiv, blockDiv);
        } else {
          document.body.appendChild(blockDiv);
          document.body.insertBefore(containingDiv, blockDiv);
        }
        var addedLoadingDisplay = document.createElement("div");
        addedLoadingDisplay.id = "addedLoadingDisplay";
        addedLoadingDisplay.style.display="none";
        document.body.appendChild(addedLoadingDisplay);
        setTimeout(function() { enableImage(loadingDiv, image) }, imageLoadingDelay );
  
        setTimeout(removeLoadingDisplay , loadingDisplayTimeout);
      }
    }
    else { 
      setTimeout(function() { addLoadingDisplay(blockDiv, 
            containingDiv, loadingDiv, image) }, addLoadingDisplayTimer);
    }
  }
}


/**
*  Enable the image
*/
function enableImage(loadingDiv, image) { 
  loadingDiv.appendChild(image);
}

/** 
 *  Enable CSRF protection on every page that loads without having to edit every jsp
 */
function addCsrfEventListener() { 
  //this enables CSRF protection on every page that loads without having to edit every jsp
  if(window.addedCsrfEventListener == null) {
    if(window.addEventListener){ //non ie
      window.addEventListener("load",getCSRFTokenAJAX,false);
    }
    else if(window.attachEvent){ //ie
      window.attachEvent("onload", getCSRFTokenAJAX);
    }
    window.addedCsrfEventListener = true;
  }
}

//Execution


/* Setup the loading display */
setupLoading();
/* Add the CSRF event listeners */
addCsrfEventListener();

//Utility definitions

function weaveCSRFToken(CSRFResp){
  var delimiter = CSRFResp.indexOf(":::");
  TokenName = CSRFResp.substring(0,delimiter);
  TokenValue = CSRFResp.substring(delimiter+3);

  addTokenToForms();
  addTokenToLinks();
  addTokenToFrames();
  addTokenToMenuItems();
  addTokenToOnClick();
}

/** 
 * Loops through all forms on a page
 * Then it create a new element type of input that is hidden
 * and adds the CSRF token to the form.
 */
function addTokenToForms(){
  for(var i=0;i<document.forms.length; i++){
    var currentForm = document.forms[i];
    var token = document.createElement('input');
    token.setAttribute("name",  TokenName);
    token.setAttribute("value", TokenValue);
    token.setAttribute("type", "hidden");
    currentForm.appendChild(token);

    // If the Content-Type is multipart/form-data, Struts is known to
    // have issues; add to the action URL as well.
    if (/^multipart\/form-data$/i.test(currentForm.enctype)) {
      var oldURL = null;
      var actionAttr = currentForm.getAttribute("action");

      if (actionAttr && actionAttr.nodeType === undefined) {
          // This rather strange test is necessary in the case where
          // the form has an <input> element with name "action", which
          // occurs at least once in the SI code base (BP invocation
          // through the UI).  In this situation, getAttribute() in
          // IE8 appears to return the <input> element instead of the
          // form's attribute.  The assumption is that the CSRF token
          // has been correctly woven independent of this code (the BP
          // invocation code appears to use wowmultipart.jsp)

          oldURL = actionAttr;
      }

      if (oldURL) { currentForm.setAttribute("action", appendURL(oldURL)); }
    }
  }//end for loop
}

/**
 *   Remove the loading display after the CSRF tokens have been
 *   updated 
 */
function removeLoadingDisplay() {

  var blockDiv = document.getElementById("blockDiv");
  var container = document.getElementById("loadingDivContainer");
  if(blockDiv != null) { 
    blockDiv.style.display="none";
  }
  if(container != null) { 
    container.style.display="none";
  }
  var loadingRemoved = document.createElement('div');
  loadingRemoved.style.display="none";
  loadingRemoved.id="loadingRemoved";
  document.body.appendChild(loadingRemoved);
}

/**
 *  Makes a call to the servlet CSRFInfo using AJAX and returns the response from the servlet
 */
function getCSRFTokenAJAX(){

  //This is called on formload so its the best place to call these
  var xhttp;
  var resText;
  if (window.XMLHttpRequest) { //Current Browsers
    xhttp = new XMLHttpRequest();	
  }
  else{  //Older IE
    xhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  //gotta listen for the response
  xhttp.onreadystatechange = function(){
    if(xhttp.readyState == 4 && xhttp.status == 200){
      weaveCSRFToken(xhttp.responseText);
    }

    if (xhttp.readyState == 4) {
      //Remove the loader regardless of the response status
      var delay = removeLoadingDisplayDelay;
      var loadingDiv = document.getElementById("loadingDiv");
      //If the image was loaded, delay removing it to ensure a
      //smoother transition
      if(loadingDiv != null && loadingDiv.hasChildNodes() && delay < removeLoadingImageDelay) {
          delay = removeLoadingImageDelay; 
      }
      setTimeout( removeLoadingDisplay, delay);
    }
  }
  var csrfURL;
  var pathArray = window.location.pathname.split('/');
  var pathWebApp = pathArray[1];
  if (!pathWebApp){                            
    pathWebApp = ".";
  }
  else {
    pathWebApp = "/" + pathWebApp;
  }
  
  /* 
   * RKP 2015-11-09
   * Hardcode reference to /ws (replacing the logic in the lines above)
   * This allows calls to the /CSRFInfo servlet running on the WS app
   */
  pathWebApp="/ws";
  
  if(window.location.href.indexOf("/admin") > -1){
    csrfURL =  "./CSRFInfo";
  }
  else{
    csrfURL = pathWebApp + "/CSRFInfo";    
  }

  csrfURL = csrfURL + "?rand=" +Math.floor(Math.random()*11) + new Date().getTime(); //Have to append randon unique number to get around IE caching issue
  xhttp.open("GET", csrfURL , true);
  xhttp.send(null);
}

/**
 *  Also need to override window.location so we can append a token to it
 */
function addTokenToOnClick(){
  var tags = document.getElementsByTagName("input");
  for( var i=0; i<tags.length; i++){
    var attr = tags[i].attributes.onclick;
    if((attr != null) && (typeof attr != 'undefined') && (attr.value != 'null') )
    {
      var oldURL = String(tags[i].attributes.onclick.value);
      if(oldURL.indexOf("window.location") > -1 && oldURL.indexOf("javascript") < 0){
        var quotPos1 = oldURL.indexOf("'");
        var quotPos2 = oldURL.lastIndexOf("'");
        var URL1 = oldURL.substring(quotPos1 + 1, quotPos2);
        var newURL =  appendURL(URL1);
        tags[i].onclick =  (function(newURL){
            return function(){
            window.location =  newURL;
            }
            })(newURL);
      }
    }
  }//end for loop
}//end addTokenToOnClick


/**
 *  Appends TokenName and TokenValue to a URL
 */
function appendURL(url){
    var appendType = (url.indexOf("?")<0) ? "?" : "&";
    var newURL = url;
    if (url.indexOf(TokenName) == -1){
      newURL = url + appendType + TokenName + "=" + TokenValue;
    }
    return newURL;
}

/**
 *  Needs to loop through every href on the page and append the token 
 */
function addTokenToLinks(){
  for(var i=0; i<document.links.length; i++){
    var currentLink = document.links[i];
    if(currentLink.href.indexOf('javascript:') == -1)//Javascript functions should be handled by the form update or the window.open replace above
    {
      var oldURL = currentLink.href;
      currentLink.href = appendURL(oldURL);
    }
  }	
}

/**
 * Replace src in iFrames
 */
function addTokenToFrames(){
  var tags = document.getElementsByTagName("iframe");
  for( var i=0; i<tags.length; i++){
    var oldURL = tags[i].src;
    tags[i].src = appendURL(oldURL);
  }
}

/**
 *  Add token to menu items
 */
function addTokenToMenuItems(){
  if(typeof yfcMenu1 != 'undefined'){
    fixSpecificMenu(yfcMenu1.subMenu);
    fixSpecificMenu(yfcMenu2.subMenu);
    fixSpecificMenu(yfcMenu3.subMenu);
    fixSpecificMenu(yfcMenu4.subMenu);
    fixSpecificMenu(yfcMenu5.subMenu);	
  }
}
/**
 * Recursively change all the sub menu URL's
 */
function fixSpecificMenu(menuToFix){
  for(var i=0; i<menuToFix.length;i++){
    if(menuToFix[i].subMenu != null)
    {	fixSpecificMenu(menuToFix[i].subMenu);	} //submenuception
    else
    {	menuToFix[i].url = appendURL(menuToFix[i].url); }
  }
}



var swiftLc1Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ23456789";
var swiftLc2Chars = "ABCDEFGHIJKLMNPQRSTUVWXYZ0123456789";

function validateSWIFTADDRESS(address, type) {
  if (address == "*") return true;
  if (type == "BIC8") {
    if (address.length != 8) return false;
    for (var k = 0; k < 6; k++) {
      if (uppercaseChars.indexOf(address.charAt(k)) == -1) return false;
    }
    if (swiftLc1Chars.indexOf(address.charAt(6)) == -1) return false;
    if (swiftLc2Chars.indexOf(address.charAt(7)) == -1) return false;
    return true;
  } else if (type == "Nickname") {
    if ((address.length > 31) || (address.length < 1)) return false;
    return true;
  } else if (type == "DN") {
    if ((address.length > 100) || (address.length < 1)) return false;
    return true;
  } else {
    return true;
  }
}

function validateSWIFTVALFLAG(flag, yearField1, yearField2) {
  // SLOA was replaced by SECL in 2007.
  var year;
  if (yearField1 != null) {
    year = yearField1.value;
  } else if (yearField2 != null) {
    year = yearField2.value;
  }
  if ((year != null) && (year != "")) {
    var yearInt = parseInt(year);
    if ((yearInt >= 2007) && (flag == "SECL")) {
      return false;
    } else if ((yearInt < 2007) && (flag == "SLOA")) {
      return false;
    }
  }
  return true;
}

function addPriorityCodeTest(priorityCode) {
  var code = priorityCode;
  if((code != null) && ( code != "" )){
  	if((code.length == 1)&& (code != "*")){
  		return false;
  	}else if((code.length == 2)&& (code.indexOf('Q') != 0)) {
		return false;
	}
  }  
  return true;
}

var swiftLc1Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ23456789";
var swiftLc2Chars = "ABCDEFGHIJKLMNPQRSTUVWXYZ0123456789";

function validateSWIFTADDRESS(address, type) {
  if (address == "*") return true;
  if (type == "BIC8") {
    if (address.length != 8) return false;
    for (var k = 0; k < 6; k++) {
      if (uppercaseChars.indexOf(address.charAt(k)) == -1) return false;
    }
    if (swiftLc1Chars.indexOf(address.charAt(6)) == -1) return false;
    if (swiftLc2Chars.indexOf(address.charAt(7)) == -1) return false;
    return true;
  } else if (type == "Nickname") {
    if ((address.length > 31) || (address.length < 1)) return false;
    return true;
  } else if (type == "DN") {
    if ((address.length > 100) || (address.length < 1)) return false;
    return true;
  } else {
    return true;
  }
}

function validateSWIFTVALFLAG(flag, yearField1, yearField2) {
  // SLOA was replaced by SECL in 2007.
  var year;
  if (yearField1 != null) {
    year = yearField1.value;
  } else if (yearField2 != null) {
    year = yearField2.value;
  }
  if ((year != null) && (year != "")) {
    var yearInt = parseInt(year);
    if ((yearInt >= 2007) && (flag == "SECL")) {
      return false;
    } else if ((yearInt < 2007) && (flag == "SLOA")) {
      return false;
    }
  }
  return true;
}

function addPriorityCodeTest(priorityCode) {
  var code = priorityCode;
  if((code != null) && ( code != "" )){
  	if((code.length == 1)&& (code != "*")){
  		return false;
  	}else if((code.length == 2)&& (code.indexOf('Q') != 0)) {
		return false;
	}
  }  
  return true;
}

function validateGS05TimeFormat(timeFormat, version) {   
   if (timeFormat != null) {
      if (timeFormat.length < 6) {
         // No version check needed - the format is valid.
         return true;
      } else {
         // Parse the version.
         var versionInt = null;
         if (version.length >= 2) {
            if (version.substring(0, 2) == "00") {
               if (version.length >= 6)
                  versionInt = parseInt(version.substring(2, 6));
               else
                  return false;
            } else {
               // Leading zeroes were not included.
               if (version.length >= 4)
                  versionInt = parseInt(version.substring(0, 4));
               else
                  return false;               
            }
         } else {
            // Unrecognized version.
            return false;
         }
         if (timeFormat.length < 7) {            
            // Version must be 003020 or above.
            if (versionInt >= 3020)
               return true;
            else
               return false;            
         } else {            
            // Version must be 003031 or above.
            if (versionInt >= 3031)
               return true;
            else
               return false;
         }
      }
   } else {
      // No time format specified.  This should not happen from the UI.
      return false;
   }
}





////////////////////////////////////////////////////////////////////
// Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.
//
// ** Trade Secret Notice **
//
// This software, and the information and know-how it contains, is
// proprietary and confidential and constitutes valuable trade secrets
// of Sterling Commerce, Inc., its affiliated companies or its or
// their licensors, and may not be used for any unauthorized purpose
// or disclosed to others without the prior written permission of the
// applicable Sterling Commerce entity. This software and the
// information and know-how it contains have been provided
// pursuant to a license agreement which contains prohibitions
// against and/or restrictions on its copying, modification and use.
// Duplication, in whole or in part, if and when permitted, shall
// bear this notice and the Sterling Commerce, Inc. copyright
// legend. As and when provided to any governmental entity,
// government contractor or subcontractor subject to the FARs,
// this software is provided with RESTRICTED RIGHTS under
// Title 48 CFR 52.227-19.
// Further, as and when provided to any governmental entity,
// government contractor or subcontractor subject to DFARs,
// this software is provided pursuant to the customary
// Sterling Commerce license, as described in Title 48
// CFR 227-7202 with respect to commercial software and commercial
// software documentation.
/////////////////////////////////////////////////////////////////
function helpWin(loc){
  window.open(loc,'Info','top=10,left=15,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=460,height=400').focus();
}

function EDIIntWin(loc){
  window.open(loc,'Info','top=10,left=15,location=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=800,height=500').focus();
}

function BPSSAudit(loc){
  location.href = loc;
}

 function winopen(loc,name,menubar,width,height){

     var tmp = "top=10,left=300,location=no,status=yes,menubar=";
     tmp += menubar ;
     tmp += ",scrollbars=yes,resizable=yes,width=";
     tmp += width ;
     tmp += ",height=";
     tmp += height ;
     tmp += ",dependent=yes";
     window.open(loc, name , tmp).focus()
   }

/*
 function openWin(loc,name){
     window.open(loc, name , 'top=10,left=300,location=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=600,height=400,dependent=yes').focus()
   }

/*
 function openInfoWin(loc , name ){
     window.open(loc, name , 'top=10,left=15,location=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=725,height=400').focus()
   }

 function openSubProcessWin(loc, name){
     window.open(loc, name , 'top=10,left=15,location=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width=725,height=400').focus()
   }
*/
 function openSizableSubProcessWin(loc, name, width, height){
     window.open(loc, name , 'top=10,left=15,location=no,status=yes,menubar=no,scrollbars=yes,resizable=yes,width='+width+',height='+height).focus()
 }



var validNumAlpha="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
var validNumAlphaSpecial="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-$";
var validNumAlphaSpace="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_- &";
var validSpecial="-:$&/_.\\' ";
var validSpecial_no_slashes="-:$&_.' ";
var validSpecial_no_spaces="-:$&/_.\\'";

var validTRADCOMCHARS=" (_-%&).*,/0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
var validURI="-_.!~*();/?:@$,abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
var validSAPHOST="-_./abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

var invalidMsgPattern = ":?<>|/\"%\\"
var invalidMbox = "?<>|\'\":\\/%*"
var invalidMboxDesc = "!@#%^()+?,<>{}[]|\"'$/";
var invalidChars = "!@#%^*()+?,<>[]{}'\"|;"
var invalidCharsPwd = "()+?,<>[]{}'\"|;"
var invalidPassword = " \\/'\""
var invalidServicePassword = " \\/'\""
var invalidCharsSlashes = "!@#%^*()+?,<>[]{}\\/'\"|;"
var invalidCharsSpaces = "!@#%^*()+?,<>[]{}' \"|;"
var invalidNumbers = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-:$&/_.\\'!@#%^*()+?,<>[]{}=~|\";` "
 var validNumbers = "0123456789"
var valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-:$&/_.\\ ";

var valid_no_slashes = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-:$&_. ";

var valid_no_spaces =
"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-:$&/_.\\";

var valid_fractional_number = "0123456789.";

function freeText(elm, required) {
  var ele = elm.value + "";
  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }
  var allBlanks=true;
  for (var i=0; i<ele.length; i++) {
    if (ele.charAt(i) != ' ')
       allBlanks= false;
  }
  if (allBlanks)
      return false;
   return true;
}

function checkLength(elm, minSize,wildcardAllow ) {
    var ele = elm.value + "";
    // Check for wild card character
    if( wildcardAllow == "1"  ){
      if( ele.length >= 1 && ele.charAt(0) == '*' ) return true;
    }
    if (minSize != -1 && ele.length < minSize)
       return false;
    if (minSize != -1 && ele == 'EMPTY')
       return false;

    return true;
}
function checkExactLength(elm, size) {
    var ele = elm.value + "";
    if ((size != -1 && ele.length < size) ||
        (size != -1 && ele.length > size))
       return false;
    return true;
}

function addTimeZone(url){
	var tz = (new Date()).getTimezoneOffset();
	var qmpos = url.lastIndexOf( '?' );
	var hashpos = url.lastIndexOf( '#' );
	var buf = hashpos > qmpos ? url.substring( 0, hashpos ) : url;
	buf+= qmpos > -1 ? '&' : '?';
	buf+= 'tz=' + tz ;
	if( hashpos > qmpos ) {
		buf+= url.substring( hashpos );
	}
location.href = buf;

}

function evalChars(elm, required, wildcardAllow , type ) {
  var ele = elm.value + "";
  // Check whether value is empty and required
  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }
  // Check for all blanks
  var allBlanks=true;
  for (var i=0; i<ele.length; i++) {
    if (allBlanks && ele.charAt(i) != ' '){
       allBlanks= false;
       break;
    }
  }
// Check for wild card character
 if( wildcardAllow == "1"  ){
    if( ele.length == 1 && ele.charAt(0) == '*' ) return true;
  }

  if( (required == "1") && allBlanks ) return false ;
  if( type == "ACHRULES"){
     if( ele.length != 9 ) return false ;
     for( var k=0; k<9 ; k++ ){
       if(validNumbers.indexOf(ele.charAt(k)) == -1) return false ; 
     }
     var chksum = 0;
     chksum = ele.charAt(0) * 3 ;
     chksum +=  ele.charAt(1) * 7 ;
     chksum +=  ele.charAt(2) * 1;
     chksum +=  ele.charAt(3) * 3 ;
     chksum +=  ele.charAt(4) * 7 ;
     chksum +=  ele.charAt(5) * 1;
     chksum +=  ele.charAt(6) * 3 ;
     chksum +=  ele.charAt(7) * 7 ;
     chksum = chksum % 10 ;
     if( chksum != 0 )chksum = 10 - chksum ; 
     if( chksum != ele.charAt(8) ) return false ;
     return true ; 
  }
  var allZeroes = true;
  // Check for valid chars based on type
  for (var i=0; i<ele.length; i++) {
    if( type == "ALPHANUMERIC"){
       if(validNumAlphaSpecial.indexOf(ele.charAt(i)) == -1)
        return false;
    }else if( type == "ALPHANUMERIC_SPACE"){
       if(validNumAlphaSpace.indexOf(ele.charAt(i)) == -1){
        return false;
	}
    }else if (type == "MESSAGE_PATTERN"){
       if(invalidMsgPattern.indexOf(ele.charAt(i)) != -1) {
           return false;
       }
    }else if (type == "MBOX"){
       if(invalidMbox.indexOf(ele.charAt(i)) != -1){
          return false;
        }
    }else if (type == "MBOX_DESCRIPTION"){
       if(invalidMboxDesc.indexOf(ele.charAt(i)) != -1){
          return false;
        }
    } else if( type == "NUMBER"){
      if(validNumbers.indexOf(ele.charAt(i)) == -1)
        return false;
    }else if( type == "NUMBER-NOZERO"){
      if(validNumbers.indexOf(ele.charAt(i)) == -1)
        return false;
      if( allZeroes && ele.charAt(i) != '0' )
        allZeroes = false;
    }else if( type == "PASSWORD"){
      if(invalidPassword.indexOf(ele.charAt(i)) != -1)
        return false;
    }else if( type == "SERVICE_PASSWORD"){
      if(invalidServicePassword.indexOf(ele.charAt(i)) != -1)
        return false;
    }else if( type == "TRADCOMCHARS"){
      if(validTRADCOMCHARS.indexOf(ele.charAt(i)) == -1)
        return false;
    }else if( type == "URI"){
      if(validURI.indexOf(ele.charAt(i)) == -1)
        return false;
    }else if( type == "FRACTIONALNUM"){
      if(valid_fractional_number.indexOf(ele.charAt(i)) == -1)
        return false;
      if(ele.indexOf(".") != ele.lastIndexOf("."))
      	return false;
      if((ele.length - 1) == ele.lastIndexOf("."))
      	return false;
      if(ele == ".") return false;
      //if(ele.indexOf(".") == 0) return false;
    }


  }
  if( (type == "NUMBER-NOZERO") && allZeroes ) return false;
  return true;
}

function valChars(elm, required, wildcardAllow) {
  var ele = elm.value + "";
  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }
  var allBlanks=true;
  var allSpecial=false;

  for (var i=0; i<ele.length; i++) {
    //if (valid.indexOf(ele.charAt(i)) == -1)
    //   return false;
    if (ele.charAt(i) != ' '){
       allBlanks= false;
    }
// Check for wild card character
 if( wildcardAllow == "1"  ){
    if( ele.length == 1 && ele.charAt(0) == '*' ) return true;
  }

    if(invalidChars.indexOf(ele.charAt(i)) != -1){
	return false;
    }

  }
  if (allBlanks | allSpecial)
      return false;
   return true;
}

function valCharsPwd(elm, required, wildcardAllow) {
  var ele = elm.value + "";
  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }
  var allBlanks=true;
  var allSpecial=false;

  for (var i=0; i<ele.length; i++) {
    //if (valid.indexOf(ele.charAt(i)) == -1)
    //   return false;
    if (ele.charAt(i) != ' '){
       allBlanks= false;
    }
// Check for wild card character
 if( wildcardAllow == "1"  ){
    if( ele.length == 1 && ele.charAt(0) == '*' ) return true;
  }

    if(invalidCharsPwd.indexOf(ele.charAt(i)) != -1){
	return false;
    }

  }
  if (allBlanks | allSpecial)
      return false;
   return true;
}

function valHostChars(elmValue, required) {
  var ele = elmValue + "";

  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }

  if (ele.indexOf('.') != -1 ){
    return (verifyIP(ele, required) || verifyDomainName(ele, required));
  }

  if (verifyDomainName(ele, required) == false) {
    return false;
  }

  return true;
}

function valSapHostChars(elm, required, minSize) {
  var ele = elm.value + "";

  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }

  if (ele == ".") {
        return false;
  }

  /*if (ele.indexOf('.') != -1 ){
  	return (verifyIP(ele, required) || verifyDomainName(ele, required));
  }

  if (verifyDomainName(ele, required) == false) {
    return false;
  }*/

  var allBlanks=true;
  var allSpecial=false;

  for (var i=0; i<ele.length; i++) {
    //if (valid.indexOf(ele.charAt(i)) == -1)
    //   return false;
    if (ele.charAt(i) != ' '){
       allBlanks= false;
    }

    if(validSAPHOST.indexOf(ele.charAt(i)) == -1){
	return false;
    }

  }
  if (allBlanks | allSpecial)
      return false;
   return true;
}

function valSapPathChars(elm, required, minSize) {
  var ele = elm.value + "";

  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }

  if (ele.length = 1 && validNumbers.indexOf(ele.charAt(0)) != -1){
  	return false;
  }

  var allBlanks=true;
  var allSpecial=false;

  for (var i=0; i<ele.length; i++) {
    //if (valid.indexOf(ele.charAt(i)) == -1)
    //   return false;
    if (ele.charAt(i) != ' '){
       allBlanks= false;
    }

    if(validNumAlpha.indexOf(ele.charAt(i)) == -1 && validSpecial.indexOf(ele.charAt(i))== -1){
	return false;
    }

  }
  if (allBlanks | allSpecial)
      return false;
   return true;
}

function validChars(elm, required, extraChars) {
  var ele = elm.value + "";
  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }

  var allBlanks=true;
  var allSpecial=false;

  for (var i=0; i<ele.length; i++) {
    //if (valid.indexOf(ele.charAt(i)) == -1 && extraChars.indexOf(ele.charAt(i)) == -1)
    //    return false;
    if (ele.charAt(i) != ' '){
       allBlanks= false;
    }

    if(invalidChars.indexOf(ele.charAt(i)) != -1){
	return false;
    }

  }
  if (allBlanks | allSpecial)
      return false;
   return true;
}

function validNumAlphaChars(elm, required, extraChars) {
  var ele = elm.value + "";
  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }

  var allBlanks=true;
  var allSpecial=false;

  for (var i=0; i<ele.length; i++) {
    //if (validNumAlpha.indexOf(ele.charAt(i)) == -1 && extraChars.indexOf(ele.charAt(i)) == -1)
    //   return false;
    if (ele.charAt(i) != ' '){
       allBlanks= false;
    }
    if(invalidChars.indexOf(ele.charAt(i)) != -1){
	return false;
    }

  }
  if (allBlanks | allSpecial)
      return false;
   return true;
}


function valCharsNoSlashes(elm, required, minSize) {
  var ele = elm.value + "";
  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }

  var allBlanks=true;
   var allSpecial=false;
  for (var i=0; i<ele.length; i++) {
    //if (valid_no_slashes.indexOf(ele.charAt(i)) == -1)
    //   return false;
    if (ele.charAt(i) != ' '){
       allBlanks= false;
     }
    if(invalidCharsSlashes.indexOf(ele.charAt(i)) != -1){
	return false;
    }
  }
  if (allBlanks | allSpecial)
      return false;
   return true;
}

function valCharsNoSpaces(elm, required, minSize) {
  var ele = elm.value + "";
  if (ele == "") {
     if (required == "1")
        return false;
     else
        return true;
  }

  var allBlanks=true;
  var allSpecial=false;
  for (var i=0; i<ele.length; i++) {
    //if (valid_no_spaces.indexOf(ele.charAt(i)) == -1)
    //   return false;
    if (ele.charAt(i) != ' '){
       allBlanks= false;
    }
    if(invalidCharsSpaces.indexOf(ele.charAt(i)) != -1){
       return false;
    }
  }
  if (allBlanks | allSpecial)
      return false;
   return true;
}

// Validate that elm1 is less than or Equal to elm2
function validateLE(elm1, elm2) {
  var val1 = elm1.value + "";
  var val2 = elm2.value + "";

  if ((val1 != "") && (val2 != "") && (parseInt(val1) <= parseInt(val2))) {
    return true;
  }

  return false;

}

function chgButton() {
   if (document.images) {
      document.images[chgButton.arguments[0]].src = eval(chgButton.arguments[1] + ".src");
   }
   return true;
}

function setAction(form, action) {
  form.WizardAction.value=action;
  return true;
}

function isFilled(elm) {
  if (elm.value==null ||
        elm.value=="")
     return false;
   for (var i=0; i<elm.value.length; i++) {
   if (elm.value.charAt(i) != ' ')
     return true;
  }
  return false;
}



function isSelectListFilled(elm){
        if( elm.selectedIndex == -1 )
           return false;
	if(elm.options[elm.selectedIndex].value == null ||
		elm.options[elm.selectedIndex].value == ""){
	return false;
   	}
	else{
		return true;
	}
}



function isInt(elm, required, zeroAllowed, wildcardAllow) {
  if( elm.disabled == true ) return true;
  var elmstr = elm.value + "";
  if (elmstr=="") {
    if (required == "1")
      return false;
    else
      return true;
  }

if(zeroAllowed == "0"){
  var i = 0;
  for( ; i < elmstr.length && elmstr.charAt(i) == "0" ; i++ );
  if( i == elmstr.length ) return false;
}

// Check for wild card character
 if( wildcardAllow == "1"  ){
    if( elmstr.length == 1 && elmstr.charAt(0) == '*' ) return true;
  }

  for (var i=0; i<elmstr.length; i++) {
     if(invalidNumbers.indexOf(elmstr.charAt(i)) != -1){
       return false;
    }

  }
  return true;
}


function validCheckBox(form, variable) {
  var e = form.elements;
  var count=0;
  for (var i=0; i<e.length; i++) {
     if (e[i].type == "checkbox" && e[i].name == variable) {
        if (e[i].checked == true)
           count++;
     }
  }
  return count;
}

function validRadio(form, variable) {
  var e = form.elements;
  var count=0;
  for (var i=0; i<e.length; i++) {
     if (e[i].type == "radio" && e[i].name == variable) {
        if (e[i].checked == true)
           count++;
     }
  }
  return count;
}

function validYYYYMMDD(ele, confirmMessage) {
  var elmstr = ele.value + "";
  if (elmstr  == "" || elmstr.length != 8)
     return 1;

   var goodval = 0;
   var today = new Date();

   year = elmstr.substring(0, 4);
   month = elmstr.substring(4,6);
   day = elmstr.substring(6,8);

   month = month-1;
   var test = new Date(year,month,day);
   var tyear = year;
   if (test.getYear() < 1000)
      tyear = test.getYear() + 1900;

    if ( tyear == year &&
        (month == test.getMonth()) &&
        (day == test.getDate()) ) {
       if (year < today.getYear())
          goodval = 1;
        else if (year == today.getYear() && month < today.getMonth())
          goodval = 1;
        else if (month == today.getMonth() &&
                 year == today.getYear() &&
                 day < today.getDate())
          goodval = 1;
        else
          goodval = 2;
     }

     if (goodval == 1) {
       question = confirm(confirmMessage);
       if (question =="0"){
          return 2;
       }
     }
     else if (goodval == 0) {
        return 1;
     }
     return 0;
}


function validSepYYYYMMDD(ele) {

 var elmstr = ele.value;

  if (elmstr  == "" || elmstr.length != 10){

     return false;
}

if(elmstr.substring(4,5) != '-' || elmstr.substring(7,8) != '-'){
return false;
}

   year = elmstr.substring(0, 4);
   month = elmstr.substring(5,7);
   day = elmstr.substring(8,10);

intYear = parseInt(year, 10);
if (isNaN(intYear)) {
return false;
}
intMonth= parseInt(month, 10);
if (isNaN(intMonth)) {
return false;
}
intday= parseInt(day, 10);
if (isNaN(intday)) {
return false;
}

if (intMonth>12 || intMonth<1) {
return false;
}

if ((intMonth == 1 || intMonth == 3 || intMonth == 5 || intMonth == 7 || intMonth == 8 || intMonth == 10 || intMonth == 12) && (intday > 31 || intday < 1)) {
return false;
}

if ((intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11) && (intday > 30 || intday < 1)) {
return false;
}

if (intMonth == 2) {
        if (intday < 1) {
        return false;
        }

        if (LeapYear(intYear) == true) {
        if (intday > 29) {
        return false;
        }
        }

        else {
        if (intday > 28) {
        return false;
        }
        }
}

return true;
}

function validMMDDYYYY(ele) {

 var elmstr = ele.value;

var datePat = /(\d{2})\/(\d{2})\/(\d{4})/;

var matchArray = elmstr.match(datePat);
if (matchArray == null) {
return false;
}

month = matchArray[1];
day = matchArray[2];
year = matchArray[3];

intYear = parseInt(year, 10);
intMonth= parseInt(month, 10);
intday= parseInt(day, 10);

if (intMonth>12 || intMonth<1) {
return false;
}

if (intYear < 1970  || intYear > 3000) {
return false;
}

if ((intMonth == 1 || intMonth == 3 || intMonth == 5 || intMonth == 7 || intMonth == 8 || intMonth == 10 || intMonth == 12) && (intday > 31 || intday < 1)) {
return false;
}

if ((intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11) && (intday > 30 || intday < 1)) {
return false;
}
if (intMonth == 2) {
        if (intday < 1) {
        return false;
        }

        if (LeapYear(intYear) == true) {
        if (intday > 29) {
        return false;
        }
        }

        else {
        if (intday > 28) {
        return false;
        }
        }
}

return true;
}


function validSepMMDDYYYY(ele) {


var elmstr = ele.value;
if (elmstr  == ""  || elmstr.length != 10){
     return false;
}


if(elmstr.substring(2,3) != '-' || elmstr.substring(5,6) != '-'){
return false;
}

year = elmstr.substring(6, 10);
month = elmstr.substring(0,2);
day = elmstr.substring(3,5);

intYear = parseInt(year, 10);
intMonth= parseInt(month, 10);
intday= parseInt(day, 10);

if (intMonth>12 || intMonth<1) {
return false;
}

if (intYear < 1970  || intYear > 3000) {
return false;
}

if ((intMonth == 1 || intMonth == 3 || intMonth == 5 || intMonth == 7 || intMonth == 8 || intMonth == 10 || intMonth == 12) && (intday > 31 || intday <
1)) {
return false;
}

if ((intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11) && (intday > 30 || intday < 1)) {
return false;
}

if (intMonth == 2) {
        if (intday < 1) {
        return false;
        }

        if (LeapYear(intYear) == true) {
        if (intday > 29) {
        return false;
        }
        }

        else {
        if (intday > 28) {
        return false;
        }
        }
}

return true;
}

function validTime(timeStr) {
// Checks if time is in HH:MM:SS AM/PM format.
// The seconds and AM/PM are optional.

var timePat = /^(\d{1,2}):(\d{2})(:(\d{2}))?$/;

var matchArray = timeStr.match(timePat);
if (matchArray == null) {
return false;
}

hour = matchArray[1];
minute = matchArray[2];
second = matchArray[4];

if (second=="") { second = null; }

if (hour <= 0  || hour > 12) {
return false;
}
if (minute<0 || minute > 59) {
return false;
}
if (second != null && (second < 0 || second > 59)) {
return false;
}
if( hour ==0 && minute ==0 )
   return false;
return true;
}



function checkPassword(element1, element2) {
pw1 = element1.value;
pw2 = element2.value;

if (pw1 != pw2) {
return false;
}
else return true;
}



function emailCheck (emailStr, required) {

var checkTLD=1;


var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum)$/;



var emailPat=/^(.+)@(.+)$/;


var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]";



var validChars="\[^\\s" + specialChars + "\]";

/* The following pattern applies if the "user" is a quoted string (in
which case, there are no rules about which characters are allowed
and which aren't; anything goes).  E.g. "jiminy cricket"@disney.com
is a legal e-mail address. */

var quotedUser="(\"[^\"]*\")";

/* The following pattern applies for domains that are IP addresses,
rather than symbolic names.  E.g. joe@[123.124.233.4] is a legal
e-mail address. NOTE: The square brackets are required. */

var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;

/* The following string represents an atom (basically a series of non-special characters.) */

var atom=validChars + '+';


var word="(" + atom + "|" + quotedUser + ")";

// The following pattern describes the structure of the user

var userPat=new RegExp("^" + word + "(\\." + word + ")*$");

/* The following pattern describes the structure of a normal symbolic
domain, as opposed to ipDomainPat, shown above. */

var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");

/* Finally, let's start trying to figure out if the supplied address is valid. */

/* Begin with the coarse pattern to simply break up user@domain into
different pieces that are easy to analyze. */
var emailVal = emailStr.value
if (required == "1"){
if(emailVal == ""){
        return false;
}
}
if(emailVal != ""){
var matchArray=emailVal.match(emailPat);

if (matchArray==null) {

/* Too many/few @'s or something; basically, this address doesn't
even fit the general mould of a valid e-mail address. */

return false;
}
var user=matchArray[1];
var domain=matchArray[2];

// Start by checking that only basic ASCII characters are in the strings (0-127).

for (i=0; i<user.length; i++) {
if (user.charCodeAt(i)>127) {

return false;
   }
}
for (i=0; i<domain.length; i++) {
if (domain.charCodeAt(i)>127) {

return false;
   }
}

// See if "user" is valid

if (user.match(userPat)==null) {

// user is not valid

return false;
}

/* if the e-mail address is at an IP address (as opposed to a symbolic
host name) make sure the IP address is valid. */

var IPArray=domain.match(ipDomainPat);
if (IPArray!=null) {

// this is an IP address

for (var i=1;i<=4;i++) {
if (IPArray[i]>255) {
return false;
   }
}
return true;
}

// Domain is symbolic name.  Check if it's valid.

var atomPat=new RegExp("^" + atom + "$");
var domArr=domain.split(".");
var len=domArr.length;
for (i=0;i<len;i++) {
if (domArr[i].search(atomPat)==-1) {

return false;
   }
}

/* domain name seems valid, but now make sure that it ends in a
known top-level domain (like com, edu, gov) or a two-letter word,
representing country (uk, nl), and that there's a hostname preceding
the domain or country. */

if (checkTLD && domArr[domArr.length-1].length!=2 &&
domArr[domArr.length-1].search(knownDomsPat)==-1) {

return false;
}

// Make sure there's a host name preceding the domain.

if (len<2) {
return false;
}
}
// If we've gotten this far, everything's valid!
return true;


}



var isNav4 = false, isNav5 = false, isIE4 = false
var vDateType = 1;              // Global value for type of date format
//                1 = mm/dd/yyyy
//                2 = yyyy/dd/mm  (Unable to do date check at this time)
//                3 = dd/mm/yyyy
var vYearType = 4;              //Set to 2 or 4 for number of digits in the year for Netscape
var err = 0;                    // Set the error code to a default of zero
if(navigator.appName == "Netscape") {
if (navigator.appVersion < "5") {
isNav4 = true;
isNav5 = false;
}
else
if (navigator.appVersion > "4") {
isNav4 = false;
isNav5 = true;
   }
}
else isIE4 = true;
var strSeperator = "-";

function DateFormat(vDateName, vDateValue, e, dateCheck, dateType, message) {
vDateType = dateType;

//////////////////////////////////////////////////////////////////////////////////////
// vDateName = object name
// vDateValue = value in the field being checked
// e = event
// dateCheck
//       True  = Verify that the vDateValue is a valid date
//       False = Format values being entered into vDateValue only
// vDateType
//       1 = mm/dd/yyyy
//       2 = yyyy/mm/dd
//       3 = dd/mm/yyyy
//Enter a tilde sign for the first number and you can check the variable information.
//////////////////////////////////////////////////////////////////////////////////////

if (vDateValue == "~") {
alert("AppVersion = "+navigator.appVersion+" \nNav. 4 Version = "+isNav4+" \nNav. 5 Version = "+isNav5+" \nIE Version = "+isIE4+" \nYear Type = "+vYearType+" \nDate Type = "+vDateType+" \nSeparator = "+strSeperator);
vDateName.value = "";
vDateName.focus();
return true;
}
var whichCode = (window.Event) ? e.which : e.keyCode;
// Check to see if a seperator is already present.
// bypass the date if a seperator is present and the length greater than 8
if (vDateValue.length > 8 && isNav4) {
if ((vDateValue.indexOf("-") >= 1) || (vDateValue.indexOf("/") >= 1)) return true;
}
//Eliminate all the ASCII codes that are not valid
var alphaCheck = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/-";
if (alphaCheck.indexOf(vDateValue) >= 1) {
if (isNav4) {
vDateName.value = "";
vDateName.focus();
vDateName.select();
return false;
}
else {
vDateName.value = vDateName.value.substr(0, (vDateValue.length-1));
return false;
   }
}
if (whichCode == 8) //Ignore the Netscape value for backspace. IE has no value
return false;
else {
//Create numeric string values for 0123456789/
//The codes provided include both keyboard and keypad values
var strCheck = '47,48,49,50,51,52,53,54,55,56,57,58,59,95,96,97,98,99,100,101,102,103,104,105';
if (strCheck.indexOf(whichCode) != -1) {
if (isNav4) {
if (((vDateValue.length < 6 && dateCheck) || (vDateValue.length == 7 && dateCheck)) && (vDateValue.length >=1)) {
alert(message);
vDateName.value = "";
vDateName.focus();
vDateName.select();
return false;
}
if (vDateValue.length == 6 && dateCheck) {
var mDay = vDateName.value.substr(2,2);
var mMonth = vDateName.value.substr(0,2);
var mYear = vDateName.value.substr(4,4);
//Turn a two digit year into a 4 digit year
if (mYear.length == 2 && vYearType == 4) {
var mToday = new Date();
//If the year is greater than 30 years from now use 19, otherwise use 20
var checkYear = mToday.getFullYear() + 30;
var mCheckYear = '20' + mYear;
if (mCheckYear >= checkYear) mYear = '19' + mYear;
else mYear = '20' + mYear;
}
var vDateValueCheck = mMonth+strSeperator+mDay+strSeperator+mYear;
if (!dateValid(vDateValueCheck)) {
alert(message);
vDateName.value = "";
vDateName.focus();
vDateName.select();
return false;
}
return true;
}
else {
// Reformat the date for validation and set date type to a 1
if (vDateValue.length >= 8  && dateCheck) {
// mmddyyyy
if (vDateType == 1) {
var mDay = vDateName.value.substr(2,2);
var mMonth = vDateName.value.substr(0,2);
var mYear = vDateName.value.substr(4,4)
vDateName.value = mMonth+strSeperator+mDay+strSeperator+mYear;
}
// yyyymmdd
if (vDateType == 2) {
var mYear = vDateName.value.substr(0,4)
var mMonth = vDateName.value.substr(4,2);
var mDay = vDateName.value.substr(6,2);
vDateName.value = mYear+strSeperator+mMonth+strSeperator+mDay;
}
// ddmmyyyy
if (vDateType == 3) {
var mMonth = vDateName.value.substr(2,2);
var mDay = vDateName.value.substr(0,2);
var mYear = vDateName.value.substr(4,4)
vDateName.value = mDay+strSeperator+mMonth+strSeperator+mYear;
}
//Create a temporary variable for storing the DateType and change
//the DateType to a 1 for validation.
var vDateTypeTemp = vDateType;
vDateType = 1;
var vDateValueCheck = mMonth+strSeperator+mDay+strSeperator+mYear;
if (!dateValid(vDateValueCheck)) {
alert(message);
vDateType = vDateTypeTemp;
vDateName.value = "";
vDateName.focus();
vDateName.select();
return false;
}
vDateType = vDateTypeTemp;
return true;
}
else {
if (((vDateValue.length < 8 && dateCheck) || (vDateValue.length == 9 && dateCheck)) && (vDateValue.length >=1)) {
alert(message);
vDateName.value = "";
vDateName.focus();
vDateName.select();
return false;
         }
      }
   }
}
else {
// Non isNav Check
if (((vDateValue.length < 8 && dateCheck) || (vDateValue.length == 9 && dateCheck)) && (vDateValue.length >=1)) {
alert(message);
vDateName.value = "";
vDateName.focus();
return true;
}
// Reformat date to format that can be validated. mm/dd/yyyy
if (vDateValue.length >= 8 && dateCheck) {
// Additional date formats can be entered here and parsed out to
// a valid date format that the validation routine will recognize.
// mm/dd/yyyy
if (vDateType == 1) {
var mMonth = vDateName.value.substr(0,2);
var mDay = vDateName.value.substr(3,2);
var mYear = vDateName.value.substr(6,4)
}
// yyyy/mm/dd
if (vDateType == 2) {
var mYear = vDateName.value.substr(0,4)
var mMonth = vDateName.value.substr(5,2);
var mDay = vDateName.value.substr(8,2);
}
// dd/mm/yyyy
if (vDateType == 3) {
var mDay = vDateName.value.substr(0,2);
var mMonth = vDateName.value.substr(3,2);
var mYear = vDateName.value.substr(6,4)
}
// Create temp. variable for storing the current vDateType
var vDateTypeTemp = vDateType;
// Change vDateType to a 1 for standard date format for validation
// Type will be changed back when validation is completed.
vDateType = 1;
// Store reformatted date to new variable for validation.
var vDateValueCheck = mMonth+strSeperator+mDay+strSeperator+mYear;
if (vDateValueCheck.length >= 8 && dateCheck) {
//Turn a two digit year into a 4 digit year
if (mYear.length == 2 && vYearType == 4) {
var mToday = new Date();
//If the year is greater than 30 years from now use 19, otherwise use 20
var checkYear = mToday.getFullYear() + 30;
var mCheckYear = '20' + mYear;
if (mCheckYear >= checkYear) mYear = '19' + mYear;
else mYear = '20' + mYear;
}
vDateValueCheck = mMonth+strSeperator+mDay+strSeperator+mYear;
}
if (!dateValid(vDateValueCheck)) {
alert(message);
vDateType = vDateTypeTemp;
vDateName.value = "";
vDateName.focus();
return true;
}
vDateType = vDateTypeTemp;
return true;
}
else {
if (vDateType == 1) {
if (vDateValue.length == 2) {
vDateName.value = vDateValue+strSeperator;
}
if (vDateValue.length == 5) {
vDateName.value = vDateValue+strSeperator;
   }
}
if (vDateType == 2)
{
if (vDateValue.length == 4)
{
vDateName.value = vDateValue+strSeperator;
}
if (vDateValue.length == 7) {
vDateName.value = vDateValue+strSeperator;
   }
}
if (vDateType == 3) {
if (vDateValue.length == 2) {
vDateName.value = vDateValue+strSeperator;
}
if (vDateValue.length == 5) {
vDateName.value = vDateValue+strSeperator;
   }
}
return true;
   }
}
if (vDateValue.length == 10&& dateCheck) {
if (!dateValid(vDateName)) {
// Un-comment the next line of code for debugging the dateValid() function error messages
//alert(err);
alert(message);
vDateName.focus();
vDateName.select();
   }
}
return false;
}
else {
// If the value is not in the string return the string minus the last
// key entered.
if (isNav4) {
vDateName.value = "";
vDateName.focus();
vDateName.select();
return false;
}
else {
vDateName.value = vDateName.value.substr(0, (vDateValue.length-1));
return false;
         }
      }
   }
}
function dateValid(objName) {
var strDate;
var strDateArray;
var strDay;
var strMonth;
var strYear;
var intday;
var intMonth;
var intYear;
var booFound = false;
var datefield = objName;
var strSeparatorArray = new Array("-"," ","/",".");
var intElementNr;
// var err = 0;
var strMonthArray = new Array(12);
strMonthArray[0] = "Jan";
strMonthArray[1] = "Feb";
strMonthArray[2] = "Mar";
strMonthArray[3] = "Apr";
strMonthArray[4] = "May";
strMonthArray[5] = "Jun";
strMonthArray[6] = "Jul";
strMonthArray[7] = "Aug";
strMonthArray[8] = "Sep";
strMonthArray[9] = "Oct";
strMonthArray[10] = "Nov";
strMonthArray[11] = "Dec";
//strDate = datefield.value;
strDate = objName;
if (strDate.length < 1) {
return true;
}
for (intElementNr = 0; intElementNr < strSeparatorArray.length; intElementNr++) {
if (strDate.indexOf(strSeparatorArray[intElementNr]) != -1) {
strDateArray = strDate.split(strSeparatorArray[intElementNr]);
if (strDateArray.length != 3) {
err = 1;
return false;
}
else {
strDay = strDateArray[0];
strMonth = strDateArray[1];
strYear = strDateArray[2];
}
booFound = true;
   }
}
if (booFound == false) {
if (strDate.length>5) {
strDay = strDate.substr(0, 2);
strMonth = strDate.substr(2, 2);
strYear = strDate.substr(4);
   }
}
//Adjustment for short years entered
if (strYear.length == 2) {
strYear = '20' + strYear;
}
strTemp = strDay;
strDay = strMonth;
strMonth = strTemp;
intday = parseInt(strDay, 10);
if (isNaN(intday)) {
err = 2;
return false;
}
intMonth = parseInt(strMonth, 10);
if (isNaN(intMonth)) {
for (i = 0;i<12;i++) {
if (strMonth.toUpperCase() == strMonthArray[i].toUpperCase()) {
intMonth = i+1;
strMonth = strMonthArray[i];
i = 12;
   }
}
if (isNaN(intMonth)) {
err = 3;
return false;
   }
}
intYear = parseInt(strYear, 10);
if (isNaN(intYear)) {
err = 4;
return false;
}
if (intMonth>12 || intMonth<1) {
err = 5;
return false;
}
if ((intMonth == 1 || intMonth == 3 || intMonth == 5 || intMonth == 7 || intMonth == 8 || intMonth == 10 || intMonth == 12) && (intday > 31 || intday < 1)) {
err = 6;
return false;
}
if ((intMonth == 4 || intMonth == 6 || intMonth == 9 || intMonth == 11) && (intday > 30 || intday < 1)) {
err = 7;
return false;
}
if (intMonth == 2) {
if (intday < 1) {
err = 8;
return false;
}
if (LeapYear(intYear) == true) {
if (intday > 29) {
err = 9;
return false;
   }
}
else {
if (intday > 28) {
err = 10;
return false;
      }
   }
}
return true;
}
function LeapYear(intYear) {
if (intYear % 100 == 0) {
if (intYear % 400 == 0) {
return true;
   }
}
else {
if ((intYear % 4) == 0) {
return true;
   }
}
return false;
}



function validate_TextAreaLength(objTextArea, intMaxLength, required){
        var strResult = "";
        if(required !=1){
                if(objTextArea.value == ""){
                         objTextArea.focus();
                         return false;
                }//end if
        }//end if
        if(intMaxLength != 0){
                if(objTextArea.value.length > intMaxLength){
                        objTextArea.value = objTextArea.value.substring(0, intMaxLength);
                        objTextArea.focus();
                        return false;

                }//end if
        }//end if
return true;
}

function validate_CEUNameLength(objTextArea){
         if(objTextArea.value == "" || objTextArea.value.length > 8){
                 objTextArea.value = "";
                 objTextArea.focus();
                 return false;
         }//end if
         return true;
}


function checkStartEndDateByFormat(startElement, endElement, dateFormat) {
    if (startElement.value != '' && endElement.value != '') {
        var startYear, endYear, startMonth, endMonth, startDay, endDay;
        var yyyymmddSepPattern = /^(YYYY).(MM).(DD)$/;
        var yyyymmddPattern = /^YYYYMMDD$/;
		// define other patterns here as need arises

        if (checkPatternMatch(dateFormat, yyyymmddSepPattern) == true) {
            startYear = startElement.value.substr(0,4);
            startMonth = startElement.value.substr(5,2);
            startDay = startElement.value.substr(8,2);
            endYear = endElement.value.substr(0,4);
			endMonth = endElement.value.substr(5,2);
            endDay = endElement.value.substr(8,2);
        } else if (checkPatternMatch(dateFormat,yyyymmddPattern) == true) {
            startYear = startElement.value.substr(0,4);
            startMonth = startElement.value.substr(4,2);
            startDay = startElement.value.substr(6,2);
            endYear = endElement.value.substr(0,4);
			endMonth = endElement.value.substr(4,2);
            endDay = endElement.value.substr(6,2);
        } else {
//            alert ("Didn't match any pattern");
            return false;
        }

        return checkValidDateRange(startYear, endYear, startMonth, endMonth, startDay, endDay);
    } else {
//            alert ("Didn't specify both dates");
        return false;
    }
}

function checkValidDateRange(startYear, endYear, startMonth, endMonth, startDay, endDay) {
    if(parseInt(endYear, 10) < parseInt(startYear, 10)){
      return false;
    }else if(parseInt(endYear, 10) > parseInt(startYear, 10)){
      return true;
    }else{
      if(parseInt(endMonth, 10) < parseInt(startMonth, 10)){
        return false;
      }else if(parseInt(endMonth, 10) > parseInt(startMonth, 10)){
        return true;
      }else{
        if(parseInt(endDay, 10) < parseInt(startDay, 10)){
          return false;
        }else if(parseInt(endDay, 10) > parseInt(startDay, 10)){
          return true;
        }else{
          return true;
        }
      }
    }
}


function checkStartEndDate(element1, element2) {
  if(element1.value != '' && element2.value != ''){
    var mMonth = element1.value.substr(0,2);
    var mDay = element1.value.substr(3,2);
    var mYear = element1.value.substr(6,4);

    var mMonth1 = element2.value.substr(0,2);
    var mDay1 = element2.value.substr(3,2);
    var mYear1= element2.value.substr(6,4);

    if(parseInt(mYear1, 10) < parseInt(mYear, 10)){
      return false;
    }else if(parseInt(mYear1, 10) > parseInt(mYear, 10)){
      return true;
    }else{
      if(parseInt(mMonth1, 10) < parseInt(mMonth, 10)){
        return false;
      }else if(parseInt(mMonth1, 10) > parseInt(mMonth, 10)){
        return true;
      }else{
        if(parseInt(mDay1, 10) < parseInt(mDay, 10)){
          return false;
        }else if(parseInt(mDay1, 10) > parseInt(mDay, 10)){
          return true;
        }else{
          return true;
        }
      }
    }
  }
  else{
    return false;
  }
}


function checkMinLength(element1, minLength, required) {

if (required == "1"){
if(element1.value != ''){
        if(element1.value.length < minLength){
        return false;
        }
        return true;
}
else{
        return false;
  }
 }

else{
        if(element1.value != ''){
                if(element1.value.length < minLength){
                return false;
                }
        return true;
        }
        else{
        return true;
        }
  }

}


function verifyDomainName(domainName, required) {
  if (required == "1"){
    if(domainName == ''){
        return false;
    }
  }

  var matchArray = null;
//
//  if (domainName == "...") {
//    return false;
//  }

  // RFC 1034 Rule: All chars must be either letter, hyphen or digit
  var alphaNumericPattern = /^((([a-zA-Z0-9-]*)\.)*)([a-zA-Z0-9-]*)$/;
  // RFC 1034 Rule: Starting char in each segment must be a letter
  var startCharAlphaPattern = /^((([a-zA-Z])([a-zA-Z0-9-]*)\.)*)([a-zA-Z])([a-zA-Z0-9-]*)$/;
  // RFC 1034 Rule: Ending character in each segment must be a letter or digit

  var endCharAlphaNumPattern = /^((([a-zA-Z0-9-]*)([a-zA-Z0-9])\.)*)([a-zA-Z0-9-]*)([a-zA-Z0-9])$/;

  return (checkPatternMatch(domainName, alphaNumericPattern) &&
          checkPatternMatch(domainName, startCharAlphaPattern) &&
          checkPatternMatch(domainName, endCharAlphaNumPattern));

}


function checkPatternMatch (str, pattern) {
  var matchArray = str.match(pattern);
  if (matchArray == null) {
    return false;
  } else {
    return true;
  }
}


function verifyIP(IPvalue, required) {

if (required == "1"){
if(IPvalue == ''){
return false;
}
}

var ipPattern = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
var ipArray = IPvalue.match(ipPattern);

if (IPvalue == "0.0.0.0")
return false;
else if (IPvalue == "255.255.255.255")
return false;
if (ipArray == null)
return false;
else {
for (i = 0; i < 4; i++) {
thisSegment = ipArray[i];
if (thisSegment > 255) {
return false;
i = 4;
}
if ((i == 0) && (thisSegment > 255)) {
return false;
i = 4;
      }
   }
}
extensionLength = 3;
return true;

}


function verifyMultiPicker(element, required) {

  if (required == "1") {
    if (element.options.length <= 0) {
      return false;
    } else {
      isValidSelection = "false";

      for ( i = 0; i< element.options.length ; i++ ){
	if (element.options[i].value != "") {
	  isValidSelection = "true";
	  break;
	}
      }

      if (isValidSelection == "false") {
	return false;
      }
    }
  }

  return true;
}


function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);


///////////This is for dynamic select lists

function updateList(from, to){

if(from.value != ""){
	for(var i=0; i<to.options.length; i++) {
		if(to.options[i].value ==  from.value.toUpperCase()) {
		  alert(from.value.toUpperCase() + " service already exists in the list!");
                  from.value = "";
		  return;
		}
	}


 var no = new Option();
 no.value = from.value.toUpperCase();
 no.text = from.value.toUpperCase();
 no.selected = true;

 to.options[to.options.length] = no;

BumpUp(to);
}
from.value = "";

}

///////////This is for dynamic select lists

function updateComboList(from, to, errorMsg1, errorMsg2){

if(to.disabled == 0){
if(from.value != ""){

	for(var i=0; i<to.options.length; i++) {
		if(to.options[i].value ==  from.value.toUpperCase()) {
		  alert(from.value.toUpperCase() + " "  + errorMsg2);
                  from.value = "";
		  return;
		}
	}


 var no = new Option();
 no.value = from.value.toUpperCase();
 no.text = from.value.toUpperCase();
 no.selected = true;

 to.options[to.options.length] = no;

BumpUp(to);

}
from.value = "";

  }else{
	alert(errorMsg1);
 }

}

function addToList(listField, val1, val2, val3, val4) {
if (val1 != "" && val3 != ""){
  var textStr = val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4;
  var valStr = val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4;     
      var len = listField.length++;       
      listField.options[len].value = textStr;
      listField.options[len].text = valStr;
      listField.selectedIndex = len; 
      BumpUp(listField);
  }else{
   alert( "Cannot add blank values!");
  }
}

function addToListMil(listField, val1, val2) {
if (val1 != "" && val2 != ""){
  var textStr = val1  + ' - ' + val2;
  var valStr = val1  + ' - ' + val2;
      var len = listField.length++;       
      listField.options[len].value = textStr;
      listField.options[len].text = valStr;
      listField.selectedIndex = len; 
       BumpUp(listField);
  }else{
   alert( "Cannot add blank values!");
  }
}

function addToListTime(listField, val1, val2) {
if (val1 != "" && val2 != ""){
     var textStr = val1 + ' ' + val2  ;
     var valStr = val1 + ' ' + val2  ;	
      var len = listField.length++;       
      listField.options[len].value = textStr;
      listField.options[len].text = valStr;
      listField.selectedIndex = len; 
       BumpUp(listField);
  }else if (val2 == "" ){
     var textStr = val1;
     var valStr = val1;	   
      var len = listField.length++; 
      listField.options[len].value = textStr;
      listField.options[len].text = valStr;
      listField.selectedIndex = len; 
       BumpUp(listField);
  }else{
   alert( "Cannot add blank values!");
  }
}

function addToListIntervalTime(listField, val1, val2, val3, val4, val5, val6) {
if (val1 != '' && val3 != ''){
 if(val5 != ' ' && val6 !=' '){		
     var textStr =val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4 +  " Every " + val5 + " Hour(s) " + val6 + " Min(s)" ;
     var valStr = val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4 +   " Every " + val5 +  " Hour(s) " + val6 + " Min(s)" ;
   }else if ( val5 == ' ' && val6 !=' ') {
      var textStr = val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4 + " Every " + val6 + " Min(s)" ;
     var valStr = val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4 + " Every " + val6 + " Min(s)" ;	   	
  } else if ( val5 != ' ' && val6 ==' ') {
     var textStr = val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4 + " Every " + val5 + " Hour(s) " ;
     var valStr = val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4 + " Every " + val5 + " Hour(s) " ;
  } else if  ( val5 == ' ' && val6 ==' '){
      var textStr = val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4;
     var valStr = val1 + ' ' + val2 + ' - ' + val3 + ' ' + val4;	
  } 
      var len = listField.length++; 
      listField.options[len].value = textStr;
      listField.options[len].text = valStr;
      listField.selectedIndex = len; 
       BumpUp(listField);
  }else{
   alert( "Cannot add blank values!");
  }
}

function removeSelectedTime(from ){
	for(var i=0; i<from.options.length; i++) {
		if(from.options[i].selected && from.options[i].value != "") {
		from.options[i].value = "";
		from.options[i].text = "";
 	   }
	}
	BumpUpTime(from);
}

function BumpUpTime(box)  {
   for(var i=0; i<box.options.length; i++) {
      if(box.options[i].value == "")  {
          for(var j=i; j<box.options.length-1; j++)  {
             box.options[j].value = box.options[j+1].value;
             box.options[j].text = box.options[j+1].text;
          }
          var ln = i;
          break;
      }
   }
   if(ln < box.options.length)  {
            box.options.length -= 1;
            BumpUpTime(box);
   }
   if(box.options.length == 0){
       var no = new Option();
       no.value = "";
       no.text = "            ";
       box.options[box.options.length] = no;
   }
}

function removeSelected(from ){
	for(var i=0; i<from.options.length; i++) {
		if(from.options[i].selected && from.options[i].value != "") {
		from.options[i].value = "";
		from.options[i].text = "";
 	   }
	}
	BumpUp(from);
}
var emptyOption ;
function moveItemsFromSrc2Target(src, target){
	// make sure something is selected;
	if (src.selectedIndex == -1)
		return;

	// find selected items
	var srcSize = src.options.length;
	var targetSize = target.options.length;
	var selected = new Array();
    var blankoptions = new Array();
	var cnt = 0;

		//unselect everything in target
        for( var t = 0; t < targetSize; t++){
            target.options[t].selected = false;
        }


	for( var i = 0; i < srcSize ; i++){
		if (src.options[i].selected){
			src.options[i].selected = false;
            selected[cnt++] = i; //currently selected item
				if( src.options[i].value != "" ){
					target.options[targetSize] = new Option(src.options[i].text,src.options[i].value);  //create new option in target as a copy of source
					target.options[targetSize].selected = true; //mark it as selected
					targetSize++; 
				}else {
					emptyOption = src.options[i].text ;
				}
		}
	}
	for( var j = cnt-1; j >=0 ;j--){
		src.options[selected[j]] = null;
	}
        src.options.length = (srcSize - cnt );
        for( var j = cnt-1; j >=0 ;j--){
            if( src.options.length > selected[j])
               src.options[selected[j]].selected = true;
        }

        cnt =0;
        for ( var k =0; k< targetSize ; k++ ){
            if( target.options[k].value == "" ){
               emptyOption = target.options[k].text;
               blankoptions[cnt++] = k ;
              }
        }

        for( var j = blankoptions.length-1; j >=0 ;j--){
                target.options[blankoptions[j]] = null;
        }
        target.options[target.options.length] = new Option( emptyOption , "" );
}


function BumpUp(box)  {
   for(var i=0; i<box.options.length; i++) {
      if(box.options[i].value == "")  {
          for(var j=i; j<box.options.length-1; j++)  {
             box.options[j].value = box.options[j+1].value;
             box.options[j].text = box.options[j+1].text;
          }
          var ln = i;
          break;
      }
   }
   if(ln < box.options.length)  {
            box.options.length -= 1;
            BumpUp(box);
   }
   if(box.options.length == 0){
       var no = new Option();
       no.value = "";
       no.text = "None Available";

       box.options[box.options.length] = no;
   }

}
//end dynamic select list code


function moveAllItemsFromSrc2Target(src, target){
	var srcSize = src.options.length;
	var targetSize = target.options.length;

        for ( var j = 0 ; j < targetSize ; j++){
               if( target.options[j].value == "" ){
                  emptyOption = target.options[j].text ;
                  target.options[j] = null;
               }
        }

       targetSize = target.options.length ;

        for( var i = 0; i < srcSize ; i++){
          if( src.options[i].value != "" ){
			target.options[targetSize++] = new Option(src.options[i].text,src.options[i].value);
			target.options[targetSize - 1].selected = true;
          }
	}

	for( var j = 0 ; j < srcSize ; j++){
		src.options[j] = null;
	}
	src.length = 0;
        target.options[target.options.length] = new Option( emptyOption , "" );
}


//Envelope Specific Script
function invokeEdit(){
var next = document.wizform.NextEnvelope;
document.wizform.envelopeID.value = next.options[next.selectedIndex].value;
document.wizform.WizardAction.value = 'edit';
//alert(document.wizform.envelopeID.value);
document.wizform.submit();

}

function invokeAdd(myLocation){
if(document.wizform.special_type){
 var special_type = document.wizform.special_type.value;
 //alert(special_type);
 myLocation = myLocation + "&special_type=" + special_type;
}
location.href = myLocation;

}


// Method to swap Select control values
function valueSwap(form ,controlName, arrayindex ) {
if ((arrayindex == null) || (controlName == null) ) return;
	var x = SelectOptions[arrayindex].data;
        var tmp = eval("document."+form);
	for (var i = 0; i < tmp.elements.length; i++ ) {
		// Find the elements which needs to change
		if(tmp.elements[i].name == controlName){
			//replace options
			tmp.elements[i].options.length =0;
			for (var j = 0 ; j < x.length; j++ ) {
			    tmp.elements[i].options[j] = new Option(x[j], x[j], false, false );
			}
// Added for Netscape support
			if(x.length > 0)
		        	tmp.elements[i].options[selectedversionindex].selected = true ;

			//remove extra options
			tmp.elements[i].options.length = x.length;
			return;
		}
	}
}

// Method to swap Select control values
function valueSwap1(form ,controlName, arrayindex1 , arrayindex2 ) {
if ((arrayindex1 == null) || (arrayindex2 == null ) || (controlName == null) ) return;
	var x = SelectOptions[arrayindex1].roles[arrayindex2].data;
        var tmp = eval("document."+form);
	for (var i = 0; i < tmp.elements.length; i++ ) {
		// Find the elements which needs to change
		if(tmp.elements[i].name == controlName){
			//replace options
			tmp.elements[i].options.length =0;
			for (var j = 0 ; j < x.length; j++ ) {
			    tmp.elements[i].options[j] = new Option(x[j], x[j], false, false );
			}

			 if(x.length > 0 )
                                tmp.elements[i].options[selectedroleindex].selected = true ;
			//remove extra options
			tmp.elements[i].options.length = x.length;
			return;
		}
	}
}



//BPML License check
function alertSubmit(themsg){
 alert(themsg);
}


function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}

MM_reloadPage(true);

function textCounter(field, maxlimit, message) {
  if (field.value.length > maxlimit) {
field.value = field.value.substring(0, maxlimit);
 alert(message);
  }
}

//Suspend submitting the form by pressing ENTER/RETURN key.
function checkEnter(e){
	var characterCode;

	if(e && e.which){ //if which property of event object is supported (NN4)
		e = e;
		characterCode = e.which; //character code is contained in NN4's which property
	}
	else{
		e = event;
		characterCode = e.keyCode; //character code is contained in IE's keyCode property
	}


	if(characterCode == 13){ //if generated character code is equal to ascii 13 (if enter key)
		return false;
	}
	else{
		return true;
	}

}

function validTimeSched(timeStr, timeStd) {
// Checks if time is in HH:MM:SS AM/PM format.
// The seconds and AM/PM are optional.
var timePat = /^(\d{1,2}):(\d{2})(:(\d{2}))?$/;
if( timeStr != ""){
var matchArray = timeStr.match(timePat);
if (matchArray == null) {
return false;
}
hour = matchArray[1];
minute = matchArray[2];
second = matchArray[4];
if (second=="") { second = null; }

if (timeStd == "false"){
if (hour < 0  || hour > 12 ) {
return false;
}
}else if (timeStd=="true"){
if (hour < 0  || hour > 24 ) {
return false;
}
}
if (minute<0 || minute > 59) {
return false;
}
if (second != null && (second < 0 || second > 59)) {
return false;
}
}
return true;

}

function checkFileExt( formField, ext , req ){
  var ele = formField.value;
  var hasExt = false ;
  var tmp = "";
  for (var i=0; i< ele.length; i++) {
       if (ele.charAt(i) == '.'){
          hasExt= true;
          if( ele.length > (i+1) ) tmp = ele.slice( i+1 , ele.length);
          break;
        }
  }
  if( hasExt == false && req == 0 ) return true  ;
  if( hasExt == false && req == 1 ) return false ;
  if( tmp == ext ) return true ;
  return false ;
}

function moveToTop(){
  try {
    window.parent.parent.scrollTo(0,0);
  } catch(e) {
  	;
  }
}

function fix_wheel() {
  try {
     if( (document.activeElement.type  != "select-one") && (document.activeElement.type  != "select-multiple"))
       window.parent.parent.scrollBy(0, -event.wheelDelta);
  } catch(e) {
  	;
  }
}

  function validDateTimeStr (startDate, startTime, startAMPM, endDate, endTime, endAMPM){ 
    
           if (startDate != "" && endDate !="" && startTime!= "" && endTime!=""){         
                   //create JS time 
                   var timePat = /^(\d{1,2}):(\d{2})(:(\d{2}))?$/; 
                   var matchstartTimeArray = startTime.match(timePat);         
                   startHour = matchstartTimeArray[1]; 
                   startMinute = matchstartTimeArray[2]; 
                   startSecond = matchstartTimeArray[4]; 
                    
                   var matchendTimeArray = endTime.match(timePat);         
                   endHour = matchendTimeArray[1]; 
                   endMinute = matchendTimeArray[2]; 
                   endSecond = matchendTimeArray[4]; 
                    
                   if (startAMPM == "PM"){ 
                           intstartHour= parseInt(startHour, 10); 
                           startHour = intstartHour +12;         
                   } 
                    
                   if (endAMPM == "PM"){ 
                           intendHour= parseInt(endHour, 10); 
                           endHour = intendHour +12;         
                   } 
                   //create JS date 
                   var datePat = /(\d{2})\/(\d{2})\/(\d{4})/; 
            
                   var matchstartDateArray = startDate.match(datePat);                 
                    
                   startMonth = matchstartDateArray[1]; 
                   startDay = matchstartDateArray[2]; 
                   startYear = matchstartDateArray[3]; 
                    
                   intstartMonth= parseInt(startMonth, 10); 
                   startMonth = monthToString (intstartMonth); 
    
                   var matchendDateArray = endDate.match(datePat);                 
                    
                   endMonth = matchendDateArray[1]; 
                   endDay = matchendDateArray[2]; 
                   endYear = matchendDateArray[3]; 
    
                   intendMonth= parseInt(endMonth, 10); 
                   endMonth = monthToString (intendMonth); 
                                    
                   var startDateTime = new Date(startMonth+" "+ startDay +  
                          ", "+startYear +" " + startHour + ":" + startMinute + ":" + startSecond); 
                            
                           var endDateTime = new Date(endMonth+" "+ endDay +  
                          ", "+endYear +" " + endHour + ":" + endMinute + ":" + endSecond); 
                           
                   if (startDateTime >= endDateTime){ 
                           return false;         
                   }         
           } 
           return true;         
   }        
    
   function monthToString (intMonth){ 
            
   var strMonth; 
            
           switch(intMonth){ 
                   case 1: 
                      strMonth= "January";          
                      break; 
                   case 2: 
                      strMonth = "February";          
                      break; 
                    case 3: 
                      strMonth = "March";          
                      break;         
                    case 4: 
                      strMonth = "April";          
                      break; 
                    case 5: 
                      strMonth = "May";          
                      break; 
                    case 6: 
                      strMonth = "June";          
                      break; 
                    case 7: 
                      strMonth = "July";          
                      break; 
                    case 8: 
                      strMonth = "August";          
                      break; 
                    case 9: 
                      strMonth = "September";          
                      break; 
                    case 10: 
                      strMonth = "October";          
                      break; 
                    case 11: 
                      strMonth = "November";          
                      break; 
                    case 12: 
                      strMonth = "December";          
                      break;                                        
           } 
           return strMonth; 
   } 
