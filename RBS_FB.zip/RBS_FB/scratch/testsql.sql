select * from 

( 
	select	paymentimp0_.payment_Id as payment1_366_,
			paymentimp0_.bundle_Id as bundle2_366_, 
			paymentimp0_.message_Id as message3_366_, 
			paymentimp0_.isoutbound as isoutbound366_, 
			paymentimp0_.pTimestamp as pTimestamp366_, 
			paymentimp0_.reference as reference366_, 
			paymentimp0_.settle_Amt as settle7_366_, 
			paymentimp0_.settle_Date as settle8_366_, 
			paymentimp0_.status as status366_, 
			paymentimp0_.transaction_Id as transac10_366_, 
			paymentimp0_.type as type366_, 
			paymentimp0_.wf_Id as wf12_366_, 
			paymentimp0_.clazz_ as clazz_ 
	from 
		( select 	type, 
					isoutbound,  
					wf_Id,  
					status,  
					pTimestamp,  
					bundle_Id,  
					payment_Id,  
					transaction_Id,  
					message_Id,  
					settle_Date,  
					settle_Amt,  
					reference,  
					1 as clazz_  
			from SCT_PAYMENT 

			union all

			select 	type, 
					isoutbound,  
					wf_Id, status,  
					pTimestamp,  
					bundle_Id,  
					payment_Id,  
					transaction_Id,  
					message_Id,  
					settle_Date,  
					settle_Amt,  
					reference,  
					2 as clazz_  
			from SCT_PAYMENT_ARCHIVE 
		) paymentimp0_ ) 


	where rownum <= ?