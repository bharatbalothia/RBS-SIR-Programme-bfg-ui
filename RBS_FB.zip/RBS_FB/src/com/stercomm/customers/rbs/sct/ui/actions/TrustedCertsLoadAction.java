package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.stercomm.customers.rbs.sct.ui.dao.TrustedCertDAO;
import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;


public class TrustedCertsLoadAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(TrustedCertsLoadAction.class);

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {	
		return super.viewForm(mapping, form, request, response);
	}

	public ActionForward create(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		TrustedCertDAO dao = new TrustedCertDAO(getHibernateSession());
		TrustedCert trustedCert = dao.getNewInstance();
		trustedCert.setCreateBean(true);
		trustedCert.setNewBean(true);
		trustedCert.setDeleteBean(false);

		request.getSession().setAttribute("trustedCertBean", trustedCert);
		return mapping.findForward("newTrustedCert");

	}

	public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		try {
			String tcid = request.getParameter("id");
			if (tcid!=null){
				TrustedCertDAO dao = new TrustedCertDAO(getHibernateSession());
				TrustedCert trustedCert = dao.getTrustedCert(tcid);
				trustedCert.setCreateBean(false);
				trustedCert.setNewBean(false);
				trustedCert.setDeleteBean(true);

				request.getSession().setAttribute("trustedCertBean", trustedCert);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return mapping.findForward("notfound");
		}
		
		return mapping.findForward("deleteTrustedCert");
		
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public static Logger getLog() {
		return log;
	}



}
