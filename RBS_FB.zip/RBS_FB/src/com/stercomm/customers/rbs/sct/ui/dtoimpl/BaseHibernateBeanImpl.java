/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dtoimpl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean;
import com.stercomm.customers.rbs.sct.ui.interfaces.XMLable;


/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class BaseHibernateBeanImpl implements BaseHibernateBean, XMLable{
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(BaseHibernateBeanImpl.class);
	
	
	private boolean newBean = false;
	private boolean createBean = false;
	private boolean deleteBean = false;
	private boolean updated = false;
	
	public boolean isNewBean() {
		return newBean;
	}
	public void setNewBean(boolean newBean) {
		this.newBean = newBean;
	}
	public boolean isCreateBean() {
		return createBean;
	}
	public void setCreateBean(boolean createBean) {
		this.createBean = createBean;
	}
	public boolean isUpdated() {
		return this.updated;
	}
	public void setUpdated(boolean updated) {
		this.updated = updated;		
	}
	
	public Document getDocument() {
		log.debug("generating DOM document for Endpoint: "+this.toString());
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.newDocument();
			
//			***root element***
			addToNode(doc, doc);
			
			return doc;
		} catch (DOMException e) {
			log.fatal("DOMException while building document", e);
			throw new RuntimeException(e);
		} catch (ParserConfigurationException e) {
			log.fatal("ParserConfigurationException while building document", e);
			throw new RuntimeException(e);
		}
	}
	
	public Element addToNode(Node node, Document doc){
		Element ele = getAsElement(doc);
		node.appendChild(ele);
		return ele;
	}
	
	public Element getAsElement(Document doc){
		throw new UnsupportedOperationException("this operation has not been implemented for this object");
	}
	
	/**
	 * Returns a XML String representation of the parameter Document object 
	 * @param doc
	 * @return
	 */
	public String toXML(Document doc){
		log.debug("generating xml string org.w3c.dom.Docment");
		//doc.normalize();
		
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		OutputFormat format = new OutputFormat(doc);
		XMLSerializer output = new XMLSerializer(outputStream, format);
		try {
			output.serialize(doc);
		} catch (IOException e) {
			log.fatal("IOException while serializing Document", e);
			throw new RuntimeException(e);
		}
		String out = outputStream.toString();
		log.debug("xml string generated successfully");
		
		return out;
	}
	
	/**
	 * Returns a XML String representation of the parameter UserBean object 
	 * @param hibernateBean
	 * @return
	 */
	public String toXML(){
		Document doc = getDocument();
		String out = toXML(doc);
		return out;
		
	}
	
	public byte[] getObjectBytes() throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oout = new ObjectOutputStream(baos);
		oout.writeObject(this);
		oout.close();
		return baos.toByteArray();
	}
	@Override
	public boolean isDeleteBean() {
		// TODO Auto-generated method stub
		return deleteBean;
	}
	@Override
	public void setDeleteBean(boolean deleteBean) {
		this.deleteBean= deleteBean;
		
	}
}
