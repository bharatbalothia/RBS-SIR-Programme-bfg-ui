/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria;
import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.ResultMetaImpl;
import com.stercomm.customers.rbs.sct.ui.dao.StatusDAO.Status;
import com.stercomm.customers.rbs.sct.ui.dto.Payment;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unchecked"})
public class PaymentDAO extends BaseHibernateDAO {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(PaymentDAO.class);

	protected PaymentDAO(Session hibSession, String messageResourcesKey) {
		super(hibSession, messageResourcesKey);
	}




	public Payment getPayment(Long paymentId){
		Payment payment = getPaymentCurrent(paymentId);
		if (payment==null){
			payment = getPaymentArchive(paymentId);
		}
		return payment;
	}

	public Payment getPaymentCurrent(Long paymentId){
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.paymentCurrent.byId");
		query.setLong("paymentId", paymentId.longValue());
		Payment payment = (Payment)query.uniqueResult();
		return payment;
	}

	public Payment getPaymentArchive(Long paymentId){
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.paymentArchive.byId");
		query.setLong("paymentId", paymentId.longValue());
		Payment payment = (Payment)query.uniqueResult();
		return payment;
	}

	public List getCurrentPayments(Long bundleId){
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.paymentCurrent.list.byBundleId");
		query.setLong("bundleId", bundleId.longValue());
		List results = query.list();
		return results;
	}

	public List getArchivePayments(Long bundleId){
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.paymentArchive.list.byBundleId");
		query.setLong("bundleId", bundleId.longValue());
		List results = query.list();
		return results;
	}

	public List getAllPayments(Long bundleId){
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.paymentArchive.list.byBundleId");

		query.setLong("bundleId", bundleId.longValue());
		List results1 = query.list();

		query = session.getNamedQuery("dao.paymentCurrent.list.byBundleId");
		query.setLong("bundleId", bundleId.longValue());
		List results2 = query.list();

		List results = new ArrayList();
		if (results1!=null){
			results.addAll(results1);
		}
		if (results2!=null){
			results.addAll(results2);
		}

		Collections.sort(results, Collections.reverseOrder());
		return results;
	}

	public ResultMeta getAllPayments(int pageNo, int pageSize){
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();

		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.paymentAll.list");
		query.setFirstResult(firstResult-1); //zero indexed
		query.setMaxResults(pageSize);

		List results = query.list();
		Collections.sort(results, Collections.reverseOrder());
		rm.setResultsList(results);

		query = session.getNamedQuery("dao.paymentAll.list.size");
		Integer totalResults = (Integer)query.uniqueResult();
		rm.setTotalResults(totalResults);

		return rm;
	}

	public ResultMeta getAllPayments(int pageNo, int pageSize, Long bundleId){
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();

		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.paymentAll.list.byBundleId");
		query.setLong("bundleId", bundleId.longValue());
		query.setFirstResult(firstResult-1); //zero indexed
		query.setMaxResults(pageSize);

		List results = query.list();
		rm.setResultsList(results);

		query = session.getNamedQuery("dao.paymentAll.list.byBundleId.size");
		query.setLong("bundleId", bundleId.longValue());
		Integer totalResults = (Integer)query.uniqueResult();
		rm.setTotalResults(totalResults);

		return rm;
	}



	protected static final Object[] ENTITY_ID = {"entityId", java.lang.Integer.class};
	protected static final Object[] SERVICE = {"service", java.lang.String.class};
	protected static final Object[] IS_OUTBOUND = {"isOutbound", java.lang.Boolean.class};

	protected static final Object[] FILE_STATUS = {"fileStatus", java.lang.Integer.class};
	protected static final Object[] REFERENCE = {"reference", java.lang.String.class};
	protected static final Object[] TRANSACTION_ID = {"transactionId", java.lang.String.class};
	//CHG_UI_IBM_RJ_002
	protected static final Object[] PAYMENT_BIC = {"paymentBIC", java.lang.String.class};
	protected static final Object[] TYPE = {"type", java.lang.String.class};
	protected static final Object[] FROM_DATE = {"fromDate", java.util.Date.class};
	protected static final Object[] TO_DATE = {"toDate", java.util.Date.class};
	protected static final Object[] MIN_DIFF = {"minDiff", java.lang.Integer.class};
	protected static final Object[] DOC_ID = {"docId", java.lang.String.class};


	public ResultMeta getPayments(int pageNo, int pageSize, PaymentSearchCriteria criteria){
		Session session = getHibernateSession();

		String qsCurrent;
		String qsCurrentCount;
		

		{
			Query query = session.getNamedQuery("dao.paymentAll.list");
			qsCurrent = query.getQueryString();
			query = session.getNamedQuery("dao.paymentAll.list.size");
			qsCurrentCount = query.getQueryString();

			query = session.getNamedQuery("dao.paymentArchive.list");
			query = session.getNamedQuery("dao.paymentArchive.list.size");

			query = null;
		}

		
		
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();

		StringBuffer whereStatements =  new StringBuffer();
		Map params = new HashMap();

		if (criteria.getEntityId()!=null){
			if (criteria.getService()!=null && criteria.getService().equals("SCT")){
				/*
				 * Matt Bradley - 28/10/2009
				 * Hack to search for unbundled payments if ENTITY is being used to search the payments
				 * Only for SCT, it searches based on the Entity MailboxPathOout/In as well as the Bundle|EntityId
				 */
				whereStatements.append(getMessage("rbs.sfg.sct.payment.search.entity2"));
				params.put(ENTITY_ID, criteria.getEntityId());
			} else {
				whereStatements.append(getMessage("rbs.sfg.sct.payment.search.entity"));
				params.put(ENTITY_ID, criteria.getEntityId());
			}
		}
		if (!(criteria.getService()==null || criteria.getService().equals("*") || criteria.getService().equals("ALL") )){
			if(criteria.getService().equals("SCT")){
				whereStatements.append(getMessage("rbs.sfg.sct.payment.search.service"));
				params.put(SERVICE, criteria.getService());
			}
			if(criteria.getService().equals("XCT")){
				whereStatements.append(getMessage("rbs.sfg.xct.payment.search.service"));
				params.put(SERVICE, criteria.getService());
			}
		}
		if (!(criteria.getDirection()==null || criteria.getDirection().equals("ALL")|| criteria.getDirection().equals("*"))){
			whereStatements.append(getMessage("rbs.sfg.sct.payment.search.outbound"));
			params.put(IS_OUTBOUND, criteria.getDirection().equalsIgnoreCase("outbound")?Boolean.TRUE:Boolean.FALSE);
		}
		if (criteria.getDocId()!=null){
			whereStatements.append(getMessage("rbs.sfg.sct.payment.search.docId"));
			params.put(DOC_ID, criteria.getDocId());
		}


		StatusDAO tsDAO = StatusDAO.getInstance();
		if (!(criteria.getTransactionStatus()==null || criteria.getTransactionStatus().equals("ALL") || criteria.getTransactionStatus().equals("*"))){
			if (criteria.getTransactionStatus().equals("error")){
				whereStatements.append(getMessage("rbs.sfg.sct.payment.search.filestatus.error"));
			}
			else{	
				Status ts = tsDAO.getTransactionStatus(criteria.getTransactionStatus());
				if (ts==null){
					log.warn("Error looking up transaction status value for key '"+criteria.getTransactionStatus()+"' - critera skipped!");
				}
				else {
					whereStatements.append(getMessage("rbs.sfg.sct.payment.search.filestatus"));
					params.put(FILE_STATUS, ts.statusI);
					System.out.println("RJLOG whereStatements:" + whereStatements);
				}
			}
		}

		if (!(criteria.getReference()==null || criteria.getReference().length()==0 || criteria.getReference().equals("%"))){
			whereStatements.append(getMessage("rbs.sfg.sct.payment.search.reference"));
			params.put(REFERENCE, criteria.getReference());
		}
		if (!(criteria.getTransactionId()==null || criteria.getTransactionId().length()==0 || criteria.getTransactionId().equals("%"))){
			whereStatements.append(getMessage("rbs.sfg.sct.payment.search.transactionId"));
			params.put(TRANSACTION_ID, criteria.getTransactionId());
		}
		
		//CHG_UI_IBM_RJ_002
		if (!(criteria.getPaymentBIC()==null || criteria.getPaymentBIC().length()==0 || criteria.getPaymentBIC().equals("%"))){
			whereStatements.append(getMessage("rbs.sfg.sct.payment.search.paymentBIC"));
			params.put(PAYMENT_BIC, criteria.getPaymentBIC());
		}
		
		if (! 
				( criteria.getType()==null 
						|| criteria.getType().length()==0
						|| criteria.getType().equals("%") 
						|| criteria.getType().equals("*") 
						|| criteria.getType().equalsIgnoreCase("ALL")
				)
		){
			whereStatements.append(getMessage("rbs.sfg.sct.payment.search.type"));
			params.put(TYPE, criteria.getType());
		}
		if (criteria.getSettlementDateFrom()!=null){
			whereStatements.append(getMessage("rbs.sfg.sct.payment.search.settleDateFrom"));
			params.put(FROM_DATE, criteria.getSettlementDateFrom());
		}
		if (criteria.getSettlementDateTo()!=null){
			whereStatements.append(getMessage("rbs.sfg.sct.payment.search.settleDateTo"));
			params.put(TO_DATE, criteria.getSettlementDateTo());
		}

//		for Traffic summary static searches
		if (criteria.getMinDiff()!=null){
			Integer md = Integer.valueOf(criteria.getMinDiff());
			if(md.intValue()>0){
				whereStatements.append(getMessage("rbs.sfg.sct.payment.search.minDiff"));
				params.put(MIN_DIFF, md);
			}
			log.debug("minDiff="+criteria.getMinDiff());
		}

		if (whereStatements.length()>0){
			whereStatements.delete(0, 4);
			whereStatements.append(getMessage("rbs.sfg.sct.payment.search.orderBy"));
			qsCurrent += (" WHERE ");
			qsCurrent +=(whereStatements.toString());

			qsCurrentCount += (" WHERE ");
			qsCurrentCount +=(whereStatements.toString());
		}
		else {
			qsCurrent += " "+getMessage("rbs.sfg.sct.payment.search.orderBy");
		}

		session = getHibernateSession();
		log.debug("hql query: "+qsCurrent);
		Query queryCurrent = session.createQuery(qsCurrent);
		System.out.println("RJLOG queryCurrent is: " + queryCurrent);
		log.debug("hql count query: "+qsCurrentCount);
		Query countQueryCurrent = session.createQuery(qsCurrentCount);


		{
			Iterator paramKeySetIterator = params.keySet().iterator();
			while (paramKeySetIterator.hasNext()){
				Object[] arr = (Object[])paramKeySetIterator.next();
				if(arr[1]==String.class){
					queryCurrent.setString((String)arr[0], (String)params.get(arr));
					countQueryCurrent.setString((String)arr[0], (String)params.get(arr));
				}
				else if(arr[1]==Integer.class){
					queryCurrent.setInteger((String)arr[0], ((Integer)params.get(arr)).intValue());
					countQueryCurrent.setInteger((String)arr[0], ((Integer)params.get(arr)).intValue());
				}
				else if(arr[1]==Long.class){
					queryCurrent.setLong((String)arr[0], ((Long)params.get(arr)).longValue());
					countQueryCurrent.setLong((String)arr[0], ((Long)params.get(arr)).longValue());
				}
				else if(arr[1]==Double.class){
					queryCurrent.setDouble((String)arr[0], ((Double)params.get(arr)).doubleValue());
					countQueryCurrent.setDouble((String)arr[0], ((Double)params.get(arr)).doubleValue());
				}
				else if (arr[1]==Date.class){
					queryCurrent.setDate((String)arr[0], (Date)params.get(arr));
					countQueryCurrent.setDate((String)arr[0], (Date)params.get(arr));
				}
				else if (arr[1]==Boolean.class){
					queryCurrent.setBoolean((String)arr[0], ((Boolean)params.get(arr)).booleanValue());
					countQueryCurrent.setBoolean((String)arr[0], ((Boolean)params.get(arr)).booleanValue());
				}
			}
		}

		queryCurrent.setFirstResult(firstResult-1); //zero indexed
		queryCurrent.setMaxResults(pageSize);


		List results = queryCurrent.list();
		rm.setResultsList(results);

		rm.setTotalResults(((Integer)countQueryCurrent.uniqueResult()).intValue());



		return rm;
	}
}
