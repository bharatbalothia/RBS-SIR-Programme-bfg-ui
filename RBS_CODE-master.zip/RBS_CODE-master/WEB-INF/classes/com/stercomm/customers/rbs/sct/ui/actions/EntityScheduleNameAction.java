/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.MessageResources;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.dto.Schedule;
import com.stercomm.customers.rbs.sct.ui.forms.EntityScheduleForm;
import com.stercomm.customers.rbs.sct.ui.forms.adapters.ScheduleAdapter;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"deprecation", "static-access", "unused", "unchecked"})
public class EntityScheduleNameAction extends BaseEntityWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(EntityScheduleNameAction.class);
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		EntityScheduleForm esf = (EntityScheduleForm)form;
		Schedule schedule = (Schedule)request.getSession().getAttribute("scheduleBean");
//		boolean isNew = schedule.isNewBean();
//		boolean isCreate = schedule.isCreateBean();
		ScheduleAdapter adapter = new ScheduleAdapter(esf);
		
		copyBeanProperties(schedule, adapter);
		
		return mapping.findForward("viewForm");
	}
	
	public ActionForward refresh(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		EntityScheduleForm esf = (EntityScheduleForm)form;
		Schedule scheduleAdapter =  new ScheduleAdapter(esf);
		
		Schedule schedule = (Schedule)request.getSession().getAttribute("scheduleBean");
		boolean isNew = schedule.isNewBean();
		boolean isCreate = schedule.isCreateBean();
		Long scheduleId = schedule.getScheduleId();
		/*
		 * Fix for issue where invalid data is added and then the type dropdown is changed
		 * We will just reset the values if invalid
		 */
		Integer _Int = null;
		try {
			_Int = new Integer(esf.getTimeStart());
		} catch (Exception e){
			log.warn("Schedule TimeStart is invalid...setting to 0");
			scheduleAdapter.setTimestart(new Integer(0));
			esf.setTimeStart("0");
		}
		try {
			_Int = new Integer(esf.getTimeEnd());
		} catch (Exception e){
			log.warn("Schedule TimeEnd is invalid...setting to 0");
			scheduleAdapter.setWindowEnd(new Integer(0));
			esf.setTimeEnd("0");
		}
		try {
			_Int = new Integer(esf.getInterval());
		} catch (Exception e){
			log.warn("Schedule TimeInterval is invalid...setting to 0");
			scheduleAdapter.setWindowInterval(new Integer(0));
			esf.setInterval("0");
		}
		
		/*
		 * Fix end
		 */
		schedule.setWindowInterval(0);
		copyBeanProperties(scheduleAdapter, schedule);
		schedule.setCreateBean(isCreate);
		schedule.setNewBean(isNew);
		schedule.setScheduleId(scheduleId);
		
		return mapping.findForward("viewForm");
	}
	
	public ActionForward save(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		//saveForm2Bean(mapping, form, request, response);
		//return mapping.findForward("save");
		if(validateForm(form, request)){
			//saveForm2Bean(mapping, form, request, response);
			//return mapping.findForward("save");
			return super.save(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}
	}
	
	public ActionForward next(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		
		//saveForm2Bean(mapping, form, request, response);
		//return mapping.findForward("next");
		if(validateForm(form, request)){
			//saveForm2Bean(mapping, form, request, response);
			//return mapping.findForward("next");
			return super.next(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}
	}
	
	public ActionForward entitySwift(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if(validateForm(form, request)){
			//saveForm2Bean(mapping, form, request, response);
			//return mapping.findForward("entitySwift");
			return super.entitySwift(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}
		
	}
	
	public ActionForward confirm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		if(validateForm(form, request)){
			//saveForm2Bean(mapping, form, request, response);
			//return mapping.findForward("confirm");
			return super.confirm(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}

	}
	
	public ActionForward back(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		if(validateForm(form, request)){
			//saveForm2Bean(mapping, form, request, response);
			//return mapping.findForward("back");
			return super.back(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}

	}
	
	public ActionForward entityName(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		if(validateForm(form, request)){
			//saveForm2Bean(mapping, form, request, response);
			//return mapping.findForward("entityName");
			return super.entityName(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}

	}
	
//	public ActionForward cancel(ActionMapping mapping, ActionForm form,
//			HttpServletRequest request, HttpServletResponse response)
//			throws Exception {
//		
//		if(validateForm(form, request)){
//			saveForm2Bean(mapping, form, request, response);
//			return mapping.findForward("cancel");
//		} else {
//			return mapping.findForward("viewForm");
//		}
//
//	}
	
	public ActionForward entityScheduleList(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		if(validateForm(form, request)){
			//saveForm2Bean(mapping, form, request, response);
			//return mapping.findForward("entityScheduleList");
			return super.entityScheduleList(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}

	}
	
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.actions.BaseEntityWizardAction#saveForm2Bean(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public void saveForm2Bean(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)	throws Exception {
		
		EntityScheduleForm esf = (EntityScheduleForm)form;
		
		Schedule scheduleAdapter =  new ScheduleAdapter(esf);
		
		Schedule schedule = (Schedule)request.getSession().getAttribute("scheduleBean");
		boolean isNew = schedule.isNewBean();
		boolean isCreate = schedule.isCreateBean();
		Long scheduleId = schedule.getScheduleId();
		Entity entity = (Entity)request.getSession().getAttribute("entityBean");// schedule.getEntity();
		
		copyBeanProperties(scheduleAdapter, schedule);
		
		schedule.setCreateBean(isCreate);
		schedule.setNewBean(isNew);
		schedule.setScheduleId(scheduleId);
		schedule.setEntity(entity); //set for both new and update schedules
		
		if (schedule.isNewBean()){
			schedule.setNewBean(false);
			//Entity entity = 
			entity.getSchedules().add(schedule);
			schedule.setEntity(entity);
		}
		
		schedule.setUpdated(true);
		
		
		if (!schedule.getIsWindow().booleanValue()){
			schedule.setWindowEnd(null);
			schedule.setWindowInterval(null);
		}
	}
	
private boolean validateForm(ActionForm form, HttpServletRequest request){
		
		EntityScheduleForm esf = (EntityScheduleForm)form;
		ActionMessages messages = new ActionMessages();
		MessageResources messageResources = getResources(request);
		boolean rtn=true;
		
		log.debug("Validating Entity[Schedule Name] form.");
		
		//Start Time Check
		if(esf.getTimeStart()==null || esf.getTimeStart().equalsIgnoreCase("")){
			log.debug("Start Time is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.timestart.required" ));
			rtn=false;
		} else {
			log.debug("Validating [" + esf.getTimeStart() + "] against ["+ messageResources.getMessage("sct.validate.entity.timestart")+ "]");
			if(!esf.getTimeStart().matches(messageResources.getMessage("sct.validate.entity.timestart"))){
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.timestart.invalid" ));
				log.debug("Validation of Start Time [" + esf.getTimeStart() + "] failed");
				rtn=false;
			}
		}
		
		//Only if Window Type schedule
		if(esf.getType()!=null && esf.getType().equalsIgnoreCase(messageResources.getMessage("sct.label.Window"))){
		
//			End Time Check
			if(esf.getTimeEnd()==null || esf.getTimeEnd().equalsIgnoreCase("")){
				log.debug("End Time is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.timeend.required" ));
				rtn=false;
			} else {
				log.debug("Validating [" + esf.getTimeEnd() + "] against ["+ messageResources.getMessage("sct.validate.entity.timeend")+ "]");
				if(!esf.getTimeEnd().matches(messageResources.getMessage("sct.validate.entity.timeend"))){
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.timeend.invalid" ));
					log.debug("Validation of End Time [" + esf.getTimeEnd() + "] failed");
					rtn=false;
				}
			}
			
//			Interval Check
			if(esf.getInterval()==null || esf.getInterval().equalsIgnoreCase("")){
				log.debug("Interval is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.interval.required" ));
				rtn=false;
			} else {
				log.debug("Validating [" + esf.getInterval() + "] against ["+ messageResources.getMessage("sct.validate.entity.interval")+ "]");
				if(!esf.getInterval().matches(messageResources.getMessage("sct.validate.entity.interval"))){
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.interval.invalid" ));
					log.debug("Validation of Interval [" + esf.getInterval() + "] failed");
					rtn=false;
				}
			}
			
		}
		saveMessages(request, messages);
		return rtn;
	}
}
