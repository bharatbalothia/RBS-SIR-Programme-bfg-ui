package com.stercomm.customers.rbs.sct.ui.change;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.rmi.RemoteException;

import org.w3c.dom.Document;

import com.stercomm.customers.rbs.sct.ui.xapi.FBXAPIClient;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSException;

public class ChangeActionImpl implements ChangeAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Override
	public void commit() throws Exception {
		throw new UnsupportedOperationException();
	}

	public byte[] getObjectBytes() throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oout = new ObjectOutputStream(baos);
		oout.writeObject(this);
		oout.close();
		return baos.toByteArray();
	}
	
	protected Document invokeXAPI(String action, Document doc)
	throws YFCException
	{
		Document result = null;
		try
		{
			result = (Document)FBXAPIClient.invoke(null, action, doc);

		} catch (RemoteException e) {
			throw new YFCException(e);
		} catch (YFSException e) {
			throw new YFCException(e);
		} catch (YIFClientCreationException e) {
			throw new YFCException(e);
		}
		return result;
	}

}
