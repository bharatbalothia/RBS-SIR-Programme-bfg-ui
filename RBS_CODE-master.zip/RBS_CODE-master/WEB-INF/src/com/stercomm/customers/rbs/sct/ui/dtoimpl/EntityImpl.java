/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dtoimpl;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;


import com.stercomm.customers.rbs.sct.ui.dto.Entity;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 * @hibernate.class table="SCT_ENTITY"
 */
@SuppressWarnings({"unused", "unchecked"})
public class EntityImpl extends BaseHibernateBeanImpl implements Entity{
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(EntityImpl.class);
	
	
	private Integer entityId;
	private String entity;
	private String service;
	private String requestorDN;
	private String responderDN;
	private String serviceName;
	private String requestType;
	private Boolean SnF = Boolean.FALSE;
	private Boolean trace = Boolean.FALSE;
	private Boolean deliveryNotification = Boolean.FALSE;
	private String deliveryNotifDN;
	private String deliveryNotifRT;
	private String requestRef;
	private String fileDesc;
	private String fileInfo;
	private String transferDesc;
	private String transferInfo;
	private Boolean compression = Boolean.FALSE;
	private String mailboxPathIn;
	private String mailboxPathOut;
	private String mqQueueIn;
	private String mqQueueOut;
	private Integer maxTransfersPerBulk;
	private Integer maxBulksPerFile;
	private Integer startOfDay;
	private Integer endOfDay;
	
	private List schedules = new ArrayList();
	private List deletedSchedules = new ArrayList();
	
	private String cdNode;
	private String idfWTOMsgId;
	private String cdfWTOMsgId;
	private String sdfWTOMsgId;
	private String rsfWTOMsgId;
	private String dnfWTOMsgId;
	private String dvfWTOMsgId;
	private String msrWTOMsgId;
	private String psrWTOMsgId;
	private String drrWTOMsgId;
	private String rtfWTOMsgId;
	private String mbpWTOMsgId;
	
	private String mqHost;
	private Integer mqPort;
	private String mqQManager;
	private String mqChannel;
	private String mqQueueName;
	private String mqQueueBinding;
	private String mqQueueContext;
	private Integer mqDebug;
	private String mqSSLoptions;
	private String mqSSLciphers;
	private String mqSSLkey;
	private String mqSSLcaCert;
	
	private Boolean routeInbound = Boolean.TRUE;
	private Boolean routeOutbound = Boolean.TRUE;
	private Boolean inboundDir = Boolean.FALSE;
	private Boolean inboundRoutingRule = Boolean.FALSE;
	private String inboundRequestorDN = "";
	private String inboundResponderDN = "";
	private String inboundService = "";
	private String inboundType = "";
	private String[] inboundRequestType = new String[0];
	private Boolean nonRepudiation = Boolean.FALSE;
	private Boolean pauseInbound = Boolean.FALSE;
	private Boolean pauseOutbound= Boolean.FALSE;
	private Boolean deleted= Boolean.FALSE;
	
	private String changeID="";
	private String changerComments="";
	
	private Boolean irishStep2 = Boolean.FALSE;
	
	private String e2eSigning;
	
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
		
	}
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	/**
	 * @return the compression
	 * @hibernate.property column = "compression"
	 */
	public Boolean getCompression() {
		return compression;
	}
	/**
	 * @param compression the compression to set
	 */
	public void setCompression(Boolean compression) {
		this.compression = compression;
	}
	/**
	 * @return the deliveryNotif
	 * @hibernate.property column = "deliveryNotif"
	 */
	public Boolean getDeliveryNotification() {
		return deliveryNotification;
	}
	/**
	 * @param deliveryNotif the deliveryNotif to set
	 */
	public void setDeliveryNotification(Boolean deliveryNotification) {
		this.deliveryNotification = deliveryNotification;
	}
	/**
	 * @return the deliveryNotifDN
	 * @hibernate.property column = "deliveryNotifDN"
	 */
	public String getDeliveryNotifDN() {
		return deliveryNotifDN;
	}
	/**
	 * @param deliveryNotifDN the deliveryNotifDN to set
	 */
	public void setDeliveryNotifDN(String deliveryNotifDN) {
		this.deliveryNotifDN = deliveryNotifDN;
	}
	/**
	 * @return the deliveryNotifRT
	 * @hibernate.property column = "deliveryNotifRT"
	 */
	public String getDeliveryNotifRT() {
		return deliveryNotifRT;
	}
	/**
	 * @param deliveryNotifRT the deliveryNotifRT to set
	 */
	public void setDeliveryNotifRT(String deliveryNotifRT) {
		this.deliveryNotifRT = deliveryNotifRT;
	}
	/**
	 * @return the endOfDay
	 * @hibernate.property column = "endOfDay"
	 */
	public Integer getEndOfDay() {
		return endOfDay;
	}
	/**
	 * @param endOfDay the endOfDay to set
	 */
	public void setEndOfDay(Integer endOfDay) {
		this.endOfDay = endOfDay;
	}
	/**
	 * @return the entity
	 * @hibernate.property column = "entity" 
	 */
	public String getEntity() {
		return entity;
	}
	/**
	 * @param entity the entity to set
	 */
	public void setEntity(String entity) {
		this.entity = entity;
	}
	/**
	 * @return the entityId
	 * @hibernate.id column = "entity_Id" generator-class = "sequence"
	 * @hibernate.generator-param name = "sequence" value = "SCT_ENTITY_IDSEQ"
	 */
	public Integer getEntityId() {
		return entityId;
	}
	/**
	 * @param entityId the entityId to set
	 */
	public void setEntityId(Integer entityId) {
		this.entityId = entityId;
	}
	/**
	 * @return the fileDesc
	 * @hibernate.property column = "fileDesc"
	 */
	public String getFileDesc() {
		return fileDesc;
	}
	/**
	 * @param fileDesc the fileDesc to set
	 */
	public void setFileDesc(String fileDesc) {
		this.fileDesc = fileDesc;
	}
	/**
	 * @return the fileInfo
	 * @hibernate.property column = "fileInfo"
	 */
	public String getFileInfo() {
		return fileInfo;
	}
	/**
	 * @param fileInfo the fileInfo to set
	 */
	public void setFileInfo(String fileInfo) {
		this.fileInfo = fileInfo;
	}
	/**
	 * @return the mailboxPathOut
	 * @hibernate.property column = "mailboxPathOut"
	 */
	public String getMailboxPathOut() {
		return mailboxPathOut;
	}
	/**
	 * @param mailboxPathOut the mailboxPathOut to set
	 */
	public void setMailboxPathOut(String mailboxPathOut) {
		this.mailboxPathOut = mailboxPathOut;
	}
	/**
	 * @return the mailboxPathIn
	 * @hibernate.property column = "mailboxPathIn"
	 */
	public String getMailboxPathIn() {
		return mailboxPathIn;
	}
	/**
	 * @param mailboxPathIn the mailboxPathIn to set
	 */
	public void setMailboxPathIn(String mailboxPathIn) {
		this.mailboxPathIn = mailboxPathIn;
	}
	/**
	 * @return the maxBulksPerFile
	 * @hibernate.property column = "maxBulksPerFile"
	 */
	public Integer getMaxBulksPerFile() {
		return maxBulksPerFile;
	}
	/**
	 * @param maxBulksPerFile the maxBulksPerFile to set
	 */
	public void setMaxBulksPerFile(Integer maxBulksPerFile) {
		this.maxBulksPerFile = maxBulksPerFile;
	}
	/**
	 * @return the maxTransfersPerBulk
	 * @hibernate.property column = "maxTransPerBulk"
	 */
	public Integer getMaxTransfersPerBulk() {
		return maxTransfersPerBulk;
	}
	/**
	 * @param maxTransferBulk the maxTransferBulk to set
	 */
	public void setMaxTransfersPerBulk(Integer maxTransfersPerBulk) {
		this.maxTransfersPerBulk = maxTransfersPerBulk;
	}
	/**
	 * @return the mqQueueIn
	 * @hibernate.property column = "mqQueueIn"
	 */
	public String getMqQueueIn() {
		return mqQueueIn;
	}
	/**
	 * @param mqQueueIn the mqQueueIn to set
	 */
	public void setMqQueueIn(String mqQueueIn) {
		this.mqQueueIn = mqQueueIn;
	}
	/**
	 * @return the mqQueueOut
	 * @hibernate.property column = "mqQueueOut"
	 */
	public String getMqQueueOut() {
		return mqQueueOut;
	}
	/**
	 * @param mqQueueOut the mqQueueOut to set
	 */
	public void setMqQueueOut(String mqQueueOut) {
		this.mqQueueOut = mqQueueOut;
	}
	/**
	 * @return the requestType
	 * @hibernate.property column = "requestType"
	 */
	public String getRequestType() {
		return requestType;
	}
	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	/**
	 * @return the requestorDN
	 * @hibernate.property column = "requestorDN"
	 */
	public String getRequestorDN() {
		return requestorDN;
	}
	/**
	 * @param requestorDN the requestorDN to set
	 */
	public void setRequestorDN(String requestorDN) {
		this.requestorDN = requestorDN;
	}
	/**
	 * @return the requestRef
	 * @hibernate.property column = "requestRef"
	 */
	public String getRequestRef() {
		return requestRef;
	}
	/**
	 * @param requestRef the requestRef to set
	 */
	public void setRequestRef(String requestRef) {
		this.requestRef = requestRef;
	}
	/**
	 * @return the responderDN
	 * @hibernate.property column = "responderDN"
	 */
	public String getResponderDN() {
		return responderDN;
	}
	/**
	 * @param responderDN the responderDN to set
	 */
	public void setResponderDN(String responderDN) {
		this.responderDN = responderDN;
	}
	/**
	 * @return the service
	 * @hibernate.property column = "service"
	 */
	public String getService() {
		return service;
	}
	/**
	 * @param service the service to set
	 */
	public void setService(String service) {
		this.service = service;
	}
	/**
	 * @return the serviceName
	 * @hibernate.property column = "serviceName"
	 */
	public String getServiceName() {
		return serviceName;
	}
	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	/**
	 * @return the SNF
	 * @hibernate.property column = "SNF"
	 */
	public Boolean getSnF() {
		return SnF;
	}
	/**
	 * @param SnF the SnF to set
	 */
	public void setSnF(Boolean SnF) {
		this.SnF = SnF;
	}
	/**
	 * @return the startOfDay
	 * @hibernate.property column = "startOfDay"
	 */
	public Integer getStartOfDay() {
		return startOfDay;
	}
	/**
	 * @param startOfDay the startOfDay to set
	 */
	public void setStartOfDay(Integer startOfDay) {
		this.startOfDay = startOfDay;
	}
	/**
	 * @return the trace
	 * @hibernate.property column = "trace"
	 */
	public Boolean getTrace() {
		return trace;
	}
	/**
	 * @param trace the trace to set
	 */
	public void setTrace(Boolean trace) {
		this.trace = trace;
	}
	/**
	 * @return the transferDesc
	 * @hibernate.property column = "transferDesc"
	 */
	public String getTransferDesc() {
		return transferDesc;
	}
	/**
	 * @param transferDesc the transferDesc to set
	 */
	public void setTransferDesc(String transferDesc) {
		this.transferDesc = transferDesc;
	}
	/**
	 * @return the transferInfo
	 * @hibernate.property column = "transferInfo"
	 */
	public String getTransferInfo() {
		return transferInfo;
	}
	/**
	 * @param transferInfo the transferInfo to set
	 */
	public void setTransferInfo(String transferInfo) {
		this.transferInfo = transferInfo;
	}
	
	
	/**
	 * @return the schedules
//	 * hibernate.list
//	 * @hibernate.collection-key column="ENTITY_ID"
//	 * @hibernate.collection-index column="TIMESTART"
//	 * @hibernate.collection-one-to-many  class="com.stercomm.customers.rbs.sct.ui.dtoimpl.ScheduleImpl" 
	 */
	public List getSchedules() {
		return schedules;
	}
	/**
	 * @param schedules the schedules to set
	 */
	public void setSchedules(List schedules) {
		this.schedules = schedules==null?new ArrayList():schedules;
	}
	/**
	 * @return the deleted schedules
	 */ 
	public List getDeletedSchedules() {
		return deletedSchedules;
	}
	/**
	 * @param schedules the deleted schedules to set
	 */
	public void setDeletedSchedules(List schedules) {
		this.deletedSchedules = schedules==null?new ArrayList():schedules;
	}
	
	
	
	public String toString() {
		StringBuffer out = new StringBuffer();
		out.append("Entity[");
		out.append(getEntityId()==null?"NEW":getEntityId().toString());
		out.append("];");
		return out.toString();
	}
	public String getCdfWTOMsgId() {
		return cdfWTOMsgId;
	}
	public void setCdfWTOMsgId(String cdfWTOMsgId) {
		this.cdfWTOMsgId = cdfWTOMsgId;
	}
	public String getCdNode() {
		return cdNode;
	}
	public void setCdNode(String cdNode) {
		this.cdNode = cdNode;
	}
	public String getDnfWTOMsgId() {
		return dnfWTOMsgId;
	}
	public void setDnfWTOMsgId(String dnfWTOMsgId) {
		this.dnfWTOMsgId = dnfWTOMsgId;
	}
	public String getDrrWTOMsgId() {
		return drrWTOMsgId;
	}
	public void setDrrWTOMsgId(String drrWTOMsgId) {
		this.drrWTOMsgId = drrWTOMsgId;
	}
	public String getDvfWTOMsgId() {
		return dvfWTOMsgId;
	}
	public void setDvfWTOMsgId(String dvfWTOMsgId) {
		this.dvfWTOMsgId = dvfWTOMsgId;
	}
	public String getIdfWTOMsgId() {
		return idfWTOMsgId;
	}
	public void setIdfWTOMsgId(String idfWTOMsgId) {
		this.idfWTOMsgId = idfWTOMsgId;
	}
	public String getMsrWTOMsgId() {
		return msrWTOMsgId;
	}
	public void setMsrWTOMsgId(String msrWTOMsgId) {
		this.msrWTOMsgId = msrWTOMsgId;
	}
	public String getPsrWTOMsgId() {
		return psrWTOMsgId;
	}
	public void setPsrWTOMsgId(String psrWTOMsgId) {
		this.psrWTOMsgId = psrWTOMsgId;
	}
	public String getRsfWTOMsgId() {
		return rsfWTOMsgId;
	}
	public void setRsfWTOMsgId(String rsfWTOMsgId) {
		this.rsfWTOMsgId = rsfWTOMsgId;
	}
	public String getSdfWTOMsgId() {
		return sdfWTOMsgId;
	}
	public void setSdfWTOMsgId(String sdfWTOMsgId) {
		this.sdfWTOMsgId = sdfWTOMsgId;
	}
	public String getRtfWTOMsgId() {
		return rtfWTOMsgId;
	}
	public void setRtfWTOMsgId(String rtfWTOMsgId) {
		this.rtfWTOMsgId = rtfWTOMsgId;
	}
	public String getMbpWTOMsgId() {
		return mbpWTOMsgId;
	}
	public void setMbpWTOMsgId(String mbpWTOMsgId) {
		this.mbpWTOMsgId = mbpWTOMsgId;
	}
	

	public void setMqHost(String mqHost) {
		this.mqHost =  mqHost;
	}
	public void setMqPort(Integer mqPort) {
		this.mqPort =  mqPort;
	}
	public void setMqQManager(String mqQManager) {
		this.mqQManager =  mqQManager;
	}
	public void setMqChannel(String mqChannel) {
		this.mqChannel =  mqChannel;
	}
	public void setMqQueueName(String mqQueueName) {
		this.mqQueueName =  mqQueueName;
	}
	public void setMqQueueBinding(String mqQueueBinding) {
		this.mqQueueBinding =  mqQueueBinding;
	}
	public void setMqQueueContext(String mqQueueContext) {
		this.mqQueueContext =  mqQueueContext;
	}
	public void setMqDebug(Integer mqDebug) {
		this.mqDebug =  mqDebug;
	}
	public void setMqSSLoptions(String mqSSLoptions) {
		this.mqSSLoptions =  mqSSLoptions;
	}
	public void setMqSSLciphers(String mqSSLciphers) {
		this.mqSSLciphers =  mqSSLciphers;
	}
	public void setMqSSLkey(String mqSSLkey) {
		this.mqSSLkey =  mqSSLkey;
	}
	public void setMqSSLcaCert(String mqSSLcaCert) {
		this.mqSSLcaCert =  mqSSLcaCert;
	}
	
	public String getMqHost(){
		return mqHost;
	}
	public Integer getMqPort(){
		return mqPort;
	}
	public String getMqQManager(){
		return mqQManager;
	}
	public String getMqChannel(){
		return mqChannel;
	}
	public String getMqQueueName(){
		return mqQueueName;
	}
	public String getMqQueueBinding(){
		return mqQueueBinding;
	}
	public String getMqQueueContext(){
		return mqQueueContext;
	}
	public Integer getMqDebug(){
		return mqDebug;
	}
	public String getMqSSLoptions(){
		return mqSSLoptions;
	}
	public String getMqSSLciphers(){
		return mqSSLciphers;
	}
	public String getMqSSLkey(){
		return mqSSLkey;
	}
	public String getMqSSLcaCert(){
		return mqSSLcaCert;
	}
	
	//GPL
	
	public Boolean getRouteInbound() {
		return routeInbound;
	}
	public Boolean getRouteOutbound() {
		return routeOutbound;
	}
	public Boolean getInboundDir() {
		return inboundDir;
	}
	public Boolean getInboundRoutingRule() {
		return inboundRoutingRule;
	}
	public String getInboundRequestorDN() {
		return  inboundRequestorDN;
	}
	public String getInboundResponderDN() {
		return  inboundResponderDN;
	}
	public String getInboundService() {
		return inboundService;
	}
	public String getInboundType() {
		return inboundType;
	}
	public String[] getInboundRequestType() {
		return inboundRequestType;
	}
	public Boolean getNonRepudiation() {
		return nonRepudiation;
	}
	
	public void setRouteInbound(Boolean routeInbound) {
		this.routeInbound = routeInbound;
	}
	public void setRouteOutbound(Boolean routeOutbound) {
		this.routeOutbound = routeOutbound;
	}
	
	public void setInboundDir(Boolean inboundDir) {
		this.inboundDir = inboundDir;
	}
	public void setInboundRoutingRule(Boolean inboundRoutingRule) {
		this.inboundRoutingRule = inboundRoutingRule;
	}	
	public void setInboundRequestorDN(String inboundRequestorDN) {
		this.inboundRequestorDN = inboundRequestorDN;
	}
	public void setInboundResponderDN(String inboundResponderDN) {
		this.inboundResponderDN = inboundResponderDN;
	}
	public void setInboundService(String inboundService) {
		this.inboundService = inboundService;
	}
	public void setInboundType(String inboundType) {
		this.inboundType = inboundType;
	}
	public void setInboundRequestType(String[] inboundRequestType) {
		this.inboundRequestType = inboundRequestType;
	}
	public void setNonRepudiation(Boolean nonRepudiation){
		this.nonRepudiation = nonRepudiation;
	}
	public Boolean getPauseInbound() {
		return pauseInbound;
	}
	public void setPauseInbound(Boolean pauseInbound) {
		this.pauseInbound = pauseInbound;
	}
	public Boolean getPauseOutbound() {
		return pauseOutbound;
	}
	public void setPauseOutbound(Boolean pauseOutbound) {
		this.pauseOutbound = pauseOutbound;
	}
	public Boolean getDeleted() {
		return deleted;
	}
	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}
	
	public String getChangeID() {
		return changeID;
	}
	public void setChangeID(String changeID) {
		this.changeID = changeID;
	}
	public String getChangerComments() {
		return changerComments;
	}

	public void setChangerComments(String changerComments) {
		this.changerComments = changerComments;
	}
	
	public Boolean getIrishStep2() {
		return irishStep2;
	}
	public void setIrishStep2(Boolean irishStep2) {
		this.irishStep2=irishStep2;
	}
	public boolean isIrishStep2(){
		if(this.getMailboxPathOut()!=null && this.getMailboxPathOut().endsWith("_ROI_STEP2")){
			return true;
		} else {
			return false;
		}
	}
	public String getE2eSigning() {
		return e2eSigning;
	}
	public void setE2eSigning(String signing) {
		e2eSigning = signing;
	}
	
	
}
