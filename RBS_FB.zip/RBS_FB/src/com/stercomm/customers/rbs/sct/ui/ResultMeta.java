package com.stercomm.customers.rbs.sct.ui;

import java.util.List;

public interface ResultMeta {

	/**
	 * @return the resultsList
	 */
	public abstract List<?> getResultsList();

	/**
	 * @param resultsList the resultsList to set
	 */
	public abstract void setResultsList(List<?> resultsList);

	/**
	 * @return the totalResults
	 */
	public abstract int getTotalResults();

	/**
	 * @param totalResults the totalResults to set
	 */
	public abstract void setTotalResults(int totalResults);
	
	/**
	 * @param totalResults the totalResults to set
	 */
	public abstract void setTotalResults(Integer totalResults);

	/**
	 * @return the currentPage
	 */
	public abstract int getCurrentPage();

	/**
	 * @param currentPage the currentPage to set
	 */
	public abstract void setCurrentPage(int currentPage);

	/**
	 * @return the pageSize
	 */
	public abstract int getPageSize();

	/**
	 * @param pageSize the pageSize to set
	 */
	public abstract void setPageSize(int pageSize);

	/**
	 * @return the totalPages
	 */
	public abstract int getTotalPages();

	/**
	 * @param totalPages the totalPages to set
	 */
	public abstract void setTotalPages(int totalPages);
	
	
	
	public int getFirstResult();
	public int getLastResult();
	

}