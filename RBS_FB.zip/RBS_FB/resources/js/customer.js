//images

retailerdown= new Image();
retailerdown.src= "./images/selected_btn_tra.gif";
retailerup= new Image();
retailerup.src= "./images/unselected_btn.gif";

BackOver = new Image();
BackOver.src = "./../images/en/blue/wiz_back_dep_over.gif";
BackOff = new Image();
BackOff.src = "./../images/en/blue/wiz_back_off.gif";
BackDown = new Image();
BackDown.src = "./../images/en/blue/wiz_back_dep_down.gif";
NextOver = new Image();
NextOver.src = "./../images/en/blue/wiz_next_dep_over.gif";
NextOff = new Image();
NextOff.src = "./../images/en/blue/wiz_next_off.gif";
NextDown = new Image();
NextDown.src = "./../images/en/blue/wiz_next_dep_down.gif";
CancelOver = new Image();
CancelOver.src = "./../images/en/blue/wiz_cancel_dep_over.gif";
CancelOff = new Image();
CancelOff.src = "./../images/en/blue/wiz_cancel_off.gif";
CancelDown = new Image();
CancelDown.src = "./../images/en/blue/wiz_cancel_dep_down.gif";
SaveOver = new Image();
SaveOver.src = "./../images/en/blue/wiz_save_dep_over.gif";
SaveOff = new Image();
SaveOff.src = "./../images/en/blue/wiz_save_off.gif";
SaveDown = new Image();
SaveDown.src = "./../images/en/blue/wiz_save_dep_down.gif";
FinishOver = new Image();
FinishOver.src = "./../images/en/blue/wiz_finish_dep_over.gif";
FinishOff = new Image();
FinishOff.src = "./../images/en/blue/wiz_finish_off.gif";
FinishDown = new Image();
FinishDown.src = "./../images/en/blue/wiz_finish_dep_down.gif";
DeleteOver = new Image();
DeleteOver.src = "./../images/en/blue/wiz_delete_dep_over.gif";
DeleteOff = new Image();
DeleteOff.src = "./../images/en/blue/wiz_delete_off.gif";
DeleteDown = new Image();
DeleteDown.src = "./../images/en/blue/wiz_delete_dep_down.gif";
ReturnOver = new Image();
ReturnOver.src = "./../images/en/blue/wiz_return_dep_over.gif";
ReturnOff = new Image();
ReturnOff.src = "./../images/en/blue/wiz_return_off.gif";
ReturnDown = new Image();
ReturnDown.src = "./../images/en/blue/wiz_return_dep_down.gif";
RefreshOver = new Image();
RefreshOver.src = "./../images/en/blue/wiz_refresh_dep_over.gif";
RefreshOff = new Image();
RefreshOff.src = "./../images/en/blue/wiz_refresh_off.gif";
RefreshDown = new Image();
RefreshDown.src = "./../images/en/blue/wiz_refresh_dep_down.gif";
PreviewOver = new Image();
PreviewOver.src = "./../images/en/blue/wiz_preview_dep_over.gif";
PreviewOff = new Image();
PreviewOff.src = "./../images/en/blue/wiz_preview_off.gif";
PreviewDown = new Image();
PreviewDown.src = "./../images/en/blue/wiz_preview_dep_down.gif";

function initWizard(){
	initWizNavBtns();
	initPage();
}

function initPage(){
	setWizardFormRollover();
	setRowColours();
}

function initWizNavBtns(){
	var links = document.getElementsByName('link');

	for (var i=0; i<links.length; i++){
		if (!isNaN(Number(i))) {
			var aid = links[i].id;//document.anchors[i].id;
			var alen = aid.length;
			if (aid.search('link') > -1){
				if ('link'.match(aid.substr(alen-4, alen)) !=null){
					document.getElementById(aid).href='javascript:document.getElementById("wizForm").submit();';
					setWizLink(aid, aid.substring(0, alen-5));
				}
			}
		}
	}
}

function setWizLink(elementName, actionName){
	var ele = document.getElementById(elementName);
	setEventListener(ele, 'click', function(){setStrutsAction(actionName)} );
}

function setWizardFormRollover(){	
	var wizForm = document.getElementById('wizFormTable');
	if (wizForm!=null){
		var wizFormTRs = wizForm.getElementsByTagName('TR');
		for (var i=0; i<wizFormTRs.length; i++){
			var orgClass = wizFormTRs[i].className;
			setEventListener(wizFormTRs[i], 'mouseout', doMouseOut);
			setEventListener(wizFormTRs[i], 'mouseover', doMouseOver);
	
		} 
	}
}	

function setEventListener(ele, event, listenerFunction){
	if (ele.addEventListener){
		ele.addEventListener(event, listenerFunction, false);
	}
	else if (ele.attachEvent){
		ele.attachEvent('on'+event, listenerFunction);
		document.recalc();
	}
}
		
function doMouseOver(){
	var obj;
	if (this.className) {
		obj=this;
	}
	else if(doMouseOver.arguments && doMouseOver.arguments[0].srcElement){
		obj = doMouseOver.arguments[0].srcElement;
	}
	if (obj && obj.className.search('mouseover') == -1){
		obj.className +=' mouseover';
	}
}
	
function doMouseOut(){
	var obj;
	if (this.className) {obj=this;}
	else if(doMouseOut.arguments && doMouseOut.arguments[0].srcElement){
		obj = doMouseOut.arguments[0].srcElement;
	}
	
	if (obj){
		var index = obj.className.search('mouseover');
		if (index > -1){
			var newClass = obj.className.substr(0, index);
			newClass += obj.className.substr(index+9, obj.className.length)
			obj.className = newClass;
		}
	}
}	
	

function setStrutsAction(action){
	window.alert('action set to :'+action);
	document.getElementById('strutsDispatch').value = action;
}



function setRowColours(){
	var tbl = document.getElementById('wizListBody');
	if (tbl !=null && tbl.rows){
		var TRs = tbl.rows;
		for (i in TRs){
			if (i%2==0){
				TRs[i].className += ' editSelection';	
			}
			else {
				TRs[i].className += ' grayEditSelection';
			}
		}
	}
}





function toggleHidden(sectionName){
	var section = document.getElementById(sectionName);
	//var toggleBtn = document.getElementById("filterToggleButton");
	
	if (section.className=="hidden"){
		section.className="";
		//toggleBtn.src = "./resources/images/en/blue/Filter_dep_down.gif";
		//document.getElementById('filterHidden').value='false';
		
	}
	else{
		section.className="hidden";
		//toggleBtn.src = "./resources/images/en/blue/Filter_off.gif";
		//document.getElementById('filterHidden').value='true';
		
	}
}
	
function toggleDisabled(sectionName){
	var section = document.getElementById(sectionName);
	section.disabled = (section.disabled==true)?false:true;
}

