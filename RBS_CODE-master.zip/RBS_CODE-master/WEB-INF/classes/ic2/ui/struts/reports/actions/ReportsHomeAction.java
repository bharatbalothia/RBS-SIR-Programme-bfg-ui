/**
 * 
 */
package ic2.ui.struts.reports.actions;

import ic2.ui.struts.actions.IC2UIAction;
import ic2.ui.utils.ReportLoader;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * @author Ravi K Patel
 * created May 3, 2006
 */
@SuppressWarnings({"unchecked"})
public class ReportsHomeAction extends IC2UIAction {

	protected ActionForward unspecified(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return viewForm(mapping, form, request, response);
	}
	
	
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map reports = ReportLoader.getReports();
		request.setAttribute("reports", reports);
		return mapping.findForward("viewForm");
	}
	
}
