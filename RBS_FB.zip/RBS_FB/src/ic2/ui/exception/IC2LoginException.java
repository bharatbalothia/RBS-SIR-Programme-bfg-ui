/**
 * 
 */
package ic2.ui.exception;

/**
 * @author Matt Bradley
 * created Sept 4th, 2006
 */
public class IC2LoginException extends Exception {
	private static final long serialVersionUID = 1L;

	public IC2LoginException() {
		super();
	}

	public IC2LoginException(String message, Throwable cause) {
		super(message, cause);
	}

	public IC2LoginException(String message) {
		super(message);
	}

	public IC2LoginException(Throwable cause) {
		super(cause);
	}

}