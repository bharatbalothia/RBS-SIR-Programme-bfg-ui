package com.stercomm.customers.rbs.sct.ui;
interface SearchCriteria {
	
}
