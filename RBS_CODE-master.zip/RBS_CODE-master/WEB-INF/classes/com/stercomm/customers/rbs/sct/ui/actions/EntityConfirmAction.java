/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.stercomm.customers.rbs.sct.ui.change.ChangeControl;
import com.stercomm.customers.rbs.sct.ui.change.EntityChange;
import com.stercomm.customers.rbs.sct.ui.change.EntityCreateAction;
import com.stercomm.customers.rbs.sct.ui.change.EntityDeleteAction;
import com.stercomm.customers.rbs.sct.ui.change.EntityUpdateAction;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.forms.EntityForm;
import com.sterlingcommerce.woodstock.dmi.visibility.event.DmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.ExceptionLevel;
import com.sterlingcommerce.woodstock.event.InvalidEventException;
import com.sterlingcommerce.woodstock.util.Util;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class EntityConfirmAction extends BaseEntityWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(EntityConfirmAction.class);

	public ActionForward viewForm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		return mapping.findForward("viewForm");

	}

	public ActionForward finish(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		
		EntityForm entityForm = (EntityForm)form;
		Entity entity = getEntity(request);
		EntityChange ec = new EntityChange();

		try {
			entity.setChangerComments(entityForm.getChangerComments());
			entity.setChangeID(ec.getChangeID());
			
			if(entity.isCreateBean()){
				EntityCreateAction eca = new EntityCreateAction(entity);
				ec.setActionType(eca.getClass().getName());
				ec.setActionObject(eca.getObjectBytes());
				ec.setOperation(ChangeControl.OPERATION_CREATE);
			} else if(entity.isDeleteBean()){
				EntityDeleteAction eda = new EntityDeleteAction(entity);
				ec.setActionType(eda.getClass().getName());
				ec.setActionObject(eda.getObjectBytes());
				ec.setObjectKey(String.valueOf(entity.getEntityId()));
				ec.setOperation(ChangeControl.OPERATION_DELETE);
			} else {
				EntityUpdateAction eua = new EntityUpdateAction(entity);
				ec.setActionType(eua.getClass().getName());
				ec.setActionObject(eua.getObjectBytes());
				ec.setObjectKey(String.valueOf(entity.getEntityId()));
				ec.setOperation(ChangeControl.OPERATION_UPDATE);
			}
			ec.setChanger(this.getGisUsername(request));
			ec.setChangerNotes(entity.getChangerComments());
			ec.setResultType(entity.getClass().getName());
			ec.setResultObject(entity.getObjectBytes());
			ec.setResultMeta1(entity.getEntity());
			ec.setResultMeta2(entity.getService());

			ec.insert();
			
			 try
             {
                 DmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, Util.createGUID(), System.currentTimeMillis(), getGisUsername(request), ec.getShortType() + ": " + ec.getOperation(), "Change Requested", ec.getChangeID(), entity.getEntity());
             }
             catch(InvalidEventException e){
            	 log.error("Error firing the Change record Admin Audit event: " + e.getMessage());
             }


		}catch(Exception e){
			log.error("Error persisting the Change Control record: " + e.getMessage());
			e.printStackTrace();
			throw new Exception("The Entity could not be saved.");
			//return mapping.findForward("error");
		}
		
		return mapping.findForward("finish");

//		Entity entity = getEntity(request);
//		
//		if(entity.isDeleteBean()){
//			//change these values so we don't get DB constraint violations
//			entity.setDeleted(Boolean.TRUE);
//			entity.setService("DEL_" + entity.getEntityId() + "_" + entity.getService());
//			entity.setMailboxPathOut("DEL_" + entity.getEntityId() + "_" + entity.getMailboxPathOut());
//			entity.setMqQueueOut("DEL_" + entity.getEntityId() + "_" + entity.getMqQueueOut());
//		}
//
//		log.debug("**** MBX IN ****: " + entity.getMailboxPathIn());
//
//		EntityDAO dao = new EntityDAO(getHibernateSession());
//		dao.commit(entity, request);
//		log.debug("saved entity to DB");
//
//		if(!entity.isDeleteBean()){
//			boolean isBPError=false;
//
//			//fire the GPL UI BP
//			String service = entity.getService();
//			if(service!=null && service.equalsIgnoreCase("GPL")){
//
//				String bpRoutingName="SFG_GPL_Inbound";
//				String rrType="";
//				int requestTypeLength = entity.getInboundRequestType().length;
//				//entity.setInboundType("");
//
//				Properties props = Utils.getGISProperties("gpl");
//				if(props==null){
//					throw new Exception("Exception loading request type mappings");
//				}
//
//
//
//				for( int i=0; i < requestTypeLength; i++){
//
//					log.debug("Inbound RequestType Code: " + entity.getInboundRequestType()[i]);
//					rrType = props.getProperty("gpl.ui.rtm." + entity.getInboundRequestType()[i]);
//					if(rrType==null || rrType.equalsIgnoreCase("")){
//						rrType=entity.getInboundRequestType()[i].replaceAll(".", "");
//					}
//					log.debug("Inbound RequestType: " + rrType);
//
//					int entId = entity.getEntityId().intValue();
//					String inboundService = entity.getInboundService();
//					String RuleName = "GPL_" + entity.getEntity() + "_" + entity.getInboundRequestType()[i] + "_RR";
//					String RequestorDN = entity.getInboundRequestorDN();
//					String ResponderDN = entity.getInboundResponderDN();
//					String RequestType = rrType;
//					String CreateDirectory = entity.getInboundDir().toString();
//					String CreateRoutingRule = entity.getInboundRoutingRule().toString();
//					String SWIFTDirectory = createSWIFTDirectory(RequestorDN,ResponderDN);
//
//					MessageResources messageResources = getBPNames(request);
//					EntityBPDAOcreateDirectory bpDAO = new EntityBPDAOcreateDirectory(messageResources, getGisUsername(request));
//					if(Boolean.valueOf(CreateDirectory)==Boolean.TRUE || Boolean.valueOf(CreateRoutingRule)==Boolean.TRUE){
//						boolean runOK = bpDAO.runNow(entId, RuleName, RequestorDN, ResponderDN, inboundService, RequestType, CreateDirectory, CreateRoutingRule, SWIFTDirectory, "bpNames.rbs.sct.entity.createDirectory.gpl", bpRoutingName );
//						if(!runOK){
//							isBPError=true;
//						}
//					}
//				}
//
//			}
//
//
//			/*
//			 * ROI ONLY
//			 */
//			if(service!=null && service.equalsIgnoreCase("ROI")){
//
//				String[] rrType= new String[3];
//				String[] rrCode= new String[3];
//				String bpRoutingName="SFG_ROI_Inbound";
//
//				rrType[0]="pain.xxx.irishstd18.dat";
//				rrCode[0]="DAT";
//				rrType[1]="pain.xxx.irishstd18.rep";
//				rrCode[1]="REP";
//				//rrType[2]="pain.xxx.irishstd18.ack";
//				rrType[2]="pain.xxx.irishstd18.fac";
//				rrCode[2]="ACK";
//
//
//
//				for( int i=0; i < rrType.length; i++){
//
//					log.debug("Inbound RequestType: " + rrType[i]);
//					log.debug("Inbound RequestType Code: " + rrCode[i]);
//
//					int entId = entity.getEntityId().intValue();
//					String inboundService = entity.getInboundService();
//					String RuleName = "ROI_" + entity.getEntity() + "_" + rrCode[i] + "_RR";
//					String RequestorDN = entity.getInboundRequestorDN();
//					String ResponderDN = entity.getInboundResponderDN();
//					String RequestType = rrType[i];
//					String CreateDirectory = entity.getInboundDir().toString();
//					String CreateRoutingRule = entity.getInboundRoutingRule().toString();
//					String SWIFTDirectory = createSWIFTDirectory(RequestorDN,ResponderDN);
//
//					MessageResources messageResources = getBPNames(request);
//					EntityBPDAOcreateDirectory bpDAO = new EntityBPDAOcreateDirectory(messageResources, getGisUsername(request));
//					if(Boolean.valueOf(CreateDirectory)==Boolean.TRUE || Boolean.valueOf(CreateRoutingRule)==Boolean.TRUE){
//						//bpDAO.runNow(entId, RuleName, RequestorDN, ResponderDN, inboundService, RequestType, CreateDirectory, CreateRoutingRule, SWIFTDirectory, "bpNames.rbs.sct.entity.createDirectory.roi", bpRoutingName);
//						boolean runOK = bpDAO.runNow(entId, RuleName, RequestorDN, ResponderDN, inboundService, RequestType, CreateDirectory, CreateRoutingRule, SWIFTDirectory, "bpNames.rbs.sct.entity.createDirectory.roi", bpRoutingName);
//						if(!runOK){
//							isBPError=true;
//						}
//					}
//				}
//			}
//
//			if(isBPError){
//				throw new Exception("An error occuring running a UI business process. Check Current Processes on the Admin Console.");
//			}
//		}

		//return mapping.findForward("finish");
	}

//	private String createSWIFTDirectory(String reqDN, String respDN){
//
//		String swiftDir = readSWIFTDN(respDN) + "/" + readSWIFTDN(reqDN);
//		return swiftDir;
//	}
//
//	private String readSWIFTDN(String dn){
//
//		final String SWIFT_DN_END = ",o=swift";
//
//		String respstub = dn.substring(0, dn.indexOf( SWIFT_DN_END ));
//		String[] tok = respstub.split(",");
//
//		StringBuffer sb = new StringBuffer();
//		for(int i=tok.length-1;i>=0;i--){
//			String fld = tok[i].replaceAll("ou=", "").trim();
//			fld = fld.replaceAll("o=", "").trim();
//			fld = fld.replaceAll("cn=", "").trim();
//			if(!fld.equalsIgnoreCase("")){
//				sb.append(fld);
//				if(i>0){
//					sb.append("_");
//				}
//			}
//		}
//
//		return sb.toString();
//
//	}
}
