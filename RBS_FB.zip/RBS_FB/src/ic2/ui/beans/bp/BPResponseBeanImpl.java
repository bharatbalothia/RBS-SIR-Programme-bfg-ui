/**
 * 
 */
package ic2.ui.beans.bp;

import org.w3c.dom.Document;


/**
 * @author Ravi K Patel
 * created Apr 5, 2006
 */
public class BPResponseBeanImpl implements BPResponseBean {
	private static final long serialVersionUID=1L;
	
	private boolean success;
	private String errorCode;
	private String errorDescription;
	private Document responseDocument;
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorDescription() {
		return errorDescription;
	}
	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public Document getResponseDocument() {
		return responseDocument;
	}
	public void setResponseDocument(Document responseDocument) {
		this.responseDocument = responseDocument;
	}
	
	
}
