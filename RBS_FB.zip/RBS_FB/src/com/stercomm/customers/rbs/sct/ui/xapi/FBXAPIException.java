package com.stercomm.customers.rbs.sct.ui.xapi;

import com.yantra.yfc.util.YFCErrorDetails;
import com.yantra.yfc.util.YFCException;

public class FBXAPIException extends YFCException {

	 private static final long serialVersionUID = 1L;

	  public FBXAPIException(Exception ex)
	  {
	    super(ex);
	  }

	  public FBXAPIException(Exception ex, String errorCode)
	  {
	    super(ex, errorCode);
	  }

	  public FBXAPIException(String errorCode, String moreInfo)
	  {
	    super(errorCode, moreInfo);
	  }

	  public FBXAPIException(YFCErrorDetails details)
	  {
	    super(details);
	  }

	  public FBXAPIException(String errorCode)
	  {
	    super(errorCode);
	  }
	  
}
