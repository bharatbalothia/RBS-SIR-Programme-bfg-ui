/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dao;

import org.apache.log4j.Logger;
import org.apache.struts.util.MessageResources;
import org.hibernate.Session;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class BaseHibernateDAO extends BaseDAO{
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(BaseHibernateDAO.class);
	
	private Session hibernateSession;
	private String messageResourcesKey;
	
	
	/**
	 * @param hibSession
	 * @deprecated Use a Factory to create objects instead!
	 */
	public BaseHibernateDAO(Session hibSession) {
		this.hibernateSession = hibSession;
		//this.messageResourcesKey = messageResourcesKey;
	}
	
	public BaseHibernateDAO(Session hibSession, String messageResourcesKey) {
		this.hibernateSession = hibSession;
		this.messageResourcesKey = messageResourcesKey;
	}

	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}

	/**
	 * @return the hibernateSession
	 */
	protected Session getHibernateSession() {
		return hibernateSession;
	}

	/**
	 * @param hibSession the hibernateSession to set
	 */
	protected void setHibernateSession(Session hibSession) {
		this.hibernateSession = hibSession;
	}

	/**
	 * @return the messageResources
	 */
	public MessageResources getMessageResources() {
		MessageResources resources = MessageResources.getMessageResources(getMessageResourcesKey());
		return resources;
	}

	/**
	 * @return the messageResourcesKey
	 */
	public String getMessageResourcesKey() {
		return messageResourcesKey;
	}

	/**
	 * @param messageResourcesKey the messageResourcesKey to set
	 */
	public void setMessageResourcesKey(String messageResourcesKey) {
		this.messageResourcesKey = messageResourcesKey;
	}


	public String getMessage(String key){
		return getMessageResources().getMessage(key);
	}
	
	
}
