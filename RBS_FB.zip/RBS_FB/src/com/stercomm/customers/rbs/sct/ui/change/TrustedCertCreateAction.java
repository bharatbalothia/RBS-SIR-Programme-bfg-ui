package com.stercomm.customers.rbs.sct.ui.change;

import org.apache.log4j.Logger;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;
import com.sterlingcommerce.security.kcapi.CertificateInfoBase;
import com.sterlingcommerce.woodstock.xml.xslt.DOMUtil;

public class TrustedCertCreateAction extends TrustedCertAction implements ChangeAction {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(TrustedCertCreateAction.class);

	public TrustedCertCreateAction(TrustedCert tc){
		super(tc);
	}

	@Override
	public void commit() throws Exception {
		/* 
		 * create the cert using the XAPI
		 */
		log.debug("Committing the Trusted Cert create action");
		String userName="FBSystem";
		ChangeControl cc = new ChangeControl(tc.getChangeID());
		if(cc!=null){
			userName = cc.getChanger();
		}
		
		if(manageCertificate(createXAPI(userName))){
			log.debug("TrustedCert creation committed");
		} else {
			throw new Exception("The Trusted Certificate create action could not be committed");
		}
		//System.out.println("TRUSTED CERT: " + Utils.toXML(createXAPI()));
	}

	private Document createXAPI(String user) throws Exception{

		Document cDoc = DOMUtil.newDocument();
		Element cRoot = cDoc.createElement("Certificate");
		cRoot.setAttribute("Name", tc.getCertificateName());
		cRoot.setAttribute("Operation", "create");
		cRoot.setAttribute("Type", "Trusted");
		
		Element cCER = cDoc.createElement("CER");
		cCER.setAttribute("CertName", tc.getCertificateName());
		cCER.setAttribute("AuthChain", "true");
		cCER.setAttribute("Validity", "true");
		cCER.setAttribute("CrlCache", "true");
		cCER.setAttribute("UserName", user);
		CDATASection cdata = cDoc.createCDATASection(CertificateInfoBase.encodeToString(tc.getX509Certificate().getEncoded()));
		cCER.appendChild(cdata);
		cRoot.appendChild(cCER);
		cDoc.appendChild(cRoot);
		
		return cDoc;
	}
	
	

}
