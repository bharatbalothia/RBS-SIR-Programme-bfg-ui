package com.stercomm.customers.rbs.sct.ui;

import java.util.Date;

public interface MQTransferSearchCriteria extends SearchCriteria{

	
	
	public abstract String getCorrelationid();
	public abstract String getProducer();
	public abstract String getConsumer();
	public abstract String getFilename();
	public abstract String getTransferState();
	public abstract String getAlerted();
	public abstract Integer getDataflowid();
	public abstract Date getTodate();
	public abstract Date getFromdate();
	
	public abstract void setCorrelationid(String correlationid);
	public abstract void setProducer(String producer);
	public abstract void setConsumer(String consumer);
	public abstract void setFilename(String filename);
	public abstract void setTransferState(String transferstate);
	public abstract void setAlerted(String alerted);
	public abstract void setDataflowid(Integer dataflowid);
	public abstract void setTodate(Date todate);
	public abstract void setFromdate(Date fromdate);
	

}