/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.webapps.util.hibernate;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.util.ConfigHelper;

import com.sterlingcommerce.woodstock.util.frame.jdbc.JDBCConnectionException;
import com.sterlingcommerce.woodstock.util.frame.jdbc.JDBCService;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unused", "unchecked", "deprecation"})
public class HibernateUtils {

	private static final SessionFactory sessionFactory;
	private static final ThreadLocal<Session> threadSession = new ThreadLocal<Session>();
	//private static final ThreadLocal threadTransaction = new ThreadLocal();
	
	private static final Log log = LogFactory.getLog(HibernateUtils.class);
	
	private static Properties props = new Properties();
	static {
		try{
			
			URL url = ConfigHelper.findAsResource("WebAppBase.properties");
			System.out.println("*******URL******* : "+url);
			InputStream is = ConfigHelper.getResourceAsStream("WebAppBase.properties");
			props.load(is);
			//props.load(HibernateUtils.class.getResourceAsStream("WebAppBase.properties"));
		}
		catch (Exception e){
			throw new RuntimeException(e);
		}
		
		
		

		
	}
	private static final String GIS_JDBC_POOL = props.getProperty("webappGISPool");
	
	
	static {
		Configuration cfg = new Configuration();
		cfg = cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();

		sessionFactory = sf;
	}
	
	
	public static Session getSession(){ //i don't like this being static.....it doesn't look thread safe
		Session s = (Session)threadSession.get();
		try {
			if (s==null){
				synchronized (HibernateUtils.class) {
					s= sessionFactory.openSession(JDBCService.getConnection(GIS_JDBC_POOL));
					threadSession.set(s);
				}
				
			}
		}
		catch (HibernateException e){
			String msg = "Could not open Hibernate Session";
			log.fatal(msg, e);
			throw new RuntimeException(msg, e);
		}
		catch (JDBCConnectionException e){
			String msg = "Could not open Hibernate Session";
			log.fatal(msg, e);
			throw new RuntimeException(msg, e);
		}
		
		return s;
	}
	
	public static void closeSession(){
		try{
			Session s = (Session)threadSession.get();
			threadSession.set(null);
			if (s!=null && s.isOpen()){
				JDBCService.freeConnection(s.close());
				
			}
		}
		catch (HibernateException e){
			String msg = "Could not close Hibernate Session";
			log.fatal(msg, e);
			throw new RuntimeException(msg, e);
		}
	}
	
	
}

/**********************************************************************
*
* Revision History
* ================
*
* $Log: $
*/