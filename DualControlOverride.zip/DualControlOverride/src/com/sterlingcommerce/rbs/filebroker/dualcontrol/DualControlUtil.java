package com.sterlingcommerce.rbs.filebroker.dualcontrol;

import java.util.HashMap;

import javax.servlet.http.HttpSession;

import com.sterlingcommerce.woodstock.ui.EntityObject;
import com.sterlingcommerce.woodstock.ui.UIGlobals;
import com.sterlingcommerce.woodstock.ui.UserAutho;
import com.sterlingcommerce.woodstock.util.frame.lock.LockManager;

public class DualControlUtil {
	
	public final String DEFAULT_MESSAGE="Authorization for the change must be provided by an approver.";
	
	private String message;
	private boolean changerLocked=false;
	private boolean approverLocked=false;

	public String getMessage(boolean returnDefault) {
		if (message==null || message.equalsIgnoreCase("")){
			setMessage(DEFAULT_MESSAGE);
		}
		return getMessage();
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public DualControlUtil(){}

	public boolean isDualControlAuthorized(String dcPermission, String dcUser, String dcPass, 
			String dcCurrentUser, String dcCurrentUserPass, HttpSession session){

		boolean isAuthorized = false;
		UIGlobals.out.logDebug("isDualControlAuthorized(): Start");
	

		if (dcUser != null && dcUser.length() != 0 &&
				dcPass != null && dcPass.length() != 0 && 
				dcCurrentUserPass!=null && dcCurrentUserPass.length()!=0) {

			UIGlobals.out.logDebug("isDualControlAuthorized(): Approver User=" + dcUser );
			UIGlobals.out.logDebug("isDualControlAuthorized(): Changer User=" + dcCurrentUser );
			//authorize the user and check for DC
			EntityObject entityObj = null;
			UserAutho dcAuthoObj = null;
			

			boolean approverAuthenticated = false;
			boolean userValidated = false;

			try {
				entityObj  = new EntityObject();
				if(entityObj != null) {
					userValidated = entityObj.isAuthorized(dcCurrentUser, dcCurrentUserPass, false);
					approverAuthenticated = entityObj.isAuthorized(dcUser, dcPass, false);
				}							 

				if(dcCurrentUser.equalsIgnoreCase(dcUser)){
					UIGlobals.out.logDebug("isDualControlAuthorized(): Approver and changer are the same" );
					setMessage("You are not permitted to approve your own changes.");
				} else {
					if(approverAuthenticated){
						dcAuthoObj = entityObj.getEntityAutho(dcUser).theAutho;
						if (dcAuthoObj.hasPermission(dcPermission)) {
							if(!userValidated){
								//Bad changer credentials
								changerLocked = storeLoginFailures(dcCurrentUser, session, false);
								UIGlobals.out.logDebug("isDualControlAuthorized(): Wrong changer password" );
								setMessage("The current user's password was entered incorrectly.");
							} else {
								UIGlobals.out.logDebug("isDualControlAuthorized(): All authorized" );
								isAuthorized=true;
							}
						} else {
							UIGlobals.out.logDebug("isDualControlAuthorized(): Approver does not have the permission: " + dcPermission );
							setMessage("User does not have 'approver' permissions.");
						}
					} else {
						//Approver failed login
						approverLocked = storeLoginFailures(dcUser, session, true);
						UIGlobals.out.logDebug("isDualControlAuthorized(): Bad approver credentials" );
						if(approverLocked){
							setMessage("Incorrect 'approver' username and/or password. Account is now locked.");
						} else {
							setMessage("Incorrect 'approver' username and/or password");
						}
						
					}
				}


			} catch (Exception e) {
				// TODO Auto-generated catch block
				setMessage("Error validating approver");
				UIGlobals.out.logError("DUAL CONTROL: Error authorizing user: " + dcUser + " - " + e );
			}
		} 

		UIGlobals.out.logDebug("isDualControlAuthorized(): " + dcUser + " is authorized? "+ isAuthorized);
		return isAuthorized;
	}

//	copied and amended from Login Servlet
	@SuppressWarnings("unchecked")
	public boolean storeLoginFailures (String key, HttpSession session, boolean approver) {

		if ( UIGlobals.CONSEC_FAILED_ATTEMPTS > 0 ) {

			HashMap failedLogins = null;
			String sessionkey="DCC_sessionFailedLogins";
			if(approver){
				sessionkey="DCA_sessionFailedLogins";
			}


			if ( session.getAttribute(sessionkey) == null ) {
				failedLogins = new HashMap();
			} else {
				failedLogins = (HashMap)session.getAttribute(sessionkey);
			}

			Integer oInt = (Integer)failedLogins.get(key);
			if ( oInt != null ) {
				int i = oInt.intValue();
				i++;
				if (i == UIGlobals.CONSEC_FAILED_ATTEMPTS) {
					LockManager.lock( key, key, 30*60*1000 );
					return true;
				} else {
					failedLogins.put(key, new Integer(i));
				}
			} else {
				failedLogins.put(key, new Integer(1));
			}

			if (UIGlobals.out.debug) {
				Integer cnt = (Integer)failedLogins.get(key);
				UIGlobals.out.logDebug("[Login] "+key+" - number of failed login attempts  - "+cnt);
			}
			// updating the session with new number of failed login attempts
			session.setAttribute( sessionkey, failedLogins );
		}
		return false;
	}
	
	public String buildDualControlSection(HttpSession session){
		
		StringBuffer buf = new StringBuffer();
		 //**************************************************************************************************************
        //DUAL CONTROL USER ID/PASS BLOCK
        buf.append("<!--DUAL CONTROL BLOCK START -->");
        buf.append("<tr><td><br></td></tr>");
        buf.append("<tr><td colspan=\"5\">");
        buf.append("<table><tr><td valign=\"bottom\" class=\"WizardAccountsText\" colspan=\"5\"><img src='./images/blue/alert.gif' border=0 >&nbsp;Authorization</td></tr><tr>");
        buf.append("<tr><td valign=\"bottom\" class='whiteStripe' colspan=\"5\">A user with 'Account Change Approver' permissions must authorize the changes.</td></tr><tr>");
        buf.append("<td id='DUAL_CONTROL_USER_id' valign=\"bottom\" class=\"WizardInputText\">User ID:</td><td valign=\"bottom\" class=\"WizardInputData\"><input type=\"text\" name='DUAL_CONTROL_USER' value=\"\" size=12 maxlength=28 ></td>");
        buf.append("</tr><tr>");
        buf.append("<td id='DUAL_CONTROL_PASSWORD_id' valign=\"bottom\" class=\"WizardInputText\">Password:</td><td valign=\"bottom\" class=\"WizardInputData\"><input type=\"password\" name='DUAL_CONTROL_PASSWORD' value=\"\" size=14 maxlength=28 ></td>");
        buf.append("</tr>");
        
        //verify the currently logged in user
        buf.append("<tr><td><br></td></tr>");
        buf.append("<tr><td valign=\"bottom\" class=\"WizardAccountsText\" colspan=\"5\"><img src='./images/blue/alert.gif' border=0 >&nbsp;User Validation</td></tr>");
        buf.append("<tr><td valign=\"bottom\" class='whiteStripe' colspan=\"5\">The user making the changes must re-enter their password</td></tr>");
        buf.append("<tr><td id='DUAL_CONTROL_C_PASSWORD_id' valign=\"bottom\" class=\"WizardInputText\">Password:</td><td valign=\"bottom\" class=\"WizardInputData\"><input type=\"password\" name='DUAL_CONTROL_C_PASSWORD' value=\"\" size=14 maxlength=28 ></td></tr>");
        
        //hack: this shouldn't be here for MVC
        String msg = null;
        msg=(String)session.getAttribute("DUAL_CONTROL_MESSAGE");
        if(msg!=null && msg.length()>0){
        	buf.append("<tr><td colspan='5' align=\"left\" colspan=\"5\"><img src='./images/blue/error.gif' border=0  >&nbsp;" + msg + "</td></tr>");
        	session.setAttribute("DUAL_CONTROL_MESSAGE", "");
        }
        buf.append("</table>");
        buf.append("</td></tr>");
        buf.append("<!--DUAL CONTROL BLOCK END -->");
        //**************************************************************************************************************
        
		return buf.toString();
	}

	public boolean isApproverLocked() {
		return approverLocked;
	}

	public boolean isChangerLocked() {
		return changerLocked;
	}


}

