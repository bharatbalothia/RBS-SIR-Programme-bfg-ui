/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dtoimpl;

import java.util.Date;
import java.util.Set;

import org.apache.log4j.Logger;


import com.stercomm.customers.rbs.sct.ui.dto.Bundle;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.dto.WFInstS;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 * @hibernate.class table="SCT_BUNDLE"
 */
@SuppressWarnings({"unchecked", "unused"})
public class BundleImpl extends BaseHibernateBeanImpl implements Bundle, Comparable{
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(BundleImpl.class);
	
	private Long bundleId;
	private String filename;
	private String reference;
	private Date bTimestamp;
	private String bType;
	private Entity entity;
	private Integer status;
	private String error;
	private WFInstS wf;
	private Integer messageId;
	private Boolean outbound;
	private Boolean override;
	private String service;
	private String docId;
	
	private Set payments;
	
	public int getExecutionStatus() {
		int status = getStatus().intValue();
		if (status < 0){
			return Bundle.STATUS_ERROR;
		}
		if (status == 100 || status==200 || status==900){
			return Bundle.STATUS_GREEN;
		}
		if (status == 500){
			return Bundle.STATUS_AMBER;
		}
		else {
			return Bundle.STATUS_RUNNING;
		}
	}
	
	
	
	
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	/**
	 * @return the bTimestamp
	 * @hibernate.property column = "bTimestamp"
	 */
	public Date getBTimestamp() {
		return bTimestamp;
	}
	/**
	 * @param timestamp the bTimestamp to set
	 */
	public void setBTimestamp(Date timestamp) {
		bTimestamp = timestamp;
	}
	/**
	 * @return the bundleId
	 * @hibernate.id column = "bundle_Id" generator-class="sequence"
	 * @hibernate.generator-param name = "sequence" value = "SCT_BUNDLE_IDSEQ"
	 */
	public Long getBundleId() {
		return bundleId;
	}
	/**
	 * @param bundleId the bundleId to set
	 */
	public void setBundleId(Long bundleId) {
		this.bundleId = bundleId;
	}
	/**
	 * @return the entity
	 * @hibernate.many-to-one column = "entity_Id" class="com.stercomm.customers.rbs.sct.ui.dtoimpl.EntityImpl"
	 */
	public Entity getEntity() {
		return entity;
	}
	/**
	 * @param entityId the entity to set
	 */
	public void setEntity(Entity entity) {
		this.entity = entity;
	}
	/**
	 * @return the error
	 * @hibernate.property column = "error"
	 */
	public String getError() {
		return error;
	}
	/**
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}
	/**
	 * @return the filename
	 * @hibernate.property column = "filename"
	 */
	public String getFilename() {
		return filename;
	}
	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}
	/**
	 * @return the outbound
	 * @hibernate.property column = "isOutbound"
	 */
	public Boolean isOutbound() {
		return outbound;
	}
	/**
	 * @param isOutbound the outbound to set
	 */
	public void setOutbound(Boolean isOutbound) {
		this.outbound = isOutbound;
	}
	/**
	 * @return the override
	 * @hibernate.property column = "isOverride"
	 */
	public Boolean isOverride() {
		return override;
	}
	/**
	 * @param isOverride the isOverride to set
	 */
	public void setOverride(Boolean isOverride) {
		this.override = isOverride;
	}
	/**
	 * @return the messageId
	 * @hibernate.property column = "message_Id"
	 */
	public Integer getMessageId() {
		return messageId;
	}
	/**
	 * @param messageId the messageId to set
	 */
	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}
	/**
	 * @return the reference
	 * @hibernate.property column = "reference"
	 */
	public String getReference() {
		return reference;
	}
	/**
	 * @param reference the reference to set
	 */
	public void setReference(String reference) {
		this.reference = reference;
	}
	/**
	 * @return the status
	 * @hibernate.property column = "status"
	 */
	public Integer getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}
	/**
	 * @return the wf
	 * @hibernate.many-to-one column = "wf_Id" class="com.stercomm.customers.rbs.sct.ui.dtoimpl.WFInstSImpl"
	 */
	public WFInstS getWF() {
		return wf;
	}
	/**
	 * @param wf the wf to set
	 */
	public void setWF(WFInstS wf) {
		this.wf = wf;
	}
	
	
	
//	/**
//	 * @return the currentPayments
//	 * @hibernate.set
//	 * @hibernate.collection-one-to-many class = "com.stercomm.customers.rbs.sct.ui.dtoimpl.PaymentCurrentImpl"
//	 * @hibernate.collection-key column="BUNDLE_ID"
//	 */
//	public Set getCurrentPayments() {
//		return currentPayments;
//	}
//	/**
//	 * @param payments the payments to set
//	 */
//	public void setCurrentPayments(Set currentPayments) {
//		this.currentPayments = currentPayments;
//	}
	
//	/**
//	 * @return the archivePayments
//	 * @hibernate.set
//	 * @hibernate.collection-one-to-many class = "com.stercomm.customers.rbs.sct.ui.dtoimpl.PaymentArchiveImpl"
//	 * @hibernate.collection-key column="BUNDLE_ID"
//	 */
//	public Set getArchivePayments() {
//		return archivePayments;
//	}
//	/**
//	 * @param archivePayments the archivePayments to set
//	 */
//	public void setArchivePayments(Set archivePayments) {
//		this.archivePayments = archivePayments;
//	}
	
	/**
	 * @return the payments
	 * @hibernate.set lazy="true"
	 * @hibernate.collection-one-to-many class = "com.stercomm.customers.rbs.sct.ui.dtoimpl.PaymentImpl"
	 * @hibernate.collection-key column="BUNDLE_ID"
	 */
	public Set getPayments() {
		return payments;
	}
	
	/**
	 * @param payments the payments to set
	 */
	public void setPayments(Set payments) {
		this.payments = payments;
	}
	
	
	/**
	 * @return the bType
	 * @hibernate.property column = "BTYPE"
	 */
	public String getBType() {
		return bType;
	}
	/**
	 * @param type the bType to set
	 */
	public void setBType(String type) {
		bType = type;
	}
	
	public int compareTo(Object o) {
		if (!(o instanceof Bundle)){
			throw new ClassCastException("parameter object is not an instance of the Bundle interface. obj:"+o.toString());
		}
		Bundle other = (Bundle)o;
		return this.getBundleId().compareTo(other.getBundleId());
	}




	public String getDocId() {
		return docId;
	}




	public void setDocId(String docId) {
		this.docId = docId;
	}




	public String getService() {
		return service;
	}




	public void setService(String service) {
		this.service = service;
	}
	
}
