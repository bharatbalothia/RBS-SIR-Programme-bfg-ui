/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui;

import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;


import com.stercomm.customers.rbs.sct.ui.forms.TransactionSearchForm;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class TransactionSearchCriteriaFormAdapter implements PaymentSearchCriteria{

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger
			.getLogger(TransactionSearchCriteriaFormAdapter.class);
	
	private TransactionSearchForm tsf;

	public TransactionSearchCriteriaFormAdapter(TransactionSearchForm transactionSearchForm) {
		super();
		this.tsf = transactionSearchForm;
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#getDirection()
	 */
	public String getDirection() {
		return tsf.getDirection();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#getEntityId()
	 */
	public Integer getEntityId() {
		return tsf.getEntityId()==null||tsf.getEntityId().equals("ALL")?null:new Integer(tsf.getEntityId());
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#getReference()
	 */
	public String getReference() {
		return tsf.getReference();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#getService()
	 */
	public String getService() {
		return tsf.getService();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#getSettlementDateFrom()
	 */
	public Date getSettlementDateFrom() {
		if (tsf.getSettlementDateFrom()==null || tsf.getSettlementDateFrom().length()==0 ) {
					return null;
		}

		try {
			Date day = Utils.parseDate(tsf.getSettlementDateFrom(), "dd/MM/yyyy");
			
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(day);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			
			return cal.getTime();

		} catch (NumberFormatException e) {
			e.printStackTrace();
			log.error("Error parsing 'settlementDateFrom' in Transaction Search Form", e);
			throw new RuntimeException(e);
		}
		
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#getSettlementDateTo()
	 */
	public Date getSettlementDateTo() {
		if (tsf.getSettlementDateTo()==null || tsf.getSettlementDateTo().length()==0 ) {
			return null;
		}

		try {
			Date day = Utils.parseDate(tsf.getSettlementDateTo(), "dd/MM/yyyy");


			Calendar cal = Calendar.getInstance();
			cal.setTime(day);
			cal.set(Calendar.HOUR_OF_DAY, 23);
			cal.set(Calendar.MINUTE, 59);
			cal.set(Calendar.SECOND, 59);
			cal.set(Calendar.MILLISECOND, 999);

			return cal.getTime();

		} catch (NumberFormatException e) {
			e.printStackTrace();
			log.error("Error parsing 'settlementDateTo' in Transaction Search Form", e);
			throw new RuntimeException(e);
		}
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#getTransactionId()
	 */
	public String getTransactionId() {
		return tsf.getTransactionId();
	}
	//CHG_UI_IBM_RJ_010
	public String getPaymentBIC() {
		return tsf.getPaymentBIC();
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#getTransactionStatus()
	 */
	public String getTransactionStatus() {
		return tsf.getTransactionStatus();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#getType()
	 */
	public String getType() {
		return tsf.getType();
	}

	public String getDocId() {
		return tsf.getDocId();
	}
	
	public void setDocId(String docId) {
		tsf.setDocId(docId);
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#setDirection(java.lang.String)
	 */
	public void setDirection(String direction) {
		tsf.setDirection(direction);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#setEntityId(java.lang.Integer)
	 */
	public void setEntityId(Integer entityId) {
		tsf.setEntityId(entityId.toString());
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#setReference(java.lang.String)
	 */
	public void setReference(String reference) {
		tsf.setReference(reference);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#setService(java.lang.String)
	 */
	public void setService(String service) {
		tsf.setService(service);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#setSettlementDateFrom(java.util.Date)
	 */
	public void setSettlementDateFrom(Date settlementDateFrom) {
		tsf.setSettlementDateFrom(Utils.formatDate(settlementDateFrom, "dd/MM/yyyy"));
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#setSettlementDateTo(java.util.Date)
	 */
	public void setSettlementDateTo(Date settlementDateTo) {
		tsf.setSettlementDateTo(Utils.formatDate(settlementDateTo, "dd/MM/yyyy"));
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#setTransactionId(java.lang.String)
	 */
	public void setTransactionId(String transactionId) {
		tsf.setTransactionId(transactionId);
	}
	//CHG_UI_IBM_RJ_010
	public void setPaymentBIC(String paymentBIC) {
		tsf.setTransactionId(paymentBIC);
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#setTransactionStatus(java.lang.String)
	 */
	public void setTransactionStatus(String transactionStatus) {
		tsf.setTransactionStatus(transactionStatus);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria#setType(java.lang.String)
	 */
	public void setType(String type) {
		tsf.setType(type);
	}
	
	public void setMinDiff(String minDiff){
		tsf.setMinDiff(minDiff);
	}
	
	public String getMinDiff(){
		return tsf.getMinDiff();
	}
	
	
}
