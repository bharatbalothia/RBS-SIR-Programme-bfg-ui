package com.stercomm.customers.rbs.sct.ui.change;

//import org.apache.log4j.Logger;

import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;

public class TrustedCertUpdateAction extends TrustedCertAction implements ChangeAction {

	private static final long serialVersionUID = 1L;
	//private static final Logger log = Logger.getLogger(TrustedCertUpdateAction.class);
	
	public TrustedCertUpdateAction(TrustedCert tc){
		super(tc);
	}
	
	@Override
	public void commit() {
		throw new UnsupportedOperationException();
	}

}
