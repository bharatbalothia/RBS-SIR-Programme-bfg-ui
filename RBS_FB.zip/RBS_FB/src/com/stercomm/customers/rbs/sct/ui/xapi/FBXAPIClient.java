package com.stercomm.customers.rbs.sct.ui.xapi;

import java.rmi.RemoteException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.DOMException;

import com.sterlingcommerce.woodstock.xml.xslt.DOMUtil;
import com.sterlingcommerce.woodstock.ui.UIGlobals;
import com.yantra.interop.japi.YIFApi;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.interop.japi.YIFClientFactory;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSEnvironment;
import com.yantra.yfs.japi.YFSException;

/**
 * @author hli
 * 
 */
public class FBXAPIClient {
	
	private FBXAPIClient(){super();}

    public static Object invoke(YFSEnvironment env, String api, Object input, String userName)
    throws YIFClientCreationException, RemoteException, YFSException {
    	return invoke(env, api, input, userName, null);
    }
    public static Object invoke(YFSEnvironment env, String api, Object input)
    throws YIFClientCreationException, RemoteException, YFSException {
    	return invoke(env, api, input, "FBSystem", null);
    }
    private static Document toDocument(Object input) throws YFCException, FBXAPIException{
    	    if(input instanceof Document){
	            return (Document)input;
	        }else if(input instanceof Element){
	            // deep clone for now, but we should look into adding Element support...
	        	try {
	        	Document doc = DOMUtil.newDocument();
                doc.appendChild(doc.importNode((Element)input, true));
                return doc;
	        	} catch(DOMException e){ throw new YFCException(e); }  
	        }else{
	            throw new FBXAPIException("INTERNAL ERROR: Unsupported input type " + input.getClass().getName());
	        }
    	
    }

   	public static Object invoke(YFSEnvironment env, String api, Object input, String userName, Object template)
            throws YIFClientCreationException, RemoteException, YFSException {
   		
   		if (UIGlobals.out.debug) { 
   			UIGlobals.out.logDebug(api+" starts using local environement = "+(env==null));
   		}
   		Document doc = toDocument(input);
        if (UIGlobals.out.debug) { 
        	UIGlobals.out.logDebug("XAPI call:\n========== "+api+" ========== \n"+DOMUtil.getString(doc)+"\n================================\n");			
		}
        YIFApi yapi = getApi(null);
        YFSEnvironment localEnv = null;
        try{
        	if(env == null){
                Document envDoc = DOMUtil.newDocument();
                Element envElement = envDoc.createElement("YFSEnvironment");
                envElement.setAttribute("userId", userName);
                envElement.setAttribute("progId", "FILEBROKER");
                envDoc.appendChild(envElement);
                localEnv = yapi.createEnvironment(envDoc);
            }else{
            	localEnv = env;
            }
            addTemplate(localEnv, api, template);
            Document ret= yapi.invoke(localEnv, api, doc);
            if (UIGlobals.out.debug) { 
            	UIGlobals.out.logDebug("XAPI result:\n----------- "+api+" ---------- \n"+DOMUtil.getString(ret)+"\n----------------------------------\n");
			}
			return ret;
        }catch(DOMException e){ 
        	throw new YFCException(e); 
        }finally{
        	//If env is null then local was created here.
        	if(env == null){
        		yapi.releaseEnvironment(localEnv);
        	}
        	if (UIGlobals.out.debug) { UIGlobals.out.logDebug(api+" ends"); }
        }
    }
   	private static void addTemplate(YFSEnvironment env, String api, Object template){
        if(template!=null){
            if(template instanceof Document){
            	env.setApiTemplate(api, (Document)template);
            }else if(template instanceof String){
            	env.setApiTemplate(api, (String)template);
            }
        }
   	}

    /**
     * Get the YIFApi
     * 
     * @param protocol
     *            The optional protocol (EJB/HTTP/HTTPS/LOCAL)
     * @return The YIFApi
     */
    protected static YIFApi getApi(String protocol)
            throws YIFClientCreationException {
        if (protocol == null) {
            return YIFClientFactory.getInstance().getLocalApi();
        }
        return YIFClientFactory.getInstance().getApi(protocol);
    }

}
