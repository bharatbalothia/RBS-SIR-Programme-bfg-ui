/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   $Revision: $
 * Date/time:  $Date: $
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;


import com.stercomm.customers.rbs.sct.ui.forms.MQTransferSearchForm;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class MQTransferSearchCriteriaFormAdapter implements MQTransferSearchCriteria{

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger
	.getLogger(MQTransferSearchCriteriaFormAdapter.class);

	private static final String DATE_FORMAT = "dd/MM/yyyy";

	private MQTransferSearchForm fsf;


	public MQTransferSearchCriteriaFormAdapter(MQTransferSearchForm mqtSearchForm) {
		this.fsf = mqtSearchForm;
	}


	@Override
	public String getAlerted() {
		return String.valueOf(fsf.getAlerted());
	}



	@Override
	public String getConsumer() {
		String a = fsf.getConsumer();
		if (a==null || a.length()==0){
			return null;
		}
		return a;
	}



	@Override
	public String getCorrelationid() {
		String a = fsf.getCorrelationid();
		if (a==null || a.length()==0){
			return null;
		}
		return a;
	}



	@Override
	public Integer getDataflowid() {
		String a = fsf.getDataflowid();
		if (a==null || a.length()==0){
			return null;
		} else {
			return Integer.getInteger(a);
		}
	}



	@Override
	public String getFilename() {
		String a = fsf.getFilename();
		if (a==null || a.length()==0){
			return null;
		}
		return a;
	}



	@Override
	public String getProducer() {
		String a = fsf.getProducer();
		if (a==null || a.length()==0){
			return null;
		}
		return a;
	}



	@Override
	public String getTransferState() {
		String a = fsf.getTransferstate();
		if (a==null || a.length()==0){
			return null;
		}
		return a;
	}



	@Override
	public void setAlerted(String alerted) {
		fsf.setAlerted(alerted);
	}

	@Override
	public void setConsumer(String consumer) {
		fsf.setConsumer(consumer);

	}

	@Override
	public void setCorrelationid(String correlationid) {
		fsf.setCorrelationid(correlationid);

	}

	@Override
	public void setDataflowid(Integer dataflowid) {
		fsf.setDataflowid(Integer.toString(dataflowid));

	}


	@Override
	public void setProducer(String producer) {
		fsf.setProducer(producer);

	}

	@Override
	public void setTransferState(String transferstate) {
		fsf.setTransferstate(transferstate);

	}


	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getBpState()
	//	 */
	//	public String getTransferState() {
	//		String a = fsf.getTransferstate();
	//		if (a==null || a.length()==0){
	//			return null;
	//		}
	//		return a;
	//	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getDirection()
	//	 */
	//	public String getDirection() {
	//		String a =  fsf.getDirection();
	//		if (a==null || a.length()==0){
	//			return null;
	//		}
	//		return a;
	//	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getEntityId()
	//	 */
	//	public Integer getEntityId() {
	//		String eid = fsf.getEntityId();
	//		
	//		if (eid==null || eid.length()==0 || eid.equals("ALL") ||eid.equals("*")){
	//			return null;
	//		}
	//		
	//		return new Integer(eid);
	//	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getFilename()
	//	 */
	//	public String getFilename() {
	//		String a =  fsf.getFilename();
	//		if (a==null || a.length()==0){
	//			return null;
	//		}
	//		return a;
	//	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getFileStatus()
	//	 */
	//	public String getFileStatus() {
	//		String a =  fsf.getFileStatus();
	//		if (a==null || a.length()==0){
	//			return null;
	//		}
	//		return a;
	//	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getFromDate()
	 */
	public Date getFromdate(){
		if (fsf.getFromDate()==null || fsf.getFromDate().length()==0
				||fsf.getFromHr()==null || fsf.getFromHr().length()==0
				||fsf.getFromMin()==null || fsf.getFromMin().length()==0 )
		{
			return null;
		}

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date day = sdf.parse(fsf.getFromDate());
			Calendar cal = Calendar.getInstance();
			cal.setTime(day);
			cal.set(Calendar.HOUR, Integer.parseInt(fsf.getFromHr()));
			cal.set(Calendar.MINUTE, Integer.parseInt(fsf.getFromMin()));
			cal.set(Calendar.AM_PM, fsf.getFromMeridiem().equals("AM")?Calendar.AM:Calendar.PM);

			return cal.getTime();


		} catch (NumberFormatException e) {
			e.printStackTrace();
			log.error("Error parsing 'from date' in File Search Form", e);
			throw new RuntimeException(e);
		} catch (ParseException e) {
			e.printStackTrace();
			log.error("Error parsing 'from date' in File Search Form", e);
			throw new RuntimeException(e);
		}

	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getReference()
	//	 */
	//	public String getReference() {
	//		String a =  fsf.getReference();
	//		if (a==null || a.length()==0){
	//			return null;
	//		}
	//		return a;
	//	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getService()
	//	 */
	//	public String getService() {
	//		String a = fsf.getService();
	//		if (a==null || a.length()==0){
	//			return null;
	//		}
	//		return a;
	//	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getToDate()
	 */
	public Date getTodate() {

		if (fsf.getToDate()==null || fsf.getToDate().length()==0
				||fsf.getToHr()==null || fsf.getToHr().length()==0
				||fsf.getToMin()==null || fsf.getToMin().length()==0 )
		{
			return null;
		}


		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date day = sdf.parse(fsf.getToDate());
			Calendar cal = Calendar.getInstance();
			cal.setTime(day);
			cal.set(Calendar.HOUR, Integer.parseInt(fsf.getToHr()));
			cal.set(Calendar.MINUTE, Integer.parseInt(fsf.getToMin()));
			cal.set(Calendar.AM_PM, fsf.getToMeridiem().equals("AM")?Calendar.AM:Calendar.PM);

			return cal.getTime();

		} catch (NumberFormatException e) {
			e.printStackTrace();
			log.error("Error parsing 'to date' in File Search Form", e);
			throw new RuntimeException(e);
		} catch (ParseException e) {
			e.printStackTrace();
			log.error("Error parsing 'to date' in File Search Form", e);
			throw new RuntimeException(e);
		}
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#getType()
	 */
	//	public String getType() {
	//		String a =  fsf.getType();
	//		if (a==null || a.length()==0){
	//			return null;
	//		}
	//		return a;
	//	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setBpState(java.lang.String)
	//	 */
	//	public void setBpState(String bpState) {
	//		fsf.setBpState(bpState);
	//		
	//	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setDirection(java.lang.String)
	//	 */
	//	public void setDirection(String direction) {
	//		fsf.setDirection(direction);		
	//	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setEntityId(java.lang.Integer)
	//	 */
	//	public void setEntityId(Integer entityId) {
	//		fsf.setEntityId(entityId==null?"ALL":entityId.toString());
	//	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setFilename(java.lang.String)
	 */
	public void setFilename(String filename) {
		fsf.setFilename(filename);

	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setFileStatus(java.lang.String)
	//	 */
	//	public void setFileStatus(String fileStatus) {
	//		fsf.setFileStatus(fileStatus);
	//		
	//	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setFromDate(java.util.Date)
	 */
	public void setFromdate(Date fromDate) {
		if (fromDate==null){
			fsf.setFromDate("");
			fsf.setFromHr("");
			fsf.setFromMin("");
			fsf.setFromMeridiem("");
			return;
		}

		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		String day = sdf.format(fromDate);

		fsf.setFromDate(day);

		Calendar cal = Calendar.getInstance();
		cal.setTime(fromDate);

		fsf.setFromHr(Integer.toString(cal.get(Calendar.HOUR)));
		fsf.setFromMin(Integer.toString(cal.get(Calendar.MINUTE)));

		fsf.setFromMeridiem(cal.get(Calendar.AM_PM)==Calendar.AM?"AM":"PM");

	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setReference(java.lang.String)
	//	 */
	//	public void setReference(String reference) {
	//		fsf.setReference(reference);
	//		
	//	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setService(java.lang.String)
	//	 */
	//	public void setService(String service) {
	//		fsf.setService(service);
	//		
	//	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setToDate(java.util.Date)
	 */
	public void setTodate(Date toDate) {
		if (toDate==null){
			fsf.setToDate("");
			fsf.setToHr("");
			fsf.setToMin("");
			fsf.setToMeridiem("");
			return;
		}


		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		String day = sdf.format(toDate);

		fsf.setToDate(day);

		Calendar cal = Calendar.getInstance();
		cal.setTime(toDate);

		fsf.setToHr(Integer.toString(cal.get(Calendar.HOUR)));
		fsf.setToMin(Integer.toString(cal.get(Calendar.MINUTE)));

		fsf.setToMeridiem(cal.get(Calendar.AM_PM)==Calendar.AM?"AM":"PM");



	}
	//	/* (non-Javadoc)
	//	 * @see com.stercomm.customers.rbs.sct.ui.FileSearchCriteria#setType(java.lang.String)
	//	 */
	//	public void setType(String type) {
	//		fsf.setType(type);
	//	}
	//	
	//	public void setMinDiff(String minDiff){
	//		fsf.setMinDiff(minDiff);
	//	}
	//	
	//	public String getMinDiff(){
	//		return fsf.getMinDiff();
	//	}

}
