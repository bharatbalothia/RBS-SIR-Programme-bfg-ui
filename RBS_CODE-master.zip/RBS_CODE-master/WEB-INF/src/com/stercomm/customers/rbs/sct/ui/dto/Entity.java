/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dto;

import java.io.IOException;
import java.util.List;


/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unchecked"})
public interface Entity extends BaseHibernateBean {
	/**
	 * @return the compression
	 */
	public Boolean getCompression();
	
	/**
	 * @param compression the compression to set
	 */
	public void setCompression(Boolean compression);
	
	/**
	 * @return the deliveryNotification
	 */
	public Boolean getDeliveryNotification();
	
	/**
	 * @param deliveryNotif the deliveryNotif to set
	 */
	public void setDeliveryNotification(Boolean deliveryNotifification);
	
	/**
	 * @return the deliveryNotifDN
	 */
	public String getDeliveryNotifDN() ;
	
	/**
	 * @param deliveryNotifDN the deliveryNotifDN to set
	 */
	public void setDeliveryNotifDN(String deliveryNotifDN);
	
	/**
	 * @return the deliveryNotifRT
	 */
	public String getDeliveryNotifRT() ;
	
	/**
	 * @param deliveryNotifRT the deliveryNotifRT to set
	 */
	public void setDeliveryNotifRT(String deliveryNotifRT) ;
	
	/**
	 * @return the endOfDay
	 */
	public Integer getEndOfDay() ;
	
	/**
	 * @param endOfDay the endOfDay to set
	 */
	public void setEndOfDay(Integer endOfDay) ;
	
	/**
	 * @return the entity
	 */
	public String getEntity() ;
	
	/**
	 * @param entity the entity to set
	 */
	public void setEntity(String entity);
	
	/**
	 * @return the entityId
	 */
	public Integer getEntityId() ;
	
	/**
	 * @param entityId the entityId to set
	 */
	public void setEntityId(Integer entityId);
	
	/**
	 * @return the fileDesc
	 */
	public String getFileDesc();
	
	/**
	 * @param fileDesc the fileDesc to set
	 */
	public void setFileDesc(String fileDesc);
	
	/**
	 * @return the fileInfo
	 */
	public String getFileInfo();
	
	/**
	 * @param fileInfo the fileInfo to set
	 */
	public void setFileInfo(String fileInfo);
	
	/**
	 * @return the mailboxPathIn
	 */
	public String getMailboxPathIn();
	
	/**
	 * @param mailboxPathIn the mailboxPathIn to set
	 */
	public void setMailboxPathIn(String mailboxPathIn);
	
	/**
	 * @return the mailboxPathOut
	 */
	public String getMailboxPathOut();
	
	/**
	 * @param mailboxPathOut the mailboxPathOut to set
	 */
	public void setMailboxPathOut(String mailboxPathOut) ;
	
	/**
	 * @return the maxBulksPerFile
	 */
	public Integer getMaxBulksPerFile() ;
	
	/**
	 * @param maxBulksPerFile the maxBulksPerFile to set
	 */
	public void setMaxBulksPerFile(Integer maxBulksPerFile) ;
	
	/**
	 * @return the maxTransfersPerBulk
	 */
	public Integer getMaxTransfersPerBulk() ;
	
	/**
	 * @param maxTransfersPerBulk the maxTransfersPerBulk to set
	 */
	public void setMaxTransfersPerBulk(Integer maxTransfersPerBulk);
	
	/**
	 * @return the mqQueueIn
	 */
	public String getMqQueueIn() ;
	
	/**
	 * @param mqQueueIn the mqQueueIn to set
	 */
	public void setMqQueueIn(String mqQueueIn);
	
	/**
	 * @return the mqQueueOut
	 */
	public String getMqQueueOut();
	
	/**
	 * @param mqQueueOut the mqQueueOut to set
	 */
	public void setMqQueueOut(String mqQueueOut);
	
	/**
	 * @return the requestorDN
	 */
	public String getRequestorDN();
	
	/**
	 * @param requesterDN the requestorDN to set
	 */
	public void setRequestorDN(String requestorDN);
	
	/**
	 * @return the requestRef
	 */
	public String getRequestRef();
	
	/**
	 * @param requestRef the requestRef to set
	 */
	public void setRequestRef(String requestRef);
	
	/**
	 * @return the requestType
	 */
	public String getRequestType();
	
	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) ;
	
	/**
	 * @return the responderDN
	 */
	public String getResponderDN() ;
	
	/**
	 * @param responderDN the responderDN to set
	 */
	public void setResponderDN(String responderDN) ;
	
	/**
	 * @return the service
	 */
	public String getService() ;
	
	/**
	 * @param service the service to set
	 */
	public void setService(String service) ;
	
	/**
	 * @return the serviceName
	 */
	public String getServiceName() ;
	
	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) ;
	
	/**
	 * @return the snf
	 */
	public Boolean getSnF() ;
	
	/**
	 * @param sfn the snf to set
	 */
	public void setSnF(Boolean SnF) ;
	
	/**
	 * @return the startOfDay
	 */
	public Integer getStartOfDay() ;
	
	/**
	 * @param startOfDay the startOfDay to set
	 */
	public void setStartOfDay(Integer startOfDay) ;
	
	/**
	 * @return the trace
	 */
	public Boolean getTrace() ;
	
	/**
	 * @param trace the trace to set
	 */
	public void setTrace(Boolean trace) ;
	
	
	/**
	 * @return the transferDesc
	 */
	public String getTransferDesc();
	
	/**
	 * @param transferDesc the transferDesc to set
	 */
	public void setTransferDesc(String transferDesc) ;
	
	/**
	 * @return the transferInfo
	 */
	public String getTransferInfo() ; 
	
	/**
	 * @param transferInfo the transferInfo to set
	 */
	public void setTransferInfo(String transferInfo);
	
	public List getSchedules();
	public void setSchedules(List schedules);

	public List getDeletedSchedules();
	public void setDeletedSchedules(List schedules);
	
	public String getCdfWTOMsgId();
	
	public void setCdfWTOMsgId(String cdfWTOMsgId);
	
	public String getCdNode();
	
	public void setCdNode(String cdNode);
	
	public String getDnfWTOMsgId();
	
	public void setDnfWTOMsgId(String dnfWTOMsgId);
	
	public String getDrrWTOMsgId();
	
	public void setDrrWTOMsgId(String drrWTOMsgId);
	
	public String getDvfWTOMsgId();
	
	public void setDvfWTOMsgId(String dvfWTOMsgId);
	
	public String getIdfWTOMsgId();
	
	public void setIdfWTOMsgId(String idfWTOMsgId);
	
	public String getMsrWTOMsgId();
	
	public void setMsrWTOMsgId(String msrWTOMsgId);
	
	public String getPsrWTOMsgId();
	
	public void setPsrWTOMsgId(String psrWTOMsgId);
	
	public String getRsfWTOMsgId();
	
	public void setRsfWTOMsgId(String rsfWTOMsgId);
	
	public String getSdfWTOMsgId();
	
	public void setSdfWTOMsgId(String sdfWTOMsgId);
	
	public String getRtfWTOMsgId();
	
	public void setRtfWTOMsgId(String rtfWTOMsgId);
	
	public String getMbpWTOMsgId();
	
	public void setMbpWTOMsgId(String mbpWTOMsgId);

	
	public void setMqHost(String mqHost);
	public void setMqPort(Integer mqPort);
	public void setMqQManager(String mqQManager);
	public void setMqChannel(String mqChannel);
	public void setMqQueueName(String mqQueueName);
	public void setMqQueueBinding(String mqQueueBinding);
	public void setMqQueueContext(String mqQueueContext);
	public void setMqDebug(Integer mqDebug);
	public void setMqSSLoptions(String mqSSLoptions);
	public void setMqSSLciphers(String mqSSLciphers);
	public void setMqSSLkey(String mqSSLkey);
	public void setMqSSLcaCert(String mqSSLcaCert);
	
	public String getMqHost();
	public Integer getMqPort();
	public String getMqQManager();
	public String getMqChannel();
	public String getMqQueueName();
	public String getMqQueueBinding();
	public String getMqQueueContext();
	public Integer getMqDebug();
	public String getMqSSLoptions();
	public String getMqSSLciphers();
	public String getMqSSLkey();
	public String getMqSSLcaCert();
	
	public Boolean getRouteInbound();
	public Boolean getRouteOutbound();
	public Boolean getInboundDir();
	public Boolean getInboundRoutingRule();
	public String getInboundRequestorDN();
	public String getInboundResponderDN();
	public String getInboundService();
	public String getInboundType();
	public String[] getInboundRequestType();
	public Boolean getNonRepudiation();
	public Boolean getPauseInbound();
	public Boolean getPauseOutbound();
	public Boolean getDeleted();
	
	public void setRouteInbound(Boolean routeInbound);
	public void setRouteOutbound(Boolean routeOutbound);
	public void setInboundDir(Boolean inboundDir);
	public void setInboundRoutingRule(Boolean inboundRoutingRule);
	public void setInboundRequestorDN(String inboundRequestorDN);
	public void setInboundResponderDN(String inboundResponderDN);
	public void setInboundService(String inboundService);
	public void setInboundType(String inboundType);
	public void setInboundRequestType(String[] inboundRequestType);
	public void setNonRepudiation(Boolean nonRepudiation);
	public void setPauseInbound(Boolean pauseInbound);
	public void setPauseOutbound(Boolean pauseOutbound);
	public void setDeleted(Boolean deleted);
	
	public Boolean getIrishStep2();
	public void setIrishStep2(Boolean irishStep2);
	public boolean isIrishStep2();
	
	//for Onboarding CR
	public String getChangeID();
	public void setChangeID(String changeID);
	public byte[] getObjectBytes() throws IOException;
	public String getChangerComments();
	public void setChangerComments(String changerComments);
	
	public String getE2eSigning();
	public void setE2eSigning(String e2eSigning);
	
}
