/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.MessageResources;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.stercomm.customers.rbs.sct.ui.forms.HSMPasswordForm;
import com.stercomm.customers.rbs.sct.ui.xapi.FBXAPIClient;
import com.sterlingcommerce.woodstock.dmi.visibility.event.AFCDmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.ExceptionLevel;
import com.sterlingcommerce.woodstock.util.BaseUtil;
import com.sterlingcommerce.woodstock.util.NameValue;
import com.sterlingcommerce.woodstock.util.NameValuePairs;
import com.sterlingcommerce.woodstock.xml.xslt.DOMUtil;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSException;

/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
public class HSMPasswordAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(HSMPasswordAction.class);
	
	private static final String DEFAULT_PASSWORD = "DEF_PASS";

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		HSMPasswordForm hpf = (HSMPasswordForm)form;
		hpf.setPassword1(DEFAULT_PASSWORD);
		hpf.setPassword2(DEFAULT_PASSWORD);
		hpf.setEnabled(true);
		return super.viewForm(mapping, form, request, response);
	}

	public ActionForward update(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		ActionMessages messages = new ActionMessages();

		@SuppressWarnings("unused")
		MessageResources messageResources = getResources(request);

		try{
			HSMPasswordForm hpf = (HSMPasswordForm)form;
			String p1 = hpf.getPassword1();
			String p2 = hpf.getPassword2();

			if(p1.equalsIgnoreCase(DEFAULT_PASSWORD)){
				p1=null;
			}
			if(p2.equalsIgnoreCase(DEFAULT_PASSWORD)){
				p2=null;
			}

			//System.out.println("Enabled: " + hpf.isEnabled());

			if(updateHSMPasswords(p1,p2,hpf.isEnabled())==false){
				throw new Exception("Error updating the HSM Partition Passwords");
			} else {
				AFCDmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, BaseUtil.createGUID(), System.currentTimeMillis(), getGisUsername(request), "HSM Partition Password update", "Service / Adapter", "FB_LunaHSMTokenManager", "******");
			}

			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.hsmpassword.success" ));
			saveMessages(request, messages);
		}catch (Exception e){
			ActionErrors errors = new ActionErrors();
			errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("setup.msgs.hsmpassword.error"));
			saveErrors(request, errors);		
		}
		//System.out.println("HSM UPDATE HERE");


		return mapping.findForward("success");
	}

	public boolean updateHSMPasswords(String password1, String password2, boolean active){

		boolean ret1 = false;
		boolean ret2 = false;
		ret1 = updateLunaHSMTokenService("FB_LunaHSMTokenManager_Node1", password1, password2, active);
		ret2 = updateLunaHSMTokenService("FB_LunaHSMTokenManager_Node2", password1, password2, active);

		if(ret1 && ret2){
			return true;
		} else {
			return false;
		}

	}

	public boolean updateLunaHSMTokenService(String serviceName, String password1, String password2, boolean active){

		boolean ret=false;
		Element ele = null;
		NodeList parmList = null;
		HashMap<String, String> parms = new HashMap<String, String>();

		String description=null;
		String displayName=null;
		String targetEnv= null;
		String serviceGroupName=null;
		
		Document doc = getServiceInstance(serviceName);
		//System.out.println(toXML(doc));

		if (doc != null) {
			ele = doc.getDocumentElement();

			if ((ele.hasChildNodes()) && (ele.getTagName().equalsIgnoreCase("ServiceInstance"))) {
				
				description = ele.getAttribute("Description");
				displayName = ele.getAttribute("DisplayName");
				targetEnv = ele.getAttribute("TargetEnv");
				serviceGroupName = ele.getAttribute("ServiceGroupName");
				
				//System.out.println("DisplayName: " + displayName);
				
				Element child = (Element)ele.getChildNodes().item(0);
				parmList = child.getChildNodes();
				String name=null;
				String value=null;
				Element parmEle = null;
				for (int index = 0; index < parmList.getLength(); index++) {
					parmEle = (Element)parmList.item(index);
					name = parmEle.getAttribute("Name");
					value = parmEle.getAttribute("Value");
					parms.put(name, value);
					//System.out.println("PARMS: " + name+ "=" + value);
				}
				
				Document cDoc = DOMUtil.newDocument();
                Element cRoot = cDoc.createElement("ServiceInstance");
                cRoot.setAttribute("Description", description);
                cRoot.setAttribute("DisplayName", displayName);
                cRoot.setAttribute("TargetEnv", targetEnv);
                cRoot.setAttribute("Active", String.valueOf(active));
                cRoot.setAttribute("SystemService", "false");
                cRoot.setAttribute("ServiceGroupName", serviceGroupName);
                cRoot.setAttribute("ServiceName", serviceName);
                
                Element cParms = cDoc.createElement("ParmList");
                Element cSlot = cDoc.createElement("Parm");
                cSlot.setAttribute("Name", "Slot");
                cSlot.setAttribute("Value", (String)parms.get("Slot"));
                cParms.appendChild(cSlot);
                Element cWait = cDoc.createElement("Parm");
                cWait.setAttribute("Name", "WaitTime");
                cWait.setAttribute("Value", (String)parms.get("WaitTime"));
                cParms.appendChild(cWait);
                Element cTP1 = cDoc.createElement("Parm");
                cTP1.setAttribute("Name", "TokenPass");
                if(password1==null){
                	cTP1.setAttribute("Value", (String)parms.get("TokenPass"));
                } else {
                	cTP1.setAttribute("Value", password1);
                }
                cParms.appendChild(cTP1);
                Element cTP2 = cDoc.createElement("Parm");
                cTP2.setAttribute("Name", "TokenPass2");
                if(password2==null){
                	cTP2.setAttribute("Value", (String)parms.get("TokenPass2"));
                } else {
                	cTP2.setAttribute("Value", password2);
                }
                cParms.appendChild(cTP2);
                cRoot.appendChild(cParms);
                cDoc.appendChild(cRoot);
                //System.out.println(toXML(cDoc));
                //ret=true;
				ret=changeServiceInstance(serviceName, cDoc);
				
				
			}

			
		}
		return ret;

	}

	private Document invokeXAPI(String action, String root, NameValuePairs nvpAttrs)
	throws YFCException
	{
		Document result = null;
		try
		{
			Document doc = DOMUtil.newDocument(root);
			Element ele = doc.getDocumentElement();

			NameValue nv = null;
			for (int index = 0; index < nvpAttrs.numEntries(); index++) {
				nv = nvpAttrs.getElement(index);
				ele.setAttribute(nv.getName(), (String)nv.getValue());
			}

			result = (Document)FBXAPIClient.invoke(null, action, doc);

		} catch (RemoteException e) {
			throw new YFCException(e);
		} catch (YFSException e) {
			throw new YFCException(e);
		} catch (YIFClientCreationException e) {
			throw new YFCException(e);
		}
		return result;
	}
	
	private Document invokeXAPI(String action, Document doc)
	throws YFCException
	{
		Document result = null;
		try
		{
			result = (Document)FBXAPIClient.invoke(null, action, doc);

		} catch (RemoteException e) {
			throw new YFCException(e);
		} catch (YFSException e) {
			throw new YFCException(e);
		} catch (YIFClientCreationException e) {
			throw new YFCException(e);
		}
		return result;
	}


	public Document getServiceInstance(String serviceName)
	throws YFCException
	{
		Document doc = null;
		try
		{
			//this.nodeId = (InetAddress.getLocalHost().getHostName() + ":" + new UIDWrapper());

			NameValuePairs nvp = new NameValuePairs();
			nvp.addElement("ServiceName", serviceName);

			doc = invokeXAPI("getServiceInstanceDetails", "ServiceInstance", nvp);

		} catch (YFCException ye) {
			log.error("[HSMPasswordAction].getServiceInstance() XAPI exception ", ye);
			throw ye;
		}
		return doc;
	}

	public boolean changeServiceInstance(String serviceName, Document doc)
	throws YFCException
	{
		boolean changed = false;
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("changeServiceInstance", doc);
			//System.out.println(rdoc.getDocumentElement().getTagName());
			if ((rdoc != null) && (rdoc.getDocumentElement().getTagName().equalsIgnoreCase("ChangeServiceInstance"))){
				changed=true;
			} 
		} catch (YFCException ye) {
			log.error("[HSMPasswordAction].changeServiceInstance() XAPI exception ", ye);
			throw ye;
		}
		return changed;
	}

	public String toXML(Document doc){
		log.debug("generating xml string org.w3c.dom.Docment");
		//doc.normalize();

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		OutputFormat format = new OutputFormat(doc);
		XMLSerializer output = new XMLSerializer(outputStream, format);
		try {
			output.serialize(doc);
		} catch (IOException e) {
			log.fatal("IOException while serializing Document", e);
			throw new RuntimeException(e);
		}
		String out = outputStream.toString();
		log.debug("xml string generated successfully");

		return out;
	}
}
