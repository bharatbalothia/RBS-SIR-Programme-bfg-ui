package com.stercomm.customers.rbs.sct.ui.fileauth;

import java.util.Date;

public class FileAuthRow {

	private String fileAuthID;
	private String fileName;
	private String action;
	private String status;
	private Date created;
	
	public FileAuthRow(){
		
	}
	
	public String getFileAuthID() {
		return fileAuthID;
	}
	public void setFileAuthID(String fileAuthID) {
		this.fileAuthID = fileAuthID;
	}
	public void setFileAuthID(int fileAuthID) {
		setFileAuthID(String.valueOf(fileAuthID));
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setStatus(int status) {
		setStatus(FileAuth.validateStatus(status));
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	
	
	
}
