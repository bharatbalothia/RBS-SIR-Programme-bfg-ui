/**
 * 
 */
package ic2.ui.db;

import ic2.ui.beans.reports.ReportColumn;
import ic2.ui.beans.reports.ReportDataBean;
import ic2.ui.beans.reports.ReportRunnerBean;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;



/**
 * @author Ravi K Patel
 * created May 4, 2006
 */
public class ReportsDBUtils extends DBUtils {
	private static final Logger logger = Logger.getLogger(ReportsDBUtils.class);
	
	@SuppressWarnings("unchecked")
	public ReportDataBean getReport(ReportRunnerBean reportRunnerBean,  HttpServletRequest request) throws SQLException{
		ReportDataBean reportBean = new ReportDataBean();
		Connection connection = getConnection(request);
		
		
		
		PreparedStatement pstmnt = connection.prepareStatement(reportRunnerBean.getReportSettings().getSql());
		
		if(reportRunnerBean.getReportStartDate()!=null){
			pstmnt.setString(1, reportRunnerBean.getReportStartDate());
		}
		if(reportRunnerBean.getReportEndDate()!=null){
			pstmnt.setString(2, reportRunnerBean.getReportEndDate());
		}
		
		pstmnt.execute();
		
		ResultSet rset = pstmnt.getResultSet();
		int colCount = rset.getMetaData().getColumnCount();
		//List[] data = new List[colCount];
		//ReportColumn[] columns = new ReportColumn[colCount];
		List<ReportColumn> columns = new ArrayList<ReportColumn>();
		reportBean.setReportColumns(columns);
		for (int i=0; i<colCount; i++){
			ReportColumn col = new ReportColumn();
			col.setTitle(rset.getMetaData().getColumnLabel(i+1));
			col.setData(new ArrayList<Object>());
			columns.add(col);
		}
		
		while (rset.next()){
			for (int i=0; i<colCount; i++){
				ReportColumn column = (ReportColumn)columns.get(i);
				List data = column.getData(); 
				data.add(rset.getObject(i+1));
				logger.debug("getting data: "+data.get(data.size()-1));
			}
			
			if (rset.isFirst()){
				
				
				for (int i=0; i<colCount; i++){
					ReportColumn column = (ReportColumn)columns.get(i);
					List data = column.getData(); 
					Object o = data.get(0);
					if (o != null){
						
						
						if (o instanceof BigDecimal){
							BigDecimal bd = (BigDecimal)o;
							data.set(0, new Integer(bd.intValue()));
						}
						
						column.setDataType(o.getClass());
					}
				}
			}
		}
		

		return reportBean;
		
	}
}
