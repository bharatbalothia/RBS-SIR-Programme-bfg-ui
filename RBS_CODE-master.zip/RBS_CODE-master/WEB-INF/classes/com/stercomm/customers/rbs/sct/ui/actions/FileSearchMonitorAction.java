/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import org.apache.log4j.Logger;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.stercomm.customers.rbs.sct.ui.FileSearchCriteria;
import com.stercomm.customers.rbs.sct.ui.FileSearchCriteriaFormAdapter;
import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.dao.BundleDAO;
import com.stercomm.customers.rbs.sct.ui.dao.BundleDAOFactory;
import com.stercomm.customers.rbs.sct.ui.forms.FileMonitorForm;
import com.stercomm.customers.rbs.sct.ui.forms.FileSearchForm;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class FileSearchMonitorAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	//private static final Logger log = Logger.getLogger(FileSearchMonitorAction.class);
	protected static final int DEFAULT_PAGE_SIZE = 10;
	
	public ActionForward results(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return viewForm(mapping, form, request, response);
	}
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionErrors errors = new ActionErrors();
		BundleDAO bundleDAO = BundleDAOFactory.getFactoryInstance().getNewBundleDAOInstance();//new BundleDAO(getHibernateSession());
		FileSearchForm fsf = (FileSearchForm)form;
		FileSearchCriteria criteria = new FileSearchCriteriaFormAdapter(fsf);
		ResultMeta resultMeta = bundleDAO.getBundles(Integer.parseInt(fsf.getPage()), Integer.parseInt(fsf.getPageSize()), criteria);
		
		if (resultMeta.getTotalResults()>0){
			request.setAttribute("resultMeta", resultMeta);
			return mapping.findForward("viewResults");
		}
		else {
			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.errors.fileSearch.noResults"));
			saveErrors(request, errors);
			return mapping.findForward("noResults");
		}
	}

	public ActionForward overrideDuplicates(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionMessages messages = new ActionMessages();
		ActionErrors errors = new ActionErrors();
		FileMonitorForm fmf = (FileMonitorForm)form;
		String[] ids_s = fmf.getSelectedBundleId();
		
		if (ids_s==null || ids_s.length==0){
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.overrideDuplicates.noneSelected" ));
		}
		else{
			long[] bundleIds = new long[ids_s.length];

			for (int i=0; i<bundleIds.length; i++){
				bundleIds[i] = Long.parseLong(ids_s[i]);
			}

			BundleDAO dao = BundleDAOFactory.getFactoryInstance().getNewBundleDAOInstance();//new BundleDAO(getHibernateSession());
			boolean[] status = dao.overrideDuplicates(bundleIds, getGisUsername(request));

			for (int i=0; i<status.length; i++){
				
				
				boolean success = status[i];
				if (success){
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.overrideDuplicates.success", ids_s[i] ));
				}else{
					
					errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.overrideDuplicates.failure", ids_s[i] ));
					//return mapping.findForward("overrideDuplicateFailure");
				}
			}
		}
		
		//fmf.setSelectedBundleId(new String[0]);
		for (int i=0; i<ids_s.length; i++){
			ids_s[i] = "off";
		}
		
		saveMessages(request, messages);
		saveErrors(request, errors);
		return mapping.findForward("overrideDuplicateSuccess");
		
	}
	
	public ActionForward terminate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionMessages messages = new ActionMessages();
		ActionErrors errors = new ActionErrors();
		FileMonitorForm fmf = (FileMonitorForm)form;
		String[] ids_s = fmf.getSelectedBundleId();
		
		
		if (ids_s==null || ids_s.length==0){
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.terminateWF.noneSelected" ));
		}
		else{
			long[] bundleIds = new long[ids_s.length];

			for (int i=0; i<bundleIds.length; i++){
				bundleIds[i] = Long.parseLong(ids_s[i]);
			}
			
			
			BundleDAO dao = BundleDAOFactory.getFactoryInstance().getNewBundleDAOInstance();
			
			String username = getGisUsername(request);
			boolean[] results = dao.terminateWFs(bundleIds, username);
			
			for (int i=0; i<bundleIds.length; i++){
				if (results[i]){
					messages.add(ActionMessages.GLOBAL_MESSAGE ,new ActionMessage("sct.msgs.terminateWF.success", new Long(bundleIds[i])));
				}
				else {
					errors.add(ActionMessages.GLOBAL_MESSAGE ,new ActionMessage("sct.msgs.terminateWF.failure", new Long(bundleIds[i])));
				}
			}
			
		}
		
		fmf.setSelectedBundleId(new String[0]);
		saveMessages(request, messages);
		saveErrors(request, errors);
		return mapping.findForward("overrideDuplicateSuccess");
	}
	
	
}
