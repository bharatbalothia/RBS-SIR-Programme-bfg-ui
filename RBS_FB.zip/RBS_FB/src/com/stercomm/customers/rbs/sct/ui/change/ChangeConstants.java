package com.stercomm.customers.rbs.sct.ui.change;

public class ChangeConstants {

	public final static int STATUS_PENDING=0;
	public final static int STATUS_REJECTED=1;
	public final static int STATUS_ACCEPTED=2;
	public final static int STATUS_FAILED=-1;
	
	public final static String STATUS_PENDING_TEXT="Pending";
	public final static String STATUS_REJECTED_TEXT="Rejected";
	public final static String STATUS_ACCEPTED_TEXT="Accepted";
	public final static String STATUS_FAILED_TEXT="Failed";
	public final static String STATUS_UNKNOWN_TEXT="Unknown";
	
	public final static String OPERATION_CREATE="CREATE";
	public final static String OPERATION_UPDATE="UPDATE";
	public final static String OPERATION_DELETE="DELETE";
}
