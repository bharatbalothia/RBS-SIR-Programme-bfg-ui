/**
 * 
 */
package ic2.ui.server;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;




/**
 * @author RPatel
 *
 */
public class ContextListener implements ServletContextListener {
	private static final Logger logger = Logger.getLogger(ContextListener.class);
	
	
	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent contextEvent) {
		logger.debug("initializing context shutdown");
		
		

	}
	
	
	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent contextEvent) {
		

		
	}

	
	
	
}
