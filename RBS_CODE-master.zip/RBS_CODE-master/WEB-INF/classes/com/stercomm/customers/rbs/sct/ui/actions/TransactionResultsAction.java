/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import org.apache.log4j.Logger;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.stercomm.customers.rbs.sct.ui.PaymentSearchCriteria;
import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.TransactionSearchCriteriaFormAdapter;
import com.stercomm.customers.rbs.sct.ui.dao.PaymentDAO;
import com.stercomm.customers.rbs.sct.ui.dao.PaymentDAOFactory;
import com.stercomm.customers.rbs.sct.ui.forms.TransactionSearchForm;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class TransactionResultsAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	//private static final Logger log = Logger.getLogger(TransactionResultsAction.class);
	private static final int DEFAULT_PAGE_SIZE = 10;
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionErrors errors = new ActionErrors();
		
		int pageNo;
		int pageSize;
		{
			String str_pageNo = request.getParameter("page");
			String str_ipp = request.getParameter("pageSize");
			pageNo = str_pageNo==null?1:Integer.parseInt(str_pageNo);
			pageSize = str_ipp==null?DEFAULT_PAGE_SIZE:Integer.parseInt(str_ipp);
		}
		
		TransactionSearchForm tsf = (TransactionSearchForm)form;
		PaymentSearchCriteria criteria = new TransactionSearchCriteriaFormAdapter(tsf);
		PaymentDAO transDAO =  PaymentDAOFactory.getFactoryInstance().getNewPaymentDAOInstance();
		ResultMeta resultMeta = transDAO.getPayments(pageNo, pageSize, criteria);
		
		if (resultMeta.getTotalResults()>0){
			request.setAttribute("resultMeta", resultMeta);
			return super.viewForm(mapping, form, request, response);
		}
		else {
			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.errors.transactionSearch.noResults"));
			saveErrors(request, errors);
			return mapping.findForward("noResults");
		}
	}
	
}
