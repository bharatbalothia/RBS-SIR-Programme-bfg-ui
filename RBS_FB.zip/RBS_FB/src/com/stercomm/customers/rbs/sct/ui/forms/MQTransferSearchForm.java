/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.forms;
import org.apache.log4j.Logger;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class MQTransferSearchForm extends BaseActionForm {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(MQTransferSearchForm.class);
	
	private String correlationid;
	private String producer;
	private String consumer;
	private String transferstate;
	private String filename;
	private String alerted;
	private String dataflowid;
	private String fromDate;
	private String fromHr;
	private String fromMin;
	private String fromMeridiem;
	private String toDate;
	private String toHr;
	private String toMin;
	private String toMeridiem;
	
	private String page  = "1";
	private String pageSize = "10";
	
	private String minDiff;
	

	public String getCorrelationid() {
		return correlationid;
	}

	public void setCorrelationid(String correlationid) {
		this.correlationid = correlationid;
	}
	
	
	
	public String getProducer() {
		return producer;
	}

	public void setProducer(String producer) {
		this.producer = producer;
	}

	public String getConsumer() {
		return consumer;
	}

	public void setConsumer(String consumer) {
		this.consumer = consumer;
	}

	public String getTransferstate() {
		return transferstate;
	}

	public void setTransferstate(String transferstate) {
		this.transferstate = transferstate;
	}

	public String getAlerted() {
		return alerted;
	}

	public void setAlerted(String alerted) {
		this.alerted = alerted;
	}

	public String getDataflowid() {
		return dataflowid;
	}

	public void setDataflowid(String dataflowid) {
		this.dataflowid = dataflowid;
	}



	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}
	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename==null?null:filename.trim();
	}


	/**
	 * @return the fromDate
	 */
	public String getFromDate() {
		return fromDate;
	}
	/**
	 * @param fromDate the fromDate to set
	 */
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate==null?null:fromDate.trim();
	}
	/**
	 * @return the fromHr
	 */
	public String getFromHr() {
		return fromHr;
	}
	/**
	 * @param fromHr the fromHr to set
	 */
	public void setFromHr(String fromHr) {
		this.fromHr = fromHr==null?null:fromHr.trim();
	}
	/**
	 * @return the fromMin
	 */
	public String getFromMin() {
		return fromMin;
	}
	/**
	 * @param fromMin the fromMin to set
	 */
	public void setFromMin(String fromMin) {
		this.fromMin = fromMin==null?null:fromMin.trim();
	}
	/**
	 * @return the fromMeridiem
	 */
	public String getFromMeridiem() {
		return fromMeridiem;
	}
	/**
	 * @param fromMeridiem the fromMeridiem to set
	 */
	public void setFromMeridiem(String fromMeridiem) {
		this.fromMeridiem = fromMeridiem==null?null:fromMeridiem.trim();
	}
	/**
	 * @return the toDate
	 */
	public String getToDate() {
		return toDate;
	}
	/**
	 * @param toDate the toDate to set
	 */
	public void setToDate(String toDate) {
		this.toDate = toDate==null?null:toDate.trim();
	}
	/**
	 * @return the toHr
	 */
	public String getToHr() {
		return toHr;
	}
	/**
	 * @param toHr the toHr to set
	 */
	public void setToHr(String toHr) {
		this.toHr = toHr==null?null:toHr.trim();
	}
	/**
	 * @return the toMin
	 */
	public String getToMin() {
		return toMin;
	}
	/**
	 * @param toMin the toMin to set
	 */
	public void setToMin(String toMin) {
		this.toMin = toMin==null?null:toMin.trim();
	}
	/**
	 * @return the toMeridiem
	 */
	public String getToMeridiem() {
		return toMeridiem;
	}
	/**
	 * @param toMeridiem the toMeridiem to set
	 */
	public void setToMeridiem(String toMeridiem) {
		this.toMeridiem = toMeridiem==null?null:toMeridiem.trim();
	}
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	/**
	 * @return the page
	 */
	public String getPage() {
		return page;
	}
	/**
	 * @param page the page to set
	 */
	public void setPage(String page) {
		this.page = page==null?null:page.trim();
	}
	/**
	 * @return the pageSize
	 */
	public String getPageSize() {
		return pageSize;
	}
	/**
	 * @param pageSize the pageSize to set
	 */
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize==null?null:pageSize.trim();
	}
	public String getMinDiff() {
		return minDiff;
	}
	public void setMinDiff(String minDiff) {
		this.minDiff = minDiff;
	}
	
	
}
