/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.forms.EntityForm;



/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class EntitySwiftAction extends BaseEntityWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(EntitySwiftAction.class);
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		Entity entity = getEntity(request);
		String service = entity.getService();
		if(service!=null && service.equalsIgnoreCase("XCT")){
			return mapping.findForward("entityMQDetails");
		} else {
			//return super.viewForm(mapping, form, request, response);
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
		

	}
		
	public ActionForward next(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		if(validateForm(form, request)){
			return super.next(mapping,form, request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
	}
	
	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
			
		if(validateForm(form, request)){
			return super.save(mapping, form, request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
	
		
	}
	
	public ActionForward entitySwift(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if(validateForm(form, request)){
			return super.entitySwift(mapping,form, request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
		
	}
	
	public ActionForward GPLentitySwift(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if(validateForm(form, request)){
			return super.entitySwift(mapping,form, request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
		
	}
	public ActionForward confirm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		if(validateForm(form, request)){
			return super.confirm(mapping, form, request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}

	}
	
	private boolean validateForm(ActionForm form, HttpServletRequest request){
		
		EntityForm entityForm = (EntityForm)form;
		ActionMessages messages = new ActionMessages();
		//MessageResources messageResources = getResources(request);
		boolean rtn=true;
		
		log.debug("Validating Entity[SWIFT] form.");
		
		//SDD check for indirect participant
		boolean isSDDIndirect=false;
		if(entityForm.getService()!=null && entityForm.getService().equalsIgnoreCase("SDD")){
			Entity entity = (Entity)request.getSession().getAttribute("entityBean");
			if(entityForm.getRouteOutbound().equalsIgnoreCase("INDIRECT")){
				//SDD PArticipant is INDIRECT
				entityForm.setMailboxPathOut(entity.getEntity()+ "_SDD_INDIRECT");
				entity.setRouteOutbound(Boolean.FALSE);
				log.debug("SDD PArticipant is INDIRECT. No SWIFT Validation required");
				isSDDIndirect=true;
				
				//reset the checkboxes since they get wiped if disabled
				if(entity.getTrace()==Boolean.TRUE){
					entityForm.setTrace("on");
				}
				if(entity.getSnF()==Boolean.TRUE){
					entityForm.setSNF("on");
				}
				if(entity.getDeliveryNotification()==Boolean.TRUE){
					entityForm.setDeliveryNotif("on");
				}
			} else {
				log.debug("SDD PArticipant is DIRECT. SWIFT Validation required");
				entityForm.setMailboxPathOut(entity.getEntity()+ "_SDD");
				entity.setRouteOutbound(Boolean.TRUE);
			}
		}
		
		//RequestorDN Check
		if(entityForm.getRequesterDN()==null || entityForm.getRequesterDN().equalsIgnoreCase("")){
			
			if(isSDDIndirect){
				entityForm.setRequesterDN("n/a");
			} else {
				log.debug("RequestorDN is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.sreqdn.required" ));
				rtn=false;
			}
		}
		
//		ResponderDN Check
		if(entityForm.getResponderDN()==null || entityForm.getResponderDN().equalsIgnoreCase("")){
			if(isSDDIndirect){
				entityForm.setResponderDN("n/a");
			} else {
				log.debug("ResponderDN is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.sresdn.required" ));
				rtn=false;
			}
		}
		
//		Service Check
		if(entityForm.getServiceName()==null || entityForm.getServiceName().equalsIgnoreCase("")){
			if(isSDDIndirect){
				entityForm.setServiceName("n/a");
			} else {
				log.debug("ServiceName is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.sservice.required" ));
				rtn=false;
			}
		}
		
//		Request Type Check (not for GPL OR ROI or TRD)
		if(entityForm.getService()!=null && !entityForm.getService().equalsIgnoreCase("GPL") && !entityForm.getService().equalsIgnoreCase("ROI") && !entityForm.getService().equalsIgnoreCase("TRD")){
			if(entityForm.getRequestType()==null || entityForm.getRequestType().equalsIgnoreCase("")){
				if(isSDDIndirect){
					entityForm.setRequestType("n/a");
				} else {
					log.debug("Request Type is required. Validation failed.");
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.sreqtype.required" ));
					rtn=false;
				}
			}
		}
		
////		Request Type Check (specifically for ROI Itrish Step2)
//		if(entityForm.getService()!=null && entityForm.getService().equalsIgnoreCase("ROI")){
//			if(entityForm.getIrishStep2().equalsIgnoreCase("ON")){
//				if(entityForm.getRequestType()==null || entityForm.getRequestType().equalsIgnoreCase("")){
//					if(isSDDIndirect){
//						entityForm.setRequestType("n/a");
//					} else {
//						log.debug("Request Type is required. Validation failed.");
//						messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.sreqtype.required" ));
//						rtn=false;
//					}
//				}
//			}
//		}
	
		saveMessages(request, messages);
		return rtn;
	}
	
	private void setCustom(HttpServletRequest request, ActionForm form){

		Entity entity = (Entity)request.getSession().getAttribute("entityBean");
		String service = entity.getService();
		//EntityForm entityForm=(EntityForm)form;
		log.debug("Checking defaults for service[" + service + "]");
		
		//SDD - set routeInbound as FALSE if INDIRECT
		if(service!=null && service.equalsIgnoreCase("SDD")){
			//If mailbox ends with "_SDD_INDIRECT"  then 
			//participant is INDIRECT and the routeInbound flag is FALSE
			if(!entity.isNewBean()){
				log.debug("entity.getMailboxPathOut():" + entity.getMailboxPathOut());
				//log.debug("entity.getMailboxPathIn():" + entity.getMailboxPathIn());
				if(entity.getMailboxPathOut()!=null &&
						entity.getMailboxPathOut().endsWith("_SDD_INDIRECT")
				){
					entity.setRouteOutbound(Boolean.FALSE);
					log.debug("entity.setRouteOutbound=FALSE");
				} else {
					entity.setRouteOutbound(Boolean.TRUE);
					log.debug("entity.setRouteOutbound=TRUE");
				}
			} else {
				entity.setRouteOutbound(Boolean.TRUE);
				log.debug("entity.setRouteOutbound=TRUE");
			}
		}
		
	
	}
}
