/**
 * 
 */
package ic2.ui.exception;

/**
 * @author Ravi K Patel
 * created Mar 12, 2006
 */
public class IC2UIRuntimeException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public IC2UIRuntimeException() {
		super();
	}

	public IC2UIRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public IC2UIRuntimeException(String message) {
		super(message);
	}

	public IC2UIRuntimeException(Throwable cause) {
		super(cause);
	}

}
