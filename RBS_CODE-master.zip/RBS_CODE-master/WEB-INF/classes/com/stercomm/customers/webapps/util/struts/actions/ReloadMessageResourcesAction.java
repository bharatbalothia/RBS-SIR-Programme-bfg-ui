package com.stercomm.customers.webapps.util.struts.actions;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.util.MessageResources;

import com.stercomm.customers.webapps.util.struts.ReloadablePropertyMessageResources;


/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class ReloadMessageResourcesAction extends Action{
	Log logger = LogFactory.getLog(ReloadMessageResourcesAction.class);
	
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		Object o = getResources(request, "strutsResourceKeys");
		if (o!=null && o instanceof ReloadablePropertyMessageResources){
			ReloadablePropertyMessageResources strutsResourceKeys = (ReloadablePropertyMessageResources)o;
			
			String messageKeys = strutsResourceKeys.getMessage("names");
			logger.debug("messageKeys:"+messageKeys);
			if (messageKeys == null){
				logger.debug("no message keys found - nothing to reload");
			}
			else {
				String[] keys = messageKeys.split(",");
				for (int i=0; i<keys.length; i++){
					MessageResources mr = getResources(request, keys[i]);
					if (mr!=null && mr instanceof ReloadablePropertyMessageResources){
						logger.debug("restarting message resource bundle:"+keys[i]);
						((ReloadablePropertyMessageResources)mr).reload();
						logger.debug("restart of bundle "+keys[i]+" complete");
					}
				}
				logger.debug("all message bundles restarted");
			}
		}
		
		return mapping.findForward("success");
	}
	
}

/**********************************************************************
*
* Revision History
* ================
*
* $Log: $
*/