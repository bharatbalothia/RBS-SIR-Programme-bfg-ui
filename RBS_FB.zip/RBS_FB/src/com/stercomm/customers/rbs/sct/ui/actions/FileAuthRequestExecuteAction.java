package com.stercomm.customers.rbs.sct.ui.actions;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/*
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
@SuppressWarnings("unchecked")
public class FileAuthRequestExecuteAction extends BaseFileAuthRequestWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(FileAuthRequestExecuteAction.class);
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		log.debug("FileAuthRequestExecuteAction.viewForm()");
		return super.viewForm(mapping, form, request, response);
	}
	
	public ActionForward complete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		log.debug("FileAuthRequestExecuteAction.complete()");
		return super.complete(mapping, form, request, response);
		
	}

	
	
}
