/**
 * 
 */
package ic2.ui.beans.bp;

import ic2.ui.WaitKey;

import java.io.Serializable;
import java.util.Map;

import org.apache.struts.action.ActionForward;
import org.w3c.dom.Document;

/**
 * @author Ravi K Patel
 * created Apr 3, 2006
 */
@SuppressWarnings({"unchecked"})
public class BPSubmitObject implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public static final int WAITING = 1; //init, but not started yet
	public static final int RUNNING = 2; //bp process is running
	public static final int SUCCESS = 3; //finished with success
	public static final int FAILURE = 4; //finished with failure;
	
	private boolean runAsSystemUser;
	private Document documentOut;
	private String bpName;
	private ActionForward successPage;
	private ActionForward failurePage; 
	private ActionForward waitPage; 
	private ActionForward successForward;
	private ActionForward failureForward; 
	private int status;
	private BPResponseBean responseBean;
	private String waitKey = WaitKey.getWaitKey();
	private String header = "I-Connect<sub>2</sub>";
	private String subHeader;
	private String successMessage = "The process completed successfully";
	private String failureMessage = "The process failed";
	private Exception bpRunnerException;
	private Map requestAttributes;

	private String lockItemName;

	
	
	public String getLockItemName() {
		return lockItemName;
	}
	public void setLockItemName(String lockItemName) {
		this.lockItemName = lockItemName;
	}
	public boolean isRunAsSystemUser() {
		return runAsSystemUser;
	}
	public void setRunAsSystemUser(boolean runAsSystemUser) {
		this.runAsSystemUser = runAsSystemUser;
	}
	public Map getRequestAttributes() {
		return requestAttributes;
	}

	public void setRequestAttributes(Map requestAttributes) {
		this.requestAttributes = requestAttributes;
	}

	public Exception getBpRunnerException() {
		return bpRunnerException;
	}

	public void setBpRunnerException(Exception pbRunnerException) {
		this.bpRunnerException = pbRunnerException;
	}

	public BPSubmitObject(String bpName, Document documentOut){
		this.status = WAITING;
		this.bpName = bpName;
		this.documentOut = documentOut;
	}
	
	public String getBpName() {
		return bpName;
	}

	public Document getDocumentOut() {
		return documentOut;
	}

	public ActionForward getFailurePage() {
		return failurePage;
	}

	public void setFailurePage(ActionForward failurePage) {
		this.failurePage = failurePage;
	}

	public ActionForward getSuccessPage() {
		return successPage;
	}

	public void setSuccessPage(ActionForward successPage) {
		this.successPage = successPage;
	}

	public ActionForward getWaitPage() {
		return waitPage;
	}

	public void setWaitPage(ActionForward waitPage) {
		this.waitPage = waitPage;
	}

	public ActionForward getFailureForward() {
		return failureForward;
	}

	public void setFailureForward(ActionForward failureForward) {
		this.failureForward = failureForward;
	}

	public ActionForward getSuccessForward() {
		return successForward;
	}

	public BPResponseBean getResponseBean() {
		return responseBean;
	}

	public void setResponseBean(BPResponseBean responseBean) {
		this.responseBean = responseBean;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getWaitKey() {
		return waitKey;
	}

	public String getFailureMessage() {
		return failureMessage;
	}

	public void setFailureMessage(String failureMessage) {
		this.failureMessage = failureMessage;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getSubHeader() {
		return subHeader;
	}

	public void setSubHeader(String subHeader) {
		this.subHeader = subHeader;
	}

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public void setSuccessForward(ActionForward successForward) {
		this.successForward = successForward;
	}

	
}
