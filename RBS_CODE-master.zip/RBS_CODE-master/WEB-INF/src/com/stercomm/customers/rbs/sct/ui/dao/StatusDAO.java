/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   $Revision: $
 * Date/time:  $Date: $
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Logger;
import com.stercomm.customers.rbs.sct.ui.Utils;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unchecked", "unused", "deprecation"})
public class StatusDAO extends BaseDAO {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(StatusDAO.class);

	protected static String TRANS_STATUS_PROPS = "sct";

	private static final ThreadLocal threadLocal = new ThreadLocal(); 

	private Map inboundTransactionStatuses = new HashMap();
	private Map XCTinboundTransactionStatuses = new HashMap();
	private Map SCTinboundTransactionStatuses = new HashMap();
	private Map outboundTransactionStatuses = new HashMap();
	private Map SCToutboundTransactionStatuses = new HashMap();
	private Map SCTTransactionStatuses = new HashMap();
	private Map allTransactionStatuses = new HashMap();

	private Map inboundFileStatuses = new HashMap();
	private Map outboundFileStatuses = new HashMap();
	private Map allFileStatuses = new HashMap();

	//private Map allStatuses = 

	protected StatusDAO() {
		super();

		refreshProperties(TRANS_STATUS_PROPS);
	}

	public static StatusDAO getInstance(){

		try {
			StatusDAO dao = (StatusDAO)threadLocal.get();
			if (dao==null){
				synchronized (StatusDAO.class) {
					if (dao==null){
						dao = new StatusDAO();
						threadLocal.set(dao);
					}
				}
			}
			return dao;
		} catch (RuntimeException e) {

			e.printStackTrace();
			log.error("Error getting StatusDAO instance", e);
			throw new RuntimeException(e);
		}
	}



	protected void refreshProperties(String propertyFileName){
		Properties props = Utils.getGISProperties(propertyFileName);
		
		Iterator keySet = props.keySet().iterator();
		while (keySet.hasNext()){
			String key = (String)keySet.next();
			Status ts = null;
			if (key.startsWith("sct.trx.status.inbound")){
				String value = props.getProperty(key);
				int status = Integer.parseInt(key.substring(key.lastIndexOf('.')+1));
				//value="[" + String.valueOf(status) + "] " + value;
				ts= new Status(key, value, status);
				inboundTransactionStatuses.put(key, ts);
				SCTTransactionStatuses.put(key, ts);
				SCTinboundTransactionStatuses.put(key, ts);
			} else if (key.startsWith("xct.trx.status.inbound")){
				String value = props.getProperty(key);
				int status = Integer.parseInt(key.substring(key.lastIndexOf('.')+1));
				//value="[" + String.valueOf(status) + "] " + value;
				ts= new Status(key, value, status);
				inboundTransactionStatuses.put(key, ts);
				XCTinboundTransactionStatuses.put(key, ts);
			} else if (key.startsWith("sct.trx.status.outbound")){
				String value = props.getProperty(key);
				int status = Integer.parseInt(key.substring(key.lastIndexOf('.')+1));
				//value="[" + String.valueOf(status) + "] " + value;
				ts = new Status(key, value, status);
				outboundTransactionStatuses.put(key, ts);
				SCTTransactionStatuses.put(key, ts);
				SCToutboundTransactionStatuses.put(key, ts);
			} 
			if (ts !=null){
				log.trace("added key to all transaction statuses: "+ts.key);

				allTransactionStatuses.put(key, ts);
			}
			else {
				//*********** GPL BACKOUT START***********************
				if (key.startsWith("sct.file.status.outbound") || key.startsWith("sdd.file.status.outbound") || key.startsWith("gpl.file.status.outbound") || key.startsWith("roi.file.status.outbound") || key.startsWith("trd.file.status.outbound")){
//				*********** GPL BACKOUT END***********************
				//if (key.startsWith("sct.file.status.outbound") || key.startsWith("sdd.file.status.outbound") || key.startsWith("roi.file.status.outbound")){
					String value = props.getProperty(key);
					int status = Integer.parseInt(key.substring(key.lastIndexOf('.')+1));
					//value="[" + String.valueOf(status) + "] " + value;
					ts = new Status(key, value, status);
					outboundFileStatuses.put(key, ts);
				}
//				*********** GPL BACKOUT START***********************
				else if (key.startsWith("sct.file.status.inbound") || key.startsWith("sdd.file.status.inbound")|| key.startsWith("xct.file.status.inbound") || key.startsWith("gpl.file.status.inbound") || key.startsWith("roi.file.status.inbound") || key.startsWith("trd.file.status.inbound")){
				//*********** GPL BACKOUT END***********************
				//else if (key.startsWith("sct.file.status.inbound") || key.startsWith("sdd.file.status.inbound")|| key.startsWith("xct.file.status.inbound") || key.startsWith("roi.file.status.inbound")){
					String value = props.getProperty(key);
					int status = Integer.parseInt(key.substring(key.lastIndexOf('.')+1));
					//value="[" + String.valueOf(status) + "] " + value;
					ts = new Status(key, value, status);
					inboundFileStatuses.put(key, ts);
				}
				if (ts !=null){
					log.trace("added key to all file statuses: "+ts.key);
					allFileStatuses.put(key, ts);
				}

			}
		}
	}


	public Status getTransactionStatus(String key){
		return (Status)allTransactionStatuses.get(key);
	}
	public Status getFileStatus(String key){
		return (Status)allFileStatuses.get(key);
	}

	public class Status implements Comparable{
		public final String key;
		public final String value;
		public final int status;
		public final Integer statusI;

		public Status(String key, String value, int status){
			this.key = key;
			this.status = status;
			this.statusI = new Integer(status);
			this.value = value;
		}

		public int compareTo(Object o) {
			if (o==null){
				throw new NullPointerException("parameter object is null");
			}
			if (!(o instanceof Status)){
				throw new ClassCastException ("object "+o+" is not an instance of Status");
			}
			Status other = (Status)o;
			return this.value.compareTo(other.value);

		}
	}


	/**
	 * @return the inboundStatuses
	 */
	public Map getInboundTransactionStatuses() {
		return inboundTransactionStatuses;
	}
	
	public Map getXCTInboundTransactionStatuses() {
		return XCTinboundTransactionStatuses;
	}
	
	public Map getSCTInboundTransactionStatuses() {
		return SCTinboundTransactionStatuses;
	}


//	/**
//	* @param inboundStatuses the inboundStatuses to set
//	*/
//	public void setInboundStatuses(Map inboundStatuses) {
//	this.inboundStatuses = inboundStatuses == null ? null : inboundStatuses;
//	}


	/**
	 * @return the outboundTransactionStatuses
	 */
	public Map getOutboundTransactionStatuses() {
		return outboundTransactionStatuses;
	}


//	/**
//	* @param outboundTransactionStatuses the outboundTransactionStatuses to set
//	*/
//	public void setOutboundStatuses(Map outboundTransactionStatuses) {
//	this.outboundStatuses = outboundTransactionStatuses == null ? null : outboundTransactionStatuses;
//	}
	public Map getAllTransactionStatuses() {
		return allTransactionStatuses;
	}
	public Map getSCTTransactionStatuses() {
		return SCTTransactionStatuses;
	}

	public Map getOutboundFileStatuses() {
		return outboundFileStatuses;
	}

	public Map getInboundFileStatuses() {
		return inboundFileStatuses;
	}

	public Map getAllFileStatuses() {
		return allFileStatuses;
	}
	
	public String getFilteredTrxDirection(String status){
		
		if(status==null){
			return "ALL";
		}
		
		if(status.indexOf(".trx.status.inbound.")>0){
			return "inbound";
		} else if(status.indexOf(".trx.status.outbound.")>0){
			return "outbound";
		} else {
			return "ALL";
		}
	}
	
	public String getFilteredFileDirection(String status){
		
		if(status==null){
			return "ALL";
		}
		
		if(status.indexOf(".file.status.inbound.")>0){
			return "inbound";
		} else if(status.indexOf(".file.status.outbound.")>0){
			return "outbound";
		} else {
			return "ALL";
		}
	}
	
	public String getFilteredFileService(String status){
		
		if(status==null){
			return "ALL";
		}
		
		if(status.startsWith("sct.")){
			return "SCT";
		} else if(status.startsWith("sdd.")){
			return "SDD";
		} else if(status.startsWith("xct.")){
			return "XCT";
		} else if(status.startsWith("gpl.")){
			return "GPL";
		} else if(status.startsWith("roi.")){
			return "ROI";
		} else if(status.startsWith("trd.")){
				return "TRD";
		} else {
			return "ALL";
		}
	}
	

	
	public Map getFilteredTrxStatus(String service, String direction){

		/**slow but neccessary*/

		Map FilteredStatus = new HashMap();
		Map MapToUse=null;
		boolean filtered=false;

		if(direction==null || direction.equalsIgnoreCase("ALL")){
			MapToUse=getAllTransactionStatuses();
		} else if(direction.equalsIgnoreCase("inbound")){
			MapToUse=getInboundTransactionStatuses();
		} else if(direction.equalsIgnoreCase("outbound")){
			MapToUse=getOutboundTransactionStatuses();
		} else {
			MapToUse=getAllTransactionStatuses();
		}

		if(service!=null && !service.equalsIgnoreCase("ALL")){

			filtered=true;
			Iterator keySet = MapToUse.keySet().iterator();
			while (keySet.hasNext()){

				String stkey = (String)keySet.next();
				if(stkey!=null){
					Status st = (Status)MapToUse.get(stkey);
					if(st!=null && st.key.toLowerCase().startsWith(service.toLowerCase())){
					
						FilteredStatus.put(st.key, st);
					}
				}
			}
		}

		if(filtered){
			return FilteredStatus;
		} else {
			return MapToUse;
		}
	}

	public Map getFilteredStatus(String service, String direction){

		/**slow but neccessary*/

		Map FilteredStatus = new HashMap();
		Map MapToUse=null;
		boolean filtered=false;

		if(direction==null || direction.equalsIgnoreCase("ALL")){
			MapToUse=allFileStatuses;
		} else if(direction.equalsIgnoreCase("inbound")){
			MapToUse=inboundFileStatuses;
		} else if(direction.equalsIgnoreCase("outbound")){
			MapToUse=outboundFileStatuses;
		} else {
			MapToUse=allFileStatuses;
		}

		if(service!=null && !service.equalsIgnoreCase("ALL")){

			filtered=true;
			Iterator keySet = MapToUse.keySet().iterator();
			while (keySet.hasNext()){

				String stkey = (String)keySet.next();
				if(stkey!=null){
					Status st = (Status)MapToUse.get(stkey);
					if(st!=null && st.key.toLowerCase().startsWith(service.toLowerCase())){
					
						FilteredStatus.put(st.key, st);
					}
				}
			}
		}

		if(filtered){
			return FilteredStatus;
		} else {
			return MapToUse;
		}
	}



	public String getFileStatusLabel(Integer statusCode, Boolean isOutbound, String service){
		if (statusCode==null)return null;

		int sc = statusCode.intValue();

		sc = sc<0?sc*-1:sc; //voodoo magic


		Map statuses;
		if (isOutbound.booleanValue()){
			statuses = getOutboundFileStatuses();
		}
		else {
			statuses = getInboundFileStatuses();
		}

		Iterator si = statuses.values().iterator();
		while (si.hasNext()){
			Status st = (Status)si.next();
			if (st.status==sc){
				if(st.key.toLowerCase().startsWith(service.toLowerCase())){
					return st.value;
				}
				
			}
		}

		return null;
	}

	public String getTransactionStatusLabel(Integer statusCode, Boolean isOutbound){
		if (statusCode==null)return null;

		int sc = statusCode.intValue();
		sc = sc<-1?sc*-1:sc; //voodoo magic

		Map statuses;
		if (isOutbound.booleanValue()){
			statuses = getOutboundTransactionStatuses();
		}
		else {
			statuses = getInboundTransactionStatuses();
		}

		Iterator si = statuses.values().iterator();
		while (si.hasNext()){
			Status st = (Status)si.next();
			if (st.status==sc){
				return st.value;
			}
		}

		return null;
	}
	
	public String getTransactionStatusLabel(Integer statusCode, Boolean isOutbound, String service){
		if (statusCode==null)return null;

		int sc = statusCode.intValue();
		sc = sc<-1?sc*-1:sc; //voodoo magic

		Map statuses;
		if (isOutbound.booleanValue()){
			statuses = getOutboundTransactionStatuses();
		}
		else {
			if(service == "XCT"){
			statuses = getXCTInboundTransactionStatuses();
			} else if(service == "SCT"){
			statuses = getSCTInboundTransactionStatuses();
			} else {
			statuses = getInboundTransactionStatuses();
			}
		}

		Iterator si = statuses.values().iterator();
		while (si.hasNext()){
			Status st = (Status)si.next();
			if (st.status==sc){
				return st.value;
			}
		}

		return null;
	}

	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}


	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}

}
