/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   $Revision: $
 * Date/time:  $Date: $
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dao;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.security.cert.CertificateEncodingException;
import javax.security.cert.CertificateException;
import javax.security.cert.X509Certificate;
import org.apache.log4j.Logger;

import org.hibernate.Session;

import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.ResultMetaImpl;
import com.stercomm.customers.rbs.sct.ui.Utils;
import com.stercomm.customers.rbs.sct.ui.change.ChangeControl;
import com.stercomm.customers.rbs.sct.ui.change.TrustedCertChange;
import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;
import com.stercomm.customers.rbs.sct.ui.dtoimpl.TrustedCertImpl;
import com.sterlingcommerce.security.kcapi.TrustedCertificateInfo;
/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
@SuppressWarnings({"unused", "unchecked"})
public class TrustedCertDAO extends BaseHibernateDAO {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(TrustedCertDAO.class);
	private static final int MAX_CALC_RESULTS=50;


	/**
	 * @param hibSession
	 */
	@SuppressWarnings("deprecation")
	public TrustedCertDAO(Session hibSession) {
		super(hibSession);
	}


	public TrustedCert getTrustedCert(String trustedCertId) throws Exception{
	
		TrustedCert tc = null;
		TrustedCertificateInfo tci = new TrustedCertificateInfo(trustedCertId);
		if(tci!=null){
			tc = this.getNewInstance(tci, true, false);
		} 
		
		//System.out.println("CERT ID=" + tc.getCertificateId());
		
		return tc;
	}


	//	public Entity getEntity(Integer entityId){
	//		return getEntity(entityId.intValue()); 
	//	}

	//	public boolean isDuplicateEntity(String entityName, String service){
	//		Session session = getHibernateSession();
	//		Query query = session.createQuery("from EntityImpl ent where ent.entity=:entity and ent.service=:service");
	//		query.setString("entity", entityName);
	//		query.setString("service", service);
	//		
	//		if(query.list().size()>0){
	//			return true;
	//		} else {
	//			return false;
	//		}
	//	
	//	}

	public ResultMeta getTrustedCertsByName(String name, int pageNo, int pageSize){
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();
		
		if(name==null || name.equalsIgnoreCase("")){
			name="%";
		} else {
			name="%"+name+"%";
		}

		/*
		 * Get the pending change control certs
		 * AND
		 * Get the actual SI certs (not under Change Control)
		 * 
		 * 
		 */
				
		LinkedList<TrustedCertificateInfo> certlist = null;
		LinkedList<ChangeControl> changelist = null;
		List<TrustedCert> results = null;
		
		try {
			changelist = TrustedCertChange.listPendingByName(name.toUpperCase());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			certlist = TrustedCertificateInfo.listWhere("upper(NAME) LIKE ? ", name.toUpperCase(), " upper(NAME) ASC");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		results=compileCertList(changelist, certlist);
		
		if(results!=null){
			int startIdx = pageNo==1?0:((pageNo-1)*pageSize);
			int endIdx = results.size()>(startIdx+pageSize)?(startIdx+pageSize):results.size();
			List pagedResults = results.subList(startIdx, endIdx);
			rm.setResultsList(pagedResults);
			//rm.setResultsList(results);
			rm.setTotalResults(results.size());
		}
		return rm;
	}
	
	public ResultMeta getTrustedCertsByThumbprint(String tprint, int pageNo, int pageSize){
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();
		
		/*
		 * Get the pending change control certs
		 * AND
		 * Get the actual SI certs (not under Change Control)
		 * 
		 * 
		 */
				
		LinkedList<TrustedCertificateInfo> certlist = null;
		LinkedList<TrustedCertificateInfo> shalist = null;
		LinkedList<ChangeControl> changelist = null;
		List<TrustedCert> results = null;
		
		try {
			changelist = TrustedCertChange.listPendingByThumbprint(tprint.toUpperCase());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			certlist = TrustedCertificateInfo.listWhere("upper(NAME) LIKE ? ", "%", " upper(NAME) ASC");
			if(tprint!=null && !tprint.equalsIgnoreCase("") && certlist!=null && certlist.size()>0){
				Iterator cit = certlist.iterator();
				int certCount=0;
				while(cit.hasNext() && certCount<MAX_CALC_RESULTS){
					TrustedCertificateInfo tci = (TrustedCertificateInfo)cit.next();
					if(tci!=null){
						try {
							//tiresome and hopelessly inefficient but must be done
							//get all the SHA1_HASHes and turn them into HEX strings
							tci.refresh();
							
							String sha1hash = tci.getBase64EncodedSHA1Hash();
							byte[] rawhash = TrustedCertificateInfo.decodeToBytes(sha1hash);
							String hexhash = Utils.getHexString(rawhash).toUpperCase();
							if(hexhash.indexOf(tprint.toUpperCase())>=0){
								if(shalist==null){
									shalist=new LinkedList();
								}
								shalist.add(tci);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					certCount++;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		results=compileCertList(changelist, shalist);
		
		if(results!=null){
			int startIdx = pageNo==1?0:((pageNo-1)*pageSize);
			int endIdx = results.size()>(startIdx+pageSize)?(startIdx+pageSize):results.size();
			List pagedResults = results.subList(startIdx, endIdx);
			rm.setResultsList(pagedResults);
			//rm.setResultsList(results);
			rm.setTotalResults(results.size());
		}
		return rm;
	}
	
	public ResultMeta getPendingTrustedCerts(int pageNo, int pageSize){
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();
				
		LinkedList<TrustedCertificateInfo> certlist = null;
		LinkedList<ChangeControl> changelist = null;
		List<TrustedCert> results = null;
		
		try {
			changelist = TrustedCertChange.listPendingByName("%");
		} catch (Exception e) {
			e.printStackTrace();
		}

		certlist=null;
		
		results=compileCertList(changelist, certlist);
		
		if(results!=null){
			int startIdx = pageNo==1?0:((pageNo-1)*pageSize);
			int endIdx = results.size()>(startIdx+pageSize)?(startIdx+pageSize):results.size();
			List pagedResults = results.subList(startIdx, endIdx);
			rm.setResultsList(pagedResults);
			rm.setTotalResults(results.size());
		}
		return rm;
	}

	public TrustedCert getNewInstance() {
		TrustedCertImpl trustedCert = new TrustedCertImpl();
		return trustedCert;
	}
	
	/*
	 * only use for searching
	 */
	private TrustedCert getNewInstance(TrustedCertificateInfo tci, boolean refreshCert, boolean bValidate)throws Exception {
		TrustedCertImpl trustedCert = new TrustedCertImpl();
		X509Certificate cert;
		try {
			if(refreshCert){
				tci.refresh();
			}
			if(!bValidate){
				//override temp instance for search so we don't get any errors if revoked or held etc etc
				tci.setVerifyOnUse("xxx");
				tci.setOCSPInfo("xxx");
			}
			
			trustedCert.setCertificateId(tci.getObjectID());
			trustedCert.setCertificateName(tci.getName());
			cert = X509Certificate.getInstance(tci.getRawCertificate().getEncoded());
			trustedCert.setX509Certificate(cert);
		} catch (CertificateEncodingException e) {
			log.error("Cert Encoding Error getting new TrustedCert instance from TrustedCertificateInfo object: "+e.getMessage());
			throw e;
		} catch (CertificateException e) {
			log.error("Certificate Error getting new TrustedCert instance from TrustedCertificateInfo object: "+e.getMessage());
			throw e;
		} catch (Exception e) {
			log.error("Error getting new TrustedCert instance from TrustedCertificateInfo object: "+e.getMessage());
			throw e;
		}
		return trustedCert;
	}
	
	
	public TrustedCert getNewInstance(ChangeControl cc)throws Exception {
		TrustedCert trustedCert = null;
		X509Certificate cert;
		try {
			
			byte[] bResObj = cc.getResultObject();
			ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bResObj)); 
			trustedCert = (TrustedCert)in.readObject(); 
		
		} catch (Exception e) {
			log.error("Error getting new TrustedCert instance from ChangeControl object: "+e.getMessage());
			throw e;
		}
		return trustedCert;
	}
	
	private List<TrustedCert> compileCertList(LinkedList<ChangeControl> changelist, LinkedList<TrustedCertificateInfo> certlist){
		
		ArrayList alCerts = null;
		List<TrustedCert> results = null;
		List<TrustedCert> pagedResults = null;
		
		if(changelist!=null && changelist.size()>0){
			if(results==null){
				results = new ArrayList<TrustedCert>();
			}
			Iterator ccit = changelist.iterator();
			while(ccit.hasNext()){
				ChangeControl tcc = (ChangeControl)ccit.next();
				if(tcc!=null){
					try {
						TrustedCert tc = this.getNewInstance(tcc); 
						results.add(tc);
						if(alCerts==null){
							alCerts=new ArrayList();
						}
						//add the Cert ID to a black list
						alCerts.add(tc.getCertificateId());
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
				
		if(certlist!=null && certlist.size()>0){
			int certCount=0;
			if(results==null){
				results = new ArrayList<TrustedCert>();
			}
			Iterator cit = certlist.iterator();
			while(cit.hasNext() && certCount<MAX_CALC_RESULTS){
				TrustedCertificateInfo tci = (TrustedCertificateInfo)cit.next();
				if(tci!=null){
					try {
						TrustedCert tc = this.getNewInstance(tci, true, false);
						//only add the cert if not under Change Control
						if(alCerts==null || (alCerts!=null && !alCerts.contains(tc.getCertificateId()))){
							results.add(tc);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				certCount++;
			}
		}
		
		if(results!=null){
			Collections.sort(results, new Comparator() {
	          public int compare(Object o1, Object o2) {
	               return ((Comparable) ((TrustedCert) (o1)).getCertificateName())
	              .compareTo(((TrustedCert) (o2)).getCertificateName());
	          }
	     });
			
		}
		
		return results;

	}

}
