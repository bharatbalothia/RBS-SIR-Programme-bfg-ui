/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.stercomm.customers.rbs.sct.ui.forms.MQTransferSearchForm;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class MQTransferSearchAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	private static final Logger log = Logger.getLogger(MQTransferSearchAction.class);



	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		MQTransferSearchForm fsf = (MQTransferSearchForm)form;
		
		Calendar fromCal = Calendar.getInstance();
		fromCal.set(Calendar.HOUR_OF_DAY, 0);
		fromCal.set(Calendar.MINUTE, 0);
		fromCal.set(Calendar.SECOND, 0);
		fromCal.set(Calendar.MILLISECOND, 0);
		
		fromCal.roll(Calendar.MONTH, false);
		if(fromCal.get(Calendar.MONTH)==Calendar.DECEMBER){
			fromCal.roll(Calendar.YEAR, false);
		}

//		Date now = fromCal.getTime();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		//String today = sdf.format(now);
		
		Date dateFrom = fromCal.getTime();
		String lastMonth = sdf.format(dateFrom);
		
		fsf.setFromDate(lastMonth);
		fsf.setFromHr("00");
		fsf.setFromMin("00");
		fsf.setFromMeridiem("AM");

		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);

		//Date dayStart = cal.getTime();
		cal.roll(Calendar.DAY_OF_MONTH, true);
		Date dayEnd = cal.getTime();

		String tomorrow = sdf.format(dayEnd);
		fsf.setToDate(tomorrow);
		fsf.setToHr("11");
		fsf.setToMin("59");
		fsf.setToMeridiem("PM");

		@SuppressWarnings("unused")
		Session session = getHibernateSession();

		//Map formVars = new HashMap();
		//List entities = entityDAO.getEntities();
		//List entities = entityDAO.getEntities(fsf.getService());
		//formVars.put("entities", entities);

		//Put the FileTypes in formVars
		//formVars.put("types", getFileTypes(fsf.getService()));

		//request.setAttribute("formVars", formVars);


		//StatusDAO statusDAO = StatusDAO.getInstance();
		//List fileStatuses = new ArrayList(statusDAO.getAllFileStatuses().values());
		//List fileStatuses = new ArrayList(statusDAO.getFilteredStatus(fsf.getService(), fsf.getDirection()).values());
		//Collections.sort(fileStatuses);
		//request.setAttribute("fileStatuses", fileStatuses);

		return super.viewForm(mapping, form, request, response);
	}



	public ActionForward advancedSearch(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
//		ActionErrors errors = new ActionErrors();
//		BundleDAO bundleDAO = BundleDAOFactory.getFactoryInstance().getNewBundleDAOInstance();//new BundleDAO(getHibernateSession());

//		FileSearchForm fsf = (FileSearchForm)form;
//		FileSearchCriteria criteria = new FileSearchCriteriaFormAdapter(fsf);
//		ResultMeta resultMeta = bundleDAO.getBundles(Integer.parseInt(fsf.getPage()), Integer.parseInt(fsf.getPageSize()), criteria);


//		if (resultMeta.getTotalResults()>0){
//		request.setAttribute("resultMeta", resultMeta);
//		return mapping.findForward("viewResults");
//		}
//		else {
//		errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.errors.fileSearch.noResults"));
//		saveErrors(request, errors);
//		return mapping.findForward("noResults");
//		}

		//request.setAttribute("resultMeta", resultMeta);

		return mapping.findForward("viewResults");
	}

//	private List getFileTypes(String service){
//
//		List FTypes = new ArrayList();
//
//		if(service!=null && service.equalsIgnoreCase("SCT")){
//			//added new types CRR, DRR and RTF following change request from Keith Hagger (05/10/2009)
//			FTypes.add("CCF");
//			FTypes.add("CRR");
//			FTypes.add("CVF");
//			FTypes.add("DRR");
//			FTypes.add("ICF");
//			FTypes.add("RTF");
//			FTypes.add("SCF");
//		}
//
//		if(service!=null && service.equalsIgnoreCase("SDD")){
//			FTypes.add("CDF");
//			FTypes.add("DNF");
//			FTypes.add("DRR");
//			FTypes.add("DVF");
//			FTypes.add("IDF");
//			FTypes.add("MBP");
//			FTypes.add("MSR");
//			FTypes.add("PSR");
//			FTypes.add("RSF");
//			FTypes.add("RTF");
//			FTypes.add("SDF");
//		}
//		
//		if(service!=null && service.equalsIgnoreCase("XCT") ){
//			FTypes.add("SPF");
//			FTypes.add("DRR");
//			FTypes.add("MSR");
//		}
////		**************GPL Backout Start*****************
//		if(service!=null && service.equalsIgnoreCase("GPL") ){
//			FTypes.add("PM");
//			FTypes.add("PB");
//			FTypes.add("PS");
//			FTypes.add("AI");
//			FTypes.add("PC");
//			FTypes.add("PD");
//			FTypes.add("MI");
//			FTypes.add("FR");
//			FTypes.add("FA");
//			FTypes.add("FU");
//			FTypes.add("IP");
//			FTypes.add("RI");
//			FTypes.add("RO");
//		}
////		*****************GPL Backout End*****************
//		
//		if(service!=null && service.equalsIgnoreCase("ROI") ){
//			FTypes.add("DAT");
//			FTypes.add("REP");
//			FTypes.add("ACK");
//		}
//		
//		if(service==null || service.equalsIgnoreCase("") || service.equalsIgnoreCase("ALL")){
//			
//			FTypes.add("CCF");
//			FTypes.add("CDF");
//			FTypes.add("CRR");
//			FTypes.add("CVF");
//			FTypes.add("DNF");
//			FTypes.add("DRR");
//			FTypes.add("DVF");
//			FTypes.add("ICF");
//			FTypes.add("IDF");
//			FTypes.add("MBP");
//			FTypes.add("MSR");
//			FTypes.add("PSR");
//			FTypes.add("RSF");
//			FTypes.add("RTF");
//			FTypes.add("SCF");
//			FTypes.add("SDF");
//			FTypes.add("SPF");
////*****************GPL Backout Start*****************
//			FTypes.add("PM");
//			FTypes.add("PB");
//			FTypes.add("PS");
//			FTypes.add("AI");
//			FTypes.add("PC");
//			FTypes.add("PD");
//			FTypes.add("MI");
//			FTypes.add("FR");
//			FTypes.add("FA");
//			FTypes.add("FU");
//			FTypes.add("IP");
//			FTypes.add("RI");
//			FTypes.add("RO");
////*****************GPL Backout End*****************
//			FTypes.add("DAT");
//			FTypes.add("REP");
//			FTypes.add("ACK");
//		}
//
//		Collections.sort(FTypes);
//		return FTypes;
//	}



}
