/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.stercomm.customers.rbs.sct.ui.forms.EntityForm;
import org.apache.struts.util.MessageResources;


/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class EntityMQDetailsAction extends BaseEntityWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(EntityMQDetailsAction.class);

	public ActionForward next(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if(validateForm(form, request)){
			return super.next(mapping,form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}
	}

	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if(validateForm(form, request)){
			return super.save(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}


	}

	public ActionForward entityMQDetails(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {


		if(validateForm(form, request)){
			return super.entityMQDetails(mapping,form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}


	}

	public ActionForward confirm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if(validateForm(form, request)){
			return super.confirm(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}

	}

	public static boolean validateInt(String i) {
		try {
			Integer.parseInt(i);
			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}
	/*
	 * Can't get ValidatorForm to work so doing it manually (MB)
	 */
	private boolean validateForm(ActionForm form, HttpServletRequest request){

		EntityForm entityForm = (EntityForm)form;
		ActionMessages messages = new ActionMessages();
		MessageResources messageResources = getResources(request);
		boolean rtn=true;

		log.debug("Validating Entity[MQ Details] form.");


		boolean isMqHostInt = validateInt(entityForm.getMqPort());

		//MQ Node Check
		if((entityForm.getMqHost()==null || entityForm.getMqHost().equalsIgnoreCase("")) && entityForm.getEntityParticipantType().equals("DIRECT") ){
			log.debug("MQ Node is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqnode.required" ));
			rtn=false;
		}
		//MQ Port Check
		if((entityForm.getMqPort()==null || entityForm.getMqPort().equalsIgnoreCase("")) && entityForm.getEntityParticipantType().equals("DIRECT") ){
			log.debug("MQ Port is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqport.required" ));
			rtn=false;
		}

		if((entityForm.getMqPort()!=null)){
			log.debug("Validating [" + entityForm.getMqPort() + "] against ["+ messageResources.getMessage("sct.validate.mqdetails.port")+ "]");
			if(!entityForm.getMqPort().matches(messageResources.getMessage("sct.validate.mqdetails.port"))){
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.mq.port.invalid" ));
				log.debug("Validation of MQ Port [" + entityForm.getMqPort() + "] failed");
				rtn=false;
			}
		}

		//MQ Queue Manager
		if((entityForm.getMqQManager()==null ||entityForm.getMqQManager().equalsIgnoreCase("")) && entityForm.getEntityParticipantType().equals("DIRECT") ){
			log.debug("MQ Queue Manager is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqqmanager.required" ));
			rtn=false;
		}
		//MQ Channel
		if((entityForm.getMqChannel()==null || entityForm.getMqChannel().equalsIgnoreCase("")) && entityForm.getEntityParticipantType().equals("DIRECT") ){
			log.debug("MQ Channel is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqchannel.required" ));
			rtn=false;
		}
		//MQ Queue Name
		if((entityForm.getMqQueueName()==null || entityForm.getMqQueueName().equalsIgnoreCase("")) && entityForm.getEntityParticipantType().equals("DIRECT") ){
			log.debug("MQ Queue Name is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqqname.required" ));
			rtn=false;
		}
		//MQ Queue Binding
		if(entityForm.getMqQueueBinding()==null || entityForm.getMqQueueBinding().equalsIgnoreCase("")){
			log.debug("MQ Queue Binding is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqqbinding.required" ));
			rtn=false;
		}
		//MQ Queue Context
		if(entityForm.getMqQueueContext()==null || entityForm.getMqQueueContext().equalsIgnoreCase("")){
			log.debug("MQ Queue Context is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqqcontext.required" ));
			rtn=false;
		}
		//MQ Debug
		if(entityForm.getMqDebug()==null || entityForm.getMqDebug().equalsIgnoreCase("")){
			log.debug("MQ Debug is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqdebug.required" ));
			rtn=false;
		}
		//MQ Queue Header
		if((entityForm.getMqHeader()==null || entityForm.getMqHeader().equalsIgnoreCase("")) && entityForm.getEntityParticipantType().equals("DIRECT") ){
			log.debug("MQ Queue Header is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqheader.required" ));
			rtn=false;
		}
		//MQ Session Timeout
		if((entityForm.getMqSessionTimeout()==null || entityForm.getMqSessionTimeout().equalsIgnoreCase("")) && entityForm.getEntityParticipantType().equals("DIRECT") ){
			log.debug("MQ Session Timeout is required. Validation failed.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mqsessiontimeout.required" ));
			rtn=false;
		}

		if((entityForm.getMqSessionTimeout()!=null)){
			log.debug("Validating [" + entityForm.getMqSessionTimeout() + "] against ["+ messageResources.getMessage("sct.validate.mqdetails.sessiontimeout")+ "]");
			if(!entityForm.getMqSessionTimeout().matches(messageResources.getMessage("sct.validate.mqdetails.sessiontimeout"))){
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.mq.sessiontimeout.invalid" ));
				log.debug("Validation of MQ Session Timeout [" + entityForm.getMqSessionTimeout() + "] failed");
				rtn=false;
			}
		}
		saveMessages(request, messages);
		return rtn;
	}
}
