/***************************************************************************
                                                        IN-PAGE PARAMETERS
***************************************************************************/
HM_PG_MenuWidth = 150;
HM_PG_FontFamily = "'Avian'";
HM_PG_NS4_FontFamily = "Verdana";
HM_PG_NS4_FontSize = 8;
HM_PG_FontSize = 9;
HM_PG_FontBold = false;
HM_PG_FontItalic = false;
HM_PG_FontColor = "red";
HM_PG_FontColorOver = "white";
HM_PG_BGColor = "#DDDDDD";
HM_PG_BGColorOver = "#9999CC";
HM_PG_ItemPadding = 2;

HM_PG_BorderWidth = 1;
HM_PG_BorderColor = "#DDDDDD";
HM_PG_BorderStyle = "solid";
HM_PG_SeparatorSize = 1;
HM_PG_SeparatorColor = "black";
/*HM_PG_ImageSrc = null;*/
HM_PG_ImageSize = 8;
HM_PG_ImageHorizSpace = 0;
HM_PG_ImageVertSpace =0;

HM_PG_KeepHilite = true;
HM_PG_ClickStart = 0;
HM_PG_ClickKill = false;
HM_PG_ChildOverlap = 2;
HM_PG_ChildOffset = 2;
HM_PG_ChildPerCentOver = null;
HM_PG_TopSecondsVisible = .5;
HM_PG_StatusDisplayBuild =0;
HM_PG_StatusDisplayLink = 0;
HM_PG_UponDisplay = null;
HM_PG_UponHide = null;

HM_PG_RightToLeft = false;

//HM_a_TreesToBuild = [];

