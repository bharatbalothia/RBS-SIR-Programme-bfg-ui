package com.stercomm.customers.rbs.sct.ui.dto;

public interface PaymentArchive extends Payment{


}