/**
 * 
 */
package ic2.ui.beans;

import ic2.ui.exception.IC2UIRuntimeException;

import java.io.Serializable;

import org.apache.log4j.Logger;


/**
 * @author Ravi K Patel
 * created Mar 20, 2006
 */
public class IC2UIBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(IC2UIBean.class);
	
	//Actions
	public static final int UNSPECIFIED = 0;
	public static final int INSERT = 1;
	public static final int UPDATE = 2;
	public static final int DELETE = 3;
	public static final int UNMODIFIED = 4;
	
	public static final int ARCHIVE = 5;
	public static final int RESTART = 6;
	
	public static final int READ = 7;
	public static final int WRITE= 8;
	
	
	//private static final String UNSPECIFIED_LABEL = "UNSPECIFIED";
	public static final String INSERT_LABEL = "INSERT";
	public static final String UPDATE_LABEL = "UPDATE";
	public static final String DELETE_LABEL = "DELETE";
	public static final String UNMODIFIED_LABEL = "UNMODIFIED";
	
	public static final String ARCHIVE_LABEL = "ARCHIVE";
	public static final String RESTART_LABEL = "RESTART";
	
	public static final String READ_LABEL = "READ";
	public static final String WRITE_LABEL = "WRITE";
	
	private int action = UNSPECIFIED;
	private String lockId;
	
	
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public String getLockId() {
		return lockId;
	}

	public void setLockId(String lockId) {
		this.lockId = lockId;
	}

	public String getActionName(){
		return getActionName(getAction());
	}
	
	public String getActionName(int action){
		switch (action){
		case INSERT: return INSERT_LABEL;
		case UPDATE: return UPDATE_LABEL;
		case DELETE: return DELETE_LABEL;
		case ARCHIVE: return ARCHIVE_LABEL;
		case RESTART: return RESTART_LABEL;
		case READ: return READ_LABEL;
		case WRITE: return WRITE_LABEL;
		case UNMODIFIED: /*throw new IC2UIRuntimeException("IC2UIBean action 'UNMODIFIED'");//*/return UNMODIFIED_LABEL;
		default: IC2UIRuntimeException e =  new IC2UIRuntimeException("IC2UIBean action invalid");
				logger.debug("invalid ic2 action set", e);
				throw e;
		}
	}
	
	public void setActionName(String newAction){
		if (newAction.equals(INSERT_LABEL)){
			this.action = INSERT;
		}
		else if (newAction.equals(UPDATE_LABEL)){
			this.action = UPDATE;
		}
		else if (newAction.equals(DELETE_LABEL)){
			this.action = DELETE;
		}
		else if (newAction.equals(ARCHIVE_LABEL)){
			this.action = ARCHIVE;
		}
		else if (newAction.equals(RESTART_LABEL)){
			this.action = RESTART;
		}
		else if (newAction.equals(READ_LABEL)){
			this.action = READ;
		}
		else if (newAction.equals(WRITE_LABEL)){
			this.action = WRITE;
		}
		else if (newAction.equals(UNMODIFIED_LABEL)){
			this.action = UNMODIFIED;
		}
		else throw new IC2UIRuntimeException("IC2UIBean action label "+newAction+" invalid");
	}
	
	
	/**
	 * newBean is flagged true during the Beans first existance through a wizard. 
	 * Eg, a new Rule in the mailbox wizard. As soon as the rule is present in the Rule List, it is
	 * no longer a new Bean.
	 * DO NOT CHANGE DEFAULT FROM FALSE. Any class that creates beans from the database will not manually set this to false.
	 * 
	 */
	private boolean newBean = false;
	private boolean allDataLoaded = false;
	private boolean deleted = false;
	
	public boolean isAllDataLoaded() {
		return allDataLoaded;
	}
	public void setAllDataLoaded(boolean allDataLoaded) {
		this.allDataLoaded = allDataLoaded;
	}
	public int getAction() {
		return action;
	}
	public void setAction(int action) {
		this.action = action;
	}
	public boolean isNewBean() {
		return newBean;
	}
	public void setNewBean(boolean newBean) {
		this.newBean = newBean;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
		if (deleted){
			this.action = DELETE;
		}
	}
	
	
}
