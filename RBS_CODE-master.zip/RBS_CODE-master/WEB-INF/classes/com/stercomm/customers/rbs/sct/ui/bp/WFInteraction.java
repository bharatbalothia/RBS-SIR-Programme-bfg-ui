/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.bp;
import java.rmi.RemoteException;
import java.sql.SQLException;
//import java.util.Hashtable;

import javax.ejb.CreateException;
import javax.naming.NamingException;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.sterlingcommerce.woodstock.ui.UIGlobals;
//import com.sterlingcommerce.woodstock.ui.servlet.BPMonitor;
//import com.sterlingcommerce.woodstock.ui.servlet.WFCTracker;
import com.sterlingcommerce.woodstock.util.frame.jndi.JNDIService;
import com.sterlingcommerce.woodstock.workflow.WorkFlow;
import com.sterlingcommerce.woodstock.workflow.WorkFlowContextCookie;
//import com.sterlingcommerce.woodstock.workflow.WorkFlowDef;
//import com.sterlingcommerce.woodstock.workflow.WorkFlowManager;
import com.sterlingcommerce.woodstock.workflow.WorkFlowMonitor;
import com.sterlingcommerce.woodstock.workflow.WorkFlowNotFoundException;
import com.sterlingcommerce.woodstock.workflow.engine.WorkFlowEngineRMI;
//import com.sterlingcommerce.woodstock.workflow.test.WorkFlowLauncher;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class WFInteraction {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(WFInteraction.class);
	
	//Document runBP(wfName, username ....)
	
	public boolean terminate(Long wfid, String username) {
		return terminate(wfid.toString(), username);
	}
	
	public boolean terminate(String wfid, String username) {
		
		WorkFlowMonitor wfmonitor = new WorkFlowMonitor(); 
		boolean status;
		try {
			
			status = wfmonitor.terminateWF(wfid, true, username);
		} catch (SQLException e) {
			String msg = "Error while trying to terminate WF: "+wfid;
			log.error(msg, e);
			status = false;
		}
		log.debug("trying to terminate wf:"+wfid+"...status:"+status);
		
		if (!status){
			log.error("wf "+wfid+" failed to terminate; overriding error status to success");
			status=true;
		}
		
		return status;
	}
	
	
	public int restartWF(Long wfid){
		return restartWF(wfid.longValue());
	}
	
	
	public int restartWF(long wfid){
		boolean status = false;
		
		// business process restart page

		if(UIGlobals.out.debug){
			UIGlobals.out.logDebug( "[BPMonitor] Issue restart");
			UIGlobals.out.logDebug( "[BPMonitor] bpid="+ wfid);
			UIGlobals.out.logDebug( "[BPMonitor] restart bpid="+wfid );
		}
		int wfdid=0;

		WorkFlowContextCookie myCookie = null;
		WorkFlow wf=null;
		boolean notfound=false;
		try
		{
			wf = new WorkFlow (wfid);
		} catch (WorkFlowNotFoundException we) {
			notfound=true;
			UIGlobals.out.logException("[BPMonitor]:Got workflowNotFoundexception in simple restart for workflowID "+wfid, new Exception("Business Process definition for workflowId associated with Original request not found"));
		} catch (SQLException se) {
			UIGlobals.out.logException("Got a sql exception while constructing WorkFlow.",se);
		} catch (Exception ee) {
			UIGlobals.out.logException("Got an exception while constructing WorkFlow .",ee);
		}

		try {
			WorkFlowEngineRMI engine_rmi = null;
			engine_rmi = (WorkFlowEngineRMI)JNDIService.lookupRMI("WorkFlowEngineRMI");
			/* SIMPLE restart */
			// restart the original wf from start point

			if (notfound==false) {
				if(UIGlobals.out.debug)
					UIGlobals.out.logDebug( "[BPMonitor] simplerestart wfdid="+wfdid+" bpid="+wfid);
				myCookie =  engine_rmi.restartWorkflowInstance (wfid);
				wfid = myCookie.getWorkFlowId(); // get the new wfid
				if (wf != null) {
					wfdid= wf.getWFDId();  // use the original wfdid
				}
				if ( wfid != 0 ){
					status = true;
				}
				else{
					//error
				}
			}
			else{
				//error
			}
		}
		catch (NamingException ne ){
			UIGlobals.out.logException("[BPMonitor]:Got a naming exception in restart ", ne);
			//error
			}
		catch (CreateException cre)	{
			UIGlobals.out.logException("[BPMonitor]:Got a creating exception in restart ", cre);
			//error
		}
		catch (RemoteException re){
			UIGlobals.out.logException("[BPMonitor]:Got a remote exception in restart ", re);
			//error
		}
		catch (Exception e)	{
			UIGlobals.out.logException("[BPMonitor]:Got a exception in restart ", e);
			//error
		}

		return status?1:0;
	}
}
