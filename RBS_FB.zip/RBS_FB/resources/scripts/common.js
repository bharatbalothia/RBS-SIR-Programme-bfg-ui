
////////////////////////////////////////////////////////////////////
// (C) Copyright 2001 Sterling Commerce, Inc. ALL RIGHTS RESERVED
//
// ** Trade Secret Notice **
//
// This software, and the information and know-how it contains, is
// proprietary and confidential and constitutes valuable trade secrets
// of Sterling Commerce, Inc., its affiliated companies or its or
// their licensors, and may not be used for any unauthorized purpose
// or disclosed to others without the prior written permission of the
// applicable Sterling Commerce entity. This software and the
// information and know-how it contains have been provided
// pursuant to a license agreement which contains prohibitions
// against and/or restrictions on its copying, modification and use.
// Duplication, in whole or in part, if and when permitted, shall
// bear this notice and the Sterling Commerce, Inc. copyright
// legend. As and when provided to any governmental entity,
// government contractor or subcontractor subject to the FARs,
// this software is provided with RESTRICTED RIGHTS under
// Title 48 CFR 52.227-19.
// Further, as and when provided to any governmental entity,
// government contractor or subcontractor subject to DFARs,
// this software is provided pursuant to the customary
// Sterling Commerce license, as described in Title 48
// CFR 227-7202 with respect to comercial software and commercial
// software documentation.
/////////////////////////////////////////////////////////////////


function focusForm(){
 //first element
var i = 0;

for(i=0; i < document.forms[0].elements.length; i++){
 if(document.forms[0].elements[i]){
  if((document.forms[0].elements[i].type != "hidden") &&
     (document.forms[0].elements[i].disabled != true) &&
     (document.forms[0].elements[i].type != 'select-one')&&
     (document.forms[0].elements[i].type != 'select-multiple')){
     
     document.forms[0].elements[i].focus();
	
    //done
    break;
   }
  }
 }

}


function confirmDeleteAll(msg){
var question = confirm(msg);
 if (question == "0") {
    return false;
  }
  return true;

}

function confirmDelete(msg, askSelect, form, numVersions, dField){
var i = 0;
var checked = 0;

 for ( i=0; i < numVersions; i++){
	var theField = dField + i;
	if(eval(form +"." + theField) != null){
	   var val = eval(form +"." + theField + ".value");
	   if(val != '-1'){
		checked = 1;
		break;
	   }
	}

}
if(checked == 1){
 var question = confirm(msg);
 if (question == "0") {
    return false;
  }
  return true;
}else{
  alert(askSelect);
 return false;
}

return false;

}


function submitDelete(form) {
  form.submit();
  return true;
}

//hides/shows layers on the page
//specifically the ones named like divIdPrefix<number>
//like e.g. layer_1, where layer_ is a divIdPrefix and 1 is it's number

function clickshow_hide_all(form, which, onVal, offVal) {

 var item = "form."+"show_hide_all";
 var divIdPrefix = eval("form."+"divprefix.value");
 var totalDivs = eval("form." + "totalDivs.value");
 
 var flag = 'on';

  if (eval(item).value == offVal) {
     flag = 'on';
     eval(item).value = onVal;
     document.images['show_hide_allCheckbox'+which].src = show_hide_alldown.src;
   }
   else {
     flag = 'off';
     eval(item).value = offVal;
     document.images['show_hide_allCheckbox'+which].src = show_hide_allup.src;
   }

	var count = 0;
	for(count = 0; count < totalDivs; count++){
	     
	 if(HM_IE){
		if(flag == 'off'){
			document.all[divIdPrefix + count].style.display	= 'none';
		}else{
		       document.all[divIdPrefix + count].style.display	= ''
		}
		
	  }else if(!HM_NS4) {
		if(flag == 'off'){
			document.getElementById(divIdPrefix + count).style.display = 'none';
		}else{
		  	document.getElementById(divIdPrefix + count).style.display = '';
		}
	  }

	  
	}

}


function showHideDiv(divId){

	     
	 if(HM_IE){

		if(document.all[divId].style.display == 'none'){
			document.all[divId].style.display	= '';
		}else{
			document.all[divId].style.display	= 'none';
		}
	  }else if(!HM_NS4) {

		if(document.getElementById(divId).style.display == 'none'){
		  document.getElementById(divId).style.display	= '';
		}else{
	          document.getElementById(divId).style.display	= 'none';
		}

	  }

}

function clickdeadline(form, which, onVal, offVal) {
 var item = "form."+"deadline"+which;

  if (eval(item).value == offVal) {
     eval(item).value = onVal;
     document.images['deadlineCheckbox'+which].src = deadlinedown.src;

	

	document.all.deadline_hours_id.className = "WizardDisabledInputText";
   	document.all.deadline_min_id.className = "WizardDisabledInputText";
	document.all.first_notif_hours_id.className = "WizardDisabledInputText";
	document.all.first_notif_min_id.className = "WizardDisabledInputText";
	document.all.second_notif_hours_id.className = "WizardDisabledInputText";
	document.all.second_notif_min_id.className = "WizardDisabledInputText";


          form.deadline_hours.disabled = 1;
	  form.deadline_min.disabled = 1;
          form.first_notif_hours.disabled = 1;
	  form.first_notif_min.disabled = 1;
          form.second_notif_hours.disabled = 1;
	  form.second_notif_min.disabled = 1;
	

   }
   else {
     eval(item).value = offVal;
     document.images['deadlineCheckbox'+which].src = deadlineup.src;

    	document.all.deadline_hours_id.className = "WizardInputText";
   	document.all.deadline_min_id.className = "WizardInputText";
	document.all.first_notif_hours_id.className = "WizardInputText";
	document.all.first_notif_min_id.className = "WizardInputText";
	document.all.second_notif_hours_id.className = "WizardInputText";
	document.all.second_notif_min_id.className = "WizardInputText";

	
          form.deadline_hours.disabled = 0;
	  form.deadline_min.disabled = 0;
         form.first_notif_hours.disabled = 0;
	  form.first_notif_min.disabled = 0;
          form.second_notif_hours.disabled = 0;
	  form.second_notif_min.disabled = 0;
	
}
}



function setDisplay(divId, value){

	     
	 if(HM_IE){
		if(value == 'none'){
			document.all[divId].style.visibility='hidden';
			document.all[divId].className ='';
		}else{
			document.all[divId].style.visibility='visible';
                         document.all[divId].className =''; 		
		}
		
	  }else if(!HM_NS4) {
	
		  document.getElementById(divId).style.display	= value;
		  document.all[divId].className ='';

	  }

}


function setMultiState(elName1, elName2, operValue, disableValue1, disableValue2){

 var item1 = "document.forms[0]."+ elName1;
  var item2 = "document.forms[0]."+ elName2;
 //alert(operValue);
 //alert(disableValue);
 if ( operValue == disableValue1.toUpperCase() || operValue == disableValue2.toUpperCase()){
  
   // we do not want to hide multiple select lists
   if(eval(item1).type != 'select-multiple'){
	 eval(item1).disabled = 1;
         eval(item2).disabled = 1;
    document.getElementById(elName1).style.display = 'none';
	 document.getElementById(elName2).style.display = 'none';	
   }else{

    var size1 = eval(item1).options.length;
    for(var i =0; i< size1; i++){
	eval(item1).options[i].selected = false;
	
	}
    var size2 = eval(item2).options.length;
    for(var i =0; i< size2; i++){
	eval(item2).options[i].selected = false;
	
	}
	 eval(item1).disabled = 1;
	 eval(item2).disabled = 1;

    }
 }else{
   eval(item1).disabled = 0;
   eval(item2).disabled = 0;
	   // we do not want to hide multiple select lists
   	if(eval(item1).type != 'select-multiple'){
	 document.getElementById(elName1).style.display = '';
	 document.getElementById(elName1).className = '';
	 document.getElementById(elName2).style.display = '';
	 document.getElementById(elName2).className = '';
        }else{

    var size1 = eval(item1).options.length;
    for(var i =0; i< size1; i++){
        if(	eval(item1).options[i].value.length > 0){
	      eval(item1).options[i].selected = true;
	 }
	
	}
    var size2 = eval(item2).options.length;
    for(var i =0; i< size2; i++){
        if(	eval(item2).options[i].value.length > 0){
	      eval(item2).options[i].selected = true;
	 }
	
	}

    }

  }


}


function setState(elName, operValue, disableValue){

 var item = "document.forms[0]."+ elName;
 //alert(operValue);
 //alert(disableValue);
 if ( operValue == disableValue){
  
   // we do not want to hide multiple select lists
   if(eval(item).type != 'select-multiple'){
	 eval(item).disabled = 1;
    document.getElementById(elName).style.display = 'none';
   }else{

    var size = eval(item).options.length;
    for(var i =0; i< size; i++){
	eval(item).options[i].selected = false;
	
	}
	 eval(item).disabled = 1;
    }
 }else{
   eval(item).disabled = 0;
	   // we do not want to hide multiple select lists
   	if(eval(item).type != 'select-multiple'){
	 document.getElementById(elName).style.display = '';
	 document.getElementById(elName).className = '';
        }else{

    var size = eval(item).options.length;
    for(var i =0; i< size; i++){
        if(	eval(item).options[i].value.length > 0){
	      eval(item).options[i].selected = true;
	 }
	
	}

    }

  }


}



function runReport(form, formatElm, url, warning){
  var item = "form."+ formatElm;
  var formatValue = "&format=" + eval(item).value;
 var question = confirm(warning);
 if (question == "1") {

  openReportWin(url + formatValue, "report_win");
}

}
 function openReportWin(loc, name){
     window.open(loc, name , 'top=10,left=300,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes,width=600,height=500,dependent=yes').focus()
   }


function resetControlState(form, val){
 disableAllButOne(form, val);
}


function disableAllButOne(form, whichOne){
 //first element
var i = 0;

 var which1 = whichOne;
for(i=0; i < document.forms[0].elements.length; i++){


 var _date = "_date";
 var _time=  "_time";
 var _ampm = "_ampm";


 if(form.elements(i)){

 if(which1.indexOf("from") != -1 || which1.indexOf("From") != -1){

 if(form.elements(i).name == which1 ||
	(form.elements(i).name.indexOf(_date)  != -1) || 
	(form.elements(i).name.indexOf(_time) != -1) || 
	(form.elements(i).name.indexOf(_ampm) != -1) ){

     
     document.forms[0].elements[i].disabled = false;
   
  }else{
  if(form.elements(i).type != "hidden"){
    document.forms[0].elements[i].disabled = '1';
}
  }
}else{
 if(form.elements(i).name == which1 || form.elements(i).name == which1+"_vartype"){
     
     document.forms[0].elements[i].disabled = false;
  }else{
 if(form.elements(i).type != "hidden"){
    document.forms[0].elements[i].disabled = "1";
  }
  }
}


 }

 }
}


function clickenablekeystatus(form, which, onVal, offVal) {
	var item = "form.keystatusenabled";
	if (eval(item).value == offVal) {
     		eval(item).value = onVal;
     		document.images['enablekeystatusCheckbox'+which].src = keystatusdown.src;
	}else{
     		eval(item).value = offVal;
     		document.images['enablekeystatusCheckbox'+which].src = keystatusup.src;
	}
}
