package com.stercomm.customers.rbs.sct.ui.interfaces;


public interface XMLable {

	public String toXML();
}
