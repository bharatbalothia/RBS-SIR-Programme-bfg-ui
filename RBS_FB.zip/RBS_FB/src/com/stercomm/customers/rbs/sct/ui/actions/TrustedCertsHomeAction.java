package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
public class TrustedCertsHomeAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	//private static final Logger log = Logger.getLogger(TrustedCertsHomeAction.class);
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return super.viewForm(mapping, form, request, response);
	}
	
	public ActionForward trustedCertNew(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("trustedCertNew");
	}
	
	public ActionForward searchByName(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.getSession().setAttribute("tc_certificateName", request.getParameter("certificateName"));
		request.getSession().setAttribute("tc_certificateThumbprint", null);
		request.getSession().setAttribute("tc_certificatePending", Boolean.FALSE);
		return mapping.findForward("trustedCertsResults");	
	}
	
	public ActionForward searchByThumbprint(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.getSession().setAttribute("tc_certificateName", null);
		request.getSession().setAttribute("tc_certificateThumbprint", request.getParameter("certificateThumbprint"));
		request.getSession().setAttribute("tc_certificatePending", Boolean.FALSE);
		return mapping.findForward("trustedCertsResults");	
	}

	public ActionForward searchPendingChange(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.getSession().setAttribute("tc_certificateName", null);
		request.getSession().setAttribute("tc_certificateThumbprint", null);
		request.getSession().setAttribute("tc_certificatePending",Boolean.TRUE);
		return mapping.findForward("trustedCertsResults");	
	}
	
}
