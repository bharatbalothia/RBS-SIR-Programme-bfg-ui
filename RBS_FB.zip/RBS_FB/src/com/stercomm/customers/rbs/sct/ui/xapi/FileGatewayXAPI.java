package com.stercomm.customers.rbs.sct.ui.xapi;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.sterlingcommerce.woodstock.util.NameValuePairs;
import com.sterlingcommerce.woodstock.xml.xslt.DOMUtil;
import com.yantra.yfc.util.YFCException;

public class FileGatewayXAPI extends FBXAPIBase{
	
	private static final Logger log = Logger.getLogger(FileGatewayXAPI.class);

	public static Document replayFgArrivedFile(NameValuePairs nvp)
	throws YFCException
	{
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("replayFgArrivedFile","replayFgArrivedFile", nvp);
		} catch (YFCException ye) {
			log.error("[FileGatewayXAPI].replayFgArrivedFile() XAPI exception ", ye);
			throw ye;
		}
		return rdoc;
	}
	
	public static Document redeliverFgConsumerFile(NameValuePairs nvp)
	throws YFCException
	{
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("redeliverFgConsumerFile","redeliverFgConsumerFile", nvp);
		} catch (YFCException ye) {
			log.error("[FileGatewayXAPI].redeliverFgConsumerFile() XAPI exception ", ye);
			throw ye;
		}
		return rdoc;
	}
	
	public static Document manageFgArrivedFile(NameValuePairs nvp)
	throws YFCException
	{
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("manageFgArrivedFile","manageFgArrivedFile", nvp);
		} catch (YFCException ye) {
			log.error("[FileGatewayXAPI].manageFgArrivedFile() XAPI exception ", ye);
			throw ye;
		}
		return rdoc;
	}
	
	public static Document searchFgArrivedFile(Document doc)
	throws YFCException
	{
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("searchFgArrivedFile", doc);
		} catch (YFCException ye) {
			log.error("[FileGatewayXAPI].searchFgArrivedFile() XAPI exception ", ye);
			throw ye;
		}
		return rdoc;
	}
	
	public static Document getFgArrivedFileDetails(NameValuePairs nvp )
	throws YFCException
	{
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("getFgArrivedFileDetails", "getFgArrivedFile", nvp);
		} catch (YFCException ye) {
			log.error("[FileGatewayXAPI].getFgArrivedFileDetails() XAPI exception ", ye);
			throw ye;
		}
		return rdoc;
	}
	
	public static Document getFgDeliveryDetails(NameValuePairs nvp )
	throws YFCException
	{
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("getFgDeliveryDetails", "getFgDelivery", nvp);
		} catch (YFCException ye) {
			log.error("[FileGatewayXAPI].getFgDeliveryDetails() XAPI exception ", ye);
			throw ye;
		}
		return rdoc;
	}
	
	public static Document getFgRouteDetails(NameValuePairs nvp )
	throws YFCException
	{
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("getFgRouteDetails", "getFgRoute", nvp);
		} catch (YFCException ye) {
			log.error("[FileGatewayXAPI].getFgRouteDetails() XAPI exception ", ye);
			throw ye;
		}
		return rdoc;
	}
	
	public static Document getFgRouteList(NameValuePairs nvp )
	throws YFCException
	{
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("getFgRouteList", "listFgRoute", nvp);
		} catch (YFCException ye) {
			log.error("[FileGatewayXAPI].getFgRouteList() XAPI exception ", ye);
			throw ye;
		}
		return rdoc;
	}
	
	public static Document getFgDeliveryList(NameValuePairs nvp )
	throws YFCException
	{
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("getFgDeliveryList", "listFgDelivery", nvp);
		} catch (YFCException ye) {
			log.error("[FileGatewayXAPI].getFgDeliveryList() XAPI exception ", ye);
			throw ye;
		}
		return rdoc;
	}
	
//	public static Document getFgDeliveryList(Document doc)
//	throws YFCException
//	{
//		Document rdoc = null;
//		try
//		{
//			rdoc = invokeXAPI("getFgDeliveryList", doc);
//		} catch (YFCException ye) {
//			log.error("[FileGatewayXAPI].getFgDeliveryList() XAPI exception ", ye);
//			throw ye;
//		}
//		return rdoc;
//	}
	
	public static Document searchFgArrivedFileByKey(String key){
		//NameValuePairs nvp = new NameValuePairs();
		//nvp.addElement("ArrivedFileKey", key);
		//return searchFgArrivedFile(nvp);
		Document cDoc = DOMUtil.newDocument();
        Element cRoot = cDoc.createElement("searchFgArrivedFile");
        Element cSearch = cDoc.createElement("FgSearch");
        cSearch.setAttribute("ArrivedFileKey", key);
        cRoot.appendChild(cSearch);
        cDoc.appendChild(cRoot);
        return searchFgArrivedFile(cDoc);
	}
	
	public static Document replayFgArrivedFile(String key,String replacementFilename,String comment){
		NameValuePairs nvp = new NameValuePairs();
		nvp.addElement("ArrivedFileKey", key);
		nvp.addElement("ReplacementFilename", replacementFilename);
		nvp.addElement("Comment", comment);
		return replayFgArrivedFile(nvp);
	}
	
	public static Document redeliverFgConsumerFile(String key,String comment){
		NameValuePairs nvp = new NameValuePairs();
		nvp.addElement("DeliveryKey", key);
		nvp.addElement("Comment", comment);
		return redeliverFgConsumerFile(nvp);
	}
	
	public static Document manageFgArrivedFile(String key,boolean reviewOn){
		NameValuePairs nvp = new NameValuePairs();
		nvp.addElement("ArrivedFileKey", key);
		nvp.addElement("Reviewed", reviewOn==true?"1":"0");
		return manageFgArrivedFile(nvp);
	}
	
	public static Document getFgArrivedFileDetailsByKey(String key){
		NameValuePairs nvp = new NameValuePairs();
		nvp.addElement("ArrivedFileKey", key);
		return getFgArrivedFileDetails(nvp);
	}
	
	public static Document getFgRouteDetailsByKey(String key){
		NameValuePairs nvp = new NameValuePairs();
		nvp.addElement("RouteKey", key);
		return getFgRouteDetails(nvp);
	}
	
	
	
	public static Document getFgRouteListByKey(String key){
		NameValuePairs nvp = new NameValuePairs();
		nvp.addElement("ArrivedFileKey", key);
		return getFgRouteList(nvp);
	}
	
	public static Document getFgDeliveryListByKey(String key){
		NameValuePairs nvp = new NameValuePairs();
		nvp.addElement("RouteKey", key);
		return getFgDeliveryList(nvp);
	}
	
//	public static Document getFgDeliveryListByKey(String key){
//		Document cDoc = DOMUtil.newDocument();
//        Element cRoot = cDoc.createElement("FgDelivery");
//        cRoot.setAttribute("RouteKey", key);
//        Element cOrder = cDoc.createElement("OrderBy");
//        Element cColumn = cDoc.createElement("Column");
//        cColumn.setAttribute("Desc", "true");
//        cColumn.setAttribute("Name", "Createts");
//        cOrder.appendChild(cColumn);
//        cRoot.appendChild(cOrder);
//        cDoc.appendChild(cRoot);
//        return getFgDeliveryList(cDoc);
//	}
	
	

}
