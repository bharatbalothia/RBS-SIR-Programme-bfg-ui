/**
 * 
 */
package ic2.ui.exception;

/**
 * @author Matt Bradley
 * created Sept 4th, 2006
 */
public class IC2PwdExpiryException extends Exception {
	private static final long serialVersionUID = 1L;

	public IC2PwdExpiryException() {
		super();
	}

	public IC2PwdExpiryException(String message, Throwable cause) {
		super(message, cause);
	}

	public IC2PwdExpiryException(String message) {
		super(message);
	}

	public IC2PwdExpiryException(Throwable cause) {
		super(cause);
	}

}