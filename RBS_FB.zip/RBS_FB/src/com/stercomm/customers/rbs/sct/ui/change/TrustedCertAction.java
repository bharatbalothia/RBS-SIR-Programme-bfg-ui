package com.stercomm.customers.rbs.sct.ui.change;

//import java.rmi.RemoteException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.stercomm.customers.rbs.sct.ui.Utils;
import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;
//import com.stercomm.customers.rbs.sct.ui.xapi.FBXAPIClient;
//import com.sterlingcommerce.woodstock.util.NameValuePairs;
//import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.yfc.util.YFCException;
//import com.yantra.yfs.japi.YFSException;

public class TrustedCertAction extends ChangeActionImpl implements ChangeAction {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(TrustedCertAction.class);
	protected TrustedCert tc;
	
	public TrustedCertAction(TrustedCert tc){
		this.tc=tc;
	}
	
	@Override
	public void commit() throws Exception {
			throw new UnsupportedOperationException();
	}

	public boolean manageCertificate(Document doc)
	throws YFCException
	{
		boolean changed = false;
		Document rdoc = null;
		try
		{
			rdoc = invokeXAPI("manageCertificate", doc);
			if ((rdoc != null) && (rdoc.getDocumentElement().getTagName().equalsIgnoreCase("Certificate"))){
				System.out.println("manageCertificate response: " + Utils.toXML(rdoc));
				changed=true;
			} 
		} catch (YFCException ye) {
			log.error("[TrustedCertAction].manageCertficicate() XAPI exception ", ye);
			throw ye;
		}
		return changed;
	}

}
