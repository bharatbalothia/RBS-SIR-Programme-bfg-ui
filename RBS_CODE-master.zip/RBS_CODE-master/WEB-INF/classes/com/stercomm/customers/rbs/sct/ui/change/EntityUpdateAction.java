package com.stercomm.customers.rbs.sct.ui.change;

import org.apache.log4j.Logger;

import com.stercomm.customers.rbs.sct.ui.dao.EntityDAO;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;


public class EntityUpdateAction extends EntityAction implements ChangeAction {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(EntityUpdateAction.class);

	public EntityUpdateAction(Entity entity){
		super(entity);
	}

	public void commit() throws Exception {
	
		log.debug("Committing the Entity update action");
		EntityDAO dao = new EntityDAO(getHibernateSession());
		dao.commit(entity);
		log.debug("saved entity to DB");
		boolean ok = firePostUpdateActions();
		if(!ok){
			throw new Exception("An error occuring running a UI business process. Check Current Processes on the Admin Console.");
		}
		adminAudit();
	}
}
