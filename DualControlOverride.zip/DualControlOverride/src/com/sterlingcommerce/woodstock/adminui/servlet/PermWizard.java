/*
 * (C) Copyright 2001 - 2008 Sterling Commerce, Inc. ALL RIGHTS RESERVED
 *
 * ** Trade Secret Notice **
 *
 * This software, and the information and know-how it contains, is
 * proprietary and confidential and constitutes valuable trade secrets
 * of Sterling Commerce, Inc., its affiliated companies or its or
 * their licensors, and may not be used for any unauthorized purpose
 * or disclosed to others without the prior written permission of the
 * applicable Sterling Commerce entity. This software and the
 * information and know-how it contains have been provided
 * pursuant to a license agreement which contains prohibitions
 * against and/or restrictions on its copying, modification and use.
 * Duplication, in whole or in part, if and when permitted, shall
 * bear this notice and the Sterling Commerce, Inc. copyright
 * legend. As and when provided to any governmental entity,
 * government contractor or subcontractor subject to the FARs,
 * this software is provided with RESTRICTED RIGHTS under
 * Title 48 CFR 52.227-19.
 * Further, as and when provided to any governmental entity,
 * government contractor or subcontractor subject to DFARs,
 * this software is provided pursuant to the customary
 * Sterling Commerce license, as described in Title 48
 * CFR 227-7202 with respect to commercial software and commercial
 * software documentation.
 */
package com.sterlingcommerce.woodstock.adminui.servlet;

import com.sterlingcommerce.rbs.filebroker.dualcontrol.DualControlUtil;
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop
import java.io.IOException;
import java.io.IOException;

//java stuff
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import com.sterlingcommerce.woodstock.ui.security.*;
import com.sterlingcommerce.woodstock.dmi.visibility.event.DmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.ExceptionLevel;
import com.sterlingcommerce.woodstock.event.InvalidEventException;
import com.sterlingcommerce.woodstock.security.*;
import com.sterlingcommerce.woodstock.util.frame.log.Logger;
import com.sterlingcommerce.woodstock.ui.Wizard;
import com.sterlingcommerce.woodstock.ui.BaseUIGlobals;
import com.sterlingcommerce.woodstock.ui.UIPermissions;
import com.sterlingcommerce.woodstock.ui.jspbean.LangBean;
import com.sterlingcommerce.woodstock.ui.servlet.WizardBase;
import com.sterlingcommerce.woodstock.util.Util;
import com.sterlingcommerce.woodstock.ui.SessionInfo;

import com.sterlingcommerce.woodstock.util.frame.cache.CacheManager;

/**
 * The RoleWizard class extends the ServletBase class.
 * Contains all the business logic related to handling the Role
 * related tasks.
 *
 * @version 1.0
 * @since Woodstock2.0
 */
@SuppressWarnings({ "unused", "serial" })
public class PermWizard extends WizardBase{
	/**
	 * Returns a String describing what the Servlet does.
	 * @return String
	 */
	public String getServletInfo () {
		return  "PermWizard";
	}

	/**
	 * Method for handling all the HttpRequests
	 *
	 * @param req
	 * @param res
	 * @exception javax.servlet.ServletException
	 */

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
		HttpSession session = req.getSession(false);
		SessionInfo userinfo = null;
		try { req.setCharacterEncoding("UTF8"); } catch (Exception e) {  Util.noop();  /* try/catch to resolve jetty not wanting to reopen the stream */}
		if(session != null){
			userinfo = (SessionInfo)session.getAttribute("SessionInfo");
		}

		if(!verifySession(session, userinfo, req, res)){
			return;
		}

		if(BaseUIGlobals.out.debug) {
			BaseUIGlobals.out.logDebug(" [PermWizard] START");
		}

		Wizard wiz = initWizard(req, session);
		int action = wiz.getActivity(req);

		Permission perm = (Permission)wiz.editObj();
		perm.setPrincipal(userinfo.getUserName());
		perm.setForce(true);

		synchronized (wiz.editObj()) {
			switch (action) {
			default: // the edit
			if(!updatePerm(wiz, req, perm)){
				action = Wizard.EDITPAGE;
			}
			break;
			case -1: // Ignore
				break;
			case Wizard.COMMITPAGE:
				break;
			case Wizard.FINISHPAGE:
				/*
				 * DUAL CONTROL START
				 */
//				if (wiz.commitObj() == null){
//					if(BaseUIGlobals.out.debug) BaseUIGlobals.out.logDebug("CURRENT WIZARD STATS "  + wiz.toString());
//
//					wiz.setCommitObj(new SavePerm(wiz));
//				}
//				break;
				boolean doFinish = false;
				String dcUser = req.getParameter("DUAL_CONTROL_USER");
				String dcPass = req.getParameter("DUAL_CONTROL_PASSWORD");
				String dcCurrentUser = (String)session.getAttribute("username");
				String dcCurrentUserPass = req.getParameter("DUAL_CONTROL_C_PASSWORD");
				BaseUIGlobals.out.logDebug("Entering Dual Control.");
				DualControlUtil dcu = new DualControlUtil();
				doFinish = dcu.isDualControlAuthorized("DUAL_CONTROL_PERMISSION_APPROVER", dcUser, dcPass, dcCurrentUser, dcCurrentUserPass, session);
				if(doFinish)
				{
					try
					{
						DmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, Util.createGUID(), System.currentTimeMillis(), dcCurrentUser, "PERMISSION_APPROVAL", "Permission", perm.getPermission(), dcUser);
					}
					catch(InvalidEventException e)
					{
						BaseUIGlobals.out.logError("Permissions Dual Control Admin Audit Event Error" + e);
					}
//            	ORIGINAL CODE - START
				if (wiz.commitObj() == null){
					if(BaseUIGlobals.out.debug) BaseUIGlobals.out.logDebug("CURRENT WIZARD STATS "  + wiz.toString());

					wiz.setCommitObj(new SavePerm(wiz));
				}
//              ORIGINAL CODE - END
				} else
				{
					action = 10;
					session.setAttribute("DUAL_CONTROL_MESSAGE", dcu.getMessage(true));
					if(dcu.isChangerLocked())
					{
						session.setAttribute("AccountLocked", "AccountLocked");
						req.setAttribute("badpage", "page.authofailure");
						gotoPage("page.badframe", req, res);
						session.invalidate();
					}
				}
                break;
                /*
                 * DUAL CONTROL END
                 */
			case Wizard.CANCELPAGE:
				/* reload the bugger */
				BaseUIGlobals.securityMgr.removePermissionFromCache( perm.getPermissionid() );
				perm.doneLocking = true;
				undoWizard( req );

				break;

			}
		}

		setupNextPage(req, res, session, wiz, action);

		if(BaseUIGlobals.out.debug) BaseUIGlobals.out.logDebug(" [RoleWizard] END");
	}

	/**
	 * Method for updating the role object
	 *
	 * @param req
	 * @param res
	 * @param theRole
	 */
	@SuppressWarnings("static-access")
	private boolean updatePerm(Wizard wiz, HttpServletRequest req, Permission perm){
		//unused?
		//HttpSession ses = req.getSession();
		//boolean nResult = true;

		HttpSession session = req.getSession(false); // added for fix 4105.  session is needed to post error msg.

		String s = req.getParameter("PERM_permid");
		if (s!=null && s.length() >0) {
			perm.setPermissionid( s );
		}

		boolean dupePermId = true;
		boolean dupePermName = true;
		//check for an existing groupid, or a user with the same user_id.
		if (wiz.action == wiz.ADD) {
			if (s != null && s.length() > 0) {
				dupePermId = Permission.checkExistenceWithoutStatus(s); // checks for duplicate groupid
				if (!dupePermId) {
					dupePermId = false;
				} else {
					Permission p = (Permission)CacheManager.get("PermissionCache", s);
					if (!p.isEnabled()) {
						dupePermId = false;
						perm.setNewPermission(false);
						perm.enable();
					}
				}

				if(dupePermId){ //if we have the duplicate
					LangBean lang = (LangBean)session.getAttribute("langbean");
					req.setAttribute("msg", lang.getValue("images.errorbutton") + Util.replaceString(lang.getValue("DuplicatePermissionId"),"&NAME;", s));
					return false;
				}
			}
		}

		s = req.getParameter("PERM_permname");
		if (s!=null && s.length() >0) {
			perm.setPermission( s );
		}

		if (wiz.action == wiz.ADD) {
			if (s != null && s.length() > 0) {
				dupePermName = Permission.doesPermNameExist(s); // checks for duplicate groupname
				if (!dupePermName) {
					dupePermName = false;
				} else {
					String pid = Permission.getPermissionIdFromName(s);
					Permission p = (Permission)CacheManager.get("PermissionCache", pid);
					if (!p.isEnabled()) {
						//Permission.remove(s); // removes disabled perm to avoid unique constraint violation
						Permission.remove(pid); //SR1365905 TD#37191  wrong argument, was sending name not id
						perm.setNewPermission(true); //TD#17575. Permission save() - the SQL was doing an update and the record doesn't exists since we just removed it.  Setting the flag cause the SQL to do an insert.
						//                            p.updatePermissionToGuid(); //changes permission name  of disabled permission so unique constraint isnt violated.
						//                            p.save();
						dupePermName = false;
					}
				}

				if(dupePermName){ //if we have the duplicate
					LangBean lang = (LangBean)session.getAttribute("langbean");
					req.setAttribute("msg", lang.getValue("images.errorbutton") + Util.replaceString(lang.getValue("DuplicatePermission"),"&NAME;", s));
					return false;
				}
			}
		}

		s = req.getParameter("PERM_permtype");
		if (s!=null && s.length() >0) {
			perm.setPermType( s );
		}

		return true;
	}

}
