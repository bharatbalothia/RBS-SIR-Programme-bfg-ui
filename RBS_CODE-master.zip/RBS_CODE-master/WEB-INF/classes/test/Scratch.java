package test;

import java.net.URLEncoder;


public class Scratch {
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) throws Exception {
		String url = "http://rpatel:20000/ws/Login?autho=autho=rpatel&encodedPass=true&password=44rSFJQ9qtHWTBAvrsKd5K%2Fp2j0%3D&NEOSESSION=true";
		url += "&nextURL=./Page?bpid=345447&";
		
		String encoded = URLEncoder.encode(url, "UTF-8");
		System.out.println(encoded);
		System.out.println(URLEncoder.encode("foo bar baz", "UTF-8"));
	}
	
}
