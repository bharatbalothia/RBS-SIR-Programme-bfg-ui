package com.stercomm.customers.rbs.sct.ui.change;

public interface ChangeViewer {
	
	public abstract ChangeControl getChange();
	public abstract String getObjectType();
	public abstract void setChange(ChangeControl change);
	public abstract String getBeforeChangeLink();
	public abstract String getAfterChangeLink();

}
