/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   $Revision: $
 * Date/time:  $Date: $
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dao;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.ResultMetaImpl;
import com.stercomm.customers.rbs.sct.ui.Utils;
import com.stercomm.customers.rbs.sct.ui.change.ChangeControl;
import com.stercomm.customers.rbs.sct.ui.change.EntityChange;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.dto.Schedule;
import com.stercomm.customers.rbs.sct.ui.dtoimpl.EntityImpl;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unused", "unchecked", "deprecation"})
public class EntityDAO extends BaseHibernateDAO {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(EntityDAO.class);
	private static final int MAX_CALC_RESULTS=500;


	/**
	 * @param hibSession
	 */
	public EntityDAO(Session hibSession) {
		super(hibSession);
	}


	/**
	 * Saves the Entity object to the database
	 * @param entity
	 */
	//public void commit(Entity entity, HttpServletRequest request){
	public void commit(Entity entity){

		log.debug("trying to save entity :"+entity);

		Session session = getHibernateSession();

		Transaction transaction = session.beginTransaction();

		try {

			if (entity.isCreateBean()){
				session.save(entity);
				log.debug("saved entity: "+entity);
			}
			else{
				session.update(entity);
			}

			session.flush();

			if(entity.isDeleteBean()){
				//delete all the schedules
				List schedulesToDelete = entity.getSchedules();
				if(schedulesToDelete!=null){
					for (int i=0; i<schedulesToDelete.size(); i++){
						Schedule deleteSchedule = (Schedule)schedulesToDelete.get(i);
						session.delete(deleteSchedule);
						log.debug("delete schedule: "+deleteSchedule);
					}
				}

			} else {
				List deletedSchedules = entity.getDeletedSchedules();
				for (int i=0; i<deletedSchedules.size(); i++){
					Schedule deletedSchedule = (Schedule)deletedSchedules.get(i);
					if (!deletedSchedule.isCreateBean()){
						session.delete(deletedSchedule);
						log.debug("deleted schedule: "+deletedSchedule);
					}
					else{
						log.debug("schedule to delete has not been inserted yet...nothing to delete..skipping");
					}
				}
			}




			List schedules = entity.getSchedules();

			for(int i=0; i<schedules.size(); i++){
				Schedule schedule = (Schedule)schedules.get(i);
				Date nextRun = Utils.minToDate(schedule.getTimestart());

				schedule.setNextRun(nextRun);
				log.debug("setting transaction next runtime to : "+nextRun.toString());

				//Date nextRun = schedule.getNextRun();
				if (schedule.isCreateBean()){
					log.debug("inserting new schedule: "+schedule);
					schedule.setEntity(entity);
					session.save(schedule);

				}
				else if (schedule.isUpdated()){
					log.debug("updating schedule: "+schedule);
					session.update(schedule);
				}
			}

			//handled at changeApprove action
			//Utils.adminAudit(request, entity);

			transaction.commit();
			log.debug("entity save-update transaction committed");
		} catch (HibernateException e) {
			String msg = "failed to save entity to database";
			log.debug(msg, e);
			e.printStackTrace();
			transaction.rollback();
			throw e;

		}

	}

	/**
	 * @return a List of Entity objects
	 */
	public List getEntities(){
		Session session = getHibernateSession();
		String key = "dao.entity.list";
		Query query = session.getNamedQuery(key);
		List list = query.list();
		return list;
	}

	/**
	 * @return a List of Entity objects
	 */
	public List getEntities(String service){
		Session session = getHibernateSession();
		//String key;
		if(service!=null && !service.equalsIgnoreCase("") && !service.equalsIgnoreCase("ALL")){
			String key = "dao.entity.list.ByService";
			Query query = session.getNamedQuery(key);
			query.setString("service", service);
			List list = query.list();
			return list;
		} else {
			return getEntities();
		}
		//if(service.equalsIgnoreCase("SCT")){
		//	key = "dao.entity.list.ByService.SCT";
		//}else {
		//	key = "dao.entity.list.ByService.XCT";
		//}
		//Query query = session.getNamedQuery(key);
		//List list = query.list();
		//return list;
	}
	/**
	 * Returns the Entity object identified by entityId
	 * @param entityId
	 * @return the Entity Object
	 */
	public Entity getEntity(int entityId){
		Session session = getHibernateSession();
		Query query = session.createQuery("from EntityImpl ent where ent.entityId=:entityId and ent.deleted=0");
		query.setInteger("entityId", entityId);
		Entity entity = (EntityImpl)query.uniqueResult();

		query = session.createQuery("from ScheduleImpl sch where sch.entity=:entityId");
		query.setInteger("entityId", entityId);
		entity.setSchedules(query.list());

		return entity;
	}


	public Entity getEntity(Integer entityId){
		return getEntity(entityId.intValue()); 
	}

	public boolean isDuplicateEntity(String entityName, String service){
		Session session = getHibernateSession();
		Query query = session.createQuery("from EntityImpl ent where ent.entity=:entity and ent.service=:service and ent.deleted=0");
		query.setString("entity", entityName);
		query.setString("service", service);

		if(query.list().size()>0){
			return true;
		} else {
			return false;
		}

	}


//	public ResultMeta getEntities(int pageNo, int pageSize){
//		ResultMeta rm = new ResultMetaImpl();
//		rm.setCurrentPage(pageNo);
//		rm.setPageSize(pageSize);
//
//		int firstResult = rm.getFirstResult();
//
//		Session session = getHibernateSession();
//		Query query = session.getNamedQuery("dao.entity.list");
//		query.setFirstResult(firstResult-1); //zero indexed
//		query.setMaxResults(pageSize);
//
//		List results = query.list();
//		rm.setResultsList(results);
//
//
//		query = session.getNamedQuery("dao.entity.list.size");
//		Integer totalResults = (Integer)query.uniqueResult();
//		rm.setTotalResults(totalResults);
//
//
//		return rm;
//	}

	public ResultMeta getEntities(int pageNo, int pageSize){
		return getEntities(pageNo, pageSize, "%");
	}
	
	public ResultMeta getEntitiesByService(int pageNo, int pageSize, String serviceName){
		
		List entitylist = null;
		LinkedList changelist = null;
		List results = null;
		
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);

		int firstResult = rm.getFirstResult();

		Session session = getHibernateSession();
		if(serviceName!=null && !serviceName.equalsIgnoreCase("") && !serviceName.equalsIgnoreCase("ALL")){
			String key = "dao.entity.list.ByService";
			Query query = session.getNamedQuery(key);
			query.setString("service", serviceName);
			entitylist = query.list();
		} else {
			Query query = session.getNamedQuery("dao.entity.list.byEntityName");
			//query.setFirstResult(firstResult-1); //zero indexed
			//query.setMaxResults(pageSize);
			query.setString("entityName", "%");
			entitylist = query.list();
		}
	
		
		try {
			if(serviceName!=null && !serviceName.equalsIgnoreCase("") && !serviceName.equalsIgnoreCase("ALL")){
				changelist = EntityChange.listPendingByService(serviceName.toUpperCase());
			} else {
				changelist = EntityChange.listPendingByService("%");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		results=compileEntityList(changelist, entitylist);
		
		if(results!=null){
			int startIdx = pageNo==1?0:((pageNo-1)*pageSize);
			int endIdx = results.size()>(startIdx+pageSize)?(startIdx+pageSize):results.size();
			List pagedResults = results.subList(startIdx, endIdx);
			rm.setResultsList(pagedResults);
			//rm.setResultsList(results);
			rm.setTotalResults(results.size());
		}
		return rm;

	}

	public ResultMeta getEntities(int pageNo, int pageSize, String entityName){
		
		List entitylist = null;
		LinkedList changelist = null;
		List results = null;
		
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);

		int firstResult = rm.getFirstResult();

		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.entity.list.byEntityName");
		//query.setFirstResult(firstResult-1); //zero indexed
		//query.setMaxResults(pageSize);
		query.setString("entityName", entityName+"%");
		entitylist = query.list();
	
	
		//rm.setResultsList(results);
		//query = session.getNamedQuery("dao.entity.list.size.byEntityName");
		//query.setString("entityName", entityName+"%");
		//Integer totalResults = (Integer)query.uniqueResult();
		//rm.setTotalResults(totalResults);
		
		try {
			changelist = EntityChange.listPendingByName(entityName.toUpperCase());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		results=compileEntityList(changelist, entitylist);
		
		if(results!=null){
			int startIdx = pageNo==1?0:((pageNo-1)*pageSize);
			int endIdx = results.size()>(startIdx+pageSize)?(startIdx+pageSize):results.size();
			List pagedResults = results.subList(startIdx, endIdx);
			rm.setResultsList(pagedResults);
			//rm.setResultsList(results);
			rm.setTotalResults(results.size());
		}
		return rm;

	}
	
	public ResultMeta getPendingChangeEntities(int pageNo, int pageSize){
		List entitylist = null;
		LinkedList changelist = null;
		List results = null;
		
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);

		int firstResult = rm.getFirstResult();
		
		try {
			changelist = EntityChange.listPendingByName("%");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		results=compileEntityList(changelist, entitylist);
		
		if(results!=null){
			int startIdx = pageNo==1?0:((pageNo-1)*pageSize);
			int endIdx = results.size()>(startIdx+pageSize)?(startIdx+pageSize):results.size();
			List pagedResults = results.subList(startIdx, endIdx);
			rm.setResultsList(pagedResults);
			//rm.setResultsList(results);
			rm.setTotalResults(results.size());
		}
		return rm;
	}

	public Entity getNewInstance() {
		EntityImpl entity = new EntityImpl();
		return entity;
	}
	
	private List compileEntityList(LinkedList changelist, List entitylist){
		
		ArrayList alEntities = null;
		List results = null;
		//List pagedResults = null;
		
		if(changelist!=null && changelist.size()>0){
			if(results==null){
				results = new ArrayList();
			}
			Iterator ccit = changelist.iterator();
			while(ccit.hasNext()){
				ChangeControl cc = (ChangeControl)ccit.next();
				if(cc!=null){
					try {
						Entity e1 = this.getNewInstance(cc); 
						results.add(e1);
						if(alEntities==null){
							alEntities=new ArrayList();
						}
						//add the Cert ID to a black list
						alEntities.add(e1.getEntityId());
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
				
		if(entitylist!=null && entitylist.size()>0){
			int entityCount=0;
			if(results==null){
				results = new ArrayList();
			}
			Iterator cit = entitylist.iterator();
			while(cit.hasNext() && entityCount<MAX_CALC_RESULTS){
				Entity e2 = (Entity)cit.next();
				if(e2!=null){
					try {
						//only add the Entity if not under Change Control
						if(alEntities==null || (alEntities!=null && !alEntities.contains(e2.getEntityId()))){
							results.add(e2);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				entityCount++;
			}
		}
		
		if(results!=null){
			Collections.sort(results, new Comparator() {
	          public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Entity) (o1)).getEntity())
	              .compareTo(((Entity) (o2)).getEntity());
	          }
	     });
			
		}
		
		return results;

	}
	
	public Entity getNewInstance(ChangeControl cc)throws Exception {
		Entity e = null;
		try {
			
			byte[] bResObj = cc.getResultObject();
			ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bResObj)); 
			e = (Entity)in.readObject(); 
		
		} catch (Exception ex) {
			log.error("Error getting new Entity instance from ChangeControl object: "+ex.getMessage());
			throw ex;
		}
		return e;
	}
	
	public boolean isSCTConstraintMQViolation(String mqQueueOut, int entityId){
		Session session = getHibernateSession();
		Query query = session.createQuery("from EntityImpl ent where ent.mqQueueOut=:mqQueueOut and ent.deleted=0 and ent.entityId!=:entityId");
		query.setString("mqQueueOut", mqQueueOut);
		query.setInteger("entityId", entityId);
		if(query.list().size()>0){
			return true;
		} else {
			return false;
		}

	}
	
	public boolean isSCTConstraintMbxViolation(String mailboxPathOut, int entityId){
		Session session = getHibernateSession();
		Query query = session.createQuery("from EntityImpl ent where ent.mailboxPathOut=:mailboxPathOut and ent.deleted=0 and ent.entityId!=:entityId");
		query.setString("mailboxPathOut", mailboxPathOut);
		query.setInteger("entityId", entityId);
		if(query.list().size()>0){
			return true;
		} else {
			return false;
		}

	}

}
