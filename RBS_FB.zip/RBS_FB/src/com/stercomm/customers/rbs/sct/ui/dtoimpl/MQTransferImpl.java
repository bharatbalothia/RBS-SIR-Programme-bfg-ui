/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dtoimpl;

import java.util.Date;
import org.apache.log4j.Logger;


import com.stercomm.customers.rbs.sct.ui.dto.MQTransfer;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 * @hibernate.class table="SCT_BUNDLE"
 */
@SuppressWarnings("unchecked")
public class MQTransferImpl extends BaseHibernateBeanImpl implements MQTransfer, Comparable{
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(MQTransferImpl.class);
	
	private String correlationid;
	private String producer;
	private String consumer;
	private String filename;
	private Date expires;
	private Integer status;
	private Boolean alerted;
	private Boolean archived;
	private Integer metawfid;
	private Integer ackwfid;
	private Integer filewfid;
	private String docid;
	private Integer dataflowid;
	private Date created;
	private Date lastmodified;
	private String deliverykey;
	
	
	/*
	 * *************************(non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.MQTransfer#getExecutionStatus()
	 */

	
	public String getCorrelationid() {
		return correlationid;
	}


	public void setCorrelationid(String correlationid) {
		this.correlationid = correlationid;
	}


	public String getProducer() {
		return producer;
	}


	public void setProducer(String producer) {
		this.producer = producer;
	}


	public String getConsumer() {
		return consumer;
	}


	public void setConsumer(String consumer) {
		this.consumer = consumer;
	}


	public Date getExpires() {
		return expires;
	}


	public void setExpires(Date expires) {
		this.expires = expires;
	}


	public Boolean isAlerted() {
		return alerted;
	}


	public void setAlerted(Boolean alerted) {
		this.alerted = alerted;
	}


	public Boolean isArchived() {
		return archived;
	}


	public void setArchived(Boolean archived) {
		this.archived = archived;
	}


	public Integer getMetawfid() {
		return metawfid;
	}


	public void setMetawfid(Integer metawfid) {
		this.metawfid = metawfid;
	}


	public Integer getAckwfid() {
		return ackwfid;
	}


	public void setAckwfid(Integer ackwfid) {
		this.ackwfid = ackwfid;
	}


	public Integer getFilewfid() {
		return filewfid;
	}


	public void setFilewfid(Integer filewfid) {
		this.filewfid = filewfid;
	}


	public String getDocid() {
		return docid;
	}


	public void setDocid(String docid) {
		this.docid = docid;
	}


	public Integer getDataflowid() {
		return dataflowid;
	}


	public void setDataflowid(Integer dataflowid) {
		this.dataflowid = dataflowid;
	}


	public Date getCreated() {
		return created;
	}


	public void setCreated(Date created) {
		this.created = created;
	}


	public Date getLastmodified() {
		return lastmodified;
	}


	public void setLastmodified(Date lastmodified) {
		this.lastmodified = lastmodified;
	}


	public String getDeliverykey() {
		return deliverykey;
	}


	public void setDeliverykey(String deliverykey) {
		this.deliverykey = deliverykey;
	}


	public String getFilename() {
		return filename;
	}


	public void setFilename(String filename) {
		this.filename = filename;
	}


	public Integer getStatus() {
		return status;
	}


	public void setStatus(Integer status) {
		this.status = status;
	}


	public int getExecutionStatus() {
		int status = getStatus().intValue();
		if (status < 0){
			return MQTransfer.STATUS_ERROR;
		}
		if (status == 2){
			return MQTransfer.STATUS_GREEN;
		}
		else {
			return MQTransfer.STATUS_RUNNING;
		}
	}
	
	
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	

	
	public int compareTo(Object o) {
		if (!(o instanceof MQTransfer)){
			throw new ClassCastException("parameter object is not an instance of the MQTransfer interface. obj:"+o.toString());
		}
		MQTransfer other = (MQTransfer)o;
		int ret = -1;
		
		if(this.correlationid.compareTo(other.getCorrelationid())==0 && this.consumer.compareTo(other.getConsumer())==0 && this.producer.compareTo(other.getProducer())==0){
			return 0;
		}
		if(this.correlationid.compareTo(other.getCorrelationid())>0 && this.consumer.compareTo(other.getConsumer())>0 && this.producer.compareTo(other.getProducer())>0){
			return 1;
		}

		return ret;
		
	}
}
