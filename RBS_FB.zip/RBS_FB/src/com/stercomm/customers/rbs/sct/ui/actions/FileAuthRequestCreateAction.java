package com.stercomm.customers.rbs.sct.ui.actions;




import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
//import org.apache.struts.util.MessageResources;

//import com.stercomm.customers.rbs.sct.ui.dto.FileAuthRequest;
import com.stercomm.customers.rbs.sct.ui.dto.FileAuthRequest;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuth;
import com.stercomm.customers.rbs.sct.ui.forms.FileAuthRequestForm;
import com.sterlingcommerce.woodstock.security.SecurityManager;
/*
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
@SuppressWarnings("unchecked")
public class FileAuthRequestCreateAction extends BaseFileAuthRequestWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(FileAuthRequestCreateAction.class);
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		log.debug("FileAuthRequestCreateAction.viewForm()");
		
		
		FileAuthRequest far = this.getFileAuthRequest(request);
		
		log.debug("viewing " + far.getFileKey() + ":" + far.getFileAction());
		
		Map formVars = new HashMap();
		SecurityManager sm = new SecurityManager();
		String currentUser = this.getGisUsername(request);
		
		String[] aUsers = sm.listUsersForPermission(FileAuth.getActionPermission(far.getFileAction()));
		Vector<String> users = new Vector(aUsers.length);
		for(int z=0;z<aUsers.length;z++){
			users.add(aUsers[z]);
		}
		if(users!=null){
			//sort case-insensitively
			Collections.sort(users, new Comparator() {
				public int compare(Object o1, Object o2) {
					return ((Comparable) ((String) (o1)).toString().toLowerCase())
					.compareTo(((String) (o2)).toString().toLowerCase());
				}
			});
		}
		if(users.contains(currentUser)){
			//put the current user at the top so doesn't get buried in the select list
			users.remove(currentUser);
			users.add(0, currentUser);
		}
		log.debug("added " + users.size() + "users to formVars");
		formVars.put("users", users);
		request.setAttribute("formVars", formVars);
		return super.viewForm(mapping, form, request, response);
		
	}
	
	public ActionForward save(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		log.debug("FileAuthRequestCreateAction.save()");
		
		if(validateForm(form, request)){
			return super.save(mapping, form, request, response);
		} else {
			return this.viewForm(mapping, form, request, response);
		}
	}
	
	private boolean validateForm(ActionForm form, HttpServletRequest request){

		FileAuthRequestForm farf = (FileAuthRequestForm)form;
		//FileAuthRequest far = this.getFileAuthRequest(request);
		ActionMessages messages = new ActionMessages();
		//MessageResources messageResources = getResources(request);
		boolean rtn=true;

		/*
		 * check we have a file
		 */
		if(farf.getUsers()==null || farf.getUsers().length<1 ){
			log.debug("Authorised user is required.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("fileauth.msgs.request.users.required" ));
			rtn=false;
		} 

		saveMessages(request, messages);
		return rtn;
	}

	
}
