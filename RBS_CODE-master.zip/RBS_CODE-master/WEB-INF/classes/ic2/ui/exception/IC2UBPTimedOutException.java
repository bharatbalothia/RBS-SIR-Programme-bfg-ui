/**
 * 
 */
package ic2.ui.exception;

/**
 * @author Ravi K Patel
 * created Mar 12, 2006
 */
public class IC2UBPTimedOutException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public IC2UBPTimedOutException() {
		super();
	}

	public IC2UBPTimedOutException(String message, Throwable cause) {
		super(message, cause);
	}

	public IC2UBPTimedOutException(String message) {
		super(message);
	}

	public IC2UBPTimedOutException(Throwable cause) {
		super(cause);
	}

}
