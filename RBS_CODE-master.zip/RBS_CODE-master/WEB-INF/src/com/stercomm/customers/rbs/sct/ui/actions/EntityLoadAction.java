/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.stercomm.customers.rbs.sct.ui.dao.EntityDAO;
import com.stercomm.customers.rbs.sct.ui.dao.ScheduleDAO;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings("unchecked")
public class EntityLoadAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(EntityLoadAction.class);
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {	
		return super.viewForm(mapping, form, request, response);
	}
	
	public ActionForward createSCT(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		//specific permission check
		if(!isAuthorized("SFG_UI_SCT_CREATE_ENTITY_SCT", request)){
			throw new com.stercomm.customers.webapps.security.UnauthorizedException();
		}
		
		EntityDAO dao = new EntityDAO(getHibernateSession());
		Entity entity = dao.getNewInstance();
		
		entity.setCreateBean(true);
		entity.setNewBean(true);
		entity.setService("SCT");
		
		request.getSession().setAttribute("entityBean", entity);
		return mapping.findForward("newEntity");
	}
	
	public ActionForward createSDD(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
//		specific permission check
		if(!isAuthorized("SFG_UI_SCT_CREATE_ENTITY_SDD", request)){
			throw new com.stercomm.customers.webapps.security.UnauthorizedException();
		}
		
		EntityDAO dao = new EntityDAO(getHibernateSession());
		Entity entity = dao.getNewInstance();
		
		entity.setCreateBean(true);
		entity.setNewBean(true);
		entity.setService("SDD");
		
		request.getSession().setAttribute("entityBean", entity);
		return mapping.findForward("newEntity");
	}
	
	public ActionForward createXCT(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
//		specific permission check
		if(!isAuthorized("SFG_UI_SCT_CREATE_ENTITY_XCT", request)){
			throw new com.stercomm.customers.webapps.security.UnauthorizedException();
		}
		
		EntityDAO dao = new EntityDAO(getHibernateSession());
		Entity entity = dao.getNewInstance();
		
		entity.setCreateBean(true);
		entity.setNewBean(true);
		entity.setService("XCT");
		
		request.getSession().setAttribute("entityBean", entity);
		return mapping.findForward("newEntity");
	}
	
	public ActionForward createGPL(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
//		specific permission check
		if(!isAuthorized("SFG_UI_SCT_CREATE_ENTITY_GPL", request)){
			throw new com.stercomm.customers.webapps.security.UnauthorizedException();
		}
		
		EntityDAO dao = new EntityDAO(getHibernateSession());
		Entity entity = dao.getNewInstance();
		
		entity.setCreateBean(true);
		entity.setNewBean(true);
		entity.setService("GPL");
		
		request.getSession().setAttribute("entityBean", entity);
		return mapping.findForward("newEntity");
	}
	
	public ActionForward createROI(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
//		specific permission check
		if(!isAuthorized("SFG_UI_SCT_CREATE_ENTITY_ROI", request)){
			throw new com.stercomm.customers.webapps.security.UnauthorizedException();
		}
		
		EntityDAO dao = new EntityDAO(getHibernateSession());
		Entity entity = dao.getNewInstance();
		
		entity.setCreateBean(true);
		entity.setNewBean(true);
		entity.setService("ROI");
		
		request.getSession().setAttribute("entityBean", entity);
		return mapping.findForward("newEntity");
	}
	
	public ActionForward createTRD(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
//		specific permission check
		if(!isAuthorized("SFG_UI_SCT_CREATE_ENTITY_TRD", request)){
			throw new com.stercomm.customers.webapps.security.UnauthorizedException();
		}
		
		EntityDAO dao = new EntityDAO(getHibernateSession());
		Entity entity = dao.getNewInstance();
		
		entity.setCreateBean(true);
		entity.setNewBean(true);
		entity.setService("TRD");
		
		request.getSession().setAttribute("entityBean", entity);
		return mapping.findForward("newEntity");
	}

	public ActionForward load(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String id_s = request.getParameter("id");
		if (id_s!=null){
			
			int entityId = Integer.parseInt(id_s);
			
			EntityDAO dao = new EntityDAO(getHibernateSession());
			Entity entity = dao.getEntity(entityId);
			
			if(entity.getService().equalsIgnoreCase("SCT")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_EDIT_ENTITY_SCT", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
			}
			if(entity.getService().equalsIgnoreCase("SDD")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_EDIT_ENTITY_SDD", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
			}
			if(entity.getService().equalsIgnoreCase("XCT")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_EDIT_ENTITY_XCT", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
			}
			if(entity.getService().equalsIgnoreCase("GPL")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_EDIT_ENTITY_GPL", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
			}
			if(entity.getService().equalsIgnoreCase("ROI")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_EDIT_ENTITY_ROI", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}			
			}
			
			if(entity.getService().equalsIgnoreCase("TRD")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_EDIT_ENTITY_TRD", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}			
			}
					
			
			ScheduleDAO schDao = new ScheduleDAO(getHibernateSession());
			List schList = schDao.getSchedules(entityId);
			entity.setSchedules(schList);
			
			log.debug("loaded entity: "+entity);
			
			request.getSession().setAttribute("entityBean", entity);
			return mapping.findForward("loadEntity");
		}
		throw new RuntimeException("id parameter not found in request");		
	}
	
	public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String id_s = request.getParameter("id");
		if (id_s!=null){
			
			int entityId = Integer.parseInt(id_s);
			
			EntityDAO dao = new EntityDAO(getHibernateSession());
			Entity entity = dao.getEntity(entityId);
			
			if(entity.getService().equalsIgnoreCase("SCT")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_DELETE_ENTITY_SCT", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
			}
			if(entity.getService().equalsIgnoreCase("SDD")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_DELETE_ENTITY_SDD", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
			}
			if(entity.getService().equalsIgnoreCase("XCT")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_DELETE_ENTITY_XCT", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
			}
			if(entity.getService().equalsIgnoreCase("GPL")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_DELETE_ENTITY_GPL", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
			}
			if(entity.getService().equalsIgnoreCase("ROI")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_DELETE_ENTITY_ROI", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
				
			}
			
			if(entity.getService().equalsIgnoreCase("TRD")){
//				specific permission check
				if(!isAuthorized("SFG_UI_SCT_DELETE_ENTITY_TRD", request)){
					throw new com.stercomm.customers.webapps.security.UnauthorizedException();
				}
			}
				
			ScheduleDAO schDao = new ScheduleDAO(getHibernateSession());
			List schList = schDao.getSchedules(entityId);
			entity.setSchedules(schList);
			
			log.debug("loaded entity for delete: "+entity);
			
			request.getSession().setAttribute("entityBean", entity);
			return mapping.findForward("deleteEntity");
		}
		throw new RuntimeException("id parameter not found in request");		
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public static Logger getLog() {
		return log;
	}
	
	
	
}
