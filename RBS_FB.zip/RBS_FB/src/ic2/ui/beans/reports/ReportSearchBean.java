/**
 * 
 */
package ic2.ui.beans.reports;

import ic2.ui.beans.IC2UIBean;

/**
 * @author Ravi K Patel
 * created May 4, 2006
 */
public class ReportSearchBean extends IC2UIBean {
private static final long serialVersionUID = 1L;
	
	private String reportType;
	private String reportStartDate;
	private String reportEndDate;
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getReportEndDate() {
		return reportEndDate;
	}
	public void setReportEndDate(String reportEndDate) {
		this.reportEndDate = reportEndDate;
	}
	public String getReportStartDate() {
		return reportStartDate;
	}
	public void setReportStartDate(String reportStartDate) {
		this.reportStartDate = reportStartDate;
	}
	public String getReportType() {
		return reportType;
	}
	public void setReportType(String reportType) {
		this.reportType = reportType;
	}
}
