
package com.stercomm.customers.rbs.sct.ui.forms;

import org.apache.log4j.Logger;


/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
public class ChangeApproveForm extends BaseValidatorActionForm {
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private static final Logger log = Logger.getLogger(ChangeApproveForm.class);
	
	private String approverComments;

	public String getApproverComments() {
		return approverComments;
	}

	public void setApproverComments(String approverComments) {
		this.approverComments = approverComments;
	}

	

	
	
}
