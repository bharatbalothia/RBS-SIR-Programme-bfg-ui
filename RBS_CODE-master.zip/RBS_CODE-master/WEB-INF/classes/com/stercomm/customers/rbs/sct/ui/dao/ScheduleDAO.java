/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dao;


import java.util.List;
//import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import com.stercomm.customers.rbs.sct.ui.dto.Schedule;
import com.stercomm.customers.rbs.sct.ui.dtoimpl.ScheduleImpl;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unchecked", "unused", "deprecation"})
public class ScheduleDAO extends BaseHibernateDAO {
	private static final long serialVersionUID = 1L;

	//private static final Logger log = Logger.getLogger(ScheduleDAO.class);


	public ScheduleDAO(Session hibSession) {
		super(hibSession);
	}
	
	
	public Schedule getNewSchedule(){
		return new ScheduleImpl();
	}
	
	
	public boolean commit(Schedule schedule){
		Session session = getHibernateSession();
		session.saveOrUpdate(schedule);
		return true;
	}
	
	
	
	
	
	public Schedule getSchedule(Integer scheduleId){
		
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.schedule.byId");
		query.setInteger("scheduleId", scheduleId.intValue());
		Schedule schedule = (Schedule)query.uniqueResult();
		return schedule;
	}
	
	
	public List getSchedules(int entityId){
		Session session = getHibernateSession();
		//Query query = session.getNamedQuery("dao.bundle.list.fileMonitor");
		Query query = session.createQuery("from ScheduleImpl sch where sch.entity=:entityId");
		query.setInteger("entityId", entityId);
		List results = query.list();
		return results;
	}
	
	public List getErrorBundles(){
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.bundle.list.error");
		List results = query.list();
		return results;
	}
	
	
//	public ResultMeta getBundles(int pageNo, int pageSize){
//		ResultMeta rm = new ResultMetaImpl();
//		rm.setCurrentPage(pageNo);
//		rm.setPageSize(pageSize);
//		
//		int firstResult = rm.getFirstResult();
//		
//		Session session = getHibernateSession();
//		Query query = session.getNamedQuery("dao.bundle.list.fileMonitor");
//		query.setFirstResult(firstResult-1); //zero indexed
//		query.setMaxResults(pageSize);
//		
//		List results = query.list();
//		rm.setResultsList(results);
//		
//		query = session.getNamedQuery("dao.bundle.list.size");
//		Integer totalResults = (Integer)query.uniqueResult();
//		rm.setTotalResults(totalResults);
//		
//		
//		return rm;
//	}
//	
	

//	
//	
//	protected static final Object[] ENTITY_ID = {"entityId", java.lang.Integer.class};
//	protected static final Object[] SERVICE = {"service", java.lang.String.class};
//	protected static final Object[] IS_OUTBOUND = {"isOutbound", java.lang.Boolean.class};
//	protected static final Object[] FILE_STATUS = {"fileStatus", java.lang.Integer.class};
//	protected static final Object[] BP_STATE = {"bpState", java.lang.String.class};
//	protected static final Object[] FILENAME = {"filename", java.lang.String.class};
//	protected static final Object[] REFERENCE = {"reference", java.lang.String.class};
//	protected static final Object[] TYPE = {"type", java.lang.String.class};
//	protected static final Object[] FROM_DATE = {"fromDate", java.util.Date.class};
//	protected static final Object[] TO_DATE = {"toDate", java.util.Date.class};
//
//	
//	public ResultMeta getBundles(int pageNo, int pageSize, FileSearchCriteria criteria){
//		Session session = getHibernateSession();
//		Query query = session.getNamedQuery("dao.bundle.list.fileMonitor");
//		String qsMain = query.getQueryString();
//		
//		query = session.getNamedQuery("dao.bundle.list.fileMonitor.size");
//		String qsCount = query.getQueryString();
//		query = null;
//		
//		ResultMeta rm = new ResultMetaImpl();
//		rm.setCurrentPage(pageNo);
//		rm.setPageSize(pageSize);
//		int firstResult = rm.getFirstResult();
//		
//		StringBuffer whereStatements =  new StringBuffer();
//		Map params = new HashMap();
//		
//		if (criteria.getEntityId()!=null){
//			whereStatements.append( " and bun.entity.entityId = :entityId");
//			params.put(ENTITY_ID, criteria.getEntityId());
//		}
//		if (!(criteria.getService()==null || criteria.getService().equals("*") || criteria.getService().equals("ALL") )){
//			whereStatements.append( " and upper(bun.entity.service) like upper(:service||'%')");
//			params.put(SERVICE, criteria.getService());
//		}
//		if (!(criteria.getDirection()==null || criteria.getDirection().equals("ALL")|| criteria.getDirection().equals("*"))){
//			whereStatements.append( " and bun.outbound = :isOutbound");
//			params.put(IS_OUTBOUND, criteria.getDirection().equalsIgnoreCase("outbound")?Boolean.TRUE:Boolean.FALSE);
//		}
//		if (!(criteria.getFileStatus()==null || criteria.getFileStatus().equals("ALL") || criteria.getFileStatus().equals("*"))){
//			whereStatements.append( " and upper(bun.status) like upper(:fileStatus||'%')");
//			params.put(FILE_STATUS, criteria.getFileStatus());
//		}
//		if (criteria.getBpState()!=null){
//			if (criteria.getBpState().equals("RED")){
//				whereStatements.append( " and bun.status < 0");
//			}
//			else if (criteria.getBpState().equals("GREEN")){
//				whereStatements.append( " (and bun.status=100 or bun.status=200)");
//			}
//			else if (criteria.getBpState().equals("AMBER")){ //is amber
//				whereStatements.append( " and bun.status > 0 and bun.status != 100 and  bun.status != 200");
//			}
//			
//			//params.put(BP_STATE, criteria.getBpState());
//		}
//		if (criteria.getFilename()!=null){
//			whereStatements.append( " and upper(bun.filename) like upper(:filename||'%')");
//			params.put(FILENAME, criteria.getFilename());
//		}
//		if (criteria.getReference()!=null){
//			whereStatements.append( " and upper(bun.reference) like upper(:reference||'%')");
//			params.put(REFERENCE, criteria.getReference());
//		}
//		if (! 
//				( criteria.getType()==null 
//						|| criteria.getType().length()==0
//						|| criteria.getType().equals("%") 
//						|| criteria.getType().equals("*") 
//						|| criteria.getType().equalsIgnoreCase("ALL")
//					)
//				){
//			System.out.println("*********THE TYPE IS:"+criteria.getType());
//			whereStatements.append( " and upper(bun.BType) like upper(:type||'%')");
//			params.put(TYPE, criteria.getType());
//		}
//		if (criteria.getFromDate()!=null){
//			whereStatements.append( " and bun.BTimestamp >= :fromDate");
//			params.put(FROM_DATE, criteria.getFromDate());
//		}
//		if (criteria.getToDate()!=null){
//			whereStatements.append( " and bun.BTimestamp >= :toDate");
//			params.put(TO_DATE, criteria.getToDate());
//		}
//		
//		
//		if (whereStatements.length()>0){
//			whereStatements.delete(0, 4);
//
//			qsMain += (" WHERE ");
//			qsMain +=(whereStatements.toString());
//			
//			qsCount += (" WHERE ");
//			qsCount +=(whereStatements.toString());
//		}
//		
//		System.out.println(qsMain);
//		session = getHibernateSession();
//		query = session.createQuery(qsMain);
//		Query countQuery = session.createQuery(qsCount);
//		
//		
//		{
//			Iterator paramKeySetIterator = params.keySet().iterator();
//			while (paramKeySetIterator.hasNext()){
//				Object[] arr = (Object[])paramKeySetIterator.next();
//				if(arr[1]==String.class){
//					query.setString((String)arr[0], (String)params.get(arr));
//					countQuery.setString((String)arr[0], (String)params.get(arr));
//				}
//				else if(arr[1]==Integer.class){
//					query.setInteger((String)arr[0], ((Integer)params.get(arr)).intValue());
//					countQuery.setInteger((String)arr[0], ((Integer)params.get(arr)).intValue());
//				}
//				else if(arr[1]==Double.class){
//					query.setDouble((String)arr[0], ((Double)params.get(arr)).doubleValue());
//					countQuery.setDouble((String)arr[0], ((Double)params.get(arr)).doubleValue());
//				}
//				else if (arr[1]==Date.class){
//					query.setDate((String)arr[0], (Date)params.get(arr));
//					countQuery.setDate((String)arr[0], (Date)params.get(arr));
//				}
//				else if (arr[1]==Boolean.class){
//					query.setBoolean((String)arr[0], ((Boolean)params.get(arr)).booleanValue());
//					countQuery.setBoolean((String)arr[0], ((Boolean)params.get(arr)).booleanValue());
//				}
//			}
//		}
//		
//		query.setFirstResult(firstResult-1); //zero indexed
//		query.setMaxResults(pageSize);
//		
//		List results = query.list();
//		
//		Collections.sort(results, Collections.reverseOrder());
//		rm.setResultsList(results);
//		
//		Integer totalResults = (Integer)countQuery.uniqueResult();
//		rm.setTotalResults(totalResults);
//		
//		
//		return rm;
//	}
//	
}
