package com.stercomm.customers.rbs.sct.ui.dto;

import java.util.Date;
import java.util.Set;

@SuppressWarnings({"unchecked"})
public interface Bundle {
	
	/**
	 * When (status==100 || status==200)
	 */
	public static final int STATUS_GREEN = 1;
	/**
	 * When (status >=0 && !(status==100 || status==200))
	 * (ie not ERROR or GREEN_
	 */
	public static final int STATUS_RUNNING = 2;
	/**
	 * When status < 0
	 */
	
	public static final int STATUS_AMBER = 3;
	public static final int STATUS_ERROR = 4;
	
	//public static final int STATUS_GREEN_TRXERROR = 4;
	

	/**
	 * Returns an execution status code, based on the status code
	 * @return
	 */
	public int getExecutionStatus();
	
	
	/**
	 * @return the bTimestamp
	 */
	public abstract Date getBTimestamp();

	/**
	 * @param timestamp the bTimestamp to set
	 */
	public abstract void setBTimestamp(Date timestamp);

	/**
	 * @return the bType
	 */
	public abstract String getBType();
	
	/**
	 * @param timestamp the bType to set
	 */
	public abstract void setBType(String bType);
	
	/**
	 * @return the bundleId
	 */
	public abstract Long getBundleId();

	/**
	 * @param bundleId the bundleId to set
	 */
	public abstract void setBundleId(Long bundleId);

	/**
	 * @return the entity
	 */
	public abstract Entity getEntity();

	/**
	 * @param entityId the entityId to set
	 */
	public abstract void setEntity(Entity entity);

	/**
	 * @return the error
	 */
	public abstract String getError();

	/**
	 * @param error the error to set
	 */
	public abstract void setError(String error);

	/**
	 * @return the filename
	 */
	public abstract String getFilename();

	/**
	 * @param filename the filename to set
	 */
	public abstract void setFilename(String filename);

	/**
	 * @return the isOutbound
	 */
	public abstract Boolean isOutbound();

	/**
	 * @param isOutbound the isOutbound to set
	 */
	public abstract void setOutbound(Boolean isOutbound);

	/**
	 * @return the isOverride
	 */
	public abstract Boolean isOverride();

	/**
	 * @param isOverride the isOverride to set
	 */
	public abstract void setOverride(Boolean isOverride);

	/**
	 * @return the messageId
	 */
	public abstract Integer getMessageId();

	/**
	 * @param messageId the messageId to set
	 */
	public abstract void setMessageId(Integer messageId);

	/**
	 * @return the reference
	 */
	public abstract String getReference();

	/**
	 * @param reference the reference to set
	 */
	public abstract void setReference(String reference);

	/**
	 * @return the service
	 */
	public abstract String getService();

	/**
	 * @param service the service to set
	 */
	public abstract void setService(String service);
	
	/**
	 * @return the DocID
	 */
	public abstract String getDocId();

	/**
	 * @param docId the DocID to set
	 */
	public abstract void setDocId(String docId);
	/**
	 * @return the status
	 */
	public abstract Integer getStatus();

	/**
	 * @param status the status to set
	 */
	public abstract void setStatus(Integer status);

	/**
	 * @return the wf
	 */
	public abstract WFInstS getWF();

	/**
	 * @param wf the wf to set
	 */
	public abstract void setWF(WFInstS wF);
	
//	/**
//	 * @return the currentPayments
//	 */
//	public Set getCurrentPayments();
//	
//	/**
//	 * @param payments the payments to set
//	 */
//	public void setCurrentPayments(Set currentPayments);
//	
//	/**
//	 * @return the archivePayments
//	 */
//	public Set getArchivePayments() ;
//	
//	/**
//	 * @param archivePayments the archivePayments to set
//	 */
//	public void setArchivePayments(Set archivePayments);
	
	/**
	 * @return the payments
	 */
	public Set getPayments() ;

	/**
	 * @param payments the payments to set
	 */
	public void setPayments(Set payments);

}