/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.log4j.Logger;

import javax.security.cert.CertificateException;
import javax.security.cert.X509Certificate;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.util.MessageResources;

import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;
import com.stercomm.customers.rbs.sct.ui.forms.TrustedCertsForm;

@SuppressWarnings({"unused", "unchecked"})
public class TrustedCertsNameAction extends BaseTrustedCertsWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(TrustedCertsNameAction.class);

	public ActionForward next(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		if(validateForm(form, request)){
			return super.next(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
	}

	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.save(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request,form);
			return mapping.findForward("viewForm");
		}


	}
	
	public ActionForward trustedCertsConfirm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.trustedCertsConfirm(mapping, setDefaults(form, request), request, response);
		} else {
			setCustom(request,form);
			return mapping.findForward("viewForm");
		}

	}
	/*
	 * Can't get ValidatorForm to work so doing it manually (MB)
	 */
	private boolean validateForm(ActionForm form, HttpServletRequest request){

		TrustedCertsForm tcf = (TrustedCertsForm)form;
		TrustedCert tc = getTrustedCert(request);
		ActionMessages messages = new ActionMessages();
		@SuppressWarnings("unused")
		MessageResources messageResources = getResources(request);
		boolean rtn=true;
		//String entityValidate = "";
		//String entityMessage = "";

		/*
		 * check we have a file
		 */
		if(tcf.getCertificateFile()==null ||tcf.getCertificateFile().getFileName().equalsIgnoreCase("") ){
			log.debug("Trusted Certificate file is required.");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateFile.required" ));
			rtn=false;
		} else {

			/*
			 * check we have a valid X509 certificate
			 */
			try {
				byte[] certData = tcf.getCertificateFile().getFileData();
				X509Certificate cert = X509Certificate.getInstance(certData);
				//tc.setX509Certificate(cert);
				//request.setAttribute("trustedCertBean", tc);
				log.debug("Cert OK: " + cert.toString());
			} catch (FileNotFoundException e) {
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateFile.notfound" ));
				rtn=false;
			} catch (IOException e) {
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateFile.notloaded" ));
				rtn=false;
			} catch (CertificateException e) {
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateFile.invalid" ));
				rtn=false;
			}
		}



		saveMessages(request, messages);
		return rtn;
	}

	private ActionForm setDefaults(ActionForm form, HttpServletRequest request){

		//TrustedCert trustedCert = (TrustedCert)request.getSession().getAttribute("trustedCertBean");
		TrustedCertsForm trustedCertsForm=(TrustedCertsForm)form;
		/*
		 * set defaults here
		 */
		
		//do nothing
		
		return (ActionForm)trustedCertsForm;
	}

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		setCustom(request, form);
		return super.viewForm(mapping, form, request, response);
	}

	private void setCustom(HttpServletRequest request, ActionForm form){
		//do nothing
	}

}

