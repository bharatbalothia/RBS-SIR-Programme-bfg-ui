/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dtoimpl;
import org.apache.log4j.Logger;


import com.stercomm.customers.rbs.sct.ui.dto.IError;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class ErrorImpl extends BaseHibernateBeanImpl implements IError{

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(ErrorImpl.class);
	
	private String code;
	private String name;
	private String description;
	private String action;
	private String logfile;
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#getCode()
	 */
	public String getCode() {
		return code;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#setCode(java.lang.String)
	 */
	public void setCode(String code) {
		this.code = code;
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#getName()
	 */
	public String getName() {
		return name;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#setName(java.lang.String)
	 */
	public void setName(String name) {
		this.name = name;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#getDescription()
	 */
	public String getDescription() {
		return description;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#setDescription(java.lang.String)
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#getAction()
	 */
	public String getAction() {
		return action;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#setAction(java.lang.String)
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#getLogfile()
	 */
	public String getLogfile() {
		return logfile;
	}
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dtoimpl.Error#setLogfile(java.lang.String)
	 */
	public void setLogfile(String logfile) {
		this.logfile = logfile;
	}
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	
	
	
}
