/**
 * 
 */
package com.stercomm.customers.webapps.util.struts;

import org.apache.struts.util.MessageResources;
import org.apache.struts.util.PropertyMessageResourcesFactory;

/**
 * @author Ravi K Patel
 * created Apr 25, 2006
 */
public class ReloadablePropertyMessageResourcesFactory extends
		PropertyMessageResourcesFactory {

	private static final long serialVersionUID = 1L;

	
	public MessageResources createResources(String config) {
	    return new ReloadablePropertyMessageResources(this, config, this.getReturnNull());
	  }
}
