/**
 * 
 */
package ic2.ui.beans.reports;

import java.io.Serializable;

/**
 * @author Ravi K Patel
 * created May 4, 2006
 */
public class ReportRunnerBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private ReportSettingsBean reportSettings;
	private String reportStartDate;
	private String reportEndDate;
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getReportEndDate() {
		return reportEndDate;
	}
	public void setReportEndDate(String reportEndDate) {
		this.reportEndDate = reportEndDate;
	}
	public ReportSettingsBean getReportSettings() {
		return reportSettings;
	}
	public void setReportSettings(ReportSettingsBean reportSettings) {
		this.reportSettings = reportSettings;
	}
	public String getReportStartDate() {
		return reportStartDate;
	}
	public void setReportStartDate(String reportStartDate) {
		this.reportStartDate = reportStartDate;
	}
	
	
}
