package com.stercomm.customers.rbs.sct.ui.change;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

import com.sterlingcommerce.woodstock.services.XLogger;
import com.sterlingcommerce.woodstock.util.BaseUtil;
import com.sterlingcommerce.woodstock.util.frame.jdbc.Conn;
import com.sterlingcommerce.woodstock.util.frame.jdbc.JDBCService;

@SuppressWarnings({"unused", "unchecked", "deprecation"})
public class ChangeControl extends ChangeConstants {

	private String changeID; //pkey for the record

	private String operation; //change operation - CREATE,UPDATE,DELETE
	private int status; //status of change - PENDING(0), REJECTED(1), ACCEPTED(2), FAILED(-1)
	private String objectType; //original SI object type being changed
	private String objectKey; //Key for original SI Object being changed

	private String changer; //user making the change
	private String dateChanged; //date change was requested
	private String approver; //user approving/rejecting the change
	private String dateApproved; //date change was approved/rejected
	private String changerNotes; //comments made by changer
	private String approverNotes; //comments made by approver


	private String actionType; //type of change e.g. XAPI_manageCertificae, CUSTOM_xyzClasss
	private byte[] actionObject; //DATA_ID for the action object that will fulfil the operation

	private String resultType; //type of object view that displays when action is fulfilled
	private byte[] resultObject; //DATA_ID for the object view when the action is fulfilled
	private String resultMeta1; //meta-data about the object when using CREATE action (searchable)
	private String resultMeta2; //meta-data about the object when using CREATE action (searchable)
	private String resultMeta3; //meta-data about the object when using CREATE action (searchable)

	private static XLogger log;

	public ChangeControl() throws Exception{
		init(true, false);
	}
	public ChangeControl(String cid) throws Exception{
		this.setChangeID(cid);
		init(false, true);
	}

	private void init(boolean isNew, boolean load) throws Exception{
		log = new XLogger("ChangeControl", "ChangeControl");
		if(isNew){
			this.setChangeID(BaseUtil.createGUID());
			this.setStatus(ChangeControl.STATUS_PENDING);
		} else {
			if(load){
				load();
			}
		}
	}

	public String getChangeID() {
		return changeID;
	}
	public void setChangeID(String changeID) {
		this.changeID = changeID;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	public String getObjectKey() {
		return objectKey;
	}
	public void setObjectKey(String objectKey) {
		this.objectKey = objectKey;
	}
	public String getChanger() {
		return changer;
	}
	public void setChanger(String changer) {
		this.changer = changer;
	}
	public String getDateChanged() {
		return dateChanged;
	}
	public void setDateChanged(String dateChanged) {
		this.dateChanged = dateChanged;
	}
	public String getApprover() {
		return approver;
	}
	public void setApprover(String approver) {
		this.approver = approver;
	}
	public String getDateApproved() {
		return dateApproved;
	}
	public void setDateApproved(String dateApproved) {
		this.dateApproved = dateApproved;
	}
	public String getChangerNotes() {
		return changerNotes;
	}
	public void setChangerNotes(String changerNotes) {
		this.changerNotes = changerNotes;
	}
	public String getApproverNotes() {
		return approverNotes;
	}
	public void setApproverNotes(String approverNotes) {
		this.approverNotes = approverNotes;
	}
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	public byte[] getActionObject() {
		return actionObject;
	}
	public void setActionObject(byte[] actionObject) {
		this.actionObject = actionObject;
	}
	public String getResultType() {
		return resultType;
	}
	public void setResultType(String resultType) {
		this.resultType = resultType;
	}
	public byte[] getResultObject() {
		return resultObject;
	}
	public void setResultObject(byte[] resultObject) {
		this.resultObject = resultObject;
	}
	public String getResultMeta1() {
		return resultMeta1;
	}
	public void setResultMeta1(String resultMeta1) {
		this.resultMeta1 = resultMeta1;
	}
	public String getResultMeta2() {
		return resultMeta2;
	}
	public void setResultMeta2(String resultMeta2) {
		this.resultMeta2 = resultMeta2;
	}
	public String getResultMeta3() {
		return resultMeta3;
	}
	public void setResultMeta3(String resultMeta3) {
		this.resultMeta3 = resultMeta3;
	}

	public static boolean isPendingMetaUnique(int col, String objectType, String value) throws Exception{
		boolean ret =false;
		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;

		try {

			String sCol = "RESULT_META"+col;

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "SELECT CHANGE_ID FROM FB_CHANGE_CONTROL WHERE UPPER("+sCol+")=? AND OBJECT_TYPE=? AND STATUS=?";

			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setString(1, value.toUpperCase());
			spstmt.setString(2, objectType);
			spstmt.setInt(3, STATUS_PENDING);

			rs = spstmt.executeQuery();
			if(rs.next()){
				ret = false;
			} else {
				ret = true;
			}

		} catch (SQLException sqle) {
			log.logException("SQL Error querying the FB_CHANGE_CONTROL record", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error querying the FB_CHANGE_CONTROL record", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}
		return ret;		

	}

	public static LinkedList<ChangeControl> search(String col, String value, String objectType, int status) throws Exception{

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;
		LinkedList<ChangeControl> results = null;

		try {

			if(value==null){
				value="%";
			} else {
				value="%"+value+"%";
			}

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "SELECT CHANGE_ID FROM FB_CHANGE_CONTROL WHERE UPPER("+col+") LIKE ? AND OBJECT_TYPE=? AND STATUS=?";

			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setString(1, value.toUpperCase());
			spstmt.setString(2, objectType);
			spstmt.setInt(3, status);

			rs = spstmt.executeQuery();
			if(rs!=null){
				while(rs.next()){
					if(results==null){
						results=new LinkedList<ChangeControl>();
					}
					ChangeControl cc = new ChangeControl(rs.getString(1));
					//System.out.println("LOADING CC|:" + cc.getChangeID());
					//System.out.println("LOADING CC|:" + cc.getResultMeta1());
					results.add(cc);
				}
			}

		} catch (SQLException sqle) {
			log.logException("SQL Error searching the FB_CHANGE_CONTROL record", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error searching the FB_CHANGE_CONTROL record", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}
		return results;		

	}

	public void load() throws Exception{

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "SELECT OPERATION,STATUS,OBJECT_TYPE,OBJECT_KEY,CHANGE_USER,CHANGE_DATE,CHANGE_COMMENTS,APPROVE_USER, APPROVE_DATE, APPROVE_COMMENTS, ACTION_TYPE,ACTION_OBJECT,RESULT_TYPE,RESULT_OBJECT,RESULT_META1,RESULT_META2,RESULT_META3 FROM FB_CHANGE_CONTROL WHERE CHANGE_ID=?";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setString(1, this.getChangeID());

			rs= spstmt.executeQuery();
			boolean bOne=false;
			while(rs.next()){
				if(bOne==true){
					throw new Exception("Fatal ChangeControl load() error. The primary key has been violated.");
				}
				this.setOperation(rs.getString(1));
				this.setStatus(rs.getInt(2));
				this.setObjectType(rs.getString(3));
				this.setObjectKey(rs.getString(4));
				this.setChanger(rs.getString(5));
				this.setDateChanged(rs.getString(6));
				this.setChangerNotes(rs.getString(7));
				this.setApprover(rs.getString(8));
				this.setDateApproved(rs.getString(9));
				this.setApproverNotes(rs.getString(10));
				this.setActionType(rs.getString(11));
				this.setActionObject(JDBCService.getBlob(conn, rs, 12));
				this.setResultType(rs.getString(13));
				this.setResultObject(JDBCService.getBlob(conn, rs, 14));
				this.setResultMeta1(rs.getString(15));
				this.setResultMeta2(rs.getString(16));
				this.setResultMeta3(rs.getString(17));

				bOne=true;
			}

		} catch (SQLException sqle) {
			log.logException("SQL Error loading the FB_CHANGE_CONTROL record", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error loading the FB_CHANGE_CONTROL record", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

	}

	public void insert() throws Exception {

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "INSERT INTO FB_CHANGE_CONTROL (CHANGE_ID,OPERATION,STATUS,OBJECT_TYPE,OBJECT_KEY,CHANGE_USER,CHANGE_DATE,CHANGE_COMMENTS,ACTION_TYPE,ACTION_OBJECT,RESULT_TYPE,RESULT_OBJECT,RESULT_META1,RESULT_META2,RESULT_META3) VALUES (?,?,?,?,?,?,sysdate,?,?,?,?,?,?,?,? )";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setString(1, this.getChangeID());
			spstmt.setString(2, this.getOperation());
			spstmt.setInt(3, this.getStatus());
			spstmt.setString(4, this.getObjectType());
			spstmt.setString(5, this.getObjectKey());
			spstmt.setString(6, this.getChanger());
			spstmt.setString(7, this.getChangerNotes());
			spstmt.setString(8, this.getActionType());
			JDBCService.setBlob(conn, spstmt, 9, this.getActionObject());
			spstmt.setString(10, this.getResultType());
			JDBCService.setBlob(conn, spstmt, 11, this.getResultObject());
			spstmt.setString(12, this.getResultMeta1());
			spstmt.setString(13, this.getResultMeta2());
			spstmt.setString(14, this.getResultMeta3());

			@SuppressWarnings("unused")
			int i = spstmt.executeUpdate();

		} catch (SQLException sqle) {
			log.logException("SQL Error persisting the FB_CHANGE_CONTROL record", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error persisting the FB_CHANGE_CONTROL record", e);
			throw e;
		} finally {
			try {
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

	}
	
	public void accept(String user, String comments) throws Exception{
		this.setApprover(user);
		this.setApproverNotes(comments);
		this.updateStatus(ChangeConstants.STATUS_ACCEPTED);
	}
	
	public void reject(String user, String comments) throws Exception{
		this.setApprover(user);
		this.setApproverNotes(comments);
		this.updateStatus(ChangeConstants.STATUS_REJECTED);
	}
	
	public void failed(String user, String comments) throws Exception{
		this.setApprover(user);
		this.setApproverNotes(comments);
		this.updateStatus(ChangeConstants.STATUS_FAILED);
	}
	
	private void updateStatus(int status) throws Exception {

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "UPDATE FB_CHANGE_CONTROL SET STATUS=?, APPROVE_USER=?, APPROVE_DATE=sysdate, APPROVE_COMMENTS=? WHERE CHANGE_ID=?";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setInt(1, status);
			spstmt.setString(2, this.getApprover());
			spstmt.setString(3, this.getApproverNotes());
			spstmt.setString(4, this.getChangeID());

			int i = spstmt.executeUpdate();
			if(i!=1){
				throw new Exception("The Change Control status could bot be updated.");
			}

		} catch (SQLException sqle) {
			log.logException("SQL Error updating the FB_CHANGE_CONTROL record", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error updating the FB_CHANGE_CONTROL record", e);
			throw e;
		} finally {
			try {
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

	}
	
	public String getStatusText(){
		if(getStatus()==ChangeControl.STATUS_PENDING){
			return ChangeControl.STATUS_PENDING_TEXT;
		} else if(getStatus()==ChangeControl.STATUS_REJECTED){
			return ChangeControl.STATUS_REJECTED_TEXT;
		} else if(getStatus()==ChangeControl.STATUS_ACCEPTED){
			return ChangeControl.STATUS_ACCEPTED_TEXT;
		} else if(getStatus()==ChangeControl.STATUS_FAILED){
			return ChangeControl.STATUS_FAILED_TEXT;
		} else {
			return ChangeControl.STATUS_UNKNOWN_TEXT;
		}
	}
	
	public String getShortType(){
		String st = "Unknown";
		try {
			ChangeViewer cview = (ChangeViewer) Class.forName(this.getObjectType()).newInstance(); 
			st = cview.getObjectType();
		}catch(Exception e){
			//do nothing
		}
		return st;
	}
	
	public boolean isPending(){
		return this.getStatus()==ChangeConstants.STATUS_PENDING;
	}

}
