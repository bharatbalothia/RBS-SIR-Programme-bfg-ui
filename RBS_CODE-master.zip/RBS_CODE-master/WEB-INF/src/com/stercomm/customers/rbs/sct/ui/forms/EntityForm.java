/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.forms;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
//public class EntityForm extends BaseActionForm {
public class EntityForm extends ValidatorForm {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(EntityForm.class);
	/*
	private String requesterDN;
	private String responderDN;
	private String serviceName;
	private String requestType;
	private String SNF;
	private String trace;
	private String deliveryNotif;
	private String deliveryNotifDN;
	private String deliveryNotifRT;
	private String requestRef;
	private String fileDesc;
	private String fileInfo;
	private String transferDesc;
	private String transferInfo;
	 */
	private String entity = "";
	private String service = "";
	private String requesterDN = "";
	private String responderDN = "";
	private String serviceName = "";
	private String requestType = "";
	private String SNF = "";
	private String trace = "";
	private String deliveryNotif = "";
	private String deliveryNotifDN = "";
	private String deliveryNotifRT = "";
	private String requestRef = "";
	private String fileDesc = "";
	private String fileInfo = "";
	private String transferDesc = "";
	private String transferInfo = "";
	private String compression = "";
	private String mailboxPathIn = "";
	private String mailboxPathOut = "";
	private String mqQueueIn = "";
	private String mqQueueOut = "";
	private String maxTransferBulk = "";
	private String maxBulksPerFile = "";
	private String startOfDay = "";
	private String endOfDay = "";
	
	private String cdNode = "";
	private String idfWTOMsgId = "";
	private String cdfWTOMsgId = "";
	private String sdfWTOMsgId = "";
	private String rsfWTOMsgId = "";
	private String dnfWTOMsgId = "";
	private String dvfWTOMsgId = "";
	private String msrWTOMsgId = "";
	private String psrWTOMsgId = "";
	private String drrWTOMsgId = "";
	private String rtfWTOMsgId = "";
	private String mbpWTOMsgId = "";
	
	private String mqHost = "";
	private String mqPort = "";
	private String mqQManager = "";
	private String mqChannel = "";
	private String mqQueueName = "";
	private String mqQueueBinding = "";
	private String mqQueueContext = "";
	private String mqDebug = "";
	private String mqSSLoptions = "";
	private String mqSSLciphers = "";
	private String mqSSLkey = "";
	private String mqSSLcaCert = "";
	
	private String inboundDir = "";
	private String inboundRoutingRule = "";
	private String inboundRequestorDN = "";
	private String inboundResponderDN = "";
	private String inboundService = "";
	private String inboundType = "";
	private String[] inboundRequestType = new String[0];
	private String nonRepudiation = "" ;
	private String pauseInbound = "" ;
	private String pauseOutbound = "" ;
	
	private String routeInbound="";
	private String routeOutbound="";
	
	private String changerComments="";
	
	private String irishStep2="";
	
	private String e2eSigning;
	
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		String pageName = request.getParameter("pageName");
		if (pageName!=null ){
			if (pageName.equals("entityName")){
				//this.compression = "off";
				/*
				 * field re-use
				 */
				if(!this.service.equalsIgnoreCase("ROI")){
					this.compression = "off";
				}
				this.inboundRoutingRule = "off";
				this.inboundDir = "off";
				this.pauseInbound = "off";
				this.pauseOutbound = "off";
				this.routeInbound="on";
				this.irishStep2="off";

			}

			if (pageName.equals("entitySwift")){
				this.trace = "off";
				this.SNF = "off";
				this.deliveryNotif = "off";
				this.nonRepudiation = "off";
				/*
				 * field re-use
				 */
				if(this.service.equalsIgnoreCase("ROI")){
					this.compression = "off";
				}
			}
		}
	}
	
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	/**
	 * @return the compression
	 */
	public String getCompression() {
		return compression;
	}
	/**
	 * @param compression the compression to set
	 */
	public void setCompression(String compression) {
		this.compression = compression==null?"":compression.trim();
	}
	/**
	 * @return the deliveryNotif
	 */
	public String getDeliveryNotif() {
		return deliveryNotif;
	}
	/**
	 * @param deliveryNotif the deliveryNotif to set
	 */
	public void setDeliveryNotif(String deliveryNotif) {
		this.deliveryNotif = deliveryNotif==null?"":deliveryNotif.trim();
	}
	/**
	 * @return the deliveryNotifDN
	 */
	public String getDeliveryNotifDN() {
		return deliveryNotifDN;
	}
	/**
	 * @param deliveryNotifDN the deliveryNotifDN to set
	 */
	public void setDeliveryNotifDN(String deliveryNotifDN) {
		this.deliveryNotifDN = deliveryNotifDN==null?"":deliveryNotifDN.trim();
	}
	/**
	 * @return the deliveryNotifRT
	 */
	public String getDeliveryNotifRT() {
		return deliveryNotifRT;
	}
	/**
	 * @param deliveryNotifRT the deliveryNotifRT to set
	 */
	public void setDeliveryNotifRT(String deliveryNotifRT) {
		this.deliveryNotifRT = deliveryNotifRT==null?"":deliveryNotifRT.trim();
	}
	/**
	 * @return the endOfDay
	 */
	public String getEndOfDay() {
		return endOfDay;
	}
	/**
	 * @param endOfDay the endOfDay to set
	 */
	public void setEndOfDay(String endOfDay) {
		this.endOfDay = endOfDay==null?"":endOfDay.trim();
	}
	/**
	 * @return the entity
	 */
	public String getEntity() {
		return entity;
	}
	/**
	 * @param entity the entity to set
	 */
	public void setEntity(String entity) {
		this.entity = entity==null?"":entity.trim();
	}
	/**
	 * @return the fileDesc
	 */
	public String getFileDesc() {
		return fileDesc;
	}
	/**
	 * @param fileDesc the fileDesc to set
	 */
	public void setFileDesc(String fileDesc) {
		this.fileDesc = fileDesc==null?"":fileDesc.trim();
	}
	/**
	 * @return the fileInfo
	 */
	public String getFileInfo() {
		return fileInfo;
	}
	/**
	 * @param fileInfo the fileInfo to set
	 */
	public void setFileInfo(String fileInfo) {
		this.fileInfo = fileInfo==null?"":fileInfo.trim();
	}
	/**
	 * @return the mailboxPathIn
	 */
	public String getMailboxPathIn() {
		return mailboxPathIn;
	}
	/**
	 * @param mailboxPathIn the mailboxPathIn to set
	 */
	public void setMailboxPathIn(String mailboxPathIn) {
		this.mailboxPathIn = mailboxPathIn==null?"":mailboxPathIn.trim();
	}
	/**
	 * @return the mailboxPathOut
	 */
	public String getMailboxPathOut() {
		return mailboxPathOut;
	}
	/**
	 * @param mailboxPathOut the mailboxPathOut to set
	 */
	public void setMailboxPathOut(String mailboxPathOut) {
		this.mailboxPathOut = mailboxPathOut==null?"":mailboxPathOut.trim();
	}
	/**
	 * @return the maxBulksPerFile
	 */
	public String getMaxBulksPerFile() {
		return maxBulksPerFile;
	}
	/**
	 * @param maxBulksPerFile the maxBulksPerFile to set
	 */
	public void setMaxBulksPerFile(String maxBulksPerFile) {
		this.maxBulksPerFile = maxBulksPerFile==null?"":maxBulksPerFile.trim();
	}
	/**
	 * @return the maxTransferBulk
	 */
	public String getMaxTransferBulk() {
		return maxTransferBulk;
	}
	/**
	 * @param maxTransferBulk the maxTransferBulk to set
	 */
	public void setMaxTransferBulk(String maxTransferBulk) {
		this.maxTransferBulk = maxTransferBulk==null?"":maxTransferBulk.trim();
	}
	/**
	 * @return the mqQueueIn
	 */
	public String getMqQueueIn() {
		return mqQueueIn;
	}
	/**
	 * @param mqQueueIn the mqQueueIn to set
	 */
	public void setMqQueueIn(String mqQueueIn) {
		this.mqQueueIn = mqQueueIn==null?"":mqQueueIn.trim();
	}
	/**
	 * @return the mqQueueOut
	 */
	public String getMqQueueOut() {
		return mqQueueOut;
	}
	/**
	 * @param mqQueueOut the mqQueueOut to set
	 */
	public void setMqQueueOut(String mqQueueOut) {
		this.mqQueueOut = mqQueueOut==null?"":mqQueueOut.trim();
	}
	/**
	 * @return the requesterDN
	 */
	public String getRequesterDN() {
		return requesterDN;
	}
	/**
	 * @param requesterDN the requesterDN to set
	 */
	public void setRequesterDN(String requesterDN) {
		this.requesterDN = requesterDN==null?"":requesterDN.trim();
	}
	/**
	 * @return the requestRef
	 */
	public String getRequestRef() {
		return requestRef;
	}
	/**
	 * @param requestRef the requestRef to set
	 */
	public void setRequestRef(String requestRef) {
		this.requestRef = requestRef==null?"":requestRef.trim();
	}
	/**
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}
	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType==null?"":requestType.trim();
	}
	/**
	 * @return the responderDN
	 */
	public String getResponderDN() {
		return responderDN;
	}
	/**
	 * @param responderDN the responderDN to set
	 */
	public void setResponderDN(String responderDN) {
		this.responderDN = responderDN==null?"":responderDN.trim();
	}
	/**
	 * @return the service
	 */
	public String getService() {
		return service;
	}
	/**
	 * @param service the service to set
	 */
	public void setService(String service) {
		this.service = service==null?"":service.trim();
	}
	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}
	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName==null?"":serviceName.trim();
	}
	/**
	 * @return the sNF
	 */
	public String getSNF() {
		return SNF;
	}
	/**
	 * @param snf the sNF to set
	 */
	public void setSNF(String snf) {
		SNF = snf==null?"":snf.trim();
	}
	/**
	 * @return the startOfDay
	 */
	public String getStartOfDay() {
		return startOfDay;
	}
	/**
	 * @param startOfDay the startOfDay to set
	 */
	public void setStartOfDay(String startOfDay) {
		this.startOfDay = startOfDay==null?"":startOfDay.trim();
	}
	/**
	 * @return the trace
	 */
	public String getTrace() {
		return trace;
	}
	/**
	 * @param trace the trace to set
	 */
	public void setTrace(String trace) {
		this.trace = trace==null?"":trace.trim();
	}
	/**
	 * @return the transferDesc
	 */
	public String getTransferDesc() {
		return transferDesc;
	}
	/**
	 * @param transferDesc the transferDesc to set
	 */
	public void setTransferDesc(String transferDesc) {
		this.transferDesc = transferDesc==null?"":transferDesc.trim();
	}
	/**
	 * @return the transferInfo
	 */
	public String getTransferInfo() {
		return transferInfo;
	}
	/**
	 * @param transferInfo the transferInfo to set
	 */
	public void setTransferInfo(String transferInfo) {
		this.transferInfo = transferInfo==null?"":transferInfo.trim();
	}

	public String getCdNode() {
		return cdNode;
	}

	public void setCdNode(String cdNode) {
		this.cdNode = cdNode==null?"":cdNode.trim();
	}

	public String getCdfWTOMsgId() {
		return cdfWTOMsgId;
	}

	public void setCdfWTOMsgId(String cdfWTOMsgId) {
		this.cdfWTOMsgId = cdfWTOMsgId==null?"":cdfWTOMsgId.trim();
	}

	public String getDnfWTOMsgId() {
		return dnfWTOMsgId;
	}

	public void setDnfWTOMsgId(String dnfWTOMsgId) {
		this.dnfWTOMsgId = dnfWTOMsgId==null?"":dnfWTOMsgId.trim();
	}

	public String getDrrWTOMsgId() {
		return drrWTOMsgId;
	}

	public void setDrrWTOMsgId(String drrWTOMsgId) {
		this.drrWTOMsgId = drrWTOMsgId==null?"":drrWTOMsgId.trim();
	}

	public String getDvfWTOMsgId() {
		return dvfWTOMsgId;
	}

	public void setDvfWTOMsgId(String dvfWTOMsgId) {
		this.dvfWTOMsgId = dvfWTOMsgId==null?"":dvfWTOMsgId.trim();
	}

	public String getIdfWTOMsgId() {
		return idfWTOMsgId;
	}

	public void setIdfWTOMsgId(String idfWTOMsgId) {
		this.idfWTOMsgId = idfWTOMsgId==null?"":idfWTOMsgId.trim();
	}

	public String getMsrWTOMsgId() {
		return msrWTOMsgId;
	}

	public void setMsrWTOMsgId(String msrWTOMsgId) {
		this.msrWTOMsgId = msrWTOMsgId==null?"":msrWTOMsgId.trim();
	}

	public String getPsrWTOMsgId() {
		return psrWTOMsgId;
	}

	public void setPsrWTOMsgId(String psrWTOMsgId) {
		this.psrWTOMsgId = psrWTOMsgId==null?"":psrWTOMsgId.trim();
	}

	public String getRsfWTOMsgId() {
		return rsfWTOMsgId;
	}

	public void setRsfWTOMsgId(String rsfWTOMsgId) {
		this.rsfWTOMsgId = rsfWTOMsgId==null?"":rsfWTOMsgId.trim();
	}

	public String getSdfWTOMsgId() {
		return sdfWTOMsgId;
	}

	public void setSdfWTOMsgId(String sdfWTOMsgId) {
		this.sdfWTOMsgId = sdfWTOMsgId==null?"":sdfWTOMsgId.trim();
	}
	
	public String getRtfWTOMsgId() {
		return rtfWTOMsgId;
	}

	public void setRtfWTOMsgId(String rtfWTOMsgId) {
		this.rtfWTOMsgId = rtfWTOMsgId==null?"":rtfWTOMsgId.trim();
	}
	
	public String getMbpWTOMsgId() {
		return mbpWTOMsgId;
	}

	public void setMbpWTOMsgId(String mbpWTOMsgId) {
		this.mbpWTOMsgId = mbpWTOMsgId==null?"":mbpWTOMsgId.trim();
	}
	
	public void setMqHost(String mqHost) {
		this.mqHost = mqHost==null?"":mqHost.trim();
	}
	public void setMqPort(String mqPort) {
		this.mqPort = mqPort==null?"":mqPort.trim();
	}
	public void setMqQManager(String mqQManager) {
		this.mqQManager = mqQManager==null?"":mqQManager.trim();
	}
	public void setMqChannel(String mqChannel) {
		this.mqChannel = mqChannel==null?"":mqChannel.trim();
	}
	public void setMqQueueName(String mqQueueName) {
		this.mqQueueName = mqQueueName==null?"":mqQueueName.trim();
	}
	public void setMqQueueBinding(String mqQueueBinding) {
		this.mqQueueBinding = mqQueueBinding==null?"":mqQueueBinding.trim();
	}
	public void setMqQueueContext(String mqQueueContext) {
		this.mqQueueContext = mqQueueContext==null?"":mqQueueContext.trim();
	}
	public void setMqDebug(String mqDebug) {
		this.mqDebug = mqDebug==null?"":mqDebug.trim();
	}
	public void setMqSSLoptions(String mqSSLoptions) {
		this.mqSSLoptions = mqSSLoptions==null?"":mqSSLoptions.trim();
	}
	public void setMqSSLciphers(String mqSSLciphers) {
		this.mqSSLciphers = mqSSLciphers==null?"":mqSSLciphers.trim();
	}
	public void setMqSSLkey(String mqSSLkey) {
		this.mqSSLkey = mqSSLkey==null?"":mqSSLkey.trim();
	}
	public void setMqSSLcaCert(String mqSSLcaCert) {
		this.mqSSLcaCert = mqSSLcaCert==null?"":mqSSLcaCert.trim();
	}
	
	public String getMqHost(){
		return mqHost;
	}
	public String getMqPort(){
		return mqPort;
	}
	public String getMqQManager(){
		return mqQManager;
	}
	public String getMqChannel(){
		return mqChannel;
	}
	public String getMqQueueName(){
		return mqQueueName;
	}
	public String getMqQueueBinding(){
		return mqQueueBinding;
	}
	public String getMqQueueContext(){
		return mqQueueContext;
	}
	public String getMqDebug(){
		return mqDebug;
	}
	public String getMqSSLoptions(){
		return mqSSLoptions;
	}
	public String getMqSSLciphers(){
		return mqSSLciphers;
	}
	public String getMqSSLkey(){
		return mqSSLkey;
	}
	public String getMqSSLcaCert(){
		return mqSSLcaCert;
	}
	
	public String getRouteInbound(){
		return routeInbound;
	}
	
	public String getRouteOutbound(){
		return routeOutbound;
	}
	
	public String getInboundDir(){
		return inboundDir;
	}
	public String getInboundRoutingRule(){
		return inboundRoutingRule;
	}
	public String getInboundRequestorDN(){
		return inboundRequestorDN;
	}
	public String getInboundResponderDN(){
		return inboundResponderDN;
	}
	public String getInboundService(){
		return inboundService;
	}
	public String getInboundType(){
		return inboundType;
	}
	public String[] getInboundRequestType(){
		return inboundRequestType;
	}
	public String getNonRepudiation(){
		return nonRepudiation;
	}
	public String getPauseInbound(){
		return pauseInbound;
	}
	public String getPauseOutbound(){
		return pauseOutbound;
	}
	
	public void setRouteInbound(String routeInbound) {
		this.routeInbound = routeInbound==null?"":routeInbound.trim();
	}
	public void setRouteOutbound(String routeOutbound) {
		this.routeOutbound = routeOutbound==null?"":routeOutbound.trim();
	}
	
	public void setInboundDir(String inboundDir) {
		this.inboundDir = inboundDir==null?"":inboundDir.trim();
	}
	public void setInboundRoutingRule(String inboundRoutingRule) {
		this.inboundRoutingRule = inboundRoutingRule==null?"":inboundRoutingRule.trim();
	}
	public void setInboundRequestorDN(String inboundRequestorDN) {
		this.inboundRequestorDN = inboundRequestorDN==null?"":inboundRequestorDN.trim();
	}
	public void setInboundResponderDN(String inboundResponderDN) {
		this.inboundResponderDN = inboundResponderDN==null?"":inboundResponderDN.trim();
	}
	public void setInboundService(String inboundService) {
		this.inboundService = inboundService==null?"":inboundService.trim();
	}
	public void setInboundType(String inboundType) {
		this.inboundType = inboundType==null?"":inboundType.trim();
	}
	public void setInboundRequestType(String[] inboundRequestType) {
		
		this.inboundRequestType = inboundRequestType;
	}
	
	public void setNonRepudiation(String nonRepudiation) {
		this.nonRepudiation = nonRepudiation==null?"":nonRepudiation.trim();
	}
	public void setPauseInbound(String pauseInbound) {
		this.pauseInbound = pauseInbound==null?"":pauseInbound.trim();
	}
	public void setPauseOutbound(String pauseOutbound) {
		this.pauseOutbound = pauseOutbound==null?"":pauseOutbound.trim();
	}
	
	public String getChangerComments() {
		return changerComments;
	}

	public void setChangerComments(String changerComments) {
		this.changerComments = changerComments;
	}
	
	public String getIrishStep2(){
		return irishStep2;
	}
	public void setIrishStep2(String irishStep2) {
		this.irishStep2 = irishStep2==null?"":irishStep2.trim();
	}

	public String getE2eSigning() {
		return e2eSigning;
	}

	public void setE2eSigning(String signing) {
		this.e2eSigning = signing;
	}
	
	
	
}
