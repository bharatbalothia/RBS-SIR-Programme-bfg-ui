/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.forms.adapters;

//import org.apache.log4j.Logger;
import com.stercomm.customers.rbs.sct.ui.Utils;
import com.stercomm.customers.rbs.sct.ui.dto.Schedule;
import com.stercomm.customers.rbs.sct.ui.dtoimpl.ScheduleImpl;
import com.stercomm.customers.rbs.sct.ui.forms.EntityScheduleForm;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class ScheduleAdapter extends ScheduleImpl implements Schedule {

	private static final long serialVersionUID = 1L;
	//private static final Logger log = Logger.getLogger(ScheduleAdapter.class);
	
	private EntityScheduleForm esf;
	
	//private Entity entity;
//	private boolean createdBean = false;
//	private boolean newBean = false;
//	private boolean updated = false;
//	
	
	public ScheduleAdapter(EntityScheduleForm entityScheduleForm) {
		this.esf = entityScheduleForm;
	}
	

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getActive()
	 */
	public Boolean getActive() {
		return esf.getActive().equals("1")?Boolean.TRUE:Boolean.FALSE;
	}

	

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getEntity()
//	 */
//	public Entity getEntity() {
//		return entity;
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getIsWindow()
	 */
	public Boolean getIsWindow() {
		return esf.getType().equals("WINDOW")?Boolean.TRUE:Boolean.FALSE;
	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getLastRun()
//	 */
//	public Date getLastRun() {
//		return null;
//	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getNextRun()
//	 */
//	public Date getNextRun() {
//		return null;
//	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getScheduleId()
//	 */
//	public Integer getScheduleId() {
//		return null;
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getTimestart()
	 */
	public Integer getTimestart() {
//		if (esf.getTimeStart()==null || esf.getTimeStart().length()==0){
//			return null;
//		}
//		
//		StringTokenizer timeTokens = new StringTokenizer(esf.getTimeStart(), ":");
//		String hrs = timeTokens.nextToken();
//		String mins = timeTokens.nextToken();
//		
//		int hrs_i = Integer.parseInt(hrs);
//		hrs_i = hrs_i * 60;
//		
//		int mins_i = Integer.parseInt(mins);
//		
//		int totalMins = hrs_i + mins_i;
//		
//		return new Integer(totalMins);
		return Utils.timeToMin(esf.getTimeStart());
		
	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getTransThreshold()
//	 */
//	public Integer getTransThreshold() {
//		return null;
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getWindowEnd()
	 */
	public Integer getWindowEnd() {
//		if (esf.getTimeEnd()==null || esf.getTimeEnd().length()==0){
//			return null;
//		}
//		StringTokenizer timeTokens = new StringTokenizer(esf.getTimeEnd(), ":");
//		String hrs = timeTokens.nextToken();
//		String mins = timeTokens.nextToken();
//		
//		int hrs_i = Integer.parseInt(hrs);
//		hrs_i = hrs_i * 60;
//		
//		int mins_i = Integer.parseInt(mins);
//		
//		int totalMins = hrs_i + mins_i;
//		
//		return new Integer(totalMins);
		
		return Utils.timeToMin(esf.getTimeEnd());
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#getWindowInterval()
	 */
	public Integer getWindowInterval() {
		return esf.getInterval()==null||esf.getInterval().length()==0?null:new Integer(esf.getInterval());
	}

	public String getFiletype() {
		
		return esf.getFileType();
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setActive(java.lang.Boolean)
	 */
	public void setActive(Boolean active) {
		esf.setActive(active.booleanValue()?"1":"0");

	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setEntity(com.stercomm.customers.rbs.sct.ui.dto.Entity)
//	 */
//	public void setEntity(Entity entity) {
//		this.entity = entity;
//
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setIsWindow(java.lang.Boolean)
	 */
	public void setIsWindow(Boolean isWindow) {
		esf.setType(isWindow.booleanValue()?"WINDOW":"DAILY");

	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setLastRun(java.util.Date)
//	 */
//	public void setLastRun(Date lastRun) {
//		// TODO Auto-generated method stub
//
//	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setNextRun(java.util.Date)
//	 */
//	public void setNextRun(Date nextRun) {
//		// TODO Auto-generated method stub
//
//	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setScheduleId(java.lang.Integer)
//	 */
//	public void setScheduleId(Integer scheduleId) {
//		// TODO Auto-generated method stub
//
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setTimestart(java.lang.Integer)
	 */
	public void setTimestart(Integer timestart) {
//		if (timestart==null){
//			esf.setTimeStart(null);
//			return;
//		}
//		int ts = timestart.intValue();
//		int mins = ts%60;
//		int hrs = ts/60;
//		
////		String hrs_s = Integer.toString(hrs);
////		if 
//		String time = (hrs<10?"0":"")+hrs+":"+(mins<10?"0":"")+mins;
//		
		String time = Utils.minToTime(timestart);
		esf.setTimeStart(time);
	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setTransThreshold(java.lang.Integer)
//	 */
//	public void setTransThreshold(Integer transThreshold) {
//		// TODO Auto-generated method stub
//
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setWindowEnd(java.lang.Integer)
	 */
	public void setWindowEnd(Integer windowEnd) {
//		if (windowEnd==null){
//			esf.setTimeEnd(null);
//			return;
//		}
//		
//		int ts = windowEnd.intValue();
//		int mins = ts%60;
//		int hrs = ts/60;
//		
//		String time = (hrs<10?"0":"")+hrs+":"+(mins<10?"0":"")+mins;
		String time = Utils.minToTime(windowEnd);
		esf.setTimeEnd(time);

	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Schedule#setWindowInterval(java.lang.Integer)
	 */
	public void setWindowInterval(Integer windowInterval) {
		if (windowInterval==null){
			esf.setInterval(null);
			return;
		}

		esf.setInterval(windowInterval.toString());
	}
	
	public void setFiletype(String filetype) {
		System.out.print(filetype);
		esf.setFileType(filetype);
	}
	
	
	

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#isCreateBean()
//	 */
//	public boolean isCreateBean() {
//		return createdBean;
//	}
//
//	
//
//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#isNewBean()
//	 */
//	public boolean isNewBean() {
//		return newBean;
//	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#setCreateBean(boolean)
//	 */
//	public void setCreateBean(boolean createBean) {
//		this.createdBean = createBean;
//	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#setNewBean(boolean)
//	 */
//	public void setNewBean(boolean newBean) {
//		this.newBean = newBean;
//	}
//	
//	public boolean isUpdated() {
//		return this.updated;
//	}
//	
//	
//	public void setUpdated(boolean updated) {
//		this.updated = updated;		
//	}
}
