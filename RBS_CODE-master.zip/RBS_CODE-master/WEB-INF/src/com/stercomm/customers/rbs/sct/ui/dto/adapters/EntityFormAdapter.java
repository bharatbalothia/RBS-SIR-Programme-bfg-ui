/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dto.adapters;

import java.util.List;
//import org.apache.log4j.Logger;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.forms.EntityForm;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unchecked"})
public class EntityFormAdapter extends EntityForm {

	private static final long serialVersionUID = 1L;
	//private static final Logger log = Logger.getLogger(EntityFormAdapter.class);
	
	private Entity entity;

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getCompression()
	 */
	public String getCompression() {
		return entity.getCompression().toString();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getDeliveryNotifDN()
	 */
	public String getDeliveryNotifDN() {
		return entity.getDeliveryNotifDN();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getDeliveryNotifRT()
	 */
	public String getDeliveryNotifRT() {
		return entity.getDeliveryNotifRT();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getEndOfDay()
	 */
	public String getEndOfDay() {
		return entity.getEndOfDay().toString();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getEntity()
	 */
	public String getEntity() {
		return entity.getEntity();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getEntityId()
	 */
	public String getEntityId() {
		return entity.getEntityId().toString();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getFileDesc()
	 */
	public String getFileDesc() {
		return entity.getFileDesc();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getFileInfo()
	 */
	public String getFileInfo() {
		return entity.getFileInfo();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMailboxPathIn()
	 */
	public String getMailboxPathIn() {
		return entity.getMailboxPathIn();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMailboxPathOut()
	 */
	public String getMailboxPathOut() {
		return entity.getMailboxPathOut();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMaxBulksPerFile()
	 */
	public String getMaxBulksPerFile() {
		return entity.getMaxBulksPerFile().toString();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMaxTransfersPerBulk()
	 */
	public String getMaxTransfersPerBulk() {
		return entity.getMaxTransfersPerBulk().toString();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMqQueueIn()
	 */
	public String getMqQueueIn() {
		return entity.getMqQueueIn();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMqQueueOut()
	 */
	public String getMqQueueOut() {
		return entity.getMqQueueOut();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getRequestorDN()
	 */
	public String getRequestorDN() {
		return entity.getRequestorDN();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getRequestRef()
	 */
	public String getRequestRef() {
		return entity.getRequestRef();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getRequestType()
	 */
	public String getRequestType() {
		return entity.getRequestType();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getResponderDN()
	 */
	public String getResponderDN() {
		return entity.getResponderDN();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getSchedules()
	 */
	public List getSchedules() {
		return entity.getSchedules();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getService()
	 */
	public String getService() {
		return entity.getService();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getServiceName()
	 */
	public String getServiceName() {
		return entity.getServiceName();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getStartOfDay()
	 */
	public String getStartOfDay() {
		return entity.getStartOfDay().toString();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getTrace()
	 */
	public String getTrace() {
		return entity.getTrace().booleanValue()?"1":"0";
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#isDeliveryNotif()
	 */
	public String getDeliveryNotif() {
		return entity.getDeliveryNotification().booleanValue()?"1":"0";
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#isNewBean()
	 */
	public boolean isNewBean() {
		return entity.isNewBean();
	}

	/**
	 * @return
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#isSNF()
	 */
	public String getSNF() {
		return entity.getSnF().booleanValue()?"1":"0";
	}

	/**
	 * @param compression
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setCompression(java.lang.String)
	 */
	public void setCompression(String compression) {
		entity.setCompression(compression==null||compression.length()==0?Boolean.FALSE:compression.equals("on")?Boolean.TRUE:Boolean.FALSE);
	}

	/**
	 * @param createBean
	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#setCreateBean(boolean)
	 */
	public void setCreateBean(boolean createBean) {
		entity.setCreateBean(createBean);
	}

	/**
	 * @param deliveryNotif
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setDeliveryNotif(java.lang.String)
	 */
	public void setDeliveryNotif(String deliveryNotif) {
		entity.setDeliveryNotification(deliveryNotif.equals("1")?Boolean.TRUE:Boolean.FALSE);
	}

	/**
	 * @param deliveryNotifDN
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setDeliveryNotifDN(java.lang.String)
	 */
	public void setDeliveryNotifDN(String deliveryNotifDN) {
		entity.setDeliveryNotifDN(deliveryNotifDN);
	}

	/**
	 * @param deliveryNotifRT
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setDeliveryNotifRT(java.lang.String)
	 */
	public void setDeliveryNotifRT(String deliveryNotifRT) {
		entity.setDeliveryNotifRT(deliveryNotifRT);
	}

	/**
	 * @param endOfDay
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setEndOfDay(java.lang.String)
	 */
	public void setEndOfDay(String endOfDay) {
		entity.setEndOfDay(new Integer(endOfDay));
	}

	/**
	 * @param entity
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setEntity(java.lang.String)
	 */
	public void setEntity(String entity) {
		this.entity.setEntity(entity);
	}

	/**
	 * @param fileDesc
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setFileDesc(java.lang.String)
	 */
	public void setFileDesc(String fileDesc) {
		entity.setFileDesc(fileDesc);
	}

	/**
	 * @param fileInfo
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setFileInfo(java.lang.String)
	 */
	public void setFileInfo(String fileInfo) {
		entity.setFileInfo(fileInfo);
	}

	/**
	 * @param mailboxPathIn
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMailboxPathIn(java.lang.String)
	 */
	public void setMailboxPathIn(String mailboxPathIn) {
		entity.setMailboxPathIn(mailboxPathIn);
	}

	/**
	 * @param mailboxPathOut
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMailboxPathOut(java.lang.String)
	 */
	public void setMailboxPathOut(String mailboxPathOut) {
		entity.setMailboxPathOut(mailboxPathOut);
	}

	/**
	 * @param maxBulksPerFile
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMaxBulksPerFile(java.lang.String)
	 */
	public void setMaxBulksPerFile(String maxBulksPerFile) {
		entity.setMaxBulksPerFile(new Integer(maxBulksPerFile));
	}

	/**
	 * @param maxTransfersPerBulk
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMaxTransfersPerBulk(java.lang.String)
	 */
	public void setMaxTransfersPerBulk(String maxTransfersPerBulk) {
		entity.setMaxTransfersPerBulk(new Integer(maxTransfersPerBulk));
	}

	/**
	 * @param mqQueueIn
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMqQueueIn(java.lang.String)
	 */
	public void setMqQueueIn(String mqQueueIn) {
		entity.setMqQueueIn(mqQueueIn);
	}

	/**
	 * @param mqQueueOut
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMqQueueOut(java.lang.String)
	 */
	public void setMqQueueOut(String mqQueueOut) {
		entity.setMqQueueOut(mqQueueOut);
	}

	/**
	 * @param newBean
	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#setNewBean(boolean)
	 */
	public void setNewBean(boolean newBean) {
		entity.setNewBean(newBean);
	}

	/**
	 * @param requestorDN
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setRequestorDN(java.lang.String)
	 */
	public void setRequestorDN(String requestorDN) {
		entity.setRequestorDN(requestorDN);
	}

	/**
	 * @param requestRef
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setRequestRef(java.lang.String)
	 */
	public void setRequestRef(String requestRef) {
		entity.setRequestRef(requestRef);
	}

	/**
	 * @param requestType
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setRequestType(java.lang.String)
	 */
	public void setRequestType(String requestType) {
		entity.setRequestType(requestType);
	}

	/**
	 * @param responderDN
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setResponderDN(java.lang.String)
	 */
	public void setResponderDN(String responderDN) {
		entity.setResponderDN(responderDN);
	}

	/**
	 * @param schedules
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setSchedules(java.util.Set)
	 */
	public void setSchedules(List schedules) {
		entity.setSchedules(schedules);
	}

	/**
	 * @param service
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setService(java.lang.String)
	 */
	public void setService(String service) {
		entity.setService(service);
	}

	/**
	 * @param serviceName
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setServiceName(java.lang.String)
	 */
	public void setServiceName(String serviceName) {
		entity.setServiceName(serviceName);
	}

	/**
	 * @param SNF
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setSNF(java.lang.String)
	 */
	public void setSNF(String SNF) {
		entity.setSnF(SNF.equals("1")?Boolean.TRUE:Boolean.FALSE);
	}

	/**
	 * @param startOfDay
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setStartOfDay(java.lang.String)
	 */
	public void setStartOfDay(String startOfDay) {
		entity.setStartOfDay(new Integer(startOfDay));
	}

	/**
	 * @param trace
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setTrace(java.lang.String)
	 */
	public void setTrace(String trace) {
		entity.setTrace(trace.equals("1")?Boolean.TRUE:Boolean.FALSE);
	}
	
	
	public String getCdNode() {
		return entity.getCdNode();
	}

	public void setCdNode(String cdNode) {
		entity.setCdNode(cdNode);
	}

	public String getCdfWTOMsgId() {
		return entity.getCdfWTOMsgId();
	}

	public void setCdfWTOMsgId(String cdfWTOMsgId) {
		entity.setCdfWTOMsgId(cdfWTOMsgId);
	}

	public String getDnfWTOMsgId() {
		return entity.getDnfWTOMsgId();
	}

	public void setDnfWTOMsgId(String dnfWTOMsgId) {
		entity.setDnfWTOMsgId(dnfWTOMsgId);
	}

	public String getDrrWTOMsgId() {
		return entity.getDrrWTOMsgId();
	}

	public void setDrrWTOMsgId(String drrWTOMsgId) {
		entity.setDrrWTOMsgId(drrWTOMsgId);
	}

	public String getDvfWTOMsgId() {
		return entity.getDvfWTOMsgId();
	}

	public void setDvfWTOMsgId(String dvfWTOMsgId) {
		entity.setDvfWTOMsgId(dvfWTOMsgId);
	}

	public String getIdfWTOMsgId() {
		return entity.getIdfWTOMsgId();
	}

	public void setIdfWTOMsgId(String idfWTOMsgId) {
		entity.setIdfWTOMsgId(idfWTOMsgId);
	}

	public String getMsrWTOMsgId() {
		return entity.getMsrWTOMsgId();
	}

	public void setMsrWTOMsgId(String msrWTOMsgId) {
		entity.setMsrWTOMsgId(msrWTOMsgId);
	}

	public String getPsrWTOMsgId() {
		return entity.getPsrWTOMsgId();
	}

	public void setPsrWTOMsgId(String psrWTOMsgId) {
		entity.setPsrWTOMsgId(psrWTOMsgId);
	}

	public String getRsfWTOMsgId() {
		return entity.getRsfWTOMsgId();
	}

	public void setRsfWTOMsgId(String rsfWTOMsgId) {
		entity.setRsfWTOMsgId(rsfWTOMsgId);
	}

	public String getSdfWTOMsgId() {
		return entity.getSdfWTOMsgId();
	}

	public void setSdfWTOMsgId(String sdfWTOMsgId) {
		entity.setSdfWTOMsgId(sdfWTOMsgId);
	}
	
	public String getRtfWTOMsgId() {
		return entity.getRtfWTOMsgId();
	}

	public void setRtfWTOMsgId(String rtfWTOMsgId) {
		entity.setRtfWTOMsgId(rtfWTOMsgId);
	}
	
	public String getMbpWTOMsgId() {
		return entity.getMbpWTOMsgId();
	}

	public void setMbpWTOMsgId(String mbpWTOMsgId) {
		entity.setMbpWTOMsgId(mbpWTOMsgId);
	}
	
	public void setMqHost(String mqHost) {
		entity.setMqHost(mqHost);
	}
	public void setMqPort(String mqPort) {
		entity.setMqPort(new Integer(mqPort));
	}
	public void setMqQManager(String mqQManager) {
		entity.setMqQManager(mqQManager);
	}
	public void setMqChannel(String mqChannel) {
		entity.setMqChannel(mqChannel);
	}
	public void setMqQueueName(String mqQueueName) {
		entity.setMqQueueName(mqQueueName);
	}
	public void setMqQueueBinding(String mqQueueBinding) {
		entity.setMqQueueBinding(mqQueueBinding);
	}
	public void setMqQueueContext(String mqQueueContext) {
		entity.setMqQueueContext(mqQueueContext);
	}
	public void setMqDebug(String mqDebug) {
		entity.setMqDebug(new Integer(mqDebug));
	}
	public void setMqSSLoptions(String mqSSLoptions) {
		entity.setMqSSLoptions(mqSSLoptions);
	}
	public void setMqSSLciphers(String mqSSLciphers) {
		entity.setMqSSLciphers(mqSSLciphers);
	}
	public void setMqSSLkey(String mqSSLkey) {
		entity.setMqSSLkey(mqSSLkey);
	}
	public void setMqSSLcaCert(String mqSSLcaCert) {
		entity.setMqSSLcaCert(mqSSLcaCert);
	}
	
	public String getMqHost(){
		return entity.getMqHost();
	}
	public String getMqPort(){
		return entity.getMqPort().toString();
	}
	public String getMqQManager(){
		return entity.getMqQManager();
	}
	public String getMqChannel(){
		return entity.getMqChannel();
	}
	public String getMqQueueName(){
		return entity.getMqQueueName();
	}
	public String getMqQueueBinding(){
		return entity.getMqQueueBinding();
	}
	public String getMqQueueContext(){
		return entity.getMqQueueContext();
	}
	public String getMqDebug(){
		return entity.getMqDebug().toString();
	}
	public String getMqSSLoptions(){
		return entity.getMqSSLoptions();
	}
	public String getMqSSLciphers(){
		return entity.getMqSSLciphers();
	}
	public String getMqSSLkey(){
		return entity.getMqSSLkey();
	}
	public String getMqSSLcaCert(){
		return entity.getMqSSLcaCert();
	}
	//GPL
	public String getInboundDir() {
		return entity.getInboundDir().toString();
	}
	public String getInboundRoutingRule() {
		return entity.getInboundRoutingRule().toString();
	}	
	public String getInboundRequestorDN() {
		return entity.getInboundRequestorDN();
	}
	public String getInboundResponderDN() {
		return entity.getInboundResponderDN();
	}
	public String getInboundService() {
		return entity.getInboundService();
	}
	public String getInboundType() {
		return entity.getInboundType();
	}
	
	public String[] getInboundRequestType() {
		return entity.getInboundRequestType();
	}
	
	public String getNonRepudiation() {
		return entity.getNonRepudiation().booleanValue()?"1":"0";
	} ;
	public String getPauseInbound() {
		return entity.getPauseInbound().booleanValue()?"1":"0";
	} ;
	public String getPauseOutbound() {
		return entity.getPauseOutbound().booleanValue()?"1":"0";
	} ;



	public void setInboundDir(String inboundDir) {
		entity.setInboundDir(inboundDir==null||inboundDir.length()==0?Boolean.FALSE:inboundDir.equals("on")?Boolean.TRUE:Boolean.FALSE);
	}	
	public void setInboundRoutingRule(String inboundRoutingRule) {
		entity.setInboundRoutingRule(inboundRoutingRule==null||inboundRoutingRule.length()==0?Boolean.FALSE:inboundRoutingRule.equals("on")?Boolean.TRUE:Boolean.FALSE);
	}	
	public void setInboundRequestorDN(String inboundRequestorDN) {
		entity.setInboundRequestorDN(inboundRequestorDN);
	}
	public void setInboundResponderDN(String inboundResponderDN) {
		entity.setInboundResponderDN(inboundResponderDN);
	}
	public void setInboundService(String inboundService) {
		entity.setInboundService(inboundService);
	}
	public void setInboundType(String inboundType) {
		entity.setInboundType(inboundType);
	}
	public void setInboundRequestType(String[] inboundRequestType) {
		entity.setInboundRequestType(inboundRequestType);
	}
	public void setNonRepudiation(String nonRepudiation) {
		entity.setNonRepudiation(nonRepudiation.equals("1")?Boolean.TRUE:Boolean.FALSE);
	}
	public void setPauseInbound(String pauseInbound) {
		entity.setPauseInbound(pauseInbound.equals("1")?Boolean.TRUE:Boolean.FALSE);
	}
	public void setPauseOutbound(String pauseOutbound) {
		entity.setPauseOutbound(pauseOutbound.equals("1")?Boolean.TRUE:Boolean.FALSE);
	}
	
	public String getChangerComments() {
		return entity.getChangerComments().toString();
	}

	public void setChangerComments(String changerComments) {
		entity.setChangerComments(changerComments);
	}
	public void setIrishStep2(String irishStep2) {
		entity.setIrishStep2(irishStep2==null||irishStep2.length()==0?Boolean.FALSE:irishStep2.equals("on")?Boolean.TRUE:Boolean.FALSE);
	}	
	public String getIrishStep2() {
		return entity.getIrishStep2().toString();
	}
	
	public String getE2eSigning() {
		return entity.getE2eSigning();
	}

	public void setE2eSigning(String e2eSigning) {
		entity.setE2eSigning(e2eSigning);
	}
	
}
