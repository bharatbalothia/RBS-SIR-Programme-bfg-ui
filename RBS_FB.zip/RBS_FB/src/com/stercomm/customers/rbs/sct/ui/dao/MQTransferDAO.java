/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.hibernate.Query;
import org.hibernate.Session;
import com.stercomm.customers.rbs.sct.ui.MQTransferSearchCriteria;
import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.ResultMetaImpl;
import com.stercomm.customers.rbs.sct.ui.dto.MQTransfer;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class MQTransferDAO extends BaseHibernateDAO {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(MQTransferDAO.class);

	public MQTransferDAO(Session hibSession, String messageResourcesKey) {
		super(hibSession, messageResourcesKey);
	}
	
	
	
	public boolean commit(MQTransfer mqt){
		Session session = getHibernateSession();
		session.saveOrUpdate(mqt);
		throw new UnsupportedOperationException("method not implemented");
	}
	

//	public boolean[] overrideDuplicates(long[] bundleIds){
//		Session session = getHibernateSession();
//		Transaction transaction = session.beginTransaction();
//		
//		boolean[] status = new boolean[bundleIds.length];
//		
//		try {
//			Query query;
//			for (int i=0; i<bundleIds.length; i++){
//				Bundle bundle = getBundle(bundleIds[i]);
//				if (bundle.getError()!=null 
//						&& bundle.getStatus()!=null 
//						&& (bundle.getError().equals("SCT36") || bundle.getError().equals("SDD11") || bundle.getError().equals("XCT11")) 
//						&& bundle.getStatus().intValue()==-1){
//				
//					query = session.getNamedQuery("dao.bundle.setOverrideDuplicates");
//					query.setBoolean("overrideValue", true);
//					query.setLong("bundleId", bundleIds[i]);
//					int count = query.executeUpdate();
//					log.debug("overrideDuplicated: bundleId="+bundleIds[i]);
//					log.debug(count+" rows updated");
//					status[i] = true;
//				}
//			}
//			
//			transaction.commit();
//			
//			for (int i=0; i<bundleIds.length; i++){
//				if (status[i]){
//					Bundle bundle = getBundle(bundleIds[i]);
//					WFInteraction wfi = new WFInteraction();
//					int returnStatus = wfi.restartWF(bundle.getWF().getWorkflowId());
//					status[i] = returnStatus>0;
//				}
//			}
//			
//			
//			
//			
//			
//			return status;
//		} catch (HibernateException e) {
//			e.printStackTrace();
//			String msg = "Error while setting override duplicate flags";
//			log.error(msg, e);
//			transaction.rollback();
//			throw e;
//		}
//		
//	}
//	
//	
//	public boolean[] terminateWFs(long[] bundleIds, String username){
//		boolean[] results = new boolean[bundleIds.length];
//		boolean updateStatuses = false;
//		WFInteraction wfi = new WFInteraction();
//		StringBuffer hqlBundleSet = new StringBuffer();
//		for (int i=0; i<bundleIds.length; i++){
//			results[i] = wfi.terminate(getWFID(bundleIds[i]), username);
//			if (results[i]){
//				hqlBundleSet.append(", ");
//				hqlBundleSet.append(bundleIds[i]);
//				updateStatuses = true;
//			}
//			
//		}
//		
//		if (updateStatuses){
//			String hql = "update BundleImpl bundle set bundle.status=500 where bundle.bundleId in (";
//			hqlBundleSet.replace(0, 2, hql);
//			hqlBundleSet.append(')');
//
//
//			hql = hqlBundleSet.toString();
//
//			Session session = getHibernateSession();
//			Transaction transaction = null;
//
//			try {
//				transaction = session.beginTransaction();
//				Query query = session.createQuery(hql);
//				query.executeUpdate();
//				transaction.commit();
//			} catch (HibernateException e) {
//				e.printStackTrace();
//				if (transaction!=null){
//					transaction.rollback();
//				}
//
//				throw new RuntimeException("Error while updating bundle status to 500",e);
//			}
//		}
//		return results;
//	}
//	
	
//	public Long getWFID(long bundleId){
//		Session session = getHibernateSession();
//		Query query = session.createQuery("select bun.WF.workflowId from BundleImpl bun where bun.bundleId=:bundleId");
//		query.setLong("bundleId", bundleId);
//		Object result = query.uniqueResult();
//		log.debug("get WFID result: "+result);
//		log.debug("result class: "+result.getClass());
//		Long wfid = (Long)result;
//		return wfid;
//	}
	
	
	public MQTransfer getMQTransfer(String correlationid, String producer, String consumer){
		
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.mqtransfer.byId");
		query.setString("correlationid", correlationid);
		query.setString("producer", producer);
		query.setString("consumer", consumer);
		MQTransfer mqt = (MQTransfer)query.uniqueResult();
		return mqt;
	}
	
	
	@SuppressWarnings("unchecked")
	public List getMQTransfers(){
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.mqtransfer.list.Monitor");
		List results = query.list();
		return results;
	}
	
	@SuppressWarnings("unchecked")
	public List getErrorMQTransfers(){
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.mqtransfer.error.list");
		List results = query.list();
		return results;
	}
	
	
	@SuppressWarnings("unchecked")
	public ResultMeta getMQTransfers(int pageNo, int pageSize){
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		
		int firstResult = rm.getFirstResult();
		
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.mqtransfer.list.Monitor");
		query.setFirstResult(firstResult-1); //zero indexed
		query.setMaxResults(pageSize);
		
		if (log.isDebugEnabled()){
			String queryString = query.getQueryString();
			log.debug("MQ Monitor query string:"+queryString);
		}
		
		List results = query.list();
		rm.setResultsList(results);
		
		
		
		query = session.getNamedQuery("dao.mqtransfer.list.size");
		Integer totalResults = (Integer)query.uniqueResult();
		rm.setTotalResults(totalResults);
		

		return rm;
	}
	
	
	@SuppressWarnings("unchecked")
	public ResultMeta getErrorMQTransfers(int pageNo, int pageSize){
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		
		int firstResult = rm.getFirstResult();
		
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.mqtransfer.error.list");
		query.setFirstResult(firstResult-1); //zero indexed
		query.setMaxResults(pageSize);
		
		List results = query.list();
		rm.setResultsList(results);
		
		query = session.getNamedQuery("dao.mqtransfer.error.list.size");
		Integer totalResults = (Integer)query.uniqueResult();
		rm.setTotalResults(totalResults);
		
		return rm;
	}
	
	protected static final Object[] CORRELATION_ID = {"correlationid", java.lang.String.class};
	protected static final Object[] PRODUCER = {"producer", java.lang.String.class};
	protected static final Object[] CONSUMER = {"consumer", java.lang.String.class};
	protected static final Object[] IS_ALERTED = {"isAlerted", java.lang.Boolean.class};
	protected static final Object[] TRANSFER_STATUS = {"transferstatus", java.lang.Integer.class};
	protected static final Object[] DATAFLOW_ID = {"dataflowid", java.lang.Integer.class};
	protected static final Object[] FILENAME = {"filename", java.lang.String.class};
	protected static final Object[] FROM_DATE = {"fromDate", java.util.Date.class};
	protected static final Object[] TO_DATE = {"toDate", java.util.Date.class};
	protected static final Object[] FROM_HR = {"fromHr", java.lang.Integer.class};
	protected static final Object[] FROM_MIN = {"fromMin", java.lang.Integer.class};
	protected static final Object[] TO_HR = {"toHr", java.lang.Integer.class};
	protected static final Object[] TO_MIN = {"toMin", java.lang.Integer.class};
	
	
	
	@SuppressWarnings("unchecked")
	public ResultMeta getMQTransfers(int pageNo, int pageSize, MQTransferSearchCriteria criteria){
		log.debug("entering getMQTransfers(int pageNo, int pageSize, MQTransferSearchCriteria criteria){");
		
		
		Session session = getHibernateSession();
		Query query = session.getNamedQuery("dao.mqtransfer.list");
		String qsMain = query.getQueryString();
		
		query = session.getNamedQuery("dao.mqtransfer.list.size");
		String qsCount = query.getQueryString();
		query = null;
		
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();
		
		StringBuffer whereStatements =  new StringBuffer();
		Map params = new HashMap();
		
		if (criteria.getCorrelationid()!=null){
			whereStatements.append(getMessage("rbs.fb.mqtransfer.search.correlationid"));
			params.put(CORRELATION_ID, criteria.getCorrelationid());
			
			log.debug("correlationid="+criteria.getCorrelationid());
		}
		if (!(criteria.getProducer()==null || criteria.getProducer().equals("*") || criteria.getProducer().equals("ALL") )){
			whereStatements.append(getMessage("rbs.fb.mqtransfer.search.producer"));
			params.put(PRODUCER, criteria.getProducer());
			log.debug("criteria="+criteria.getProducer());
		}
		if (!(criteria.getConsumer()==null || criteria.getConsumer().equals("*") || criteria.getConsumer().equals("ALL") )){
			whereStatements.append(getMessage("rbs.fb.mqtransfer.search.consumer"));
			params.put(CONSUMER, criteria.getConsumer());
			log.debug("criteria="+criteria.getConsumer());
		}
		if (!(criteria.getAlerted()==null || criteria.getAlerted().equals("ALL")|| criteria.getAlerted().equals("*"))){
			whereStatements.append(getMessage("rbs.fb.mqtransfer.search.alerted"));
			params.put(IS_ALERTED, criteria.getAlerted().equalsIgnoreCase("yes")?Boolean.TRUE:Boolean.FALSE);
			log.debug("direction="+criteria.getAlerted());
		}
	
		if (criteria.getTransferState()!=null){
			log.debug("transferstate="+criteria.getTransferState());
			if (criteria.getTransferState().equals("RED") || criteria.getTransferState().equalsIgnoreCase("ERROR")){
				whereStatements.append(getMessage("rbs.fb.mqtransfer.search.transferstate.red"));
			}
			else if (criteria.getTransferState().equals("GREEN")){
				whereStatements.append(getMessage("rbs.fb.mqtransfer.search.transferstate.green"));
			}
			else if (criteria.getTransferState().equals("AMBER")){ //is amber
				whereStatements.append(getMessage("rbs.fb.mqtransfer.search.transferstate.amber"));
			}
			
			//params.put(BP_STATE, criteria.getBpState());
		}
		if (criteria.getFilename()!=null){
			whereStatements.append(getMessage("rbs.fb.mqtransfer.search.filename"));
			params.put(FILENAME, criteria.getFilename());
			log.debug("filename="+criteria.getFilename());
		}
		
		if (criteria.getFromdate()!=null){
			whereStatements.append(getMessage("rbs.fb.mqtransfer.search.dateFrom"));
			//params.put(FROM_DATE, criteria.getFromDate());
			//log.debug("fromDate="+criteria.getFromDate());
			
			//fix for Hibernate leaving out the time part of the timestamp
			Calendar calFrom = Calendar.getInstance();
			calFrom.setTime(criteria.getFromdate());
			params.put(FROM_DATE, calFrom.getTime());
			log.debug("fromDate="+calFrom.getTime());
			params.put(FROM_HR, new Integer(calFrom.get(Calendar.HOUR_OF_DAY)));
			log.debug("fromHr="+calFrom.get(Calendar.HOUR_OF_DAY));
			params.put(FROM_MIN, new Integer(calFrom.get(Calendar.MINUTE)));
			log.debug("fromMin="+calFrom.get(Calendar.MINUTE));
			
		}
	
		
		if (criteria.getTodate()!=null){
			whereStatements.append(getMessage("rbs.fb.mqtransfer.search.dateTo"));
			//params.put(TO_DATE, criteria.getToDate());
			//log.debug("toDate="+criteria.getToDate());
			
//			fix for Hibernate leaving out the time part of the timestamp
			Calendar calTo = Calendar.getInstance();
			calTo.setTime(criteria.getTodate());
			params.put(TO_DATE, calTo.getTime());
			log.debug("toDate="+calTo.getTime());
			params.put(TO_HR, new Integer(calTo.get(Calendar.HOUR_OF_DAY)));
			log.debug("toHr="+calTo.get(Calendar.HOUR_OF_DAY));
			params.put(TO_MIN, new Integer(calTo.get(Calendar.MINUTE)));
			log.debug("toMin="+calTo.get(Calendar.MINUTE));
		}
		
		
		if (whereStatements.length()>0){
			whereStatements.delete(0, 4);
			whereStatements.append(getMessage("rbs.fb.mqtransfer.search.orderBy"));
			qsMain += (" WHERE ");
			qsMain +=(whereStatements.toString());
			
			qsCount += (" WHERE ");
			qsCount +=(whereStatements.toString());
		}
		else {
			qsMain += " "+getMessage("rbs.fb.mqtransfer.search.orderBy");
		}
		
		System.out.println(qsMain);
		System.out.println(qsCount);
		log.debug("executing query: "+ qsMain);
		log.debug("executing count query: "+ qsCount);
		session = getHibernateSession();
		query = session.createQuery(qsMain);
		Query countQuery = session.createQuery(qsCount);
		
		
		{
			Iterator paramKeySetIterator = params.keySet().iterator();
			while (paramKeySetIterator.hasNext()){
				Object[] arr = (Object[])paramKeySetIterator.next();
				if(arr[1]==String.class){
					query.setString((String)arr[0], (String)params.get(arr));
					countQuery.setString((String)arr[0], (String)params.get(arr));
				}
				else if(arr[1]==Integer.class){
					query.setInteger((String)arr[0], ((Integer)params.get(arr)).intValue());
					countQuery.setInteger((String)arr[0], ((Integer)params.get(arr)).intValue());
				}
				else if(arr[1]==Double.class){
					query.setDouble((String)arr[0], ((Double)params.get(arr)).doubleValue());
					countQuery.setDouble((String)arr[0], ((Double)params.get(arr)).doubleValue());
				}
				else if (arr[1]==Date.class){
					query.setDate((String)arr[0], (Date)params.get(arr));
					countQuery.setDate((String)arr[0], (Date)params.get(arr));
				}
				else if (arr[1]==Boolean.class){
					query.setBoolean((String)arr[0], ((Boolean)params.get(arr)).booleanValue());
					countQuery.setBoolean((String)arr[0], ((Boolean)params.get(arr)).booleanValue());
				}
			}
		}
		
		query.setFirstResult(firstResult-1); //zero indexed
		query.setMaxResults(pageSize);
		
		List results = query.list();
		
		//FIXME: Collections.sort should be handled by the order-by clause
//		Collections.sort(results, Collections.reverseOrder());
		rm.setResultsList(results);
		
		Integer totalResults = (Integer)countQuery.uniqueResult();
		System.out.println("TotalResults: "+ totalResults);
		rm.setTotalResults(totalResults);
		
		
		return rm;
	}
	
}
