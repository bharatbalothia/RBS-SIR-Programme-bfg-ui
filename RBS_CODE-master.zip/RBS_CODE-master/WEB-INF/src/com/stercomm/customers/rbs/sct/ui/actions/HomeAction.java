/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class HomeAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	//private static final Logger log = Logger.getLogger(HomeAction.class);

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		Date now = new Date();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String today = sdf.format(now);
		request.setAttribute("today", today);
//
//		Calendar cal = Calendar.getInstance();
//		cal.set(Calendar.HOUR_OF_DAY, 0);
//		cal.set(Calendar.MINUTE, 0);
//		cal.set(Calendar.SECOND, 0);
//		cal.set(Calendar.MILLISECOND, 0);
//
//		Date dayStart = cal.getTime();
//		cal.roll(Calendar.DAY_OF_MONTH, true);
//		Date dayEnd = cal.getTime();
//

		Session session = getHibernateSession();
		Query query;

//
//		query = session.createQuery("select count(tr.trackingId) from Tracking tr where tr.statusCode >=0 and tr.inboundTimestamp >= :dayStart and tr.inboundTimestamp < :dayEnd");
//		query.setDate("dayStart", dayStart);
//		query.setDate("dayEnd", dayEnd);
//		Integer inSuccess = (Integer)query.uniqueResult();
//
//		query = session.createQuery("select count(tr.trackingId) from Tracking tr where tr.statusCode <0 and tr.inboundTimestamp >= :dayStart and tr.inboundTimestamp < :dayEnd");
//		query.setDate("dayStart", dayStart);
//		query.setDate("dayEnd", dayEnd);
//		Integer inFailure = (Integer)query.uniqueResult();
//
//		request.setAttribute("inFailure", inFailure);
//		request.setAttribute("inSuccess", inSuccess);
//		request.setAttribute("todaysDate", getTodaysDate());


		//MB - v2.0 - updated to sct
		query = session.getNamedQuery("home.sct.transactionErrors");
		Integer count = (Integer)query.uniqueResult();
		request.setAttribute("SCTTransactionErrors", count);

		//MB - v2.0 - updated to sct
		query = session.getNamedQuery("home.sct.fileErrors");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SCTBundleErrors", count);

		//MB - v2.0 - added
		query = session.getNamedQuery("home.sdd.fileErrors");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SDDBundleErrors", count);

		query = session.getNamedQuery("home.systemErrors");
		count = (Integer)query.uniqueResult();
		request.setAttribute("systemErrors", count);

		//MB v2 - traffic summaries
		query = session.getNamedQuery("home.sct.fileTraffic.hour");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SCTBundleTrafficHour", count);

		query = session.getNamedQuery("home.sct.fileTraffic.day");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SCTBundleTrafficDay", count);

		query = session.getNamedQuery("home.sct.fileTraffic.week");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SCTBundleTrafficWeek", count);

		query = session.getNamedQuery("home.sct.trxTraffic.hour");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SCTTrxTrafficHour", count);

		query = session.getNamedQuery("home.sct.trxTraffic.day");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SCTTrxTrafficDay", count);

		query = session.getNamedQuery("home.sct.trxTraffic.week");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SCTTrxTrafficWeek", count);

		query = session.getNamedQuery("home.sdd.fileTraffic.hour");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SDDBundleTrafficHour", count);

		query = session.getNamedQuery("home.sdd.fileTraffic.day");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SDDBundleTrafficDay", count);

		query = session.getNamedQuery("home.sdd.fileTraffic.week");
		count = (Integer)query.uniqueResult();
		request.setAttribute("SDDBundleTrafficWeek", count);

		//PM Updated for GPL
		query = session.getNamedQuery("home.gpl.fileTraffic.hour");
		count = (Integer)query.uniqueResult();
		request.setAttribute("GPLBundleTrafficHour", count);

		query = session.getNamedQuery("home.gpl.fileTraffic.day");
		count = (Integer)query.uniqueResult();
		request.setAttribute("GPLBundleTrafficDay", count);

		query = session.getNamedQuery("home.gpl.fileTraffic.week");
		count = (Integer)query.uniqueResult();
		request.setAttribute("GPLBundleTrafficWeek", count);

		query = session.getNamedQuery("home.gpl.fileErrors");
		count = (Integer)query.uniqueResult();
		request.setAttribute("GPLBundleErrors", count);


//		MB Updated for ROI
		query = session.getNamedQuery("home.roi.fileTraffic.hour");
		count = (Integer)query.uniqueResult();
		request.setAttribute("ROIBundleTrafficHour", count);

		query = session.getNamedQuery("home.roi.fileTraffic.day");
		count = (Integer)query.uniqueResult();
		request.setAttribute("ROIBundleTrafficDay", count);

		query = session.getNamedQuery("home.roi.fileTraffic.week");
		count = (Integer)query.uniqueResult();
		request.setAttribute("ROIBundleTrafficWeek", count);

		query = session.getNamedQuery("home.roi.fileErrors");
		count = (Integer)query.uniqueResult();
		request.setAttribute("ROIBundleErrors", count);

//		TRD
		query = session.getNamedQuery("home.trd.fileTraffic.hour");
		count = (Integer)query.uniqueResult();
		request.setAttribute("TRDBundleTrafficHour", count);

		query = session.getNamedQuery("home.trd.fileTraffic.day");
		count = (Integer)query.uniqueResult();
		request.setAttribute("TRDBundleTrafficDay", count);

		query = session.getNamedQuery("home.trd.fileTraffic.week");
		count = (Integer)query.uniqueResult();
		request.setAttribute("TRDBundleTrafficWeek", count);

		query = session.getNamedQuery("home.trd.fileErrors");
		count = (Integer)query.uniqueResult();
		request.setAttribute("TRDBundleErrors", count);

		return super.viewForm(mapping, form, request, response);
	}

	public ActionForward fileSCTErrors(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileSCTErrors");
	}
	public ActionForward fileSDDErrors(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileSDDErrors");
	}
	public ActionForward transactionErrors(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("transactionErrors");
	}
	public ActionForward fileSCTHour(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileSCTHour");
	}
	public ActionForward fileSCTDay(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileSCTDay");
	}
	public ActionForward fileSCTWeek(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileSCTWeek");
	}
	public ActionForward fileSDDHour(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileSDDHour");
	}
	public ActionForward fileSDDDay(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileSDDDay");
	}
	public ActionForward fileSDDWeek(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileSDDWeek");
	}
	public ActionForward transactionHour(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("transactionHour");
	}
	public ActionForward transactionDay(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("transactionDay");
	}
	public ActionForward transactionWeek(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("transactionWeek");
	}
	// PM Update for XCT
	public ActionForward fileXCTErrors(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileXCTErrors");
	}
	public ActionForward fileXCTHour(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileXCTHour");
	}
	public ActionForward fileXCTDay(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileXCTDay");
	}
	public ActionForward fileXCTWeek(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileXCTWeek");
	}
	public ActionForward XCTtransactionHour(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("XCTtransactionHour");
	}
	public ActionForward XCTtransactionDay(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("XCTtransactionDay");
	}
	public ActionForward XCTtransactionWeek(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("XCTtransactionWeek");
	}
	public ActionForward XCTtransactionErrors(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("XCTtransactionErrors");
	}

	public ActionForward fileGPLHour(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileGPLHour");
	}
	public ActionForward fileGPLDay(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileGPLDay");
	}
	public ActionForward fileGPLWeek(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileGPLWeek");
	}
	public ActionForward fileGPLErrors(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileGPLErrors");
	}

	public ActionForward fileROIHour(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileROIHour");
	}
	public ActionForward fileROIDay(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileROIDay");
	}
	public ActionForward fileROIWeek(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileROIWeek");
	}
	public ActionForward fileROIErrors(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileROIErrors");
	}
	// TRD Error counts
	public ActionForward fileTRDHour(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileTRDHour");
	}
	public ActionForward fileTRDDay(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileTRDDay");
	}
	public ActionForward fileTRDWeek(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileTRDWeek");
	}
	public ActionForward fileTRDErrors(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return mapping.findForward("fileTRDErrors");
	}

}
