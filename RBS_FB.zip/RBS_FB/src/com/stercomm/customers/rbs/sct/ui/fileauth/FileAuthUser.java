package com.stercomm.customers.rbs.sct.ui.fileauth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.sterlingcommerce.woodstock.services.XLogger;
import com.sterlingcommerce.woodstock.util.BaseUtil;
import com.sterlingcommerce.woodstock.util.frame.jdbc.Conn;

public class FileAuthUser extends FileAuthConstants{

	private String fileAuthUserID;
	private int fileAuthID;
	private String user;
	
	private static XLogger log;

	public FileAuthUser() throws Exception{
		init(false);
	}
	
	public FileAuthUser(int faid, String user) throws Exception{
		this.setFileAuthID(faid);
		this.setUser(user);
		init(true);
	}
	
	private void init(boolean createID) throws Exception{
		log = new XLogger("FileAuth", "FileAuth");
		if(createID){
			this.setFileAuthUserID(BaseUtil.createGUID());
		}
	}
	
	public void insert() throws Exception {

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "INSERT INTO FB_FILE_AUTH_USERS ( FILE_AUTH_USERS_ID, FILE_AUTH_ID, USER_ID, CREATED) VALUES (?,?,?,sysdate)";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setString(1, this.getFileAuthUserID());
			spstmt.setInt(2,this.getFileAuthID());
			spstmt.setString(3, this.getUser());
			

			@SuppressWarnings("unused")
			int i = spstmt.executeUpdate();

		} catch (SQLException sqle) {
			log.logException("SQL Error persisting the FB_FILE_AUTH_USERS record", sqle);
			throw sqle;
		} catch (Exception e) {
			log.logException("Error persisting the FB_FILE_AUTH_USERS record", e);
			throw e;
		} finally {
			try {
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

	}
	
	public String getFileAuthUserID() {
		return fileAuthUserID;
	}
	public void setFileAuthUserID(String fileAuthUserID) {
		this.fileAuthUserID = fileAuthUserID;
	}
	public int getFileAuthID() {
		return fileAuthID;
	}
	public void setFileAuthID(int fileAuthID) {
		this.fileAuthID = fileAuthID;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	
	
}
