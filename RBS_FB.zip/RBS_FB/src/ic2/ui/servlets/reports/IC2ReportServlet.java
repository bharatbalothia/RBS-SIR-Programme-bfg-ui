/**
 * 
 */
package ic2.ui.servlets.reports;

import ic2.ui.SessionVarConstants;
import ic2.ui.beans.reports.ReportColumn;
import ic2.ui.beans.reports.ReportDataBean;
import ic2.ui.beans.reports.ReportSettingsBean;
import ic2.ui.exception.IC2UIRuntimeException;
import ic2.ui.reports.ReportRunner;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.apache.log4j.Logger;


/**
 * @author Ravi K Patel
 * created May 5, 2006
 */
public class IC2ReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final Logger logger = Logger.getLogger(IC2ReportServlet.class);


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		get the bean from the request
		String waitKey = request.getParameter("waitKey");
		Map<?, ?> waitKeyMap = (Map<?, ?>)request.getSession().getAttribute(SessionVarConstants.WAIT_KEY_MAP);
		ReportRunner reportRunner = (ReportRunner)waitKeyMap.remove(waitKey);
		ReportSettingsBean reportSettings = reportRunner.getReportRunnerBean().getReportSettings();
		ReportDataBean reportData = reportRunner.getReportDataBean();

		logger.debug("waitKey="+waitKey);
		logger.debug("reportRunner="+reportRunner);
		logger.debug("reportSettingsBean="+reportSettings);
		logger.debug("reportDataBean="+reportData);
		
		logger.debug("reportData="+reportData.getDocBuffer());

		if(reportSettings.getOutput().equalsIgnoreCase("pdf")
				|| reportSettings.getOutput().equalsIgnoreCase("html")
				|| reportSettings.getOutput().equalsIgnoreCase("csv")){
	
//			set the response header
			if (reportSettings.getOutput().equalsIgnoreCase("pdf")){
				response.setContentType("application/pdf");
			} else if (reportSettings.getOutput().equalsIgnoreCase("csv")){
					response.setContentType("text/csv");
					response.addHeader("Content-Disposition", "attachment;filename="+reportSettings.getName()+".csv");
			} else {
				response.setContentType("text/html");
			}
			
			ServletOutputStream outputStream;
			try {
				outputStream = response.getOutputStream();
				
			} catch (IOException e) {
				String message = "Could not obtain the ServletOutputStream from the HttpServletResponse";
				logger.fatal(message);
				throw new IC2UIRuntimeException(message, e);
			}
			
			outputStream.write(reportData.getDocBuffer());
			outputStream.close();
	

		} else {

			
			
			//set the response header
			response.setContentType("application/excel");


			//Create a new Workbook, using the response as the output stream
			ServletOutputStream outputStream;
			try {
				outputStream = response.getOutputStream();
			} catch (IOException e) {
				String message = "Could not obtain the ServletOutputStream from the HttpServletResponse";
				logger.fatal(message);
				throw new IC2UIRuntimeException(message, e);
			}

			WritableWorkbook workbook;
			try {
				workbook = Workbook.createWorkbook(outputStream);
			} catch (IOException e) {
				String message = "IOException while creating a new jxl Workbook using the response ServletOutputStream";
				logger.fatal(message);
				throw new IC2UIRuntimeException(message, e);
			}


			WritableSheet sheet = workbook.createSheet(reportSettings.getName(), 0);

			for (int columnNum=0; columnNum<reportData.getReportColumns().size(); columnNum++){
				int rowNum =0;
				ReportColumn column = (ReportColumn)reportData.getReportColumns().get(columnNum);
				//create a column header
				try {
					sheet.addCell(new Label(columnNum, rowNum++, column.getTitle()));
				} catch (RowsExceededException e) {
					String message = "RowsExceededException while trying to add a new title cell";
					logger.fatal(message);
					throw new IC2UIRuntimeException(message, e);
				} catch (WriteException e) {
					String message = "WriteException while trying to add a new title cell";
					logger.fatal(message);
					throw new IC2UIRuntimeException(message, e);
				}

				//populate rows with data
				for (int dataRow=0; dataRow <column.getData().size() ;dataRow++){
					Object data = column.getData().get(dataRow);
					try {
						sheet.addCell(new Label(columnNum, rowNum+dataRow, data==null?"":data.toString()));
					} catch (RowsExceededException e) {
						String message = "RowsExceededException while trying to add a new data cell";
						logger.fatal(message);
						throw new IC2UIRuntimeException(message, e);
					} catch (WriteException e) {
						String message = "WriteException while trying to add a new data cell";
						logger.fatal(message);
						throw new IC2UIRuntimeException(message, e);
					}
				}


			}


			workbook.write();
			workbook.close();

		}
	}
}
