function setStrutsAction(action){
	document.getElementById('strutsDispatch').value = action;
}

function setSelectedRow(rowId){
	document.getElementById('selectedRow').value = rowId;
}

function isReady(obj, str1, int, str2){
return true;
}
