package com.stercomm.customers.rbs.sct.ui.change;


import java.util.LinkedList;



public class TrustedCertChange extends ChangeControl {

	public final static String OBJECT_TYPE="com.stercomm.customers.rbs.sct.ui.change.TrustedCertViewer";

	public TrustedCertChange() throws Exception{
		super();
		this.setObjectType(OBJECT_TYPE);
	}

	public TrustedCertChange(String cid) throws Exception{
		super(cid);
		this.setObjectType(OBJECT_TYPE);
	}

	public static boolean isNameUnique(String value) throws Exception{
		return isPendingMetaUnique(1, OBJECT_TYPE, value);
	}

	public static boolean isThumbprintUnique(String value) throws Exception{
		return isPendingMetaUnique(2, OBJECT_TYPE, value);
	}

	public static LinkedList<ChangeControl> listPendingByName(String name) throws Exception{
		return search("RESULT_META1", name, OBJECT_TYPE, ChangeControl.STATUS_PENDING);
	}
	public static LinkedList<ChangeControl> listPendingByThumbprint(String tprint) throws Exception{
		return search("RESULT_META2", tprint, OBJECT_TYPE, ChangeControl.STATUS_PENDING);
	}
}
