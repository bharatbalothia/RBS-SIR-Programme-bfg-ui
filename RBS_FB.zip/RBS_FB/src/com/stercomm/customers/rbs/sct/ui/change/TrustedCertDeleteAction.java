package com.stercomm.customers.rbs.sct.ui.change;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;
import com.sterlingcommerce.woodstock.xml.xslt.DOMUtil;

public class TrustedCertDeleteAction extends TrustedCertAction implements ChangeAction {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(TrustedCertDeleteAction.class);
	
	public TrustedCertDeleteAction(TrustedCert tc){
		super(tc);
	}
	
	@Override
	public void commit()throws Exception {
			
		/* 
		 * delete the cert using the XAPI
		 */
		log.debug("Committing the Trusted Cert delete action");
		String userName="FBSystem";
		ChangeControl cc = new ChangeControl(tc.getChangeID());
		if(cc!=null){
			userName = cc.getChanger();
		}
			
		if(manageCertificate(deleteXAPI(userName))){
			log.debug("TrustedCert deletion committed");
		} else {
			throw new Exception("The Trusted Certificate delete action could not be committed");
		}
		
	}
	
	private Document deleteXAPI(String user) throws Exception{

		Document cDoc = DOMUtil.newDocument();
		Element cRoot = cDoc.createElement("Certificate");
		cRoot.setAttribute("Name", tc.getCertificateName());
		cRoot.setAttribute("Operation", "delete");
		cRoot.setAttribute("Type", "Trusted");
		cRoot.setAttribute("UserName", user);
		cRoot.setAttribute("ObjectId", tc.getCertificateId());
		
		//Element cCER = cDoc.createElement("CER");
		//cCER.setAttribute("CertName", tc.getCertificateName());
		//cCER.setAttribute("AuthChain", "true");
		//cCER.setAttribute("Validity", "true");
		//cCER.setAttribute("CrlCache", "true");
		//cCER.setAttribute("UserName", user);
		//CDATASection cdata = cDoc.createCDATASection(CertificateInfoBase.encodeToString(tc.getX509Certificate().getEncoded()));
		//cCER.appendChild(cdata);
		//cRoot.appendChild(cCER);
		cDoc.appendChild(cRoot);
		
		return cDoc;
	}

}
