package com.stercomm.customers.rbs.sct.ui.xapi;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.rmi.RemoteException;

import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.sterlingcommerce.woodstock.util.NameValue;
import com.sterlingcommerce.woodstock.util.NameValuePairs;
import com.sterlingcommerce.woodstock.xml.xslt.DOMUtil;
import com.yantra.interop.japi.YIFClientCreationException;
import com.yantra.yfc.util.YFCException;
import com.yantra.yfs.japi.YFSException;

public class FBXAPIBase {

	protected static Document invokeXAPI(String action, String root, NameValuePairs nvpAttrs)
	throws YFCException
	{
		Document result = null;
		try
		{
			Document doc = DOMUtil.newDocument(root);
			Element ele = doc.getDocumentElement();

			NameValue nv = null;
			for (int index = 0; index < nvpAttrs.numEntries(); index++) {
				nv = nvpAttrs.getElement(index);
				ele.setAttribute(nv.getName(), (String)nv.getValue());
			}

			result = (Document)FBXAPIClient.invoke(null, action, doc);

		} catch (RemoteException e) {
			throw new YFCException(e);
		} catch (YFSException e) {
			throw new YFCException(e);
		} catch (YIFClientCreationException e) {
			throw new YFCException(e);
		}
		return result;
	}
	
	protected static Document invokeXAPI(String action, Document doc)
	throws YFCException
	{
		Document result = null;
		try
		{
			result = (Document)FBXAPIClient.invoke(null, action, doc);

		} catch (RemoteException e) {
			throw new YFCException(e);
		} catch (YFSException e) {
			throw new YFCException(e);
		} catch (YIFClientCreationException e) {
			throw new YFCException(e);
		}
		return result;
	}
	
	public static String xmlToString(Document doc){
		
		if(doc==null){
			return "[Doc] is null";
		}
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		OutputFormat format = new OutputFormat(doc);
		XMLSerializer output = new XMLSerializer(outputStream, format);
		try {
			output.serialize(doc);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		if(outputStream.size()>50000){
			return "[Doc] is too big";
		}
		String out = outputStream.toString();
		return out;
	}

}
