/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   $Revision: $
 * Date/time:  $Date: $
 **********************************************************************/
package com.stercomm.customers.webapps.security;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.StringTokenizer;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
//import org.apache.log4j.Level;


import com.stercomm.customers.webapps.resources.Constants;
import com.sterlingcommerce.security.opsutilities.DBPasswords;
import com.sterlingcommerce.woodstock.security.SecurityManager;
import com.sterlingcommerce.woodstock.security.User;
//import com.sterlingcommerce.woodstock.ui.dlsso.DLSSOFilter;
import com.sterlingcommerce.woodstock.util.Util;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
@SuppressWarnings({"unused", "unchecked", "deprecation"})
public class LoginFilter implements Filter{
	Log log = LogFactory.getLog(LoginFilter.class);
	//org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(LoginFilter.class.getName());
	
	
	/* (non-Javadoc)
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		
		//logger.debug("start login filter");
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		@SuppressWarnings("unused")
		boolean DLSSOAuthenticated=false;

		//RELEASE : change authenticated to false
		boolean authenticated = false;

		StringTokenizer st = new StringTokenizer(request.getServletPath(), ".");
		if(st.countTokens()>0){
			while (st.countTokens()>1){
				st.nextToken();
			}
			String extension = st.nextToken();
			if (extension.equalsIgnoreCase("gif")||
					extension.equalsIgnoreCase("jpg")||
					extension.equalsIgnoreCase("css")||
					extension.equalsIgnoreCase("js")){

				chain.doFilter(request, response);
				return;
			}
		}

		log.debug("request path: "+request.getServletPath());


		HttpSession session = request.getSession(false);
		if(log.isDebugEnabled()){
			log.debug("LoginFilter: dumping session....");
			Enumeration<?> en = session.getAttributeNames();

			while(en.hasMoreElements()){
				String o = (String)en.nextElement();
				log.debug(o + "="+  session.getAttribute(o));
			}
		}

		/* If coming in via SSO then check it here
		 * Otherwise, provide backwards support for the autho params
		 */
		//System.out.println(System.setProperty("log4j.configuration", "log4j.properties"));
		//System.out.println(System.getProperty("log4j.configuration"));
		//String resource = org.apache.log4j.helpers.Loader.getResource("log4j.properties", Logger.class).toString();
		//System.setProperty("log4j.configuration", resource);
		if (session!= null && session.getAttribute("dlssoAuthenticated")!=null){

			log.debug("LoginFilter: FOUND DLSSO SESSION");
			String dlssoAuth = (String)session.getAttribute("dlssoAuthenticated");
			if(!dlssoAuth.equalsIgnoreCase("TRUE")){
				log.debug("LoginFilter: DLSSO SESSION AUTH = FALSE");
			} else {
				log.debug("LoginFilter: DLSSO SESSION AUTH = TRUE");
				String ssoUsername = (String)session.getAttribute("autho");
				SecurityManager sm = new SecurityManager();
				User ssoUser = sm.getUser( ssoUsername );
				//session.setMaxInactiveInterval(ssoUser.getTimeout());
				session.setAttribute(Constants.GIS_USER_OBJECT, ssoUser);
				session.setAttribute(Constants.GIS_USER_TIMEOUT, String.valueOf(ssoUser.getTimeout()));
				session.setAttribute(Constants.GIS_USERNAME, ssoUser.getUserName());
				session.setAttribute(Constants.GIS_USER_FULLNAME, ssoUser.getFullName());
				DLSSOAuthenticated=true;
				chain.doFilter(request, response);
				return;
			}
		} else {
			//logger.warn("LoginFilter: DID NOT FIND DLSSO SESSION");
			log.debug("LoginFilter: DID NOT FIND DLSSO SESSION");
		}

		if (request.getParameter("autho")!=null && session!= null){
			log.debug("autho param present...invalidating session...setting session to null");
			session.invalidate();
			session = null;
		}

		if (session==null){
			log.debug("session is null");
			session = request.getSession();
		}

		Object u = request.getSession().getAttribute(Constants.GIS_USER_OBJECT);
		User user;
		if (u==null){
			//NOT_LOGGED_IN;
			log.debug("user is not in session...start login via autho param");

			String autho = request.getParameter("autho"); //Get login info from parameter

			if (autho == null){ 
				log.debug("loging failed: autho parameter not present");
			}
			else {
				String pw = request.getParameter("password");
				String username = null;
				String password = null;
				if (pw!=null){
					log.debug("authenticating using plain text username & password");
					username=autho;
					password=pw;
				}
				else {
					log.debug("start login via encrypted autho param");




					//String autho_decoded = URLDecoder.decode(autho);
					String autho_decrypt = DBPasswords.decrypt(autho);

					StringTokenizer st1 = new StringTokenizer(autho_decrypt, "&");
					StringTokenizer st2 = new StringTokenizer(st1.nextToken(), "=");


					if (st2.nextToken().equals("username")){
						username = st2.nextToken();
						log.debug("username:"+DBPasswords.encrypt(username));
						st2 = new StringTokenizer(st1.nextToken(), "=");
						if (st2.nextToken().equals("password")){
							password = st2.nextToken();
							log.debug("password:"+DBPasswords.encrypt(password));
						}
						else {
							log.debug("login failed: password parameter (decrypted) not present");
						}
					}else {
						log.debug("login failed: username parameter (decrypted) not present");
					}


				}

				int intTimeout;
				/*
				 * 
				 */
				if (!(username==null || password==null)){
					SecurityManager sm = new SecurityManager();
					user = sm.getUser( username );  // checks CacheManager to see if the user exists

					//logger.debug("user is of type:"+user.getClass());
					if (user != null) {
						log.debug("got user '"+user.getUserName()+"' from security manager");
						if (user.isAuthenticated(password)) {
							intTimeout = user.getTimeout();

							{
								String hashedPassword=Util.hashPassword(password);
								session.setAttribute(Constants.HASHED_PASSWORD, hashedPassword);
								session.setAttribute(Constants.AUTHO_TOKEN, autho);
								StringBuffer wsLoginString = new StringBuffer();
								wsLoginString.append("autho=");
								wsLoginString.append(username);
								wsLoginString.append("&encodedPass=true&password=");
								String hashURLed = URLEncoder.encode(hashedPassword, "UTF-8"); 
								wsLoginString.append(hashURLed);
								session.setAttribute(Constants.WS_AUTHO, wsLoginString.toString());

								StringBuffer wsURL = new StringBuffer();
								if(request.getScheme().equalsIgnoreCase("HTTPS")){
									wsURL.append("https://");
								} else {
									wsURL.append("http://");
								}
								//wsURL.append("http://");
								wsURL.append(request.getServerName());
								wsURL.append(":");
								wsURL.append((request.getServerPort()/100)*100);
								wsURL.append("/ws/Login?");
								wsURL.append(wsLoginString.toString());
								session.setAttribute(Constants.WS_AUTHO_URL, wsURL.toString());
								//session.setAttribute(Constants.WS_BASE_URL, wsURL.toString().replaceAll("/ws/Login?", "/ws"));
							}


							session.setMaxInactiveInterval(intTimeout);
							session.setAttribute(Constants.GIS_USER_OBJECT, user);
							session.setAttribute(Constants.GIS_USER_TIMEOUT, String.valueOf(intTimeout));
							session.setAttribute(Constants.GIS_USERNAME, username);
							session.setAttribute(Constants.GIS_USER_FULLNAME, user.getFullName());


							authenticated = true;
							log.debug("login success: via autho params");
						} else {
							log.debug("login failed: password invalid for User object");								
						}

					}else {
						log.debug("login failed: user object not in GIS cache");
					}
				}
			}

		}
		else {
			log.debug("login success: user object already in session");
			//logger.debug("user is of type:"+u.getClass());
			user = (User)u;
			authenticated = true;

		}



		if (authenticated)
		{
			log.debug("forwarding to requested page");
			chain.doFilter(request, response);
		}
		else {
			log.debug("forwarding to "+Constants.LOGIN_URL);
			response.sendError(401);
			//request.getRequestDispatcher(Constants.LOGIN_URL).forward(request, response);
		}
		log.debug("exit login filter");
	}

	/* (non-Javadoc)
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}

/**********************************************************************
 *
 * Revision History
 * ================
 *
 * $Log: $
 */