/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dtoimpl;

import java.text.DecimalFormat;
import java.util.Date;

import org.apache.log4j.Logger;


import com.stercomm.customers.rbs.sct.ui.dto.Bundle;
import com.stercomm.customers.rbs.sct.ui.dto.Payment;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 * hibernate.class table="SCT_PAYMENT"
 */
@SuppressWarnings({"unchecked", "unused"})
public class PaymentImpl extends BaseHibernateBeanImpl implements Payment, Comparable{
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(PaymentImpl.class);
	
	private Long paymentId;
	private Long messageId;
	private Long wfId;
	private String type;
	private String reference;
	private String transactionId;
	//CHG_UI_IBM_RJ_004
	private String paymentBIC;
	private Date settleDate;
	private Double settleAmt;
	private Bundle bundle;
	private Date pTimestamp;
	private Integer status;
	private Boolean outbound;
	private String docId;
	
	
	
	public int compareTo(Object o) {
		if (!(o instanceof Payment)){
			throw new ClassCastException("parameter object is not an instance of the Payment interface. obj:"+o.toString());
		}
		
		Payment other = (Payment)o;
		return this.getPaymentId().compareTo(other.getPaymentId());
	}
	
	
	
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	/**
	 * @return the bundle
	 * @hibernate.many-to-one column = "bundle_Id" class="com.stercomm.customers.rbs.sct.ui.dtoimpl.BundleImpl"
	 */
	public Bundle getBundle() {
		return bundle;
	}
	/**
	 * @param bundle the bundle to set
	 */
	public void setBundle(Bundle bundle) {
		this.bundle = bundle;
	}
	/**
	 * @return the messageId
	 * @hibernate.property column = "message_Id"
	 */
	public Long getMessageId() {
		return messageId;
	}
	/**
	 * @param messageId the messageId to set
	 */
	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}
	/**
	 * @return the outbound
	 * @hibernate.property column = "isoutbound"
	 */
	public Boolean getOutbound() {
		return outbound;
	}
	/**
	 * @param outbound the outbound to set
	 */
	public void setOutbound(Boolean outbound) {
		this.outbound = outbound;
	}
	/**
	 * @return the paymentId
	 * @hibernate.id column = "payment_Id" generator-class = "sequence"
	 * @hibernate.generator-param name="sequence" value="SCT_PAYMENT_IDSEQ"
	 */
	public Long getPaymentId() {
		return paymentId;
	}
	/**
	 * @param paymentId the paymentId to set
	 */
	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}
	/**
	 * @return the pTimestamp
	 * @hibernate.property column = "pTimestamp"
	 */
	public Date getPTimestamp() {
		return pTimestamp;
	}
	/**
	 * @param timestamp the pTimestamp to set
	 */
	public void setPTimestamp(Date timestamp) {
		pTimestamp = timestamp;
	}
	/**
	 * @return the reference
	 * @hibernate.property column = "reference"
	 */
	public String getReference() {
		return reference;
	}
	/**
	 * @param reference the reference to set
	 */
	public void setReference(String reference) {
		this.reference = reference;
	}
	/**
	 * @return the settleAmt
	 * @hibernate.property column = "settle_Amt"
	 */
	public Double getSettleAmt() {
		return settleAmt;
	}
	/**
	 * @param settleAmt the settleAmt to set
	 */
	public void setSettleAmt(Double settleAmt) {
		this.settleAmt = settleAmt;
	}
	/**
	 * @return the settleDate
	 * @hibernate.property column = "settle_Date"
	 */
	public Date getSettleDate() {
		return settleDate;
	}
	/**
	 * @param settleDate the settleDate to set
	 */
	public void setSettleDate(Date settleDate) {
		this.settleDate = settleDate;
	}
	/**
	 * @return the status
	 * @hibernate.property column = "status"
	 */
	public Integer getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}

	/**
	 * @return the transactionId
	 * @hibernate.property column = "transaction_Id"
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	//CHG_UI_IBM_RJ_004
	public String getPaymentBIC() {
		return paymentBIC;
	}
	public void setPaymentBIC(String paymentBIC) {
		this.paymentBIC = paymentBIC;
	}	
	
	/**
	 * @return the type
	 * @hibernate.property column = "type"
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the wfId
	 * @hibernate.property column = "wf_Id"
	 */
	public Long getWfId() {
		return wfId;
	}
	/**
	 * @param wfId the wfId to set
	 */
	public void setWfId(Long wfId) {
		this.wfId = wfId;
	}
	
	/**
	 * @return the DocId
	 * @hibernate.property column = "DOC_ID"
	 */
	public String getDocId() {
		return docId;
		
	}
	/**
	 * @param docId the docId to set
	 */
	public void setDocId(String docId) {
		this.docId = docId;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((paymentId == null) ? 0 : paymentId.hashCode());
		return result;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Payment))
			return false;
		final Payment other = (Payment) obj;
		if (paymentId == null) {
			if (other.getPaymentId() != null)
				return false;
		} else if (!paymentId.equals(other.getPaymentId()))
			return false;
		return true;
	}
	
	public String getFormattedSettleAmt(){
		
		String sAmt = "";
		if(settleAmt!=null){
			try {
				DecimalFormat df = new DecimalFormat("0.00");
				sAmt = df.format(settleAmt);
			}catch (Exception e){
				log.warn("Error formatting Settelment Amount: " + e.getMessage());
				//do nothing - leave as empty string
			}
			
		}
		return sAmt;
		
	}
	
}
