/**
 * 
 */
package ic2.ui.exception;

/**
 * @author Ravi K Patel
 * created Mar 12, 2006
 */
public class IC2UISQLException extends IC2UIException {
	private static final long serialVersionUID = 1L;

	public IC2UISQLException() {
		super();
	}

	public IC2UISQLException(String message, Throwable cause) {
		super(message, cause);
	}

	public IC2UISQLException(String message) {
		super(message);
	}

	public IC2UISQLException(Throwable cause) {
		super(cause);
	}

}
