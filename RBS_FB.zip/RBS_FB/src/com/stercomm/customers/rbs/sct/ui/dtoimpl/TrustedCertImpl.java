/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dtoimpl;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;

import javax.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import javax.security.cert.X509Certificate;

import org.apache.log4j.Logger;
import com.stercomm.customers.rbs.sct.ui.Utils;
import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;
import com.sterlingcommerce.security.kcapi.CACertificateInfo;
import com.sterlingcommerce.security.kcapi.CertificateHeldException;
import com.sterlingcommerce.security.kcapi.CertificateInfoBase;
import com.sterlingcommerce.security.kcapi.CertificateRevokedException;
import com.sterlingcommerce.security.kcapi.IssuerNotFoundException;
import com.sterlingcommerce.security.kcapi.TrustedCertificateInfo;
import com.sterlingcommerce.woodstock.ui.BaseUIGlobals;

/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 */
public class TrustedCertImpl extends BaseHibernateBeanImpl implements TrustedCert{
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(TrustedCertImpl.class);

	private String certificateId;
	private String certificateName;
	//private String certificateThumbprint;
	//private FormFile certificateFile;
	private boolean valid=false;
	private String verifystatus;
	private X509Certificate certificate;
	private String authChainReport;
	private String changerComments;
	private String changeID;
	
	

	public String getChangeID() {
		return changeID;
	}
	public void setChangeID(String changeID) {
		this.changeID = changeID;
	}
	public String getCertificateId() {
		return certificateId;
	}
	public void setCertificateId(String certificateId) {
		this.certificateId = certificateId;
	}
	public String getStatus() {
		return verifystatus;
	}
	public String getAuthChainReport() {
		return authChainReport;
	}
	public void setStatus(String status) {
		this.verifystatus = status;
	}
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;

	}
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getCertificateName() {
		return certificateName;
	}
	public void setCertificateName(String certificateName) {
		this.certificateName = certificateName;
	}
	//public FormFile getCertificateFile() {
	//	return certificateFile;
	//}
	//public void setCertificateFile(FormFile certificateFile) {
	//	this.certificate=null;
	//	this.certificateFile = certificateFile;
	//}
	
	public void setX509Certificate(X509Certificate cert){
		this.certificate=cert;
	}
	
	public String getChangerComments() {
		return changerComments;
	}

	public void setChangerComments(String changerComments) {
		this.changerComments = changerComments;
	}



	public X509Certificate getX509Certificate(){

//		if(this.certificate==null){
//			try {
//				byte[] certData = this.getCertificateFile().getFileData();
//				this.certificate = X509Certificate.getInstance(certData);
//			} catch (FileNotFoundException e) {
//				throw e;
//			} catch (IOException e) {
//				throw e;
//			} catch (javax.security.cert.CertificateException e) {
//				throw e;
//			} 
//		} 	
		return this.certificate;
	}

	public String getSubjectRDNData(String tag)
	{
		String data = null;
		try {
			data = parseRDNData(tag, this.getX509Certificate().getSubjectDN().getName());
		} catch (Exception e){
			log.error("Error parsing the Subject RDN: " + e.getMessage());
		}
		return data;
	}
	public String getIssuerRDNData(String tag)
	{
		String data = null;
		try {
			data = parseRDNData(tag, this.getX509Certificate().getIssuerDN().getName());
		} catch (Exception e){
			log.error("Error parsing the Issuer RDN: " + e.getMessage());
		}
		return data;
	}

	public final String parseRDNData(String tag, String data)
	{
		if ((tag == null) || (tag.length() == 0)) {
			return null;
		}
		if (!tag.endsWith("="))
			tag = tag + "=";
		if (data == null)
			return null;
		int start = data.indexOf(tag);
		if (start == -1)
			return null;
		start += tag.length();
		int end = data.indexOf(",", start);
		if (end != -1) {
			return data.substring(start, end);
		}
		return data.substring(start);
	}

	public String getSerialNumber(){
		String data = null;
		try {
			data = String.valueOf(getX509Certificate().getSerialNumber().intValue());
		} catch (Exception e){
			log.error("Error getting the serial number: " + e.getMessage());
		}
		return data;
	}

	public String getStartDate(){
		String data = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			data =sdf.format(getX509Certificate().getNotBefore());
		} catch (Exception e){
			log.error("Error getting the start date: " + e.getMessage());
		}
		return data;
	}

	public String getEndDate(){
		String data = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			data =sdf.format(getX509Certificate().getNotAfter());
		} catch (Exception e){
			log.error("Error getting the end date: " + e.getMessage());
		}
		return data;
	}
	
	public boolean isValid(boolean bCheckUnique){
		//if(getStatus()==null){
		checkValidity(bCheckUnique);
		//}
		return this.valid;
	}

	public boolean isValid(){
		return isValid(true);
	}

	public TrustedCertificateInfo getTrustedCertificate() throws Exception{
		LinkedList<?> certList = this.getTrustedCertificates();
		if ((certList != null) && (certList.size() > 0)){
			return (TrustedCertificateInfo)certList.get(0);
		} else {
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	public LinkedList<TrustedCertificateInfo> getTrustedCertificates() throws Exception{
		LinkedList<TrustedCertificateInfo> certList = null;
		LinkedList<?> ErrorInfos = new LinkedList<Object>();

		try {
			certList = TrustedCertificateInfo.parseCertificateBlob(getX509Certificate().getEncoded(), BaseUIGlobals.out.debug, ErrorInfos, BaseUIGlobals.out, "[TrustedCertImpl].checkValidity()");
		} catch (CertificateEncodingException e) {
			log.error("Error getting the Trusted Certificates: " + e.getMessage());
			throw e;
		} catch (CertificateException e) {
			log.error("Error getting the Trusted Certificates: " + e.getMessage());
			throw e;
		} catch (Exception e) {
			log.error("Error getting the Trusted Certificates: " + e.getMessage());
			throw e;
		}

		return certList;

	}
	
	public String checkValidity(){
		return checkValidity(true);
	}

	@SuppressWarnings("unchecked")
	public String checkValidity(boolean bCheckUnique){

		LinkedList<?> certList = null;
		Vector<String> vStatus=null;
		String status = "";
		//StringBuffer sb = new StringBuffer();

		try {
			certList = this.getTrustedCertificates();
		} catch (Exception e1) {
			status = "Exception reading the import file";
			log.error("Error checking the validity of the certificate " + e1.getMessage());
		}

		if ((certList != null) && (certList.size() > 0))
		{
			vStatus = new Vector<String>(certList.size());
			Iterator<?> it = certList.iterator();
			int i = 0;
			while (it.hasNext())
			{

				this.valid=false;
				CertificateInfoBase c = (CertificateInfoBase)it.next();
				String sbOut = "Certificate is valid";
				if(i==0){
					try
					{
						//CACertificateInfo.verifyCert(c, certList, true, sb);
						Vector<CertificateInfoBase> authChain = CACertificateInfo.verifyCert(c, certList, true, null);

						if( bCheckUnique && !c.isCertUnique(TrustedCertificateInfo.m_ssInfoLocalTableName)){
							sbOut="A Trusted Certificate with this SHA-1 Thumbprint already exists in the SI keystore";
						}else{
							if(authChain==null || authChain.size()<1){
								//should not get here - IssuerNotFoundException shoul;d be thrown instead
								sbOut = "Certificate is not trusted.";
							} else if (authChain.size()==1){
								//self signed
								sbOut="Certificate is valid but is self-signed and therefore cannot be trusted via a certificate chain.";
							} else {								
								this.authChainReport=this.buildAuthChainReport(authChain);
								this.valid=true;
							}
						}
					}
					catch (CertificateHeldException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Certificate is held";
					}
					catch (CertificateRevokedException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Certificate is revoked";
					}
					catch (IssuerNotFoundException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Certificate Auth Chain incomplete. The certificate is not trusted.";
					}
					catch (CertificateExpiredException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Certificate has expired";
					}
					catch (CertificateNotYetValidException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Certificate is not yet valid";
					}
					catch (NoSuchAlgorithmException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Unsupported algorithm";
					}
					catch (InvalidKeyException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Certificate is invalid";
					}
					catch (NoSuchProviderException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Provider Exception. Contact your system administration and refer to the logs.";
					}
					catch (SignatureException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Certificate has an invalid signature";
					}
					catch (CertificateException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "Exception";
					}
					catch (SQLException e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "System exception. Contact your system administration and refer to the logs.";
					}
					catch (Exception e)
					{
						log.error("Error checking the validity of the certificate " + e.getMessage());
						sbOut = "System exception. Contact your system administration and refer to the logs.";
					}
				} else {
					this.valid=false;
					sbOut = "The import file contains " + certList.size() + " certificates. Only one certificate will be imported.";
				}

				vStatus.add(sbOut);
				i++;
				if(i>1){
					break;
				}
			}
			//	      setVerificationStatus(vStatus);
			//	      bReturn = true;
		}


		if(vStatus==null || vStatus.size()<1){
			status="Unknown";
		} else {
			Iterator<String> statii = vStatus.iterator();
			while(statii.hasNext()){
				String s = statii.next();
				if(s!=null && !s.equalsIgnoreCase("")){
					status = status + s + "\n";
				}
			}

		}
		//		if(sb!=null && sb.length()>0){
		//			status = status + "\n" + sb.toString();
		//		}

		setStatus(status);
		return status;
	}
	
	//public void setThumbprint(String thumbprint){
	//	certificateThumbprint=thumbprint;
	//}

	public String getThumbprint(){
		
		//if(getX509Certificate()==null){
		//	return certificateThumbprint;
		//}

		String thumbprint=null;

		try {
			MessageDigest md = MessageDigest.getInstance("SHA-1");        
			byte[] der = this.getX509Certificate().getEncoded();        
			md.update(der);   
			byte[] tprint = md.digest();
			thumbprint =  Utils.getHexString(tprint);
		} catch (NoSuchAlgorithmException e) {
			log.error("Error getting the Certificate Thumbprint: " + e.getMessage());
		} catch (CertificateEncodingException e) {
			log.error("Error getting the Certificate Thumbprint: " + e.getMessage());
		} catch (UnsupportedEncodingException e) {
			log.error("Error getting the Certificate Thumbprint: " + e.getMessage());
		//} catch (CertificateException e) {
		//	log.error("Error getting the Certificate Thumbprint: " + e.getMessage());
		} catch (Exception e) {
			log.error("Error getting the Certificate Thumbprint: " + e.getMessage());
		}

		return thumbprint;
	}
	
	private String buildAuthChainReport(Vector<CertificateInfoBase> authChain){
		
		Iterator<CertificateInfoBase> acit = authChain.iterator();
		StringBuffer acr = new StringBuffer();
		int acrnum = 0;
		acr.append("<ul>");
		//build an Auth Chain Report
		while(acit.hasNext()){
			CertificateInfoBase ctemp = acit.next();
			acr.append("<li>");
			acr.append("Certificate Name ("+ (acrnum + 1) + "): ");
			if(acrnum==0){
				//SI doesn't know about the first in the chain
				acr.append(this.getCertificateName());
			} else {
				acr.append(ctemp.getName());
			}
			acr.append("</li>");
			acr.append("<ul>");
			acr.append("<li>");
			acr.append("Subject DN: ");
			acr.append(ctemp.getNormalizedSubjectRDN());
			acr.append("</li>");
			acr.append("</ul>");
			acrnum++;
		}
		acr.append("</ul>");
		
		return acr.toString();
	}

}
