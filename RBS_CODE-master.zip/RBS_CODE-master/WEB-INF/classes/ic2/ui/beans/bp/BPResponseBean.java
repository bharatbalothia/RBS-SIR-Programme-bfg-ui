/**
 * 
 */
package ic2.ui.beans.bp;

import java.io.Serializable;

import org.w3c.dom.Document;

/**
 * @author Ravi K Patel
 * created Apr 26, 2006
 */
public interface BPResponseBean extends Serializable {
	public String getErrorCode() ;
	public void setErrorCode(String errorCode);
	public String getErrorDescription() ;
	public void setErrorDescription(String errorDescription) ;
	public boolean isSuccess();
	public void setSuccess(boolean success);
	
	public void setResponseDocument(Document responseDocument);
	public Document getResponseDocument();
}
