/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.stercomm.customers.rbs.sct.ui.change.ChangeControl;
import com.stercomm.customers.rbs.sct.ui.change.TrustedCertChange;
import com.stercomm.customers.rbs.sct.ui.change.TrustedCertCreateAction;
import com.stercomm.customers.rbs.sct.ui.change.TrustedCertDeleteAction;
import com.stercomm.customers.rbs.sct.ui.change.TrustedCertUpdateAction;
import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;
import com.sterlingcommerce.woodstock.dmi.visibility.event.AFCDmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.ExceptionLevel;
import com.sterlingcommerce.woodstock.util.BaseUtil;

public class TrustedCertsConfirmAction extends BaseTrustedCertsWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(TrustedCertsConfirmAction.class);

	public ActionForward viewForm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		return mapping.findForward("viewForm");

	}

	public ActionForward finish(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		TrustedCert tc = getTrustedCert(request);
		TrustedCertChange tcc = new TrustedCertChange();

		try {
			tc.setChangeID(tcc.getChangeID());
			if(tc.isCreateBean()){
				TrustedCertCreateAction tcca = new TrustedCertCreateAction(tc);
				tcc.setActionType(tcca.getClass().getCanonicalName());
				tcc.setActionObject(tcca.getObjectBytes());
				tcc.setOperation(ChangeControl.OPERATION_CREATE);
			} else if(tc.isDeleteBean()){
				
				TrustedCertDeleteAction tcda = new TrustedCertDeleteAction(tc);
				tcc.setActionType(tcda.getClass().getCanonicalName());
				tcc.setActionObject(tcda.getObjectBytes());
				tcc.setObjectKey(tc.getCertificateId());
				tcc.setOperation(ChangeControl.OPERATION_DELETE);

			} else {
				TrustedCertUpdateAction tcua = new TrustedCertUpdateAction(tc);
				tcc.setActionType(tcua.getClass().getCanonicalName());
				tcc.setActionObject(tcua.getObjectBytes());
				tcc.setObjectKey(tc.getCertificateId());
				tcc.setOperation(ChangeControl.OPERATION_UPDATE);
			}
			tcc.setChanger(this.getGisUsername(request));
			tcc.setChangerNotes(tc.getChangerComments());
			tcc.setResultType(tc.getClass().getCanonicalName());
			tcc.setResultObject(tc.getObjectBytes());
			tcc.setResultMeta1(tc.getCertificateName());
			tcc.setResultMeta2(tc.getThumbprint());

			tcc.insert();

			AFCDmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, BaseUtil.createGUID(), System.currentTimeMillis(), getGisUsername(request), tcc.getShortType() + ": " + tcc.getOperation(), "Change Requested", tc.getChangeID(), tc.getCertificateName());

		}catch(Exception e){
			log.error("Error persisting the Change Control record: " + e.getMessage());
			e.printStackTrace();
			//throw new Exception("The Trusted Certificate could not be saved.");
			return mapping.findForward("error");
		}
		
		return mapping.findForward("finish");
	}
}
