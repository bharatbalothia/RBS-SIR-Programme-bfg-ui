package com.stercomm.customers.rbs.sct.ui.actions;

import java.util.Date;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.stercomm.customers.rbs.sct.ui.dao.FileAuthRequestDAO;
import com.stercomm.customers.rbs.sct.ui.dto.FileAuthRequest;
import com.stercomm.customers.rbs.sct.ui.fileauth.FGFile;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuth;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuthUsers;
import com.stercomm.customers.webapps.resources.Constants;
import com.sterlingcommerce.woodstock.security.User;


/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
@SuppressWarnings("unchecked")
public class FileAuthRequestLoadAction extends BaseStrutsAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(FileAuthRequestLoadAction.class);

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		log.debug("FileAuthRequestLoadAction.viewForm()");

		String reqFileKey = request.getParameter("filekey");
		String reqFileAction = request.getParameter("fileaction");
		String reqFileAuthID = request.getParameter("id");
		String deliveryTab = request.getParameter("delivery");
		String currentUser = this.getGisUsername(request);
		String _fileKey=null;
		String _fileAction=null;
		boolean canRequest = false;
		boolean canApprove = false;
		boolean canExecute = false;
		boolean canApproveOwnChanges=false;

		ActionErrors errors = new ActionErrors();

		try {
			
			if(reqFileAuthID!=null &&  !reqFileAuthID.equalsIgnoreCase("")){
				int reqFAID=0;
				try {
					reqFAID = Integer.parseInt(reqFileAuthID);
				} catch (NumberFormatException e) {
					throw new Exception("Invalid FileAuthID parameter value: " +  reqFileAuthID);
				}
				FileAuth reqFA = new FileAuth(reqFAID);
				if(!reqFA.isLoaded()){
					throw new Exception("Cannot load record from File Auth ID: "+ reqFAID);
				}
				//override the request settings (if they were even set)
				reqFileKey = reqFA.getFileKey();
				reqFileAction = reqFA.getAction();
				deliveryTab="TRUE";//file key will be a delivery key
			}

			_fileAction = FileAuth.validateAction(reqFileAction);
			User user = (User)request.getSession().getAttribute(Constants.GIS_USER_OBJECT);
			
			//check the current user can REQUEST
			if(user.hasPermission(FileAuth.getRequestPermission(_fileAction))){
				canRequest=true;
			}
			//check the current user can APPROVE
			if(user.hasPermission(FileAuth.getApprovePermission(_fileAction))){
				canApprove=true;
			}
			//check the current user can EXECUTE
			if(user.hasPermission(FileAuth.getActionPermission(_fileAction))){
				canExecute=true;
			}
			//check the current user can APPROVE OWN REQUEST (explicit)
			if(user.hasExplicitPermission(FileAuth.REQUEST_APPROVE_OWN_PERM)){
				canApproveOwnChanges=true;
			}
			
			FileAuthRequestDAO dao = new FileAuthRequestDAO(getHibernateSession());
			FileAuthRequest far = null;
			
			boolean isDeliveryKey=false;			
			String arrivedFileKey = reqFileKey;
			String deliveryKey = null;
			
			if(_fileAction.equalsIgnoreCase(FileAuth.ACTION_REDELIVER)){			
				if(deliveryTab!=null && deliveryTab.equalsIgnoreCase("TRUE")){
					isDeliveryKey=true;
					deliveryKey = reqFileKey;
					arrivedFileKey=FGFile.findAFKey(deliveryKey);
					if(arrivedFileKey==null){
						throw new Exception("Cannot find FGFile for DeliveryKey: " + deliveryKey);
					}
				}
			}
		
			
			FGFile fgFile = new FGFile(arrivedFileKey);
			if(fgFile==null || fgFile.getArrivedFilename().length()==0){
				//no arrivedfile record
				throw new Exception("Cannot load FGFile with ArrivedFileKey: " + arrivedFileKey);
			}
			

			if(_fileAction.equalsIgnoreCase(FileAuth.ACTION_REDELIVER)){
				if(!isDeliveryKey){
					//we are redelivering from the ARRIVEDFILE Tab
					//we need to turn the fileKey into a DELIVERY key
					//CHECK there is only ONE DELIVERY record
					if(fgFile.getDeliveryRecordCount()>1){
						log.error("ArrivedFile has more than one delivery records.");
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.deliverycount.error"));
						saveErrors(request, errors);	
						//request.setAttribute("fgFile", fgFile);
						request.getSession().setAttribute("fileAuthRequestBean", far);
						return mapping.findForward("error");
					}
					if(fgFile.getDeliveryRecordCount()==0){
						log.error("ArrivedFile has no delivery records.");
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.nodelivery.error"));
						saveErrors(request, errors);	
						//request.setAttribute("fgFile", fgFile);
						request.getSession().setAttribute("fileAuthRequestBean", far);
						return mapping.findForward("error");
					}
					
					_fileKey = fgFile.getDeliveryKey();
				} 
				_fileKey = fgFile.getDeliveryKey();
			} else {
				_fileKey = fgFile.getArrivedFileKey();
			}
			

			//load up any existing requests
			ArrayList faList = dao.getFileAuthList(_fileKey, _fileAction);
			if(faList==null || faList.size()<1){
				
				//no existing FileAuth records (requested or approved)
				if(!canRequest){
					String msg = "fileauth.msgs.norequestperm." + _fileAction.toLowerCase() + ".error";
					errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError(msg));
					saveErrors(request, errors);	
					return mapping.findForward("error");
				}
				far = dao.getNewInstance();
				far.setCreateBean(true);
				far.setNewBean(true);
				far.setDeleteBean(false);
				far.setFgFile(fgFile);
				
			} else {
				//we have an requested or approved FileAuth record
				//only use the latest
				FileAuth latestFA = (FileAuth)faList.get(0);
				log.debug("Latest FileAuth object ID: "+latestFA.getFileAuthID());
				
				far = dao.getInstance(latestFA);
				far.setFgFile(fgFile);

				Date now = new Date();
				if(latestFA.getDateExpired().getTime()<now.getTime()){

					//latestFA.setStatus(FileAuth.STATUS_EXPIRED);
					//latestFA.updateStatus();
					latestFA.expire();
					far.setFileAuth(latestFA);
					
					String msg = "fileauth.msgs.expired." + _fileAction.toLowerCase() + ".error";
					errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError(msg));
					saveErrors(request, errors);	
					
					request.getSession().setAttribute("fileAuthRequestBean", far);
					return mapping.findForward("error");

				}

				if(latestFA.getStatus()==FileAuth.STATUS_REQUESTED){
					//pending request
					//show approval screen if permitted
					//otherwise show details of request

					if(canApprove){
						
						//check the users aren't the same
						if(latestFA.getRequestor().equalsIgnoreCase(currentUser)){
							//throw error if they can't approve their own changes
							if(!canApproveOwnChanges){
								errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.noapproveperm.ownrequest.error"));
								saveErrors(request, errors);
								request.getSession().setAttribute("fileAuthRequestBean", far);
								return mapping.findForward("error");
							}
							
							
						}
						
						request.getSession().setAttribute("fileAuthRequestBean", far);
						return mapping.findForward("approveRequest");

					} else {

						//existing pending request for non-approving user
						String msg = "fileauth.msgs.existing." + _fileAction.toLowerCase() + ".error";
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError(msg));
						if(!canRequest){
							msg = "fileauth.msgs.norequestperm." + _fileAction.toLowerCase() + ".error";
							errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError(msg));
						}
						saveErrors(request, errors);	

						request.getSession().setAttribute("fileAuthRequestBean", far);
						return mapping.findForward("error");

					}

				} else if(latestFA.getStatus()==FileAuth.STATUS_APPROVED){
					//show execution screen - only allow if user is permitted
					if(!canExecute){
						String msg = "fileauth.msgs.noexecuteperm." + _fileAction.toLowerCase() + ".error";
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError(msg));
						saveErrors(request, errors);	

						request.getSession().setAttribute("fileAuthRequestBean", far);
						return mapping.findForward("error");
					}
				
					if(!FileAuthUsers.isUserPermitted(currentUser, latestFA.getFileAuthID())){
						String msg = "fileauth.msgs.noauthperm." + _fileAction.toLowerCase() + ".error";
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError(msg));
						saveErrors(request, errors);	
		
						request.getSession().setAttribute("fileAuthRequestBean", far);
						return mapping.findForward("error");
					}
	
					
					//show the EXECUTE screen
					request.getSession().setAttribute("fileAuthRequestBean", far);
					return mapping.findForward("executeRequest");
				}

			}

			//We are free to create a new REQUEST
			far.setFileKey(_fileKey);
			far.setFileAction(_fileAction);

			//default the current user to the assigned user if they can execute
			if(canExecute){
				String[] currentUsers={currentUser};
				far.setUsers(currentUsers);
			}

			request.getSession().setAttribute("fileAuthRequestBean", far);
			return mapping.findForward("createRequest");
			
		} catch (Exception e){
			log.error("FileAuthRequestLoad error: " + e.getMessage());
			errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.load.error"));
			saveErrors(request, errors);	
			request.getSession().setAttribute("fileAuthRequestBean", null);
			String eMsg = e.getMessage()==null?"None":e.getMessage().trim();
			request.setAttribute("exceptionMessage", "Exception message: " + eMsg);
			return mapping.findForward("error");
		}
	}


}
