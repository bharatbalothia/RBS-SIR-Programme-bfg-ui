/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.webapps.security.struts;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.RequestProcessor;
import org.apache.struts.config.ExceptionConfig;


import com.stercomm.customers.webapps.security.UnauthorizedException;
import com.sterlingcommerce.woodstock.security.User;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 * created Apr 20, 2006
 */
public class SecureRequestProcessor extends RequestProcessor {
	private static final Log log = LogFactory.getLog(SecureRequestProcessor.class);
	protected boolean processRoles(HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) throws IOException, ServletException {
		log.debug("processRoles() for :"+mapping.getPath());
		//RELEASE: make sure authorized is false;
		boolean authorized = false;
		String[] roles = mapping.getRoleNames();
		if (roles.length==0){
			//authorized = true;
		}
		else {
			HttpSession session = request.getSession(false);
			if (session !=null){
				Object o = session.getAttribute("GIS_USER_OBJECT");
				if (o!=null && o instanceof User){
					User user = (User)o;
					for (int i=0; i<roles.length; i++){
						if (user.hasPermission(roles[i])){
							
							authorized = true;
							break;
						}
					}
					
				}
			}
		}
		
		if (!authorized){
			log.debug("user request not authorized. User must have permission from set:"+mapping.getRoles());
			ExceptionConfig excfg = mapping.findException(UnauthorizedException.class);
			if (excfg==null){
				throw new UnauthorizedException("Access to resource denied: User is not authorised to view the requested resource");
			}
			request.getRequestDispatcher(excfg.getPath()).forward(request, response);
		}
		return authorized;
	}
}

/**********************************************************************
*
* Revision History
* ================
*
* $Log: $
*/