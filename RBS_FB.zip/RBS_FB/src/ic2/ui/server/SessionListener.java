/**
 * 
 */
package ic2.ui.server;


import ic2.ui.SessionVarConstants;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * @author Ravi K Patel
 * created Mar 1, 2006
 */
public class SessionListener implements HttpSessionListener {

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpSessionListener#sessionCreated(javax.servlet.http.HttpSessionEvent)
	 */
	public void sessionCreated(HttpSessionEvent sessionEvent) {
		
		Map<?, ?> waitKeyMap = new HashMap<Object, Object>();
		sessionEvent.getSession().setAttribute(SessionVarConstants.WAIT_KEY_MAP, waitKeyMap);
		
	}

	/* (non-Javadoc)
	 * @see javax.servlet.http.HttpSessionListener#sessionDestroyed(javax.servlet.http.HttpSessionEvent)
	 */
	public void sessionDestroyed(HttpSessionEvent sessionEvent) {
		//sessionEvent.getSession().removeAttribute(SessionVarConstants.WAIT_KEY_MAP);
	}

}
