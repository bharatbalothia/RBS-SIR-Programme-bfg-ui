/**
 * 
 */
package ic2.ui.db;

import ic2.ui.exception.IC2UIRuntimeException;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.UndeclaredThrowableException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.apache.log4j.Logger;


/**
 * @author Ravi K Patel
 * created Mar 2, 2006
 */
public class DBUtils {
	private static final Logger logger = Logger.getLogger(DBUtils.class);
	
	public Connection getConnection(ServletContext context) throws SQLException{
		try {
			//logger.debug("Getting datasource connection from context");
			DataSource ds = (DataSource)context.getAttribute("connectionCache");
			return ds.getConnection();
			//return ((DataSource)context.getAttribute("connectionCache")).getConnection();
		} catch (SQLException e) {
			logger.debug("exception while obtaining db connection from (pooled context)DataSource", e);
			throw e;
		}
	}
	
	public Connection getConnection(HttpServletRequest request) throws SQLException{
			//logger.debug("Getting datasource connection from request");
			return getConnection(request.getSession().getServletContext());
	}
	
	public void setParams(PreparedStatement pstmnt, Object[] params) throws SQLException{
		
		try {
			for (int i=0; i<params.length; i++){
				
				logger.debug("Setting param " + String.valueOf(i+1) + " with " + params[i]);
				pstmnt.setObject(i+1, params[i]);
			}
		} catch (SQLException e) {
			logger.debug("exception while setting PreparedStatement parameters", e);
			throw e;
		}
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Object> getBeanList(Class<?> beanType, ResultSet rset, String[] sqlColumns, String[] beanMethods, Class[] types) throws Exception{
		List<Object> resultCollection = new ArrayList<Object>();
		getBeanCollection(beanType, resultCollection, rset, sqlColumns, beanMethods, types);
		return resultCollection;
	}
	
	@SuppressWarnings("unchecked")
	public void getBeanCollection(final Class<?> beanType, final Collection<Object> resultCollection, final ResultSet rset, final String[] sqlColumns, final String[] beanMethods, final Class[] types) throws Exception{
		int i=0;
		while (rset.next()){
			logger.debug("row #"+i++);
			resultCollection.add(getBean(beanType, rset, sqlColumns, beanMethods, types));
		}
	}
	
	@SuppressWarnings("unchecked")
	public Map<Object, Object> getBeanMap(final Class<?> beanType, final String beanKey, final ResultSet rset, final String[] sqlColumns, final String[] beanMethods, final Class[] types) throws Exception{
		Map<Object, Object> resultMap = new HashMap<Object, Object>();
		getBeanMap(beanType, beanKey, resultMap, rset, sqlColumns, beanMethods, types);
		return resultMap;
	}
	@SuppressWarnings("unchecked")
	public void getBeanMap(final Class<?> beanType, final String beanKey, final Map<Object, Object> resultMap,  final ResultSet rset, final String[] sqlColumns, final String[] beanMethods, final Class[] types) throws Exception{
		int i=0;
		while (rset.next()){
			logger.debug("row #"+i++);
			Object bean = getBean(beanType, rset, sqlColumns, beanMethods, types);
			String method = getGetter(beanKey);
			Object keyValue = bean.getClass().getMethod(method, new Class[0]).invoke(bean, (Object)null);
			resultMap.put(keyValue, bean);
		}
	}
	
	private String getGetter(String attribute){
		StringBuffer methodName = new StringBuffer(attribute);
		String prefix = "get";
		methodName.replace(0, 1, prefix+Character.toUpperCase(methodName.charAt(0)));
		return methodName.toString();
	}
	
	private String getSetter(String attribute){
		StringBuffer methodName = new StringBuffer(attribute);
		String prefix = "set";
		methodName.replace(0, 1, prefix+Character.toUpperCase(methodName.charAt(0)));
		return methodName.toString();
	}
	
	@SuppressWarnings("unchecked")
	public Object getBean(Class<?> beanType, ResultSet rset, String[] sqlColumns, String[] beanMethods, Class[] types) throws SQLException, IllegalAccessException, InstantiationException{
		Object bean = beanType.newInstance();
		
		for (int i=0; i<sqlColumns.length; i++){

			String methodName = getSetter(beanMethods[i]);
			
			logger.debug("current sqlcolumn:"+sqlColumns[i]);
			try {
				Object rsetObject;
				
				if (types[i]==Integer.TYPE || types[i]==Integer.class) {
					rsetObject = new Integer(rset.getInt(sqlColumns[i]));
					if (rset.wasNull()){
						rsetObject = null;
					}
						
				}
				else if (types[i]==String.class) rsetObject = rset.getString(sqlColumns[i]);
				else if (types[i]==Boolean.TYPE || types[i]==Boolean.class) {
					
					/*
					 * this _if_ block tries to convert the value from column to a boolean.
					 * 
					 * First tries to convert the row to a String or BigDecimal where the following mappings are made
					 * If it cannot be converted, the type is extracted as Object, and type is assigned by jdbc column conversions
					 * 
					 * int value '1' will map to true
					 * String value '1' or 'y' or 'Y' will map to true
					 * TODO: create a way for these mappings to be set from method parameters
					 * 
					 * All other values map to false
					 * 
					 */
					
					logger.debug("looking up boolean type");
					Object o = rset.getObject(sqlColumns[i]);
					if (o instanceof BigDecimal) {
						int intBool = ((BigDecimal)o).intValue();
						logger.debug("boolean BigDecimal value = "+o);
						rsetObject = new Boolean(intBool==1);
						logger.debug("boolean int value = "+intBool);
					}
					else if (o instanceof String){
						String obj = rset.getString(sqlColumns[i]);
						rsetObject = new Boolean((obj.equalsIgnoreCase("Y") || obj.equalsIgnoreCase("1"))); 
						logger.debug("boolean String value = "+obj);
					}
					else rsetObject = rset.getObject(sqlColumns[i]);
				}
				else rsetObject = rset.getObject(sqlColumns[i]);
				
				if (rsetObject==null){
					logger.debug("executing method "+methodName.toString()+" with arg:("+types[i].getName()+")null");
				}
				else {
					logger.debug("executing method "+methodName.toString()+" with arg:("+types[i].getName()+")"+rsetObject+" - "+rsetObject.getClass().getName());
				}
				Method method = bean.getClass().getMethod(methodName.toString(), new Class[]{types[i]});
				method.invoke(bean, new Object[]{rsetObject});
				logger.debug("method "+methodName.toString()+" executed");
				
			} catch (SecurityException e) {
				logger.fatal("SecurityException", e);
				throw new RuntimeException("SecurityException", e);
			} catch (NoSuchMethodException e) {
				logger.fatal("method "+methodName.toString()+" not found", e);
				throw new RuntimeException("NoSuchMethodException", e);
			} catch (IllegalAccessException e){
				logger.fatal("IllegalAccessException", e);
				throw new RuntimeException("IllegalAccessException", e);
			} catch (InvocationTargetException e){
				logger.fatal("InvocationTargetException", e);
				throw new RuntimeException("InvocationTargetException", e);
			}
			
			
		}
		
		
		return bean;
	}
	
	
public int executeCountQuery(HttpServletRequest request, String sql, Object[] params) throws SQLException{
	Connection connection = null;
	ResultSet rset = null;
	PreparedStatement pstmnt = null;
	int count;
	//logger.debug("Entering ExecuteCountQuery");
	try {
		connection = getConnection(request);
		pstmnt = connection.prepareStatement(sql);
		setParams(pstmnt, params);
		pstmnt.execute();
		rset = pstmnt.getResultSet();
		rset.next();
		count = rset.getInt(1);
	}catch (SQLException e){
		logger.debug("caught sql exception while excuting executeCountQuery. rethrowing", e);
		throw e;
	}
	finally {
		if (pstmnt != null) pstmnt.close();
		if (rset != null) rset.close();
		if (connection != null) connection.close();
	}
	return count;	
}

public String executeSingleStringResultQuery(HttpServletRequest request, String sql, Object[] params) throws SQLException{
	Connection connection = null;
	ResultSet rset = null;
	PreparedStatement pstmnt = null;
	String result = null;
	try {
		connection = getConnection(request);
		pstmnt = connection.prepareStatement(sql);
		setParams(pstmnt, params);
		pstmnt.execute();
		rset = pstmnt.getResultSet();
		if (rset.next()){
			result = rset.getString(1);
		}
	}catch (SQLException e){
		logger.debug("caught sql exception while excuting executeSingleStringResultQuery. rethrowing", e);
		throw e;
	}
	finally {
		if (pstmnt != null) pstmnt.close();
		if (rset != null) rset.close();
		if (connection != null) connection.close();
	}
	return result;	
}

public List<String> executeStringListQuery(HttpServletRequest request, String sql, Object[] params) throws SQLException{
	Connection connection = getConnection(request);
	return executeStringListQuery(connection, sql, params);
}

public List<String> executeStringListQuery(ServletContext context, String sql, Object[] params) throws SQLException{
	Connection connection = getConnection(context);
	return executeStringListQuery(connection, sql, params);
}

public List<String> executeStringListQuery(Connection connection, String sql, Object[] params) throws SQLException{
	ResultSet rset = null;
	PreparedStatement pstmnt = null;
	List<String> results = new ArrayList<String>();
	try {
		pstmnt = connection.prepareStatement(sql);
		setParams(pstmnt, params);
		pstmnt.execute();
		rset = pstmnt.getResultSet();
		while (rset.next()){
			results.add(rset.getString(1));
		}
	}catch (SQLException e){
		logger.debug("caught sql exception while excuting executeStringListQuery. rethrowing", e);
		throw e;
	}
	finally {
		if (pstmnt != null) pstmnt.close();
		if (rset != null) rset.close();
		if (connection != null) connection.close();
	}
	return results;	
}

public Map<Object, Object> executeGetBeanMap(Class<?> beanType, String beanKey, ServletContext context, String sql, Object[] params, DBUtils.ResultSetMapping mapping) throws SQLException, UndeclaredThrowableException {
	Map<Object, Object> resultMap = new HashMap<Object, Object>();
	executeGetBeanMap(beanType, beanKey, resultMap, context, sql, params, mapping);
	return resultMap;
}

public void executeGetBeanMap(Class<?> beanType, String beanKey, Map<Object, Object> resultMap, ServletContext context, String sql, Object[] params, DBUtils.ResultSetMapping mapping) throws SQLException, UndeclaredThrowableException {
	Connection connection = getConnection(context);
	executeGetBeanMap(beanType, beanKey, resultMap, connection, sql, params, mapping);
}

public Map<Object, Object> executeGetBeanMap(Class<?> beanType, String beanKey, HttpServletRequest request, String sql, Object[] params, DBUtils.ResultSetMapping mapping) throws SQLException, UndeclaredThrowableException {
	Map<Object, Object> resultMap = new HashMap<Object, Object>();
	executeGetBeanMap(beanType, beanKey, resultMap, request, sql, params, mapping);
	return resultMap;
}

public void executeGetBeanMap(Class<?> beanType, String beanKey, Map<Object, Object> resultMap, HttpServletRequest request, String sql, Object[] params, DBUtils.ResultSetMapping mapping) throws SQLException, UndeclaredThrowableException {
	Connection connection = getConnection(request);
	executeGetBeanMap(beanType, beanKey, resultMap, connection, sql, params, mapping);
}
public void executeGetBeanMap(Class<?> beanType, String beanKey, Map<Object, Object> resultMap, Connection connection, String sql, Object[] params, DBUtils.ResultSetMapping mapping) throws SQLException, UndeclaredThrowableException {

	ResultSet rset = null;
	PreparedStatement pstmnt = null;
	
	
	try {
		pstmnt = connection.prepareStatement(sql);
		setParams(pstmnt, params);
		pstmnt.execute();
		rset = pstmnt.getResultSet();
		getBeanMap(beanType, beanKey, resultMap, rset, mapping.getSqlColumns(), mapping.getBeanMethods(), mapping.getTypes());
	}catch (SQLException e){
		logger.debug("caught sql exception. rethrowing", e);
		throw e;
	}catch (Exception e){
		logger.debug("wrapping throwable exception into UndeclaredTrowableException");
		throw new UndeclaredThrowableException(e);
	} finally {
		if (pstmnt!=null) try {pstmnt.close();} finally{};
		if (rset!=null) try {rset.close();} finally{};
		if (connection!=null) try {connection.close();} finally{};
	}
}

public void executeGetBeanCollection(Class<?> beanType, Collection<Object> resultCollection, HttpServletRequest request, String sql, Object[] params, DBUtils.ResultSetMapping mapping) throws SQLException, UndeclaredThrowableException {
	
	Connection connection = null;
	ResultSet rset = null;
	PreparedStatement pstmnt = null;
	
	
	try {
		connection = getConnection(request);
		pstmnt = connection.prepareStatement(sql);
		setParams(pstmnt, params);
		pstmnt.execute();
		rset = pstmnt.getResultSet();
		getBeanCollection(beanType, resultCollection, rset, mapping.getSqlColumns(), mapping.getBeanMethods(), mapping.getTypes());
	}catch (SQLException e){
		logger.debug("caught sql exception. rethrowing", e);
		throw e;
	}catch (Exception e){
		logger.debug("wrapping throwable exception into UndeclaredTrowableException", e);
		throw new UndeclaredThrowableException(e);
	} finally {
		if (pstmnt!=null) try {pstmnt.close();} finally{};
		if (rset!=null) try {rset.close();} finally{};
		if (connection!=null) try {connection.close();} finally{};
	}
}
	
	
public List<Object> executeGetBeanList(Class<?> beanType, HttpServletRequest request, String sql, Object[] params, DBUtils.ResultSetMapping mapping) throws SQLException, UndeclaredThrowableException {
		
		Connection connection = null;
		ResultSet rset = null;
		PreparedStatement pstmnt = null;
		
		List<Object> list;
		try {
			connection = getConnection(request);
			pstmnt = connection.prepareStatement(sql);
			setParams(pstmnt, params);
			pstmnt.execute();
			rset = pstmnt.getResultSet();
			list = getBeanList(beanType, rset, mapping.getSqlColumns(), mapping.getBeanMethods(), mapping.getTypes());
		}catch (SQLException e){
			logger.debug("caught sql exception. rethrowing", e);
			throw e;
		}catch (Exception e){
			logger.debug("wrapping throwable exception into UndeclaredTrowableException", e);
			throw new UndeclaredThrowableException(e);
		} finally {
			if (pstmnt!=null) try {pstmnt.close();} finally{};
			if (rset!=null) try {rset.close();} finally{};
			if (connection!=null) try {connection.close();} finally{};
		}
		return list;
	}
	
	public Object executeGetBean(Class<?> beanType, HttpServletRequest request, String sql, Object[] params, DBUtils.ResultSetMapping mapping) throws SQLException, UndeclaredThrowableException {
		
		Connection connection = null;
		ResultSet rset = null;
		PreparedStatement pstmnt = null;
		
		Object bean = null;
		try {
			connection = getConnection(request);
			pstmnt = connection.prepareStatement(sql);
			setParams(pstmnt, params);
			pstmnt.execute();
			rset = pstmnt.getResultSet();
			while(rset.next()){
				bean = getBean(beanType, rset, mapping.getSqlColumns(), mapping.getBeanMethods(), mapping.getTypes());
				break;
			}
		}catch (SQLException e){
			logger.debug("caught sql exception. rethrowing", e);
			throw e;
		}catch (Exception e){
			logger.debug("wrapping throwable exception into UndeclaredTrowableException");
			throw new UndeclaredThrowableException(e);
		} finally {
			if (pstmnt!=null) try {pstmnt.close();} finally{};
			if (rset!=null) try {rset.close();} finally{};
			if (connection!=null) try {connection.close();} finally{};
		}
		return bean;
	}
	
	
	public static class ResultSetMapping{
		private static final Logger logger = Logger.getLogger(DBUtils.ResultSetMapping.class); 
		private String[] sqlColumns;
		private String[] beanMethods;
		@SuppressWarnings("unchecked")
		private Class[] types;
		@SuppressWarnings("unchecked")
		public ResultSetMapping(String[] sqlColumns, String[] beanMethods, Class[] types) {
			if ((sqlColumns.length == beanMethods.length) && (sqlColumns.length== types.length)){
				this.sqlColumns = sqlColumns;
				this.beanMethods = beanMethods;
				this.types = types;
			}
			else{
				IC2UIRuntimeException ex =  new IC2UIRuntimeException("Array lengths not equal");
				logger.fatal("parameter array lengths were not equal", ex);
				throw ex;
			}
		}
		public String[] getBeanMethods() {
			return beanMethods;
		}
		public String[] getSqlColumns() {
			return sqlColumns;
		}
		@SuppressWarnings("unchecked")
		public Class[] getTypes() {
			return types;
		}
		
		
	}
}
