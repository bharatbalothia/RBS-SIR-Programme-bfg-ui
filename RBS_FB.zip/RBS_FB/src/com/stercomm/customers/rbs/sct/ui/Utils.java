/*******************************************************************
 Copyright (c) 2006 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;

import com.stercomm.customers.webapps.resources.Constants;
import com.sterlingcommerce.woodstock.dmi.visibility.event.DmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.*;
import com.sterlingcommerce.woodstock.util.Util;
import com.sterlingcommerce.woodstock.util.frame.Manager;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class Utils {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(Utils.class);
	
	private static final ThreadLocal<Utils> threadSession = new ThreadLocal<Utils>(); 
	
	private static final String DEFAULT_DATE_FORMAT = "dd/MM/yyyy HH:mm:ss";
	
	static final byte[] HEX_CHAR_TABLE = {
		(byte)'0', (byte)'1', (byte)'2', (byte)'3',
		(byte)'4', (byte)'5', (byte)'6', (byte)'7',
		(byte)'8', (byte)'9', (byte)'a', (byte)'b',
		(byte)'c', (byte)'d', (byte)'e', (byte)'f'
	}; 
	
	private Utils(){
	}
	
	public static Utils getInstance(){
		Utils utils = (Utils)threadSession.get();
		
		if (utils==null){
			synchronized (Utils.class) {
				utils = (Utils)threadSession.get();

				if (utils==null){
					utils = new Utils();
					threadSession.set(utils);
				}
			}
		}
		return utils;
	}
	
	public static String formatDate(Date date, String format){
		return getInstance().formatDateI(date, format);
	}
	
	/**
	 * Formats the parameter Date object using the default date format(dd/MM/yyyy HH:mm:ss)
	 * @param date
	 * @return
	 */
	public static String formatDate(Date date){
		return formatDate(date, DEFAULT_DATE_FORMAT);	
	}
	
	
	
	
	public String formatDateI(Date date, String format){
		if (date==null) return "";
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		String out = sdf.format(date);
		return out;
	}
	
	
	public static Date parseDate(String date, String format){
		return getInstance().parseDateI(date, format);
	}
	
	public Date parseDateI(String date, String format){
		if (date==null) return null;
		;
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date out;
		try {
			out = sdf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
			String msg = "Error parsing date. date="+date+";format="+format+";";
			log.error(msg, e);
			throw new RuntimeException(msg, e);
		}
		return out;
	}
 
	public static String getGISProperty(String propertyFile, String key){
		return Utils.getInstance().getGISPropertyI(propertyFile, key);
	}
	
	public String getGISPropertyI(String propertyFile, String key){
		Properties propsFile = null;	
		String value;		
		try {
			propsFile = Manager.getProperties(propertyFile);
			if(propsFile==null) {
				Manager.refreshPropertiesFromDisk(propertyFile);
				propsFile = Manager.getProperties(propertyFile);
			}
			value = propsFile.getProperty(key);
		} catch(Exception e){
			String msg = "could not load GIS property '"+key+"' from file '"+propertyFile+"'";
			log.debug(msg, e);
			throw new RuntimeException(msg, e);
		} 
		return value;
	}
	
	public static Properties getGISProperties(String propertyFile){
		Utils utils = getInstance();
		return utils.getGISPropertiesI(propertyFile);
	}
	
	public Properties getGISPropertiesI(String propertyFile){
		Properties propsFile = null;		
		try {
			propsFile = Manager.getProperties(propertyFile);
			if(propsFile==null) {
				Manager.refreshPropertiesFromDisk(propertyFile);
				propsFile = Manager.getProperties(propertyFile);
			}
		}
		catch(Exception e){
			String msg = "could not load GIS property file '"+propertyFile+"'";
			log.debug(msg, e);
			throw new RuntimeException(msg, e);
		} 
		return propsFile;
	}
	
	
	public static Date minToDate(Integer totalMins){
		Utils utils = Utils.getInstance();
		return utils.minToDateI(totalMins);
	}
	
	public Date minToDateI(Integer totalMins){
		String strTime = minToTimeI(totalMins);
		
		if (strTime == null)return null;
		
		StringTokenizer tokenizer = new StringTokenizer(strTime, ":");
		int hrs = Integer.parseInt(tokenizer.nextToken());
		int mins = Integer.parseInt(tokenizer.nextToken());
		
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, hrs);
		cal.set(Calendar.MINUTE, mins);
		
		Date scheduleDate = cal.getTime();
		Date nowDate = new Date();
		
		//now is after schedule time
		if (nowDate.compareTo(scheduleDate)>=0){
			cal.roll(Calendar.DAY_OF_MONTH, true);
			return cal.getTime();
		}
		else {//now is before schedule time
			return scheduleDate;
		}
		
		
	}
	
	
	public static String minToTime(Integer totalmins){
		Utils utils = Utils.getInstance();
		return utils.minToTimeI(totalmins);	
	}
	
	public String minToTimeI(Integer totalmins){	
		if (totalmins==null){
			return null;
		}
		int ts = totalmins.intValue();
		int mins = ts%60;
		int hrs = ts/60;
		
		String time = (hrs<10?"0":"")+hrs+":"+(mins<10?"0":"")+mins;
		return time;
		
	}
	
	public static Integer timeToMin(String time){
		Utils utils = Utils.getInstance();
		return utils.timeToMinI(time);
	}
	
	public Integer timeToMinI(String time){
		if (time==null || time.length()==0){
			return null;
		}
		
		String hrs;
		String mins;
		StringTokenizer timeTokens = new StringTokenizer(time, ":");
		if (timeTokens.countTokens()==2){
			hrs = timeTokens.nextToken();
			mins = timeTokens.nextToken();
		}
		else if (timeTokens.countTokens()==1){
			hrs = "00";
			mins = timeTokens.nextToken();
		}
		else{
			return null;
		}
		
		int hrs_i = Integer.parseInt(hrs);
		hrs_i = hrs_i * 60;
		
		int mins_i = Integer.parseInt(mins);
		
		int totalMins = hrs_i + mins_i;
		
		return new Integer(totalMins);
	}
	
	public String getGISUsername(HttpServletRequest request){
		return (String)request.getSession().getAttribute(Constants.GIS_USERNAME);
	}
	
	
	


	public boolean adminAudit(HttpServletRequest request,String actionType, String objectName, String actionValue){
		
		int numericTag = 6;
		ExceptionLevel exceptionLevel = ExceptionLevel.EXCEPTIONAL;
		String adminAuditId = Util.createGUID();
		long time = System.currentTimeMillis();
		String principal = getGISUsername(request);
		String objectType = "SCT";
		 
		return adminAudit(numericTag, exceptionLevel, adminAuditId, time, principal, actionType, objectType, objectName, actionValue);
		
		//6, ExceptionLevel.NORMAL, Util.createGUID(), System.currentTimeMillis(), <user>, <action_type>, "SCT", <object_name>, <action_value>
	
	}
	
	
	
	
	
	
	public boolean adminAudit(int numericTag,
		 ExceptionLevel exceptionLevel,
		 String adminAuditId, 
		 long time, 
		 String principal, 
		 String actionType,
		 String objectType, 
		 String objectName, 
		 String actionValue){
		
		
		try {
			DmiVisEventFactory.fireAdminAuditEvent(numericTag, exceptionLevel, adminAuditId, time, principal, actionType, objectType, objectName, actionValue);
		} catch (InvalidEventException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} 
		return true;
		
	}
	
	public static String getHexString(byte[] raw) 
	throws UnsupportedEncodingException 
	{
		byte[] hex = new byte[2 * raw.length];
		int index = 0;

		for (byte b : raw) {
			int v = b & 0xFF;
			hex[index++] = HEX_CHAR_TABLE[v >>> 4];
			hex[index++] = HEX_CHAR_TABLE[v & 0xF];
		}
		return new String(hex, "ASCII");
	}
	
	public static byte[] hexStringToByteArray(String s) {    
		int len = s.length();    
		byte[] data = new byte[len / 2];    
		for (int i = 0; i < len; i += 2) {        
			data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)                             
					+ Character.digit(s.charAt(i+1), 16));    
		}    
		return data;
	}
	
	public static String toXML(Document doc){

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		OutputFormat format = new OutputFormat(doc);
		XMLSerializer output = new XMLSerializer(outputStream, format);
		try {
			output.serialize(doc);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		String out = outputStream.toString();
		return out;
	}
	
	public static long getLocalTime(){
		Calendar cal = Calendar.getInstance();
		Date now = cal.getTime();
		return now.getTime();
	}
}
