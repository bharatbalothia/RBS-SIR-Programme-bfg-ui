package com.stercomm.customers.rbs.sct.ui.fileauth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.stercomm.customers.rbs.sct.ui.xapi.FileGatewayXAPI;
import com.sterlingcommerce.woodstock.util.frame.jdbc.Conn;

public class FGFile {
	
	private static final Logger log = Logger.getLogger(FGFile.class);
	
	private boolean reviewed;
	private String dataflowId;
	
	private String arrivedFileKey;
	private String arrivedFilename;
	private long arrivedFileSize;
	private String arrivedFileStatus;
	private String arrivedFileDocumentId;
	private String arrivedFileMailbox;
	private String arrivedFileMessageId;
	private String arrivedFileProducer;
	private String arrivedFileTime;
	
	private String routeKey;
	private String routeStatus;
	private String routeConsumer;
	
	private String deliveryKey;
	private String deliveryFilename;
	private String deliveryStatus;
	private String deliveryDocumentId;
	private String deliveryMailbox;
	private String deliveryMessageId;
	private String deliveryTime;
	
	private int deliveryRecordCount;
	
	
	public FGFile(String arrivedFileKey) throws Exception{
		this.setArrivedFileKey(arrivedFileKey);
		init();
	}
	
	private void init() throws Exception{
		
		log.debug("Init using arrived file key: " + this.getArrivedFileKey());
		loadRecord();
		
	}
	

	private void loadRecord() throws Exception {
		
		Element ele1 = null;
		Element ele2=null;
		Document afDoc = FileGatewayXAPI.getFgArrivedFileDetailsByKey(this.getArrivedFileKey());
		if (afDoc != null) {
			ele1 = afDoc.getDocumentElement();
			if ((ele1.hasChildNodes()) && (ele1.getTagName().equalsIgnoreCase("FgArrivedFile"))) {
				
				this.setDataflowId(ele1.getAttribute("DataflowID"));
				this.setArrivedFileDocumentId(ele1.getAttribute("DocumentID"));
				this.setArrivedFilename(ele1.getAttribute("FileName"));
				this.setArrivedFileSize(parseLong(ele1.getAttribute("FileSize")));
				this.setArrivedFileMailbox(ele1.getAttribute("MailboxPath"));
				this.setArrivedFileMessageId(ele1.getAttribute("MessageID"));
				this.setArrivedFileProducer(ele1.getAttribute("ProducerOrgKey"));
				this.setReviewed(parseBoolean(ele1.getAttribute("Reviewed")));
				this.setArrivedFileStatus(ele1.getAttribute("State"));
				this.setArrivedFileTime(ele1.getAttribute("Createts"));
				
			}
		}

		Document rDoc = FileGatewayXAPI.getFgRouteListByKey(this.getArrivedFileKey());
		if (rDoc != null) {
			ele1 = rDoc.getDocumentElement();
			if ((ele1.hasChildNodes()) && (ele1.getTagName().equalsIgnoreCase("FgRouteList"))) {
				ele2=(Element)ele1.getChildNodes().item(0);
				this.setRouteKey(ele2.getAttribute("RouteKey"));
				this.setRouteStatus(ele2.getAttribute("State"));
				this.setRouteConsumer(ele2.getAttribute("ConsumerOrganizationKey"));
				
				if(this.getRouteKey()!=null){
					Document ddoc = FileGatewayXAPI.getFgDeliveryListByKey(this.getRouteKey());
					if (ddoc != null) {
						ele1 = ddoc.getDocumentElement();
						if ((ele1.hasChildNodes()) && (ele1.getTagName().equalsIgnoreCase("FgDeliveryList"))) {
							
							this.setDeliveryRecordCount(ele1.getChildNodes().getLength());
							
							if(this.getDeliveryRecordCount()>=1){
								//only get the first one
								ele2=(Element)ele1.getChildNodes().item(0);
								this.setDeliveryKey(ele2.getAttribute("DeliveryKey"));
								this.setDeliveryFilename(ele2.getAttribute("ConsumerFileName"));
								this.setDeliveryStatus(ele2.getAttribute("State"));
								this.setDeliveryDocumentId(ele2.getAttribute("ConsumerDocID"));
								this.setDeliveryMailbox(ele2.getAttribute("ConsumerMailboxPath"));
								this.setDeliveryMessageId(ele2.getAttribute("ConsumerMessageID"));
								this.setDeliveryTime(ele2.getAttribute("Createts"));
								
							} 
						}

					}
				}

			}
		}
		
		
		
	}

	public String getArrivedFileKey() {
		return arrivedFileKey;
	}

	public void setArrivedFileKey(String arrivedFileKey) {
		this.arrivedFileKey = arrivedFileKey;
	}

	public String getArrivedFilename() {
		return arrivedFilename;
	}

	public void setArrivedFilename(String arrivedFilename) {
		this.arrivedFilename = arrivedFilename;
	}

	public String getDataflowId() {
		return dataflowId;
	}

	public void setDataflowId(String dataflowId) {
		this.dataflowId = dataflowId;
	}

	public long getArrivedFileSize() {
		return arrivedFileSize;
	}

	public void setArrivedFileSize(long arrivedFileSize) {
		this.arrivedFileSize = arrivedFileSize;
	}

	public String getArrivedFileStatus() {
		return arrivedFileStatus;
	}

	public void setArrivedFileStatus(String arrivedFileStatus) {
		this.arrivedFileStatus = arrivedFileStatus;
	}

	public String getRouteKey() {
		return routeKey;
	}

	public void setRouteKey(String routeKey) {
		this.routeKey = routeKey;
	}

	public String getRouteStatus() {
		return routeStatus;
	}

	public void setRouteStatus(String routeStatus) {
		this.routeStatus = routeStatus;
	}

	public String getDeliveryKey() {
		return deliveryKey;
	}

	public void setDeliveryKey(String deliveryKey) {
		this.deliveryKey = deliveryKey;
	}

	public String getDeliveryFilename() {
		return deliveryFilename;
	}

	public void setDeliveryFilename(String deliveryFilename) {
		this.deliveryFilename = deliveryFilename;
	}

	public String getDeliveryStatus() {
		return deliveryStatus;
	}

	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	public int getDeliveryRecordCount() {
		return deliveryRecordCount;
	}

	public void setDeliveryRecordCount(int deliveryRecordCount) {
		this.deliveryRecordCount = deliveryRecordCount;
	}

	public String getArrivedFileDocumentId() {
		return arrivedFileDocumentId;
	}

	public void setArrivedFileDocumentId(String arrivedFileDocumentId) {
		this.arrivedFileDocumentId = arrivedFileDocumentId;
	}

	public String getArrivedFileMailbox() {
		return arrivedFileMailbox;
	}

	public void setArrivedFileMailbox(String arrivedFileMailbox) {
		this.arrivedFileMailbox = arrivedFileMailbox;
	}

	public String getArrivedFileMessageId() {
		return arrivedFileMessageId;
	}

	public void setArrivedFileMessageId(String arrivedFileMessageId) {
		this.arrivedFileMessageId = arrivedFileMessageId;
	}

	public String getArrivedFileProducer() {
		return arrivedFileProducer;
	}

	public void setArrivedFileProducer(String arrivedFileProducer) {
		this.arrivedFileProducer = arrivedFileProducer;
	}
	
	
	public boolean isReviewed() {
		return reviewed;
	}

	public void setReviewed(boolean reviewed) {
		this.reviewed = reviewed;
	}

	private long parseLong(String lng){
		try {
			return Long.parseLong(lng);
		} catch (NumberFormatException e) {
			log.error("Error parsing long: " + e.getMessage());
			return -1L;
		}
	}
	

	private boolean parseBoolean(String bln){
		if(bln!=null && (bln.equalsIgnoreCase("1") || bln.equalsIgnoreCase("TRUE") || bln.equalsIgnoreCase("YES"))){
			return true;
		} else {
			return false;
		}
	}
	
	public static String findAFKey(String deliveryKey) throws Exception{
		
		String afkey = null;
		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "SELECT r.ARRIVEDFILE_KEY FROM FG_DELIVERY d, FG_ROUTE r WHERE d.ROUTE_KEY=r.ROUTE_KEY AND TRIM(d.DELIVERY_KEY)=TRIM(?)";
			
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setString(1, deliveryKey);

			rs= spstmt.executeQuery();
			while(rs.next()){
				afkey = rs.getString(1);
				break;
			}

		} catch (SQLException sqle) {
			log.error("SQL Error finding the ArrivedFile key", sqle);
			throw sqle;
		} catch (Exception e) {
			log.error("Error finding the ArrivedFile key", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}
		
		
		return afkey;
	}

	public String getDeliveryDocumentId() {
		return deliveryDocumentId;
	}

	public void setDeliveryDocumentId(String deliveryDocumentId) {
		this.deliveryDocumentId = deliveryDocumentId;
	}

	public String getDeliveryMailbox() {
		return deliveryMailbox;
	}

	public void setDeliveryMailbox(String deliveryMailbox) {
		this.deliveryMailbox = deliveryMailbox;
	}

	public String getDeliveryMessageId() {
		return deliveryMessageId;
	}

	public void setDeliveryMessageId(String deliveryMessageId) {
		this.deliveryMessageId = deliveryMessageId;
	}

	public String getRouteConsumer() {
		return routeConsumer;
	}

	public void setRouteConsumer(String routeConsumer) {
		this.routeConsumer = routeConsumer;
	}

	public String getArrivedFileTime() {
		return arrivedFileTime;
	}

	public void setArrivedFileTime(String arrivedFileTime) {
		this.arrivedFileTime = arrivedFileTime;
	}

	public String getDeliveryTime() {
		return deliveryTime;
	}

	public void setDeliveryTime(String deliveryTime) {
		this.deliveryTime = deliveryTime;
	}
	
	
}
