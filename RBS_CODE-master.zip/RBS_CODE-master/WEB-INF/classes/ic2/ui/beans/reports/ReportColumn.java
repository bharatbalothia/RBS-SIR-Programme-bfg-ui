/**
 * 
 */
package ic2.ui.beans.reports;

import java.io.Serializable;
import java.util.List;

/**
 * @author Ravi K Patel
 * created May 4, 2006
 */
@SuppressWarnings({"unchecked"})
public class ReportColumn implements Serializable{
	private static final long serialVersionUID = 1L;
	private String title;
	private List data;
	private Class dataType;
	
	public List getData() {
		return data;
	}
	public void setData(List data) {
		this.data = data;
	}
	public Class getDataType() {
		return dataType;
	}
	public void setDataType(Class dataType) {
		this.dataType = dataType;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	
}
