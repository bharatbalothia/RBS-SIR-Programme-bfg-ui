/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.forms;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;
import org.apache.struts.validator.ValidatorForm;

public class TrustedCertsForm extends ValidatorForm {
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(TrustedCertsForm.class);
	
	private String certificateName="";
	private FormFile certificateFile;
	private String changerComments="";
	

	public void reset(ActionMapping mapping, HttpServletRequest request) {
		String pageName = request.getParameter("pageName");
		if (pageName!=null ){
//			if (pageName.equals("entityName")){
//				//this.compression = "off";
//				/*
//				 * field re-use
//				 */
//				if(!this.service.equalsIgnoreCase("ROI")){
//					this.compression = "off";
//				}
//				this.inboundRoutingRule = "off";
//				this.inboundDir = "off";
//				this.pauseInbound = "off";
//				this.pauseOutbound = "off";
//				this.routeInbound="on";
//
//			}
//
//			if (pageName.equals("entitySwift")){
//				this.trace = "off";
//				this.SNF = "off";
//				this.deliveryNotif = "off";
//				this.nonRepudiation = "off";
//				/*
//				 * field re-use
//				 */
//				if(this.service.equalsIgnoreCase("ROI")){
//					this.compression = "off";
//				}
//			}
		}
	}
	
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public String getCertificateName() {
		return certificateName;
	}

	public void setCertificateName(String certificateName) {
		this.certificateName = certificateName;
	}

	public FormFile getCertificateFile() {
		return certificateFile;
	}

	public void setCertificateFile(FormFile certificateFile) {
		this.certificateFile = certificateFile;
	}
	
	public String getChangerComments() {
		return changerComments;
	}

	public void setChangerComments(String changerComments) {
		this.changerComments = changerComments;
	}


	
}
