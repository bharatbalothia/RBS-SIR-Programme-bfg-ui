package com.stercomm.customers.rbs.sct.ui.fileauth;

public class FileAuthConstants {

	public final static int STATUS_REQUESTED=0;
	public final static int STATUS_REJECTED=1;
	public final static int STATUS_APPROVED=2;
	public final static int STATUS_COMPLETED=5;
	public final static int STATUS_EXPIRED=99;
	public final static int STATUS_FAILED=-1;
	public final static int STATUS_UNKNOWN=-99;
	
	public final static String STATUS_REQUESTED_TEXT="Requested";
	public final static String STATUS_REJECTED_TEXT="Rejected";
	public final static String STATUS_APPROVED_TEXT="Approved";
	public final static String STATUS_FAILED_TEXT="Failed";
	public final static String STATUS_COMPLETED_TEXT="Completed";
	public final static String STATUS_EXPIRED_TEXT="Expired";
	public final static String STATUS_UNKNOWN_TEXT="Unknown";
	
	public final static String ACTION_REVIEW="REVIEW";
	public final static String ACTION_UNREVIEW="UNREVIEW";
	public final static String ACTION_REPLAY="REPLAY";
	public final static String ACTION_REDELIVER="REDELIVER";
	
	public final static String ACTION_REVIEW_PERM="FG_REVIEW_FILE";
	public final static String ACTION_UNREVIEW_PERM="FG_UNREVIEW_FILE";
	public final static String ACTION_REPLAY_PERM="FG_REPLAY_FILE";
	public final static String ACTION_REDELIVER_PERM="FG_REDELIVER_FILE";
	
	public final static String APPROVE_REVIEW_PERM="FG_REVIEW_APPROVE";
	public final static String APPROVE_UNREVIEW_PERM="FG_UNREVIEW_APPROVE";
	public final static String APPROVE_REPLAY_PERM="FG_REPLAY_APPROVE";
	public final static String APPROVE_REDELIVER_PERM="FG_REDELIVER_APPROVE";
	
	public final static String REQUEST_REVIEW_PERM="FG_REVIEW_REQUEST";
	public final static String REQUEST_UNREVIEW_PERM="FG_UNREVIEW_REQUEST";
	public final static String REQUEST_REPLAY_PERM="FG_REPLAY_REQUEST";
	public final static String REQUEST_REDELIVER_PERM="FG_REDELIVER_REQUEST";
	
	public final static String REQUEST_APPROVE_OWN_PERM="FG_APPROVE_OWN_REQUEST";

}
