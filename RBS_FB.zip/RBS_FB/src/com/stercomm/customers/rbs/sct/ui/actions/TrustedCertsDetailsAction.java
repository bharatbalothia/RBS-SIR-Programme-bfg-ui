/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.security.cert.X509Certificate;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.stercomm.customers.rbs.sct.ui.change.TrustedCertChange;
import com.stercomm.customers.rbs.sct.ui.dto.TrustedCert;
import com.stercomm.customers.rbs.sct.ui.forms.TrustedCertsForm;
import com.sterlingcommerce.security.kcapi.TrustedCertificateInfo;


public class TrustedCertsDetailsAction extends BaseTrustedCertsWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(TrustedCertsDetailsAction.class);
	
	public ActionForward viewForm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		TrustedCert trustedCert = getTrustedCert(request);
		TrustedCertsForm tcf = (TrustedCertsForm)form;
		
		if(trustedCert.isCreateBean() && (tcf.getCertificateName()==null || tcf.getCertificateName().equalsIgnoreCase(""))){
			X509Certificate x509 = trustedCert.getX509Certificate();
			//String fname = trustedCert.getCertificateFile().getFileName();
			//String newCertName = fname.substring(0,fname.lastIndexOf("."));
			String newCertName = trustedCert.getSubjectRDNData("O");
			if(newCertName==null || newCertName.equalsIgnoreCase("")){
				newCertName = String.valueOf(x509.getSerialNumber().intValue());
			} else {
				newCertName = newCertName + "-" + String.valueOf(x509.getSerialNumber().intValue());
			}
			trustedCert.setCertificateName(newCertName);
			//tcf.setCertificateName(newCertName);
		}
	
		return super.viewForm(mapping, form, request, response);		

	}
		
	public ActionForward next(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		if(validateForm(form, request)){
			return super.next(mapping,form, request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
	}
	
	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
			
		if(validateForm(form, request)){
			return super.save(mapping, form, request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
	
		
	}
	
	public ActionForward delete(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		//use save action	
		return super.save(mapping, form, request, response);
		
	}
	
	public ActionForward trustedCertsDetails(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		if(validateForm(form, request)){
			return super.trustedCertsDetails(mapping,form, request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}
		
	}
	

	public ActionForward trustedCertsConfirm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		if(validateForm(form, request)){
			return super.trustedCertsConfirm(mapping, form, request, response);
		} else {
			setCustom(request, form);
			return mapping.findForward("viewForm");
		}

	}
	
	private boolean validateForm(ActionForm form, HttpServletRequest request){
		
		TrustedCertsForm tcf = (TrustedCertsForm)form;
		TrustedCert tc = getTrustedCert(request);
		ActionMessages messages = new ActionMessages();
		//MessageResources messageResources = getResources(request);
		boolean rtn=true;
		
		log.debug("Validating TrustedCerts[details] form.");
		if(tc.isDeleteBean()){
			return true;
		}
		
		if(tcf.getCertificateName()==null || tcf.getCertificateName().equalsIgnoreCase("")){
			log.error("Certificate name is required");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateName.required" ));
			rtn=false;
		}
		if(!tcf.getCertificateName().matches("^[a-zA-Z0-9._\\s:\\-]+$") || tcf.getCertificateName().indexOf("[")>=0 || tcf.getCertificateName().indexOf("]")>=0){
			log.error("Certificate name is invalid");
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateName.invalid" ));
			rtn=false;
		}
			
		
		/*
		 * Check Name is unique in the TRUSTED keystore
		 * Check Thumbprint is unique in the TRUSTED keystore
		 * Check Name is unique in CHANGE_CONTROL
		 * Check Thumbprint is unique in CHANGE_CONTROL
		 */
		try {
			if(!TrustedCertificateInfo.isNameUnique(tcf.getCertificateName())){
				//System.out.println("NOT UNIQUE: " + tcf.getCertificateName());
				log.error("Trusted Certificate name exists in the SI keystore");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateFile.uniquename1" ));
				rtn=false;
			} 
			if(!tc.getTrustedCertificate().isCertUnique()){
				//System.out.println("NOT UNIQUE: " + tcf.getCertificateName());
				log.error("Trusted Certificate thumbprint exists in the SI keystore");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateFile.uniquethumbprint1" ));
				rtn=false;
			} 
			if(!TrustedCertChange.isNameUnique(tcf.getCertificateName())){
				//System.out.println("NOT UNIQUE: " + tcf.getCertificateName());
				log.error("Trusted Certificate name exists in pending Change Control");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateFile.uniquename2" ));
				rtn=false;
			} 
			
			if(!TrustedCertChange.isThumbprintUnique(tc.getThumbprint())){
				log.error("Trusted Certificate thumbprint exists in pending Change Control");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateFile.uniquethumbprint2" ));
				rtn=false;
			} 
			
			
		}catch (Exception e){
			log.error("Error determining if certificate is unique: " + e.getMessage());
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("setup.msgs.trustedCerts.CertificateFile.uniquecheck" ));
			rtn=false;
		}
			
		saveMessages(request, messages);
		return rtn;
	}
	
	private void setCustom(HttpServletRequest request, ActionForm form){
		//do nothing
	}
}
