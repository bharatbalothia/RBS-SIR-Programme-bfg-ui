/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   $Revision: $
 * Date/time:  $Date: $
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;


import org.hibernate.Session;

import com.stercomm.customers.rbs.sct.ui.ResultMeta;
import com.stercomm.customers.rbs.sct.ui.ResultMetaImpl;
import com.stercomm.customers.rbs.sct.ui.dto.FileAuthRequest;
import com.stercomm.customers.rbs.sct.ui.dtoimpl.FileAuthRequestImpl;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuth;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuthRow;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuthUsers;
import com.sterlingcommerce.woodstock.util.frame.jdbc.Conn;

/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
@SuppressWarnings({"unchecked", "unused"})
public class FileAuthRequestDAO extends BaseHibernateDAO {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(FileAuthRequestDAO.class);

	private static final String MAX_FILEAUTH_ROWS="500";


	/**
	 * @param hibSession
	 */
	@SuppressWarnings("deprecation")
	public FileAuthRequestDAO(Session hibSession) {
		super(hibSession);
	}

	public FileAuthRequest getNewInstance() {
		FileAuthRequestImpl fileAuthRequest = new FileAuthRequestImpl();
		return fileAuthRequest;
	}

	public FileAuthRequest getInstance(FileAuth fa) throws Exception {
		FileAuthRequestImpl fileAuthRequest = new FileAuthRequestImpl();
		fileAuthRequest.setFileKey(fa.getFileKey());
		fileAuthRequest.setFileAction(fa.getAction());
		fileAuthRequest.setCreateBean(false);
		fileAuthRequest.setDeleteBean(false);
		fileAuthRequest.setNewBean(false);
		fileAuthRequest.setRequestorComments(fa.getRequestorComments());
		fileAuthRequest.setFileAuth(fa);
		FileAuthUsers faus = new FileAuthUsers(fa.getFileAuthID());
		fileAuthRequest.setFileAuthUsers(faus.getFileAuthUsers());

		return fileAuthRequest;
	}

	public ArrayList<FileAuth> getFileAuthList(String fileKey, String fileAction) throws Exception{

		ArrayList<FileAuth> l = null;
		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "SELECT FILE_AUTH_ID FROM FB_FILE_AUTH WHERE TRIM(FILE_KEY)=TRIM(?) AND ACTION=? AND (STATUS=? OR STATUS=?)ORDER BY CREATED DESC";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setString(1, fileKey);
			spstmt.setString(2, fileAction);
			spstmt.setInt(3, FileAuth.STATUS_REQUESTED);
			spstmt.setInt(4, FileAuth.STATUS_APPROVED);

			rs= spstmt.executeQuery();
			while(rs.next()){

				if(l==null){
					l = new ArrayList<FileAuth>(rs.getFetchSize());
				}

				FileAuth fa = new FileAuth(rs.getInt(1));
				l.add(fa);
				log.debug("Added FileAuth to list: " + fa.getFileAuthID());

			}

		} catch (SQLException sqle) {
			log.error("SQL Error loading the FB_FILE_AUTH record list", sqle);
			throw sqle;
		} catch (Exception e) {
			log.error("Error loading the FB_FILE_AUTH record list ", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

		return l;

	}

	public ResultMeta getFileAuthResults(String status, String action, String filename, String key, int faid, int pageNo, int pageSize) throws Exception{
		ResultMeta rm = new ResultMetaImpl();
		rm.setCurrentPage(pageNo);
		rm.setPageSize(pageSize);
		int firstResult = rm.getFirstResult();

		List<FileAuthRow> results = null;
		results = this.getFileAuthRows(status, action, filename, key, faid);

		if(results!=null){
			int startIdx = pageNo==1?0:((pageNo-1)*pageSize);
			int endIdx = results.size()>(startIdx+pageSize)?(startIdx+pageSize):results.size();
			List pagedResults = results.subList(startIdx, endIdx);
			rm.setResultsList(pagedResults);
			rm.setTotalResults(results.size());
		}
		return rm;
	}
	
	

	private List<FileAuthRow> getFileAuthRows(String status, String action,String filename, String key, int faid) throws Exception{

		ArrayList<FileAuthRow> l = null;
		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;

		boolean bSearchByAction=false;
		boolean bSearchByStatus=false;
		boolean bSearchByFilename=false;
		boolean bSearchByID=false;
		boolean bSearchByKey=false;

		try {

			if(action!=null && !action.equalsIgnoreCase("") && !action.equalsIgnoreCase("ALL")){
				bSearchByAction=true;
			} else if(status!=null && !status.equalsIgnoreCase("") && !status.equalsIgnoreCase("ALL")){
				bSearchByStatus=true;
			} else if(filename!=null && !filename.equalsIgnoreCase("")){
				bSearchByFilename=true;
			} else if(faid>0){
				bSearchByID=true;
			} else if(key!=null && !key.equalsIgnoreCase("")){
				bSearchByKey=true;
			}

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = null;
						
			if(bSearchByAction){
				ssqlStr ="SELECT * FROM ( "+
				"SELECT * FROM ( "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, af.FILE_NAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_ARRIVEDFILE af "+
				"WHERE fa.ACTION =? "+
				"AND fa.FILE_KEY=af.ARRIVEDFILE_KEY "+
				"UNION "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, d.FILENAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_DELIVERY d "+
				"WHERE fa.ACTION = ? "+
				"AND fa.FILE_KEY=d.DELIVERY_KEY "+
				") ORDER BY FILE_AUTH_ID DESC "+
				") WHERE ROWNUM<="+ MAX_FILEAUTH_ROWS;
			} else if(bSearchByStatus){
				ssqlStr ="SELECT * FROM ( "+
				"SELECT * FROM ( "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, af.FILE_NAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_ARRIVEDFILE af "+
				"WHERE fa.ACTION IN ('REPLAY', 'REVIEW','UNREVIEW') "+
				"AND fa.FILE_KEY=af.ARRIVEDFILE_KEY "+
				"AND fa.STATUS=? " + 
				"UNION "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, d.FILENAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_DELIVERY d "+
				"WHERE fa.ACTION ='REDELIVER' "+
				"AND fa.FILE_KEY=d.DELIVERY_KEY "+
				"AND fa.STATUS=? " + 
				") ORDER BY FILE_AUTH_ID DESC "+
				") WHERE ROWNUM<="+ MAX_FILEAUTH_ROWS;
			}else if(bSearchByFilename){
				ssqlStr ="SELECT * FROM ( "+
				"SELECT * FROM ( "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, af.FILE_NAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_ARRIVEDFILE af "+
				"WHERE fa.ACTION IN ('REPLAY', 'REVIEW','UNREVIEW') "+
				"AND fa.FILE_KEY=af.ARRIVEDFILE_KEY "+
				"AND af.FILE_NAME LIKE ? " + 
				"UNION "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, d.FILENAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_DELIVERY d "+
				"WHERE fa.ACTION ='REDELIVER' "+
				"AND fa.FILE_KEY=d.DELIVERY_KEY "+
				"AND d.FILENAME LIKE ? " + 
				") ORDER BY FILE_AUTH_ID DESC "+
				") WHERE ROWNUM<="+ MAX_FILEAUTH_ROWS;
			} else if(bSearchByID){
				ssqlStr ="SELECT * FROM ( "+
				"SELECT * FROM ( "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, af.FILE_NAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_ARRIVEDFILE af "+
				"WHERE fa.ACTION IN ('REPLAY', 'REVIEW','UNREVIEW') "+
				"AND fa.FILE_KEY=af.ARRIVEDFILE_KEY "+
				"AND fa.FILE_AUTH_ID=? " + 
				"UNION "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, d.FILENAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_DELIVERY d "+
				"WHERE fa.ACTION ='REDELIVER' "+
				"AND fa.FILE_KEY=d.DELIVERY_KEY "+
				"AND fa.FILE_AUTH_ID=? " + 
				") ORDER BY FILE_AUTH_ID DESC "+
				") WHERE ROWNUM<="+ MAX_FILEAUTH_ROWS;
			} else if(bSearchByKey){
				ssqlStr ="SELECT * FROM ( "+
				"SELECT * FROM ( "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, af.FILE_NAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_ARRIVEDFILE af "+
				"WHERE fa.ACTION IN ('REPLAY', 'REVIEW','UNREVIEW') "+
				"AND fa.FILE_KEY=af.ARRIVEDFILE_KEY "+
				"AND TRIM(fa.FILE_KEY)=TRIM(?) " + 
				"UNION "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, d.FILENAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_DELIVERY d, FG_ROUTE r "+
				"WHERE fa.ACTION ='REDELIVER' "+
				"AND fa.FILE_KEY=d.DELIVERY_KEY "+
				"AND d.ROUTE_KEY=r.ROUTE_KEY "+
				"AND TRIM(r.ARRIVEDFILE_KEY)=TRIM(?) " + 
				") ORDER BY FILE_AUTH_ID DESC "+
				") WHERE ROWNUM<="+ MAX_FILEAUTH_ROWS;
			} else {
				ssqlStr ="SELECT * FROM ( "+
				"SELECT * FROM ( "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, af.FILE_NAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_ARRIVEDFILE af "+
				"WHERE fa.FILE_KEY=af.ARRIVEDFILE_KEY "+
				"UNION "+
				"SELECT fa.FILE_AUTH_ID as FILE_AUTH_ID, d.FILENAME as FILE_NAME, ACTION as ACTION, fa.STATUS as STATUS, fa.CREATED as CREATED, fa.FILE_KEY as FILE_KEY "+
				"FROM FB_FILE_AUTH fa, FG_DELIVERY d "+
				"WHERE fa.FILE_KEY=d.DELIVERY_KEY "+
				") ORDER BY FILE_AUTH_ID DESC "+
				") WHERE ROWNUM<="+ MAX_FILEAUTH_ROWS;
			}
			
			spstmt = conn.prepareStatement(ssqlStr);

			if(bSearchByAction){
				spstmt.setString(1, action);
				spstmt.setString(2, action);
			} else if(bSearchByStatus){
				spstmt.setInt(1,FileAuth.validateStatus(status));
				spstmt.setInt(2,FileAuth.validateStatus(status));
			}else if(bSearchByFilename){
				spstmt.setString(1, filename+"%");
				spstmt.setString(2, filename+"%");
			} else if(bSearchByID){
				spstmt.setInt(1, faid);
				spstmt.setInt(2, faid);
			}else if(bSearchByKey){
				spstmt.setString(1, key);
				spstmt.setString(2, key);
			}
			
			rs= spstmt.executeQuery();
			while(rs.next()){

				if(l==null){
					l = new ArrayList<FileAuthRow>(rs.getFetchSize());
				}

				FileAuthRow far = new FileAuthRow();
				far.setFileAuthID(rs.getInt(1));
				far.setFileName(rs.getString(2));
				far.setAction(rs.getString(3));
				far.setStatus(FileAuth.validateStatus(rs.getInt(4)));
				far.setCreated(rs.getTimestamp(5));

				l.add(far);
				if(log.isDebugEnabled()){
					log.debug("Added FileAuthRow to list: " + far.getFileAuthID());
				}

			}

		} catch (SQLException sqle) {
			log.error("SQL Error loading the FB_FILE_AUTH row list[all]", sqle);
			throw sqle;
		} catch (Exception e) {
			log.error("Error loading the FB_FILE_AUTH row list[all]", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

		return l;
	}













}
