package com.stercomm.customers.rbs.sct.ui.change;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import org.apache.struts.util.MessageResources;
import org.hibernate.Session;
import com.stercomm.customers.rbs.sct.ui.Utils;
import com.stercomm.customers.rbs.sct.ui.dao.BP.EntityBPDAOcreateDirectory;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.webapps.util.hibernate.HibernateUtils;
import com.sterlingcommerce.woodstock.dmi.visibility.event.DmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.ExceptionLevel;
import com.sterlingcommerce.woodstock.ui.SWIFTNetRoutingRuleObj;
import com.sterlingcommerce.woodstock.util.Util;


@SuppressWarnings({"unchecked", "unused", "deprecation"})
public class EntityAction extends ChangeActionImpl implements ChangeAction {

	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(EntityAction.class);
	protected Entity entity;

	public EntityAction(Entity entity){
		this.entity=entity;
	}

	public void commit() throws Exception {
		throw new UnsupportedOperationException();
	}

	protected String getChanger() throws Exception{
		String userName="FBSystem";
		ChangeControl cc = new ChangeControl(entity.getChangeID());
		if(cc!=null){
			userName = cc.getChanger();
		}
		return userName;
	}

	protected Session getHibernateSession(){
		Session hibernateSession = HibernateUtils.getSession();
		return  hibernateSession;
	}

	protected boolean firePostUpdateActions() throws Exception{

		boolean isBPError=false;

		String service = entity.getService();
		if(service!=null && service.equalsIgnoreCase("GPL")){
			//String bpRoutingName="SFG_GPL_Inbound";
			//String bpRoutingName="FB_GPL_SWIFT_Route";
			String bpRoutingName="";
			String rrType="";
			int requestTypeLength = entity.getInboundRequestType().length;
			Properties props = Utils.getGISProperties("gpl");
			if(props==null){
				throw new Exception("Exception loading request type mappings");
			}

			//Get the current list of Routing Rules using the entity name
			SWIFTNetRoutingRuleObj srroList = new SWIFTNetRoutingRuleObj();
			String ruleQuery = "GPL_" + entity.getEntity() + "_%";
			ArrayList rulesList = srroList.listByName(ruleQuery, 0, 200, true);
			//uused to store the objects we are adding/updating below
			ArrayList rulesNew = new ArrayList(requestTypeLength);
			
			int entId = entity.getEntityId().intValue();
			String inboundService = entity.getInboundService();
			String RequestorDN = entity.getInboundRequestorDN();
			String ResponderDN = entity.getInboundResponderDN();
			String CreateDirectory = entity.getInboundDir().toString();
			String CreateRoutingRule = entity.getInboundRoutingRule().toString();
			String SWIFTDirectory = null;
			try {
				SWIFTDirectory = Utils.createSWIFTDirectory(RequestorDN,ResponderDN);
			} catch (Exception e){
				//probably because we have no inbound routing defined
				log.error("Error creating the SWIFT Directory: " + e.getMessage());
				SWIFTDirectory="";
			}

			boolean bContinue=true;

			for( int i=0; i < requestTypeLength; i++){
				
				bContinue = true;
				
				log.debug("Inbound RequestType Code: " + entity.getInboundRequestType()[i]);
				rrType = props.getProperty("gpl.ui.rtm." + entity.getInboundRequestType()[i]);
				if(rrType==null || rrType.equalsIgnoreCase("")){
					rrType=entity.getInboundRequestType()[i].replaceAll(".", "");
				}
				log.debug("Inbound RequestType: " + rrType);

				bpRoutingName = props.getProperty("gpl.route." + entity.getInboundRequestType()[i]);
				if(bpRoutingName==null || bpRoutingName.equalsIgnoreCase("")){
					bpRoutingName="FB_GPL_SWIFT_Route";
				}
				log.debug("Inbound Routing BP: " + bpRoutingName);

				//int entId = entity.getEntityId().intValue();
				//String inboundService = entity.getInboundService();
				String RuleName = "GPL_" + entity.getEntity() + "_" + entity.getInboundRequestType()[i] + "_RR";
				//String RequestorDN = entity.getInboundRequestorDN();
				//String ResponderDN = entity.getInboundResponderDN();
				String RequestType = rrType;
				//String CreateDirectory = entity.getInboundDir().toString();
				//String CreateRoutingRule = entity.getInboundRoutingRule().toString();
				//String SWIFTDirectory = Utils.createSWIFTDirectory(RequestorDN,ResponderDN);

				if(Boolean.valueOf(CreateRoutingRule)==Boolean.TRUE){

					SWIFTNetRoutingRuleObj srro = new SWIFTNetRoutingRuleObj();
					srro.setRequestor(RequestorDN);
					srro.setResponder(ResponderDN);
					srro.setRequestType(RequestType);
					srro.setService(inboundService);
					srro.setInvokeMode("SYNC");
					srro.setActionType("BP");
					srro.setWorkflowName(bpRoutingName);
					srro.setRouteName(RuleName);
					srro.setUsername(getChanger());
					srro.setNewPriority(0);//just add to the end

					String ruleID = srro.exists(srro.getRequestor(),srro.getResponder(),srro.getService(),srro.getRequestType());
					if(ruleID!=null){
						//we have a record
						//lets check the name is the same!
						log.debug("Found SRR Object with ID: "+ruleID);
						
						String checkID = srro.checkExistsByName(RuleName);
						if(checkID==null){
							log.warn("Routing Rule with the required Route Name was not found but a rule exists already with the same parameters");
							bContinue=false;
							isBPError=true;
						}
						if(checkID!=null && !checkID.equalsIgnoreCase(ruleID)){
							//something wrong but lets overwrite it
							log.warn("Routing Rule found has a record with the same name but different parameters");
							bContinue=false;
							isBPError=true;
						}
						

						if(bContinue){
							
							srro.setobjectID(ruleID);
							rulesNew.add(ruleID);
							log.debug("Updating SRR Object with ID: "+ruleID + "(" + RuleName +")");
							boolean srrOK=false;
							try {
								srrOK = srro.saveSWIFTNetRoutingRule(SWIFTNetRoutingRuleObj.UPDATE_ACTION);
							} catch(Exception e){
								log.error("Caught exception update the SWIFTNet Routing Rule: " + e.getMessage());
								isBPError=true;
							}

							if(!srrOK){
								//do something here
								log.warn("Could not update the SWIFTNet Routing Rule: " + RuleName + "(" + ruleID + ")");
								isBPError=true;
							}
						}


					} else {
						//insert a new record
						if(bContinue){
							boolean srrOK = false;
							log.debug("Inserting SRR Object with Name: "+RuleName);
							try{
								srrOK = srro.saveSWIFTNetRoutingRule(SWIFTNetRoutingRuleObj.INSERT_ACTION);
							}catch (Exception e){
								log.error("Caught exception inserting the SWIFTNet Routing Rule: " + e.getMessage());
								isBPError=true;
							}
							if(!srrOK){
								//do something here
								log.warn("Could not insert the SWIFTNet Routing Rule: " + RuleName);
								isBPError=true;
							} else {
								rulesNew.add(srro.getobjectID());
							}
						}

					}

				}

				


				//MessageResources messageResources = null;
				//EntityBPDAOcreateDirectory bpDAO = new EntityBPDAOcreateDirectory(messageResources, getChanger());
				//if(Boolean.valueOf(CreateDirectory)==Boolean.TRUE || Boolean.valueOf(CreateRoutingRule)==Boolean.TRUE){
				//	boolean runOK = bpDAO.runNow(entId, RuleName, RequestorDN, ResponderDN, inboundService, RequestType, CreateDirectory, CreateRoutingRule, SWIFTDirectory, "SFG_GPL_UIEntity", bpRoutingName );
				//	if(!runOK){
				//		isBPError=true;
				//	}
				//}
			}
			
			
			if(rulesList!=null){
				Iterator itrExisting = rulesList.iterator();
				while(itrExisting.hasNext()){
					HashMap hm = (HashMap)itrExisting.next();
					String hmid = (String)hm.get("objectID");
					boolean bDeleteRR=false;
					if(rulesNew==null || rulesNew.isEmpty()){
						//delete all
						bDeleteRR=true;
					} else {
						if(!rulesNew.contains(hmid)){
							bDeleteRR=true;
						}
					}
					
					if(bDeleteRR){
						SWIFTNetRoutingRuleObj srrDelete = new SWIFTNetRoutingRuleObj();
						srrDelete.setobjectID(hmid);
						boolean srrOK = false;
						log.debug("Deleting SRR Object with ID: "+hmid);
						try{
							srrOK = srrDelete.saveSWIFTNetRoutingRule(SWIFTNetRoutingRuleObj.DELETE_ACTION);
						}catch (Exception e){
							log.error("Caught exception deleting the SWIFTNet Routing Rule: " + e.getMessage());
							isBPError=true;
						}
						if(!srrOK){
							//do something here
							log.warn("Could not delete the SWIFTNet Routing Rule: " + hmid);
							isBPError=true;
						}
					}

					
				}
				
			}
			
			//only need to do once now to create the directory
			MessageResources messageResources = null;
			EntityBPDAOcreateDirectory bpDAO = new EntityBPDAOcreateDirectory(messageResources, getChanger());
			if(Boolean.valueOf(CreateDirectory)==Boolean.TRUE){
				boolean runOK = bpDAO.runNow(entId, "", "", "", "", "", CreateDirectory, "false", SWIFTDirectory, "SFG_GPL_UIEntity", bpRoutingName );
				if(!runOK){
					isBPError=true;
				}
			}

		}

		/*
		 * TRD ONLY
		 */
	
		if(service!=null && service.equalsIgnoreCase("TRD")){
			String bpRoutingName="";
			String rrType="";
			int requestTypeLength = entity.getInboundRequestType().length;
			Properties props = Utils.getGISProperties("trd");
			if(props==null){
				throw new Exception("Exception loading request type mappings");
			}

			//Get the current list of Routing Rules using the entity name
			SWIFTNetRoutingRuleObj srroList = new SWIFTNetRoutingRuleObj();
			String ruleQuery = "TRD_" + entity.getEntity() + "_%";
			ArrayList rulesList = srroList.listByName(ruleQuery, 0, 200, true);
			//uused to store the objects we are adding/updating below
			ArrayList rulesNew = new ArrayList(requestTypeLength);
			
			int entId = entity.getEntityId().intValue();
			String inboundService = entity.getInboundService();
			String RequestorDN = entity.getInboundRequestorDN();
			String ResponderDN = entity.getInboundResponderDN();
			String CreateDirectory = entity.getInboundDir().toString();
			String CreateRoutingRule = entity.getInboundRoutingRule().toString();
			String SWIFTDirectory = null;
			try {
				SWIFTDirectory = Utils.createSWIFTDirectory(RequestorDN,ResponderDN);
			} catch (Exception e){
				//probably because we have no inbound routing defined
				log.error("Error creating the SWIFT Directory: " + e.getMessage());
				SWIFTDirectory="";
			}

			boolean bContinue=true;

			for( int i=0; i < requestTypeLength; i++){
				
				bContinue = true;
				
				log.debug("Inbound RequestType Code: " + entity.getInboundRequestType()[i]);
				rrType = props.getProperty("trd.ui.rtm." + entity.getInboundRequestType()[i]);
				if(rrType==null || rrType.equalsIgnoreCase("")){
					rrType=entity.getInboundRequestType()[i].replaceAll(".", "");
				}
				log.debug("Inbound RequestType: " + rrType);

				bpRoutingName = props.getProperty("trd.route." + entity.getInboundRequestType()[i]);
				if(bpRoutingName==null || bpRoutingName.equalsIgnoreCase("")){
					bpRoutingName="FB_TRD_SWIFT_Route";
				}
				log.debug("Inbound Routing BP: " + bpRoutingName);

				//int entId = entity.getEntityId().intValue();
				//String inboundService = entity.getInboundService();
				String RuleName = "TRD_" + entity.getEntity() + "_" + entity.getInboundRequestType()[i] + "_RR";
				//String RequestorDN = entity.getInboundRequestorDN();
				//String ResponderDN = entity.getInboundResponderDN();
				String RequestType = rrType;
				//String CreateDirectory = entity.getInboundDir().toString();
				//String CreateRoutingRule = entity.getInboundRoutingRule().toString();
				//String SWIFTDirectory = Utils.createSWIFTDirectory(RequestorDN,ResponderDN);

				if(Boolean.valueOf(CreateRoutingRule)==Boolean.TRUE){

					SWIFTNetRoutingRuleObj srro = new SWIFTNetRoutingRuleObj();
					srro.setRequestor(RequestorDN);
					srro.setResponder(ResponderDN);
					srro.setRequestType(RequestType);
					srro.setService(inboundService);
					srro.setInvokeMode("SYNC");
					srro.setActionType("BP");
					srro.setWorkflowName(bpRoutingName);
					srro.setRouteName(RuleName);
					srro.setUsername(getChanger());
					srro.setNewPriority(0);//just add to the end

					String ruleID = srro.exists(srro.getRequestor(),srro.getResponder(),srro.getService(),srro.getRequestType());
					if(ruleID!=null){
						//we have a record
						//lets check the name is the same!
						log.debug("Found SRR Object with ID: "+ruleID);
						
						String checkID = srro.checkExistsByName(RuleName);
						if(checkID==null){
							log.warn("Routing Rule with the required Route Name was not found but a rule exists already with the same parameters");
							bContinue=false;
							isBPError=true;
						}
						if(checkID!=null && !checkID.equalsIgnoreCase(ruleID)){
							//something wrong but lets overwrite it
							log.warn("Routing Rule found has a record with the same name but different parameters");
							bContinue=false;
							isBPError=true;
						}
						

						if(bContinue){
							
							srro.setobjectID(ruleID);
							rulesNew.add(ruleID);
							log.debug("Updating SRR Object with ID: "+ruleID + "(" + RuleName +")");
							boolean srrOK=false;
							try {
								srrOK = srro.saveSWIFTNetRoutingRule(SWIFTNetRoutingRuleObj.UPDATE_ACTION);
							} catch(Exception e){
								log.error("Caught exception update the SWIFTNet Routing Rule: " + e.getMessage());
								isBPError=true;
							}

							if(!srrOK){
								//do something here
								log.warn("Could not update the SWIFTNet Routing Rule: " + RuleName + "(" + ruleID + ")");
								isBPError=true;
							}
						}


					} else {
						//insert a new record
						if(bContinue){
							boolean srrOK = false;
							log.debug("Inserting SRR Object with Name: "+RuleName);
							try{
								srrOK = srro.saveSWIFTNetRoutingRule(SWIFTNetRoutingRuleObj.INSERT_ACTION);
							}catch (Exception e){
								log.error("Caught exception inserting the SWIFTNet Routing Rule: " + e.getMessage());
								isBPError=true;
							}
							if(!srrOK){
								//do something here
								log.warn("Could not insert the SWIFTNet Routing Rule: " + RuleName);
								isBPError=true;
							} else {
								rulesNew.add(srro.getobjectID());
							}
						}

					}

				}

				


				//MessageResources messageResources = null;
				//EntityBPDAOcreateDirectory bpDAO = new EntityBPDAOcreateDirectory(messageResources, getChanger());
				//if(Boolean.valueOf(CreateDirectory)==Boolean.TRUE || Boolean.valueOf(CreateRoutingRule)==Boolean.TRUE){
				//	boolean runOK = bpDAO.runNow(entId, RuleName, RequestorDN, ResponderDN, inboundService, RequestType, CreateDirectory, CreateRoutingRule, SWIFTDirectory, "SFG_GPL_UIEntity", bpRoutingName );
				//	if(!runOK){
				//		isBPError=true;
				//	}
				//}
			}
			
			
			if(rulesList!=null){
				Iterator itrExisting = rulesList.iterator();
				while(itrExisting.hasNext()){
					HashMap hm = (HashMap)itrExisting.next();
					String hmid = (String)hm.get("objectID");
					boolean bDeleteRR=false;
					if(rulesNew==null || rulesNew.isEmpty()){
						//delete all
						bDeleteRR=true;
					} else {
						if(!rulesNew.contains(hmid)){
							bDeleteRR=true;
						}
					}
					
					if(bDeleteRR){
						SWIFTNetRoutingRuleObj srrDelete = new SWIFTNetRoutingRuleObj();
						srrDelete.setobjectID(hmid);
						boolean srrOK = false;
						log.debug("Deleting SRR Object with ID: "+hmid);
						try{
							srrOK = srrDelete.saveSWIFTNetRoutingRule(SWIFTNetRoutingRuleObj.DELETE_ACTION);
						}catch (Exception e){
							log.error("Caught exception deleting the SWIFTNet Routing Rule: " + e.getMessage());
							isBPError=true;
						}
						if(!srrOK){
							//do something here
							log.warn("Could not delete the SWIFTNet Routing Rule: " + hmid);
							isBPError=true;
						}
					}

					
				}
				
			}
			
			//only need to do once now to create the directory
			MessageResources messageResources = null;
			EntityBPDAOcreateDirectory bpDAO = new EntityBPDAOcreateDirectory(messageResources, getChanger());
			if(Boolean.valueOf(CreateDirectory)==Boolean.TRUE){
				boolean runOK = bpDAO.runNow(entId, "", "", "", "", "", CreateDirectory, "false", SWIFTDirectory, "SFG_TRD_UIEntity", bpRoutingName );
				if(!runOK){
					isBPError=true;
				}
			}

		}
		
		
		/*
		 * ROI ONLY
		 */
		if(service!=null && service.equalsIgnoreCase("ROI")){

//			String[] rrType= new String[3];
//			String[] rrCode= new String[3];
//			//String bpRoutingName="SFG_ROI_Inbound";
//			String bpRoutingName="FB_ROI_SWIFT_Route";

//			rrType[0]="pain.xxx.irishstd18.dat";
//			rrCode[0]="DAT";
//			rrType[1]="pain.xxx.irishstd18.rep";
//			rrCode[1]="REP";
//			//rrType[2]="pain.xxx.irishstd18.ack";
//			rrType[2]="pain.xxx.irishstd18.fac";
//			rrCode[2]="ACK";

			String[] rrType= null;
			String[] rrCode= null;
			String bpRoutingName="FB_ROI_SWIFT_Route";

			//if(entity.getIrishStep2().equals(Boolean.TRUE)){
			if(entity.isIrishStep2()){
//				rrType= new String[1];
//				rrCode= new String[1];
//				rrType[0]=entity.getInboundType();
//				rrCode[0]="STEP2";
				rrType= new String[3];
				rrCode= new String[3];
				rrType[0]="pacs.xxx.iet.s.sbf";
				rrCode[0]="SBF";
				rrType[1]="pacs.xxx.iet.s.vbf";
				rrCode[1]="VBF";
				rrType[2]="pacs.xxx.iet.s.drr";
				rrCode[2]="DRR";
			} else {
				rrType= new String[3];
				rrCode= new String[3];
				rrType[0]="pain.xxx.irishstd18.dat";
				rrCode[0]="DAT";
				rrType[1]="pain.xxx.irishstd18.rep";
				rrCode[1]="REP";
				//rrType[2]="pain.xxx.irishstd18.ack";
				rrType[2]="pain.xxx.irishstd18.fac";
				rrCode[2]="ACK";
			}

			for( int i=0; i < rrType.length; i++){

				log.debug("Inbound RequestType: " + rrType[i]);
				log.debug("Inbound RequestType Code: " + rrCode[i]);

				int entId = entity.getEntityId().intValue();
				String inboundService = entity.getInboundService();
				String RuleName = "ROI_" + entity.getEntity() + "_" + rrCode[i] + "_RR";
				String RequestorDN = entity.getInboundRequestorDN();
				String ResponderDN = entity.getInboundResponderDN();
				String RequestType = rrType[i];
				String CreateDirectory = entity.getInboundDir().toString();
				String CreateRoutingRule = entity.getInboundRoutingRule().toString();
				String SWIFTDirectory = Utils.createSWIFTDirectory(RequestorDN,ResponderDN);

				MessageResources messageResources = null;
				EntityBPDAOcreateDirectory bpDAO = new EntityBPDAOcreateDirectory(messageResources, getChanger());
				if(Boolean.valueOf(CreateDirectory)==Boolean.TRUE || Boolean.valueOf(CreateRoutingRule)==Boolean.TRUE){
					//bpDAO.runNow(entId, RuleName, RequestorDN, ResponderDN, inboundService, RequestType, CreateDirectory, CreateRoutingRule, SWIFTDirectory, "bpNames.rbs.sct.entity.createDirectory.roi", bpRoutingName);
					boolean runOK = bpDAO.runNow(entId, RuleName, RequestorDN, ResponderDN, inboundService, RequestType, CreateDirectory, CreateRoutingRule, SWIFTDirectory, "SFG_GPL_UIEntity", bpRoutingName);
					if(!runOK){
						isBPError=true;
					}
				}
			}
		}
		return !isBPError;
	}

	public void adminAudit(){

		try {
			String actionType = null;
			if(entity.isDeleteBean()){
				actionType = "Delete Entity";
			} else if (entity.isCreateBean()){
				actionType = "Create Entity";
			} else {
				actionType = "Update Entity";
			}
			String objectName = entity.getEntity();
			String actionValue = entity.toString();
			String objectType = "SCT";

			DmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, Util.createGUID(), System.currentTimeMillis(), getChanger(), actionType, objectType, objectName, actionValue);
		} catch (Exception e) {
			e.printStackTrace();
		} 

	}

	private boolean ruleExists(ArrayList al, String id){
		boolean ret = false;
		if(al!=null){
			Iterator listItr = al.iterator();
			while(listItr.hasNext()){
				HashMap hm = (HashMap)listItr.next();
				String hmid = (String)hm.get("objectID");
				if(hmid.equalsIgnoreCase(id)){
					ret=true;
					break;
				}
			}
		}
		return ret;
	}

}
