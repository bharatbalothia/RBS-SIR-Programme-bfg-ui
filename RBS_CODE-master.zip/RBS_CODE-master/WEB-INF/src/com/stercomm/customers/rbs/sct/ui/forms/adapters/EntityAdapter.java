/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   $Revision: $
* Date/time:  $Date: $
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.forms.adapters;

//import org.apache.log4j.Logger;
import com.stercomm.customers.rbs.sct.ui.Utils;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.dtoimpl.EntityImpl;
import com.stercomm.customers.rbs.sct.ui.forms.EntityForm;
/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class EntityAdapter extends EntityImpl implements Entity {

	private static final long serialVersionUID = 1L;
	//private static final Logger log = Logger.getLogger(EntityAdapter.class);

	
	private EntityForm ef;
	
	public EntityAdapter(EntityForm ef) {
		this.ef = ef;
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getCompression()
	 */
	public Boolean getCompression() {
		return ef.getCompression()==null||ef.getCompression().length()==0?Boolean.FALSE:ef.getCompression().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getDeliveryNotifDN()
	 */
	public String getDeliveryNotifDN() {
		return ef.getDeliveryNotifDN();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getDeliveryNotifRT()
	 */
	public String getDeliveryNotifRT() {
		return ef.getDeliveryNotifRT();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getEndOfDay()
	 */
	public Integer getEndOfDay() {
		return ef.getEndOfDay()==null||ef.getEndOfDay().length()==0?null:Utils.timeToMin(ef.getEndOfDay());
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getEntity()
	 */
	public String getEntity() {
		return ef.getEntity();
	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getEntityId()
//	 */
//	public Integer getEntityId() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getFileDesc()
	 */
	public String getFileDesc() {
		return ef.getFileDesc();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getFileInfo()
	 */
	public String getFileInfo() {
		return ef.getFileInfo();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMailboxPathIn()
	 */
	public String getMailboxPathIn() {
		return ef.getMailboxPathIn();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMailboxPathOut()
	 */
	public String getMailboxPathOut() {
		return ef.getMailboxPathOut();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMaxBulksPerFile()
	 */
	public Integer getMaxBulksPerFile() {
		return ef.getMaxBulksPerFile()==null||ef.getMaxBulksPerFile().length()==0?null:new Integer(ef.getMaxBulksPerFile());
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMaxTransfersPerBulk()
	 */
	public Integer getMaxTransfersPerBulk() {
		return ef.getMaxTransferBulk()==null||ef.getMaxTransferBulk().length()==0?null:new Integer(ef.getMaxTransferBulk());
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMqQueueIn()
	 */
	public String getMqQueueIn() {
		return ef.getMqQueueIn();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getMqQueueOut()
	 */
	public String getMqQueueOut() {
		return ef.getMqQueueOut();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getRequestRef()
	 */
	public String getRequestRef() {
		return ef.getRequestRef();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getRequestType()
	 */
	public String getRequestType() {
		return ef.getRequestType();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getRequestorDN()
	 */
	public String getRequestorDN() {
		return ef.getRequesterDN();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getResponderDN()
	 */
	public String getResponderDN() {
		return ef.getResponderDN();
	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getSchedules()
//	 */
//	public List getSchedules() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getService()
	 */
	public String getService() {
		return ef.getService();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getServiceName()
	 */
	public String getServiceName() {
		return ef.getServiceName();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getStartOfDay()
	 */
	public Integer getStartOfDay() {
		return ef.getStartOfDay()==null||ef.getStartOfDay().length()==0?null:Utils.timeToMin(ef.getStartOfDay());
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getTrace()
	 */
	public Boolean getTrace() {
		String trace = ef.getTrace();
		return trace==null||trace.length()==0?Boolean.FALSE:trace.equals("on")?Boolean.TRUE:Boolean.FALSE;
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getTransferDesc()
	 */
	public String getTransferDesc() {
		return ef.getTransferDesc();
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#getTransferInfo()
	 */
	public String getTransferInfo() {
		return ef.getTransferInfo();
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#isDeliveryNotif()
	 */
	public Boolean getDeliveryNotification() {
		return ef.getDeliveryNotif().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#isSNF()
	 */
	public Boolean getSnF() {
		return ef.getSNF().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setCompression(java.lang.Integer)
	 */
	public void setCompression(Boolean compression) {
		ef.setCompression(compression==null||!compression.booleanValue()?"off":"on");
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setDeliveryNotif(java.lang.Boolean)
	 */
	public void setDeliveryNotification(Boolean deliveryNotif) {
		ef.setDeliveryNotif(deliveryNotif==null||!deliveryNotif.booleanValue()?"off":"on");
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setDeliveryNotifDN(java.lang.String)
	 */
	public void setDeliveryNotifDN(String deliveryNotifDN) {
		ef.setDeliveryNotifDN(deliveryNotifDN);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setDeliveryNotifRT(java.lang.String)
	 */
	public void setDeliveryNotifRT(String deliveryNotifRT) {
		ef.setDeliveryNotifRT(deliveryNotifRT);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setEndOfDay(java.lang.Integer)
	 */
	public void setEndOfDay(Integer endOfDay) {
		ef.setEndOfDay(endOfDay==null?"":Utils.minToTime(endOfDay));

	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setEntity(java.lang.String)
	 */
	public void setEntity(String entity) {
		ef.setEntity(entity);
	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setEntityId(java.lang.Integer)
//	 */
//	public void setEntityId(Integer entityId) {
//		// TODO Auto-generated method stub
//
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setFileDesc(java.lang.String)
	 */
	public void setFileDesc(String fileDesc) {
		ef.setFileDesc(fileDesc);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setFileInfo(java.lang.String)
	 */
	public void setFileInfo(String fileInfo) {
		ef.setFileInfo(fileInfo);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMailboxPathIn(java.lang.String)
	 */
	public void setMailboxPathIn(String mailboxPathIn) {
		ef.setMailboxPathIn(mailboxPathIn);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMailboxPathOut(java.lang.String)
	 */
	public void setMailboxPathOut(String mailboxPathOut) {
		ef.setMailboxPathOut(mailboxPathOut);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMaxBulksPerFile(java.lang.Integer)
	 */
	public void setMaxBulksPerFile(Integer maxBulksPerFile) {
		ef.setMaxBulksPerFile(maxBulksPerFile==null?"":maxBulksPerFile.toString());
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMaxTransfersPerBulk(java.lang.Integer)
	 */
	public void setMaxTransfersPerBulk(Integer maxTransfersPerBulk) {
		ef.setMaxTransferBulk(maxTransfersPerBulk==null?"":maxTransfersPerBulk.toString());
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMqQueueIn(java.lang.String)
	 */
	public void setMqQueueIn(String mqQueueIn) {
		ef.setMqQueueIn(mqQueueIn);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setMqQueueOut(java.lang.String)
	 */
	public void setMqQueueOut(String mqQueueOut) {
		ef.setMqQueueOut(mqQueueOut);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setRequestRef(java.lang.String)
	 */
	public void setRequestRef(String requestRef) {
		ef.setRequestRef(requestRef);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setRequestType(java.lang.String)
	 */
	public void setRequestType(String requestType) {
		ef.setRequestType(requestType);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setRequestorDN(java.lang.String)
	 */
	public void setRequestorDN(String requestorDN) {
		ef.setRequesterDN(requestorDN);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setResponderDN(java.lang.String)
	 */
	public void setResponderDN(String responderDN) {
		ef.setResponderDN(responderDN);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setSNF(java.lang.Boolean)
	 */
	public void setSnF(Boolean SNF) {
		ef.setSNF(SNF==null||!SNF.booleanValue()?"off":"on");
	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setSchedules(java.util.Set)
//	 */
//	public void setSchedules(List schedules) {
//		// TODO Auto-generated method stub
//
//	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setService(java.lang.String)
	 */
	public void setService(String service) {
		ef.setService(service);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setServiceName(java.lang.String)
	 */
	public void setServiceName(String serviceName) {
		ef.setServiceName(serviceName);
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setStartOfDay(java.lang.Integer)
	 */
	public void setStartOfDay(Integer startOfDay) {
		ef.setStartOfDay(startOfDay==null?"":Utils.minToTime(startOfDay));
	}

	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setTrace(java.lang.Integer)
	 */
	public void setTrace(Boolean trace) {
		ef.setTrace(trace==null||!trace.booleanValue()?"off":"on");
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setTransferDesc(java.lang.String)
	 */
	public void setTransferDesc(String transferDesc) {
		ef.setTransferDesc(transferDesc);
	}
	
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setTransferInfo(java.lang.String)
	 */
	public void setTransferInfo(String transferInfo) {
		ef.setTransferInfo(transferInfo);
	}
		
	/* (non-Javadoc)
	 * @see com.stercomm.customers.rbs.sct.ui.dto.Entity#setTransferInfo(java.lang.String)
	 */
	

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#isCreateBean()
//	 */
//	public boolean isCreateBean() {
//		// TODO Auto-generated method stub
//		return false;
//	}

//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#isNewBean()
//	 */
//	public boolean isNewBean() {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#setCreateBean(boolean)
//	 */
//	public void setCreateBean(boolean createBean) {
//		// TODO Auto-generated method stub
//
//	}
//
//	/* (non-Javadoc)
//	 * @see com.stercomm.customers.rbs.sct.ui.dto.BaseHibernateBean#setNewBean(boolean)
//	 */
//	public void setNewBean(boolean newBean) {
//		// TODO Auto-generated method stub
//
//	}

//	/*
//	 * @return the updated
//	 */
//	public boolean isUpdated() {
//		return updated;
//	}
//
//	/*
//	 * @param updated the updated to set
//	 */
//	public void setUpdated(boolean updated) {
//		this.updated = updated;
//	}
	
	public String getCdNode() {
		return ef.getCdNode();
	}

	public void setCdNode(String cdNode) {
		ef.setCdNode(cdNode);
	}

	public String getCdfWTOMsgId() {
		return ef.getCdfWTOMsgId();
	}

	public void setCdfWTOMsgId(String cdfWTOMsgId) {
		ef.setCdfWTOMsgId(cdfWTOMsgId);
	}

	public String getDnfWTOMsgId() {
		return ef.getDnfWTOMsgId();
	}

	public void setDnfWTOMsgId(String dnfWTOMsgId) {
		ef.setDnfWTOMsgId(dnfWTOMsgId);
	}

	public String getDrrWTOMsgId() {
		return ef.getDrrWTOMsgId();
	}

	public void setDrrWTOMsgId(String drrWTOMsgId) {
		ef.setDrrWTOMsgId(drrWTOMsgId);
	}

	public String getDvfWTOMsgId() {
		return ef.getDvfWTOMsgId();
	}

	public void setDvfWTOMsgId(String dvfWTOMsgId) {
		ef.setDvfWTOMsgId(dvfWTOMsgId);
	}

	public String getIdfWTOMsgId() {
		return ef.getIdfWTOMsgId();
	}

	public void setIdfWTOMsgId(String idfWTOMsgId) {
		ef.setIdfWTOMsgId(idfWTOMsgId);
	}

	public String getMsrWTOMsgId() {
		return ef.getMsrWTOMsgId();
	}

	public void setMsrWTOMsgId(String msrWTOMsgId) {
		ef.setMsrWTOMsgId(msrWTOMsgId);
	}

	public String getPsrWTOMsgId() {
		return ef.getPsrWTOMsgId();
	}

	public void setPsrWTOMsgId(String psrWTOMsgId) {
		ef.setPsrWTOMsgId(psrWTOMsgId);
	}

	public String getRsfWTOMsgId() {
		return ef.getRsfWTOMsgId();
	}

	public void setRsfWTOMsgId(String rsfWTOMsgId) {
		ef.setRsfWTOMsgId(rsfWTOMsgId);
	}

	public String getSdfWTOMsgId() {
		return ef.getSdfWTOMsgId();
	}

	public void setSdfWTOMsgId(String sdfWTOMsgId) {
		ef.setSdfWTOMsgId(sdfWTOMsgId);
	}
	
	public String getRtfWTOMsgId() {
		return ef.getRtfWTOMsgId();
	}

	public void setRtfWTOMsgId(String rtfWTOMsgId) {
		ef.setRtfWTOMsgId(rtfWTOMsgId);
	}
	
	public String getMbpWTOMsgId() {
		return ef.getMbpWTOMsgId();
	}

	public void setMbpWTOMsgId(String mbpWTOMsgId) {
		ef.setMbpWTOMsgId(mbpWTOMsgId);
	}
	
	public void setMqHost(String mqHost) {
		ef.setMqHost(mqHost);
	}
	public void setMqPort(Integer mqPort) {
		ef.setMqPort(mqPort==null?"":mqPort.toString());
	}
	public void setMqQManager(String mqQManager) {
		ef.setMqQManager(mqQManager);
	}
	public void setMqChannel(String mqChannel) {
		ef.setMqChannel(mqChannel);
	}
	public void setMqQueueName(String mqQueueName) {
		ef.setMqQueueName(mqQueueName);
	}
	public void setMqQueueBinding(String mqQueueBinding) {
		ef.setMqQueueBinding(mqQueueBinding);
	}
	public void setMqQueueContext(String mqQueueContext) {
		ef.setMqQueueContext(mqQueueContext);
	}
	public void setMqDebug(Integer mqDebug) {
		ef.setMqDebug(mqDebug==null?"":mqDebug.toString());
	}
	public void setMqSSLoptions(String mqSSLoptions) {
		ef.setMqSSLoptions(mqSSLoptions);
	}
	public void setMqSSLciphers(String mqSSLciphers) {
		ef.setMqSSLciphers(mqSSLciphers);
	}
	public void setMqSSLkey(String mqSSLkey) {
		ef.setMqSSLkey(mqSSLkey);
	}
	public void setMqSSLcaCert(String mqSSLcaCert) {
		ef.setMqSSLcaCert(mqSSLcaCert);
	}
	
	public String getMqHost(){
		return ef.getMqHost();
	}
	public Integer getMqPort(){
		return ef.getMqPort()==null||ef.getMqPort().length()==0?null:new Integer(ef.getMqPort());
	}
	public String getMqQManager(){
		return ef.getMqQManager();
	}
	public String getMqChannel(){
		return ef.getMqChannel();
	}
	public String getMqQueueName(){
		return ef.getMqQueueName();
	}
	public String getMqQueueBinding(){
		return ef.getMqQueueBinding();
	}
	public String getMqQueueContext(){
		return ef.getMqQueueContext();
	}
	public Integer getMqDebug(){
		return ef.getMqDebug()==null||ef.getMqDebug().length()==0?null:new Integer(ef.getMqDebug());
	}
	public String getMqSSLoptions(){
		return ef.getMqSSLoptions();
	}
	public String getMqSSLciphers(){
		return ef.getMqSSLciphers();
	}
	public String getMqSSLkey(){
		return ef.getMqSSLkey();
	}
	public String getMqSSLcaCert(){
		return ef.getMqSSLcaCert();
	}

	public Boolean getRouteInbound() {
		return ef.getRouteInbound()==null||ef.getRouteInbound().length()==0?Boolean.FALSE:ef.getRouteInbound().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}
	public Boolean getInboundDir() {
		return ef.getInboundDir()==null||ef.getInboundDir().length()==0?Boolean.FALSE:ef.getInboundDir().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}
	public Boolean getInboundRoutingRule() {
		return ef.getInboundRoutingRule()==null||ef.getInboundRoutingRule().length()==0?Boolean.FALSE:ef.getInboundRoutingRule().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}
	
	public String getInboundRequestorDN(){
		return ef.getInboundRequestorDN();
	}
	public String getInboundResponderDN(){
		return ef.getInboundResponderDN();
	}
	public String getInboundService(){
		return ef.getInboundService();
	}
	public String getInboundType(){
		return ef.getInboundType();
	}
	public String[] getInboundRequestType(){
		return ef.getInboundRequestType();
	}
	
	public Boolean getNonRepudiation(){
		return ef.getNonRepudiation().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}
	public Boolean getPauseInbound(){
		return ef.getPauseInbound().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}
	public Boolean getPauseOutbound(){
		return ef.getPauseOutbound().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}
	public void setRouteInbound(Boolean routeInbound) {
		ef.setRouteInbound(routeInbound==null||!routeInbound.booleanValue()?"off":"on");
		}
	public void setInboundDir(Boolean inboundDir) {
		ef.setInboundDir(inboundDir==null||!inboundDir.booleanValue()?"off":"on");
		}
	public void setInboundRoutingRule(Boolean inboundRoutingRule) {
		ef.setInboundRoutingRule(inboundRoutingRule==null||!inboundRoutingRule.booleanValue()?"off":"on");
	}
	public void setInboundRequestorDN(String inboundRequestorDN) {
		ef.setInboundRequestorDN(inboundRequestorDN);
	}
	public void setInboundResponderDN(String inboundResponderDN) {
		ef.setInboundResponderDN(inboundResponderDN);
	}
	public void setInboundService(String inboundService) {
		ef.setInboundService(inboundService);
	}
	public void setInboundRequestType(String[] inboundRequestType) {
		ef.setInboundRequestType(inboundRequestType);
	}
	public void setInboundType(String inboundType) {
		ef.setInboundType(inboundType);
	}
	public void setNonRepudiation(Boolean nonRepudiation) {
		ef.setNonRepudiation(nonRepudiation==null||!nonRepudiation.booleanValue()?"off":"on");
	}
	public void setPauseInbound(Boolean pauseInbound) {
		ef.setPauseInbound(pauseInbound==null||!pauseInbound.booleanValue()?"off":"on");
	}
	public void setPauseOutbound(Boolean pauseOutbound) {
		ef.setPauseOutbound(pauseOutbound==null||!pauseOutbound.booleanValue()?"off":"on");
	}
	public String getChangerComments() {
		return ef.getChangerComments();
	}

	public void setChangerComments(String changerComments) {
		ef.setChangerComments(changerComments);
	}
	
	public void setIrishStep2(Boolean irishStep2) {
		ef.setIrishStep2(irishStep2==null||!irishStep2.booleanValue()?"off":"on");
		}
	public Boolean getIrishStep2() {
		return ef.getIrishStep2()==null||ef.getIrishStep2().length()==0?Boolean.FALSE:ef.getIrishStep2().equals("on")?Boolean.TRUE:Boolean.FALSE;
	}
	
	public String getE2eSigning() {
		return ef.getE2eSigning();
	}

	public void setE2eSigning(String e2eSigning) {
		ef.setE2eSigning(e2eSigning);
	}
	
}
