package com.stercomm.customers.rbs.sct.ui.fileauth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.sterlingcommerce.woodstock.util.frame.jdbc.Conn;

public class FileAuthUsers extends FileAuthConstants{

	private static final Logger log = Logger.getLogger(FileAuthUsers.class);

	private List<FileAuthUser> fileAuthUsers;
	private int fileAuthID;
	
	public FileAuthUsers(int fileAuthID) throws Exception {
		this.setFileAuthID(fileAuthID);
	}

	public FileAuthUsers(int fileAuthID, String[] users) throws Exception {
		this.setFileAuthID(fileAuthID);
		initFromArray(users);
	}

	private void initFromArray(String[] users) throws Exception{

		if(users!=null && users.length>0){
			fileAuthUsers = new ArrayList<FileAuthUser>();
			for(int i=0;i<users.length;i++){
				FileAuthUser fau = new FileAuthUser(this.getFileAuthID(), users[i]);
				fileAuthUsers.add(fau);
			}
		}
	}

	public void insert() throws Exception {

		if(this.getFileAuthUsers()!=null && this.getFileAuthUsers().size()>0){

			Iterator<FileAuthUser> iUsers = this.getFileAuthUsers().iterator();
			while(iUsers.hasNext()){
				FileAuthUser fau = (FileAuthUser)iUsers.next();
				fau.insert();
			}

		}

	}
	
	public List<FileAuthUser> getFileAuthUsers(boolean reload) throws Exception {
		if(reload){
			fileAuthUsers=null;
		}
		return getFileAuthUsers();
	}

	public List<FileAuthUser> getFileAuthUsers() throws Exception {
		if(fileAuthUsers==null){
			load();
		}
		return fileAuthUsers;
	}

	public int getFileAuthID() {
		return fileAuthID;
	}

	public void setFileAuthID(int fileAuthID) {
		this.fileAuthID = fileAuthID;
	}

	private void load() throws Exception{

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "SELECT FILE_AUTH_USERS_ID, FILE_AUTH_ID, USER_ID FROM FB_FILE_AUTH_USERS WHERE FILE_AUTH_ID=?";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setInt(1,this.getFileAuthID());

			rs= spstmt.executeQuery();
			while(rs.next()){
				FileAuthUser fau = new FileAuthUser();
				fau.setFileAuthUserID(rs.getString(1));
				fau.setFileAuthID(rs.getInt(2));
				fau.setUser(rs.getString(3));
				if(fileAuthUsers==null){
					fileAuthUsers = new ArrayList<FileAuthUser>();
				}
				fileAuthUsers.add(fau);
			}

		} catch (SQLException sqle) {
			log.error("SQL Error loading the FB_FILE_AUTH_USERS records", sqle);
			throw sqle;
		} catch (Exception e) {
			log.error("Error loading the FB_FILE_AUTH_USERS records", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}

	}

	public static boolean isUserPermitted(String userID, int faid) throws Exception{
		boolean permitted=false;

		Connection conn=null;
		PreparedStatement spstmt = null;
		String ssqlStr = null;
		ResultSet rs = null;

		try {

			conn = Conn.getConnection();

			//Oracle only
			ssqlStr = "SELECT FILE_AUTH_USERS_ID FROM FB_FILE_AUTH_USERS WHERE USER_ID=? AND FILE_AUTH_ID=?";
			spstmt = conn.prepareStatement(ssqlStr);

			spstmt.setString(1, userID);
			spstmt.setInt(2,faid);

			rs= spstmt.executeQuery();
			while(rs.next()){
				permitted=true;
				break;
			}

		} catch (SQLException sqle) {
			log.error("SQL Error querying the FB_FILE_AUTH_USERS record for user permission", sqle);
			throw sqle;
		} catch (Exception e) {
			log.error("Error querying the FB_FILE_AUTH_USERS record for user permission", e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (spstmt != null) {
					spstmt.close();
				}
				if(conn!=null){
					Conn.freeConnection(conn);
				}
			} catch (SQLException se) {
				throw se;
			}
		}



		return permitted;

	}
}
