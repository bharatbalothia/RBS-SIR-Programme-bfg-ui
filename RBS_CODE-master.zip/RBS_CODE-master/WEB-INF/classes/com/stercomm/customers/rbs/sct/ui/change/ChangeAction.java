package com.stercomm.customers.rbs.sct.ui.change;

import java.io.Serializable;

public interface ChangeAction extends Serializable {
	public abstract void commit() throws Exception;
}
