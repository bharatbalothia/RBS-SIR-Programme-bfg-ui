/****************************************************************************
 * IBM and Sterling Commerce Confidential
 *
 * OCO Source Materials
 *
 * Platform IFC version 1.3
 *
 * (C) Copyright Sterling Commerce, an IBM Company 2007, 2011
 * 
 * The source code for this program is not published or otherwise divested of
 * its trade secrets, irrespective of what has been deposited with the U.S.
 * Copyright Office.
 ****************************************************************************/

/*
 * (C) Copyright 2001 - 2010 Sterling Commerce, Inc. ALL RIGHTS RESERVED
 *
 * ** Trade Secret Notice **
 *
 * This software, and the information and know-how it contains, is
 * proprietary and confidential and constitutes valuable trade secrets
 * of Sterling Commerce, Inc., its affiliated companies or its or
 * their licensors, and may not be used for any unauthorized purpose
 * or disclosed to others without the prior written permission of the
 * applicable Sterling Commerce entity. This software and the
 * information and know-how it contains have been provided
 * pursuant to a license agreement which contains prohibitions
 * against and/or restrictions on its copying, modification and use.
 * Duplication, in whole or in part, if and when permitted, shall
 * bear this notice and the Sterling Commerce, Inc. copyright
 * legend. As and when provided to any governmental entity,
 * government contractor or subcontractor subject to the FARs,
 * this software is provided with RESTRICTED RIGHTS under
 * Title 48 CFR 52.227-19.
 * Further, as and when provided to any governmental entity,
 * government contractor or subcontractor subject to DFARs,
 * this software is provided pursuant to the customary
 * Sterling Commerce license, as described in Title 48
 * CFR 227-7202 with respect to commercial software and commercial
 * software documentation.
 */
package com.sterlingcommerce.woodstock.adminui.jspbean;

// Java stuff
import java.lang.reflect.*;
import com.sterlingcommerce.woodstock.util.Util; // to allow the use of noop

import java.text.MessageFormat;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;
import java.util.LinkedList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Arrays;

// stercomm
import com.sterlingcommerce.woodstock.util.NameValuePairs;
import com.sterlingcommerce.woodstock.util.NameValue;
import com.sterlingcommerce.woodstock.ui.EntityAutho;
import com.sterlingcommerce.woodstock.ui.BaseUIGlobals;
import com.sterlingcommerce.woodstock.ui.LangBundle;
import com.sterlingcommerce.woodstock.ui.WizardObject;
import com.sterlingcommerce.woodstock.ui.Wizard;
import com.sterlingcommerce.woodstock.ui.SessionInfo;
import com.sterlingcommerce.woodstock.adminui.*;
import com.sterlingcommerce.woodstock.adminui.jspbean.*;
import com.sterlingcommerce.woodstock.ui.jspbean.*;
import com.sterlingcommerce.woodstock.util.EntityUtil;
import com.sterlingcommerce.woodstock.security.AuthenticationProps;
import com.sterlingcommerce.woodstock.security.Group;
import com.sterlingcommerce.woodstock.security.Permission;
import com.sterlingcommerce.woodstock.util.frame.Manager;
import com.sterlingcommerce.woodstock.security.SecurityManager;
import com.sterlingcommerce.woodstock.security.User;
import com.sterlingcommerce.woodstock.security.PwdPolicy;
import com.sterlingcommerce.security.lc.LM;
import com.sterlingcommerce.woodstock.util.frame.cache.CacheManager;

import com.sterlingcommerce.rbs.filebroker.dualcontrol.DualControlUtil;


/**
 * The AccountBean class is a bean used in the Woodstock administration
 * system to provide configuration for a account management.
 */
@SuppressWarnings({"unchecked", "unused", "static-access"})
public class AccountBean extends WizardBeanBase implements WizardBean {

    private static SecurityManager sm = null;
    private static final String GROUP_STRING = "GROUP";
    private static final String PERM_STRING = "PERM";
    private static final String ENABLED_CHECKBOX = "images.Accounts.onbutton";
    private static final String DISABLED_CHECKBOX = "images.Accounts.inactiveButton";

    private Properties props = null;

   static {
    try {
        /* I have no idea why this is throwing an exception on create... */
            sm = SecurityManager.getInstance();
    } catch (Exception ex) {
        BaseUIGlobals.out.logException("[AccountBean.static]", ex);
    }
    }
    /**
     * The  EntityAutho object contains the UserAutho object
     */
    protected EntityAutho  usrAccount;


    /**
     * The method for retriving the header for the wizard
     * @return String
     */
    public String getHeader() {
       if(wiz != null){
        usrAccount = (EntityAutho)wiz.editObj();
       }

        String name = null;
        if(usrAccount != null){
           if(usrAccount.theAutho != null){
                 name = usrAccount.theAutho.getUserName();
            }
        }

        if(page != null){
          if (page.pageType.equals("FINISH")) {
              if (name != null && name.length() > 0)
                  return  name;
              else
                  return  langbean.getValue("accountname");
          }
          else {
              if (name != null && name.length() > 0)
                  return  name +": " +  super.getHeader();
              else
                  return  langbean.getValue("accountname") +": " +  super.getHeader();
          }
        }
        else{
         return super.getHeader();
        }


    }


    /**
     * The method for retrieving JavaScript validator functions
     * for the pages of this specific Wizard
     * @return String
     */
    public String getValidator() {
        StringBuffer s = new StringBuffer();
        s.append("");
        usrAccount = (EntityAutho)wiz.editObj();
        if(usrAccount != null && page != null){
            if (page.activity.equals("accNameEdit"))
            { //password
                if (wiz.action == Wizard.ADD){
                    int userIdMinLength = 5;
                    String userIdMinLengthStr = Manager.getProperties("ui").getProperty("userIdMinLength");
                    if ((userIdMinLengthStr != null) && (userIdMinLengthStr.length() > 0)) {
                       try {
                         int tmpNum = Integer.parseInt(userIdMinLengthStr);
                         if (tmpNum > 0) {
                            userIdMinLength = tmpNum;
                         }
                       } catch (NumberFormatException ne) {
                	 BaseUIGlobals.out.logException("[AccountBean.getValidator] Failed to parse the integer '" + userIdMinLengthStr + "'. Using default " + userIdMinLength + " characters user id limitation instead.", ne);
                       }
                    }
                    String[] userIdLength = {String.valueOf(userIdMinLength)};
                    addCheckMinLength(s,  "ACCOUNT_userName", userIdMinLength, MessageFormat.format(langbean.getValue("usrAccMinLength"), userIdLength), "1");
                    addValidCharsNoSlashTest(s, "ACCOUNT_userName", langbean.getValue("ACCOUNT.userName"), "1");
                    addValidTrimSpaceTest(s, "ACCOUNT_userName", langbean.getValue("ACCOUNT.userName"), "1");
                }

                if (usrAccount.theAutho.isLocallyAuthenticated()) {
                    String ps = null;
                    if (usrAccount.theAutho != null) {
                        ps = usrAccount.theAutho.getUserPassword();
                    }
                    if (ps == null) {
                        ps = "";
                    }

                    BaseUIGlobals.out.logDebug("[AccountBean] usrAccount.theAutho.getUserPassword() = " + ps);
                    if (!ps.equals("")) { //if there is a password , this field is optional
                        if (ps.equalsIgnoreCase("not applicable")) { //if this is a former exteral auth a password is required
                            addCheckMinLength(s, "ACCOUNT_userPass", 6, langbean.getValue("usrPassMinLength"), "1");
                            addValidCharsTestPwd(s, "ACCOUNT_userPass", langbean.getValue("ACCOUNT.userPass"), "1");
                        }
                        addCheckMinLength(s, "ACCOUNT_userPass", 6, langbean.getValue("usrPassMinLength"), "0");
                        addValidCharsTestPwd(s, "ACCOUNT_userPass", langbean.getValue("ACCOUNT.userPass"), "0");
                    } else { //if there is no old password this is required
                        addCheckMinLength(s, "ACCOUNT_userPass", 6, langbean.getValue("usrPassMinLength"), "1");
                        addValidCharsTestPwd(s, "ACCOUNT_userPass", langbean.getValue("ACCOUNT.userPass"), "1");
                    }

                    SessionInfo sessionInfo = (SessionInfo)wiz.session().getAttribute("SessionInfo");
                    String usrLoggedIn = sessionInfo.getAutho().getUserName();
                    String usrBeingEdited = usrAccount.theAutho.getUserName();
                    boolean usrEditedSuper = usrAccount.theAutho.hasGroup("super");
                    boolean usrLoggedInSuper = sessionInfo.getAutho().hasGroup("super");
                    if (usrLoggedIn.equals(usrBeingEdited) || (!usrLoggedInSuper && usrEditedSuper)) {
                        // added for PwdPolicy
                        addCheckMinLength(s, "ACCOUNT_userOldPass", 6, langbean.getValue("usrPassMinLength"), "0");
                        //makes sure the new password contains a value if the old password does.
                        addCheckDependantField(s, "ACCOUNT_userOldPass", "ACCOUNT_userPass", langbean.getValue("usrOldNewDependant"));
                        //makes sure the old password contains a value if the new password does.
                        addCheckDependantField(s, "ACCOUNT_userPass", "ACCOUNT_userOldPass", langbean.getValue("usrOldNewDependant"));
                        //checks if old and new password are the same
                        addComparePassword(s, "ACCOUNT_userOldPass", "ACCOUNT_userPass", langbean.getValue("usrOldNewPass"));
                    }

                    //just check if both field are same
                    addCheckPassword(s, "ACCOUNT_userPass", "ACCOUNT_userPassConfirm", langbean.getValue("usrNewPass"));
                }

                //Session timeout is changed to required value, need to check validation
                //addIntTest(s, "ACCOUNT_timeout", langbean.getValue("ACCOUNT.timeout"),
                //              "0", false); //not required
                addIntTest(s, "ACCOUNT_timeout", langbean.getValue("ACCOUNT.timeout"),
                              "0", false, "1"); //required
                addMaxIntTest(s, "ACCOUNT_timeout", 
                		langbean.getValue("ACCOUNT.timeout"), User.MAX_TIME_OUT_VAL);

             }
             if (page.activity.equals("accInfoEdit"))
            { //password
                addValidCharsTest(s, "ACCOUNT_FName", langbean.getValue("ACCOUNT.FName"), "1");
                addValidCharsTest(s, "ACCOUNT_LName", langbean.getValue("ACCOUNT.LName"), "1");
                //PRM - removed after edit box was changed to a dropdown.
//		addValidCharsTest(s, "ACCOUNT_ParentID", langbean.getValue("ACCOUNT.ParentID"), "0");
//                addValidCharsTest(s, "ACCOUNT_EntityID", langbean.getValue("ACCOUNT.EntityID"), "0");

                addEmailTest(s, "ACCOUNT_Email", langbean.getValue("ACCOUNT.Email"), "0");
                //addIntTest(s, "ACCOUNT_Pager", langbean.getValue("ACCOUNT.Pager"), "0");
             }

	     getValidatorExt( s ); // sshkey

             if (page.activity.equals("accGroupEdit")) {
                multiPickerValidator(s, "assignlist");
             }
//             if (page.activity.equals("accPermEdit"))
//             {
//            	 multiPickerValidator(s, "assignlist");
//             }

             }

        return s.toString();
    }

		/**
     * The method for building the html inputs
     * for the wizard pages
     * @return String
     */
    public String getInputs() {
        StringBuffer s = new StringBuffer();
        usrAccount = (EntityAutho)wiz.editObj();
        if( page != null){
          //this is for editing
          if (page.activity.equals("accNameEdit")) { //Account name
              buildAuthType(s);
              s.append("<table>");
              buildAccName(s);
              if (usrAccount.theAutho.isLocallyAuthenticated()) {
                  buildAccPassword(s);
                  buildPolicyId(s);
              } else {
                  buildAuthentication(s);
              }
              buildAccTimeout(s);
              buildAccessibility(s);
              buildTheme(s);
          // JOE - removing. Identity will now be optional in the group
          // buildIdentity(s);
              s.append("</table>");
           } else if (page.activity.equals("accGroupEdit")) { // groups
           buildGroupSelect(s);
       } else if (page.activity.equals("accPermEdit")) { // perms
           buildPermSelect(s);
           } else if (page.activity.equals("accRightsEdit")) { // perms
               buildRightsSelect(s);
//	   } else if (page.activity.equals("accPermDelEdit")) { // perm removal
//	       buildPermSelectDel(s);
           } else if (page.activity.equals("accInfoEdit")) { // info
                s.append("<table>");
                 buildName(s);
                 buildEmail(s);
                 buildPager(s);
                 buildLanguage(s);
                 buildParentID(s);
         buildEntityID(s);
//                 buildPolicyId(s);
                s.append("</table>");
           }
          else if (page.activity.equals("accConfirmEdit") || page.activity.equals("accConfirmDelete")) {
              buildConfirm(s);
           }
	   getInputsExt(usrAccount, s);
        }

        return s.toString();
    }

    /**
     * AccountSSHExtBean adds sshkey page in asset clump
     * @return String
     */
    protected void getInputsExt ( EntityAutho usr, StringBuffer out ) {
    	Util.noop();
   }

    /**
     * The method for retrieving JavaScript validator functions ext for sshkey
     * AccountSSHExtBean adds sshkey page in asset clump
     * @return String
     */
    protected void getValidatorExt ( StringBuffer buf ) {
	Util.noop();
    }

    /**
     * The method for building the html buildConfirm ext for sshkey
     * AccountSSHExtBean adds more in here
     * @return String
     **/

    protected void buildConfirmExt( EntityAutho usrAcount,StringBuffer buf ) {
	Util.noop();
    }

    private void buildAccTimeout( StringBuffer sb ) {
        if(usrAccount != null && usrAccount.theAutho != null){
          int s = usrAccount.theAutho.getTimeout();
      String ss = "";
      if (s >0 ) {
          ss = String.valueOf( s/60 );
      }

          sb.append("<tr>");
      //required text field
          //buildReqInputBox(sb, langbean.getValue("ACCOUNT.timeout"), "ACCOUNT_timeout", ss, "12", "12");
          buildInputBox(sb, langbean.getValue("ACCOUNT.timeout"), "ACCOUNT_timeout", ss, "9", "7");
          sb.append("</tr>");
        } else {
          sb.append("<tr><td>");
          sb.append(langbean.getValue("Label.noEditAvailable"));
          sb.append("</td></tr>");
        }
    }

    private void buildAuthentication(StringBuffer buf) {

        String s = null;
        int sc = -1;
        String aname = "";
        NameValue nv = null;

        if (usrAccount != null) {
            sc = usrAccount.theAutho.getSecurityCode();
            if (sc != -1) {
                aname = "" + sc;
            }
        }

        NameValuePairs nvp = new NameValuePairs();
        Vector v = usrAccount.theAutho.getAuthenticationNames();

        int len = v.size();
        nvp.addElement("", "");
        for (int i = 0; i < len; i++) {
            nv = (NameValue)v.get(i);
            nvp.addElement(nv.getName(), (String)nv.getValue());
        }

        nvp.sortStringValue(true);
        buf.append("<tr><td valign=\"bottom\" class=\"WizardInputText\">");
        buf.append(langbean.getValue("ACCOUNT.userAuthenticationHost"));
        buf.append(":</td><td>");
        buildSelectList(buf, "ACCOUNT_authhost", nvp, aname, true, 0, 4);
        buf.append("</td></tr>");
    }

  /**
   * builds a select control to give the choice of UI to build
   * options - Admin - UI , AS2 - UI , UCCNET - UI
   */
     private void buildAccessibility( StringBuffer buf ) {

       String s = "1";
       int access = 1;
       if(usrAccount != null ){
           access = usrAccount.getAccessibility();
           s = String.valueOf( access );
           }
           SessionInfo sessionInfo = (SessionInfo)wiz.session().getAttribute("SessionInfo");
           boolean isUCCnetAdmin = sessionInfo.getAutho().hasExplicitPermission("UCCNETADMIN");
           boolean isCDSPAdmin = sessionInfo.getAutho().hasGroup(BaseUIGlobals.CDSP_USER);
           boolean isSuperUser = sessionInfo.getAutho().getSuper();

          if (isUCCnetAdmin){
            buf.append("<input type=\"hidden\" name=\"ACCOUNT_access\" value=\"");
            buf.append("3");
            buf.append("\">");
          } else if (isCDSPAdmin && !isSuperUser){
            buf.append("<input type=\"hidden\" name=\"ACCOUNT_access\" value=\"");
            buf.append("5");
            buf.append("\">");
          } else {
       if (wiz.action == Wizard.ADD){
          NameValuePairs nvp = new NameValuePairs();
          nvp.addElement( langbean.getValue("admin_ui"), "1" );
          nvp.addElement( langbean.getValue("as2_ui"), "2" );
          nvp.addElement( langbean.getValue("ds_ui"), "3" );
          nvp.addElement( langbean.getValue("dash_ui"), "4" );
          nvp.addElement( langbean.getValue("cdsp_ui"), "5" );

          buf.append("<tr><td valign=\"bottom\" class=\"WizardInputText\">");
          buf.append(langbean.getValue("ACCOUNT.userAccess"));
          buf.append(":</td><td>");
          buildSelectList( buf, "ACCOUNT_access", nvp, s, true, 0, 1 ," onChange='Javascript:accessChange()' ");
          buf.append("</td></tr>");
       }else{
          buf.append("<tr><td valign=\"bottom\" class=\"WizardInputText\">");
          buf.append(langbean.getValue("ACCOUNT.userAccess"));
          buf.append(":</td><td>");
          switch( access ){
                        case 2:  buf.append(langbean.getValue("as2_ui"));
                             break;
                        /* TD 166510
                        case 3:   buf.append(langbean.getValue("ds_ui"));
                             break;
                        */
                        case 4:   buf.append(langbean.getValue("dash_ui"));
                             break;
                        case 5:   buf.append(langbean.getValue("cdsp_ui"));
                             break;

                        case 1:
                        default:  buf.append(langbean.getValue("admin_ui"));
        }
          buf.append("</td></tr>");

       }
         }

    }

  /**
   * builds a select control to give the choice of UI to build
   * options - Admin - UI , AS2 - UI , UCCNET - UI
   */
     private void buildTheme( StringBuffer buf ) {

       String s = "1";
       int theme = 1;
       if(usrAccount != null ){
            theme = usrAccount.getTheme();
            s = String.valueOf( theme );
       }
       SessionInfo sessionInfo = (SessionInfo)wiz.session().getAttribute("SessionInfo");
       boolean isUCCnetAdmin = sessionInfo.getAutho().hasExplicitPermission("UCCNETADMIN");

       if (isUCCnetAdmin){
            buf.append("<input type=\"hidden\" name=\"ACCOUNT_theme\" value=\"");
            buf.append("-1");
            buf.append("\">");
       } else {
          NameValuePairs nvp = new NameValuePairs();
          nvp.addElement( langbean.getValue("theme_default"), "-1" );
          nvp.addElement( langbean.getValue("theme_oper"), "1" );
          nvp.addElement( langbean.getValue("theme_participant"), "2" );
          nvp.addElement( langbean.getValue("theme_ppt_sponsor"), "3" );
          nvp.addElement( langbean.getValue("theme_sponsor"), "4" );
          nvp.addElement( langbean.getValue("theme_aft"), "5" );

          buf.append("<tr><td valign=\"bottom\" class=\"WizardInputText\">");
          buf.append(langbean.getValue("ACCOUNT.theme"));
          buf.append(":</td><td>");
          buildSelectList( buf, "ACCOUNT_theme", nvp, s, true, 1, 3 );
          buf.append("</td></tr>");
          buf.append("</td></tr>");

          buf.append("<SCRIPT LANGUAGE='JavaScript1.1'>\n");
          buf.append("function accessChange() {\n");
            buf.append(   "if (document.wizform.ACCOUNT_access.options[document.wizform.ACCOUNT_access.selectedIndex].value == 4) {\n");
            buf.append(       "document.wizform.ACCOUNT_theme.disabled=false;\n");
            buf.append("  } else {\n");
            buf.append("      document.wizform.ACCOUNT_theme.selectedIndex=0;\n");
            buf.append("      document.wizform.ACCOUNT_theme.disabled=true;\n");
            buf.append("  }\n");
         buf.append("}\n");
         buf.append("</SCRIPT>\n");


       }

    }
    /**
     * The method for building the html input for the AccountName
     * for the wizard page
     * @param buf StringBuffer to append to
     */
    private void buildAccName(StringBuffer buf) {


        if(usrAccount != null && usrAccount.theAutho != null){
          String s = usrAccount.theAutho.getUserName();
          if(s == null)
          {
              s = "";
          }
          buf.append("<tr>");
          if (wiz.action == Wizard.ADD) {
            buildReqInputBox(buf, langbean.getValue("ACCOUNT.userName"), "ACCOUNT_userName", s,
                                   "12", "36");
          } else {
            buf.append("<td valign=\"bottom\" class=\"WizardAccountsText\">");
            buf.append(langbean.getValue("ACCOUNT.userName"));
            buf.append(":</td><td>");
            buf.append(BaseUIGlobals.processHTMLDisplayValue(s));
            buf.append("</td>");
          }
          buf.append("</tr>");
        }
        else{
          buf.append("<tr><td>");
          buf.append(langbean.getValue("Label.noEditAvailable"));
          buf.append("</td></tr>");
        }

    }

    /**
     * The method for building the html input for the Security Code
     * for the wizard page
     * @param buf StringBuffer to append to
     */
    private void buildAuthType(StringBuffer buf) {

        String className = "whiteStripe";
        int access = 1;
        String s = "1";
        if(usrAccount != null ){
            access = usrAccount.getAccessibility();
            s = String.valueOf( access );
        }
        SessionInfo sessionInfo = (SessionInfo)wiz.session().getAttribute("SessionInfo");
        boolean isUCCnetAdmin = sessionInfo.getAutho().hasExplicitPermission("UCCNETADMIN");

        if (isUCCnetAdmin){
          buf.append("<input type=\"hidden\" name=\"ACCOUNT_AuthType\" value=\"");
          buf.append("0");
          buf.append("\">");
        } else {
          buf.append("<table>\n");

          buf.append("<tr>\n");
          buf.append("<td class=\"WizardAccountsText\">\n");
          buf.append(langbean.getValue("Label.UserAuthType"));
          buf.append(":</td>\n");

          // Build the Operation select controls
          String selectedValue = "";
          String label = "";
          String onValue = "";
          boolean on = true;
          boolean createJS = true;
          boolean b = usrAccount.theAutho.isLocallyAuthenticated();

          //  checks license manager for LDAP and/or SSO keys.  This neither exist, the AuthType radio buttons will be disabled.
          if (! (LM.checkLicense("SSO") || LM.checkLicense("LDAPSSO"))) {
            createJS = false; // sets flag that creates JS that pops up alert box stating the customer doesn't have the proper license.
            b = true; //defaults the radio button to 'local'
          }

          int formatType = b ? 0 : 1;
          for (int i = 0; i < 2; i++) {
            on = true;
            switch (i) {
              case 0:
                if (formatType != 0)
                  on = false;
                label = langbean.getValue("Label.AuthLocal");
                onValue = "0";
                break;
              case 1:
                if (formatType != 1)
                  on = false;
                label = langbean.getValue("Label.AuthExternal");
                onValue = "1";
                break;

              default:
                on = false;
                label = "";
                onValue = "";
                break;
            }
            buf.append("<td>\n");
            makeImage(buf, "images.spacer", "20", null, null);
            buf.append("</td><td class=\"");
            buf.append("WizardInputRadio");
            buf.append("\" valign=\"top\">");

            if (on) {
              buildImgRadio(buf, i, "ACCOUNT_AuthType", label, onValue, onValue,
                            "WizardInputRadio",
                            "images." + wiz.location + ".radio_button_on");
              selectedValue = onValue;
            }
            else {
              buildImgRadio(buf, i, "ACCOUNT_AuthType", label, onValue, null,
                            "WizardInputRadio",
                            "images." + wiz.location + ".radio_button_on");
            }

            buf.append("</td>");
            on = false;
          }
          buf.append("</tr>\n");
          buf.append("</table>\n");

          if (createJS)
            imageRadioJavascriptReload(buf, "ACCOUNT_AuthType", selectedValue, 2,
                                       "images.Deployment.radio_button_on");
          else
            buildRadioJavascriptReloadForAuthType(buf, "ACCOUNT_AuthType"); // this builds a disabled version of the radio buttons.

       }


    }

    public void imageRadioJavascriptReload(StringBuffer buffer,
                                        String keyname,
                                        String selectedValue,
                                        int count,
                                        String onbutton) {

        buffer.append("<input type='hidden' name='");
        buffer.append(keyname);
        buffer.append("' value='");
        if (selectedValue != null)
            buffer.append(selectedValue);
        buffer.append("'>\n");

        buffer.append("<SCRIPT LANGUAGE='JavaScript1.1'>\n");
        buffer.append("<!--\n");
        buffer.append(keyname);
        buffer.append("down= new Image();\n");
        buffer.append(keyname);
        buffer.append("down.src= \"");
        buffer.append(langbean.getValue(onbutton));
        buffer.append("\";\n");
        buffer.append(keyname);
        buffer.append("up= new Image();\n");
        buffer.append(keyname);
        buffer.append("up.src= \"");
        buffer.append(langbean.getValue("images.radio_button_off"));
        buffer.append("\";\n");
        buffer.append("function click");
        buffer.append(keyname);
        buffer.append("(form, which, val) {\n");

        buffer.append("  form.");
        buffer.append(keyname);
        buffer.append(".value = val;\n");
        buffer.append("  if (document.images) {\n");
        buffer.append("     for (var j=0; j<");
        buffer.append(count);
        buffer.append("; j++) {\n");
        buffer.append("       if (j==which){\n");
        buffer.append("          document.images['");
        buffer.append(keyname);
        buffer.append("Radio'+j].src = ");
        buffer.append(keyname);
        buffer.append("down.src;\n");
        buffer.append("reloadPage();\n");

        buffer.append("       }else{\n");
        buffer.append("          document.images['");
        buffer.append(keyname);
        buffer.append("Radio'+j].src = ");
        buffer.append(keyname);
        buffer.append("up.src;}\n");
        buffer.append("       }\n");
        buffer.append("   }\n");
        buffer.append("   else \n");
        buffer.append("     alert('not supported');\n");
        buffer.append("}\n");
        buffer.append("function reloadPage(){\n");
        buffer.append("document.wizform.WizardAction.value = 'edit';\n");
        buffer.append(" document.wizform.submit();\n");
        buffer.append("}\n");
        buffer.append("//-->\n");
        buffer.append("</SCRIPT>\n");

    }

    private void buildRadioJavascriptReloadForAuthType(StringBuffer buffer, String keyname) {

        buffer.append(
            "<input type='hidden' name='"+keyname+"' value='0'>\n");
        buffer.append("<SCRIPT LANGUAGE='JavaScript1.1'>\n");
        buffer.append("<!--\n");
        buffer.append("function click");
        buffer.append(keyname);
        buffer.append("(form, which, val) {\n");
        buffer.append("alert(\"A Single Sign-On or LDAP license must be installed to use this feature. \");\n");
        buffer.append("}\n");
        buffer.append("//-->\n");
        buffer.append("</SCRIPT>\n");

    }

    /**
     * The method for building the html input for the Name
     * for the wizard page
     * @param buf StringBuffer to append to
     */
    private void buildName(StringBuffer buf) {

      if(usrAccount != null && usrAccount.theAutho != null){
          String s = usrAccount.theAutho.getFName();
          if(s == null)
          {
              s = "";
          }
          buf.append("<tr>");
          buildReqInputBox(buf, langbean.getValue("ACCOUNT.FName"), "ACCOUNT_FName", s,
                                   "32", "64");
          buf.append("</tr>");

          s = usrAccount.theAutho.getLName();
          if(s == null)
          {
              s = "";
          }
          buf.append("<tr>");
          buildReqInputBox(buf, langbean.getValue("ACCOUNT.LName"), "ACCOUNT_LName", s,
                                   "32", "64");
          buf.append("</tr>");
      }
      else{
          buf.append("<tr><td>");
          buf.append(langbean.getValue("Label.noEditAvailable"));
          buf.append("</td></tr>");
        }

    }

   /**
     * The method for building the html input for the Name
     * for the wizard page
     * @param buf StringBuffer to append to
     */
    private void buildParentID(StringBuffer buf) {

      if(usrAccount != null && usrAccount.theAutho != null){
          //changed control from editbox to dropdown list v3.1
          Vector v = sm.listAllUsers();
          NameValuePairs nvp = new NameValuePairs();
          nvp.addElement( " ", " " );
          if (v!=null && v.size() > 0) {
              User u = null;
              String uName;
              for (int i=0; i<v.size(); i++) {
                 u = (User)v.elementAt(i);
                 uName = u.getUserName();
                 if ( !usrAccount.theAutho.getUserName().equals( uName ) )
                 nvp.addElement( uName, uName );
              }
          }

          String s = usrAccount.theAutho.getParentID();
          if(s == null) {
              s = "";
          }
          buf.append("<tr><td valign=\"bottom\" class=\"WizardInputText\">");
      buf.append(langbean.getValue("ACCOUNT.ParentID"));
      buf.append(":</td><td>");

          buildSelectList( buf, "ACCOUNT_ParentID", nvp, s, true, 0, 1 );

          buf.append("</td></tr>");

      } else {
          buf.append("<tr><td>");
          buf.append(langbean.getValue("Label.noEditAvailable"));
          buf.append("</xftd></tr>");
      }

    }


     /**
     * The method for building the html input for the PolicyId
     * for the wizard page
     * @param buf StringBuffer to append to
     */
    private void buildPolicyId(StringBuffer buf) {

      if(usrAccount != null && usrAccount.theAutho != null){
          //changed control from editbox to dropdown list v3.1
          Vector v = sm.listAllPolicies();
          NameValuePairs nvp = new NameValuePairs();
          nvp.addElement( " ", " " );
          if (v!=null && v.size() > 0) {
              PwdPolicy p = null;
              for (int i=0; i<v.size(); i++) {
                 p = (PwdPolicy)v.elementAt(i);
                 nvp.addElement( p.getPolicyname(), p.getPolicyid() );
              }
          }

          String s = usrAccount.theAutho.getPolicyID();
          if(s == null) {
              s = "";
          }
          buf.append("<tr><td valign=\"bottom\" class=\"WizardInputText\">");
      buf.append(langbean.getValue("ACCOUNT.Policy"));
      buf.append(":</td><td>");

          buildSelectList( buf, "ACCOUNT_PolicyID", nvp, s, true, 0, 2 );

          buf.append("</td></tr>");

      } else {
          buf.append("<tr><td>");
          buf.append(langbean.getValue("Label.noEditAvailable"));
          buf.append("</td></tr>");
      }

    }

/**
     * The method for building the html input for the Name
     * for the wizard page
     * @param buf StringBuffer to append to
     */
    private void buildEntityID(StringBuffer buf) {

        buf.append("<tr><td valign=\"bottom\" class=\"WizardAccountsText\">");
    buf.append(langbean.getValue("ACCOUNT.userEntity"));
    buf.append(":</td><td>");

    if (usrAccount != null) {

        Object maps[] = null;
        try {
        ArrayList arr = EntityUtil.listAll(0, 0, true);
        maps = arr.toArray();
        } catch (Exception ex) {
        BaseUIGlobals.out.logException("[AccountBean.buildIdentity]",ex);
        }

        String s = usrAccount.theAutho.getEntityID();
        if (s == null) s = "DEFAULT";

        NameValuePairs nvp = new NameValuePairs();
        // TD 165628 All users belongs to Hub Organization.
        // nvp.addElement( " ", " " );
        if (maps!=null && maps.length > 0) {
        Map m = null;

        for (int i=0; i<maps.length; i++) {
            m = (Map)maps[i];
            //nvp.addElement( (String)m.get( "OBJECT_NAME" ), (String)m.get( "OBJECT_ID" ) );
            //Need to trim the Organization_Key, to match space trailing Organization_Key
            nvp.addElement( (String)m.get( "ORGANIZATION_NAME" ), ((String)m.get( "ORGANIZATION_KEY" )).trim() );
        }
        }

        buildSelectList( buf, "ACCOUNT_EntityID", nvp, s, true );

    }
    buf.append("</td></tr>");

    }
    /**
     * The method for building the html input for the email
     * for the wizard page
     * @param buf StringBuffer to append to
     */
   private void buildEmail(StringBuffer buf) {

    if(usrAccount != null && usrAccount.theAutho != null){
        String s = usrAccount.theAutho.getEmail();
        if(s == null)
        {
            s = "";
            if (usrAccount.theAutho.getUserName().equalsIgnoreCase("admin")){
              s = Manager.getProperties("si_config").getProperty("SI_ADMIN_MAIL_ADDR");
              if(s == null)  s = "";
            }

        }
        buf.append("<tr>");
        buildInputBox(buf, langbean.getValue("ACCOUNT.Email"), "ACCOUNT_Email", s.trim(),
                                 "32", "64");
        buf.append("</tr>");
    }

   }

    /**
     * The method for building the html input for the pager
     * for the wizard page
     * @param buf StringBuffer to append to
     */
   private void buildPager(StringBuffer buf) {

    if(usrAccount != null && usrAccount.theAutho != null){
        String s = usrAccount.theAutho.getPager();
        if(s == null)
        {
            s = "";
        }
        buf.append("<tr>");
        buildInputBox(buf, langbean.getValue("ACCOUNT.Pager"), "ACCOUNT_Pager", s.trim(),
                                 "24", "24");
        buf.append("</tr>");
    }

   }


    /**
     * The method for building the html input for the language
     * for the wizard page
     * @param buf StringBuffer to append to
     */
   private void buildLanguage(StringBuffer s) {

    if(usrAccount != null && usrAccount.theAutho != null){
        String lang = usrAccount.theAutho.getLang();
        if(lang == null)
        {
            lang = "";
        }

        String l[] = LangBundle.getLongnames();
        if(l != null && l.length != 0)
            {
                if(l.length > 1)
                    {
                        s.append("<tr>");
                        s.append("<td valign=\"bottom\" class=\"WizardInputText\">");
                        s.append(langbean.getValue("ACCOUNT.Language"));
                        s.append(":");
                        s.append("</td>");

                        s.append("<td>");
                        s.append(langbean.getSelectlist(lang));

                        s.append("</td>");
                    }
                else
                    {

                        /* LangBundle b = LangBundle.getBundleByLongname(l[0]);
                           String code = b.getCode();
                        */
                        s.append("<input type=\"hidden\" name=\"lang\" value=\"");
                        s.append(lang);
                        s.append("\">");
                     }
            }
    }

   }


    /**
     * The method for building the html input for the password
     * for the wizard page
     * @param buf StringBuffer to append to
     */
    private void buildAccPassword(StringBuffer buf) {

     if(usrAccount != null && usrAccount.theAutho != null){
        String s = usrAccount.theAutho.getUserPassword();

        SessionInfo sessionInfo = (SessionInfo)wiz.session().getAttribute("SessionInfo");
        String usrLoggedIn = sessionInfo.getAutho().getUserName();
        String usrBeingEdited = usrAccount.theAutho.getUserName();
        boolean usrEditedSuper = usrAccount.theAutho.hasGroup("super");
        boolean usrLoggedInSuper = sessionInfo.getAutho().hasGroup("super");

        if(s == null)
        {
            s = "";
        }

        //if(!s.equals("")){ // This test fails when switching from local to LDAP authentication
        if(wiz.action == Wizard.EDIT){
            buf.append("<tr>");
            //disable property is not supported in NS 4.7
            //buildPasswordInputBox(buf, langbean.getValue("ACCOUNT.userOldPassword"), "ACCOUNT_userOldPass", s.substring(0,5),"12", "12", true);//disable

            if ( usrLoggedIn.equals( usrBeingEdited ) || ( !usrLoggedInSuper && usrEditedSuper ) ) {
                buf.append("<tr>");
                buildPasswordInputBox(buf, langbean.getValue("ACCOUNT.userOldPass"), "ACCOUNT_userOldPass", "","12", "28", false);//enable
                buf.append("</tr>");
            } else {
                    buf.append("<td valign=\"bottom\" class=\"WizardInputText\">");
                    buf.append(langbean.getValue("ACCOUNT.userOldPassword"));
                    buf.append(":");
                    buf.append("</td>");
                    buf.append("<td>");
                    buf.append("*****");//since we display only first 5 chars, have 5 stars instead
                    buf.append("</td>");
                    buf.append("</tr>");
            }
            buf.append("<tr>");
            buildPasswordInputBox(buf, langbean.getValue("ACCOUNT.userNewPass"), "ACCOUNT_userPass", "","12", "28", false);//enable
            buf.append("</tr>");
            buf.append("<tr>\n");
            buildPasswordInputBox(buf, langbean.getValue("ACCOUNT.userNewPassConfirm"), "ACCOUNT_userPassConfirm", "" ,"12", "28", false);//enabled
            buf.append("</tr>");
        } else {
            buf.append("<tr>");
            buildReqPasswordInputBox(buf, langbean.getValue("ACCOUNT.userPass"), "ACCOUNT_userPass", "","12", "28", false);//enable
            buf.append("</tr>");
            buf.append("<tr>\n");
            buildReqPasswordInputBox(buf, langbean.getValue("ACCOUNT.userPassConfirm"), "ACCOUNT_userPassConfirm", "" ,"12", "28", false);//enabled
            buf.append("</tr>");
        }
     }

    }

    private void buildPermSelect(StringBuffer sb) {

    	if (usrAccount.getAvailablePermissions() == null)
    	{
    		usrAccount.initAvailableSelectedPermissions();
    	}
    	NameValuePairs fromList = usrAccount.getAvailablePermissionsAsNVP();
        NameValuePairs toList = usrAccount.getSelectedPermissionsAsNVP();
        NameValuePairs permTypes = new NameValuePairs();
        String nameFilter = "";
        String typeFilter = "";
        int selectedSize = toList.size();
        for(int i=0; i<selectedSize; i++){
        	NameValue elem = (NameValue)toList.get(i);
            String id = elem.name;
            if(fromList.getValue(id) != null){
            	fromList.removeElement(id);
            }
        }
        try {
            nameFilter = usrAccount.theAutho.getPermNameFilter();
            typeFilter = usrAccount.theAutho.getPermTypeFilter();
            String strGrp = null;
            Permission perm = null;

            Properties props = Manager.getProperties("ADMIN-UI");
            String type = "" ;
            permTypes.addElement( "" , "" );
            if( props != null ) {
            	// Since each clump now has its own allocated range of permission type
            	// numbers, the numbers won't be contiguous.

            	// Iterator through and find the permission properties, making a
            	// list of the numbers so that we can sort them.
            	Iterator i = props.keySet().iterator();
            	ArrayList<Integer> numList = new ArrayList<Integer>(20);
            	String num;
            	String key;
            	while (i.hasNext()) {
            		key = (String)i.next();
            		if ((key.startsWith("PERM.type.")) && (!"PERM.type.99".equals(key))) {
            			num = key.substring(10);
            			numList.add(Integer.parseInt(num));
            		}
            	}
            	Collections.sort(numList);
            	Iterator<Integer> numIt = numList.iterator();
            	String numStr;
            	while (numIt.hasNext()) {
            		numStr = String.valueOf(numIt.next());
            		key = "PERM.type." + numStr;
            		permTypes.addElement(props.getProperty(key), numStr);
            	}

            	// Add in "Other".
            	String otherType = props.getProperty("PERM.type.99");
            	if (otherType != null) {
            		permTypes.addElement(otherType, "99");
            	}
            }



    }catch( Exception ex ){
        BaseUIGlobals.out.logException("[GroupBean] build permissions", ex);
    }

    boolean usingNS = false ;
        int i_ns = -1;
        if( wiz.session() != null )
           i_ns = ((Integer)wiz.session().getAttribute("NS4Browser")).intValue();
        if( i_ns == 1 ) usingNS = true;

        buildVMPickerHiddenFormData(sb);
        buildFilter(sb, "filterdata", "byname", "permname" , nameFilter, "bytype", "permtype",
        			typeFilter, permTypes, 25);
        buildMboxMultiPicker(sb, fromList, toList);

//        buildMultiPicker( sb, fromList , toList, imaxPerms ,
//                          "filterdata", "byname", "permname", nameFilter,
//                          "bytype","permtype",typeFilter,permTypes,
//                          "SelectPerm", "available", "assigned", "availlist", "assignlist", usingNS);
//        buildMultiPickerJScript( sb );

    }

        private void buildRightsSelect(StringBuffer buf) {

            buf.append("<table cellpadding=0 cellspacing=0 border=0 width=520>\n");
            String className = "whiteStripe";
        String val = "";

            Vector v = usrAccount.theAutho.getTmpGroups();
            Vector vnames = new Vector();
            NameValuePairs nvpGroupPerms = null;
            NameValuePairs nvpTotPerms = new NameValuePairs();
            Group group = null;
            if (v!=null && v.size() > 0) {
                int z = v.size();
                String g;
                for (int i=0; i<z; i++) {
                    g = (String)v.elementAt(i);
                    if (!g.equals("false")) {
                        group = BaseUIGlobals.securityMgr.getGroup( g );
                        if( group != null ) {
                            usrAccount.theAutho.removeTmpSubGroups();
                            usrAccount.theAutho.refreshGroupsForGroupWizard ( group.getGroupid() ); // for each group, it will go out and get all subgroups.
                            nvpGroupPerms = group.getPermIDsWithRightsForGroup();
                            int gn = nvpGroupPerms.numEntries();
                            for( int n=0;n<nvpGroupPerms.numEntries(); n++ ) {
                                //  need to add
                                if ( !nvpTotPerms.contains( nvpGroupPerms.getElement(n).name, nvpGroupPerms.getElement(n).value.toString() ) ) {
                                    nvpTotPerms.addElement( nvpGroupPerms.getElement(n).name, nvpGroupPerms.getElement(n).value );
                                }
                            }

                            // gets subgroups that were retrieved above.  then gets all the subgroup permissions for display
                            Vector vSubGrps = usrAccount.theAutho.getTmpSubGroups();
                            NameValuePairs nvp = null;
                            if ( vSubGrps != null ) {
                                for (int a=0; a<vSubGrps.size(); a++) {
                                    group = BaseUIGlobals.securityMgr.getGroup( (String)vSubGrps.elementAt(a) );
                                    if( group != null ) {
                                        nvp = group.getPermIDsWithRightsForGroup();
                                        if( nvp != null ) {
                                            for( int j=0;j<nvp.numEntries(); j++ ) {
                                                //  need to add
                                                if ( !nvpTotPerms.contains( nvp.getElement(j).name, nvp.getElement(j).value.toString() ) ) {
                                                    nvpTotPerms.addElement( nvp.getElement(j).name, nvp.getElement(j).value );
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                usrAccount.theAutho.setTmpSubPermWithRightsFromWizard( nvpTotPerms );
            }

            NameValuePairs names = usrAccount.theAutho.getTmpPermsAddWithRights();

            buildRightsRow( buf , "", className, "ACCOUNT.userPerm", names, ENABLED_CHECKBOX, PERM_STRING, true );
            spacerLine(buf);
            addHSpace(buf, "5");
            addHSpace(buf, "5", null, "20");
            buildRightsRow( buf , "", className, "ACCOUNT.userGroupPerm", nvpTotPerms, DISABLED_CHECKBOX, GROUP_STRING, true );
            spacerLine(buf);
            addHSpace(buf, "5");
            addHSpace(buf, "5", null, "20");

            buf.append("</table>");

    }

    public void buildRightsRow(StringBuffer buf , String width, String className, String label, NameValuePairs val, String img, String accType, boolean addSpacer ){

        if (accType.equals(PERM_STRING)) {
            buf.append("<tr><td colspan=5>");
            buf.append(langbean.getValue("ACCOUNT.RWXD"));
            buf.append("</td>\n<tr>\n");
        }
        buf.append("<tr><td>");
        buf.append(langbean.getValue("ACCOUNT.R"));
        buf.append("</td>\n<td>\n");
        buf.append(langbean.getValue("ACCOUNT.W"));
        buf.append("</td>\n<td>\n");
        buf.append(langbean.getValue("ACCOUNT.X"));
        buf.append("</td>\n<td>\n");
        buf.append(langbean.getValue("ACCOUNT.D"));
        buf.append("</td>\n<td>\n");
        buf.append(langbean.getValue(label));
        buf.append("</td>\n</tr>\n");

        addHSpace(buf, "5");
        addHSpace(buf, "5", null, "1");
        addHSpace(buf, "5");
        spacerLine(buf);

        Vector vRead = new Vector();
        Vector vWrite = new Vector();
        Vector vExecute = new Vector();
        Vector vDelete = new Vector();

        if ( val==null || val.size() < 1) {
            buf.append("<tr>\n<td colspan=5>\n");
            buf.append(langbean.getValue("Label.notspecified"));
            buf.append("</td>\n</tr>\n");
        } else {
            boolean b = (wiz.action == Wizard.ADD);
            boolean flag = false;
            NameValue nv = null;
            Integer right = null;
            Permission p = null;
            val.sortStringValue(false);
            for (int i=0;i<val.numEntries();i++) {
                nv = val.getElement(i);
                buf.append("<tr>\n<td>\n");
                right = (Integer)nv.value;

                flag = usrAccount.theAutho.checkRight(right.intValue(), Permission.READ);
                buildImgCheckbox(buf, i, accType+"Read", "","1", "0",  flag?"1":"0","WizardInputText", img);
                vRead.addElement(flag?"1":"0");

                buf.append("</td>\n");
                buf.append("<td>\n");

                flag = usrAccount.theAutho.checkRight(right.intValue(), Permission.WRITE);
                buildImgCheckbox(buf, i, accType+"Write", "","1", "0", flag?"1":"0","WizardInputText", img);
                vWrite.addElement(flag?"1":"0");

                buf.append("</td>\n");
                buf.append("<td>\n");

                flag = usrAccount.theAutho.checkRight(right.intValue(), Permission.EXECUTE);
                buildImgCheckbox(buf, i, accType+"Execute", "","1", "0", flag?"1":"0","WizardInputText", img);
                vExecute.addElement(flag?"1":"0");

                buf.append("</td>\n");
                buf.append("<td>\n");

                flag = usrAccount.theAutho.checkRight(right.intValue(), Permission.DELETE);
                buildImgCheckbox(buf, i, accType+"Delete", "","1", "0", flag?"1":"0","WizardInputText", img);
                vDelete.addElement(flag?"1":"0");

                p = BaseUIGlobals.securityMgr.getPermission( nv.name );
                buf.append("</td>\n");
                buf.append("<td>\n");
                buf.append(p.getPermission());
                buf.append("</td>\n");
                buf.append("</tr>\n");
            }
        }

        buf.append("<input type='hidden' name='PERM_SIZE' value='");
        buf.append(val.size());
        buf.append("'>\n");

        if (accType.equals(PERM_STRING)) {
            NameValue nv = null;
            for (int j=0; j<val.numEntries(); j++) {
                nv = val.getElement(j);
                buf.append("<input type='hidden' name='");
                buf.append("PERM_NAME");
                buf.append(j);
                buf.append("' value='");
                buf.append( nv.name );
                buf.append("'>\n");
            }

            imageCheckboxJavascript(buf, accType+"Read", vRead, val.numEntries());
            imageCheckboxJavascript(buf, accType+"Write", vWrite, val.numEntries());
            imageCheckboxJavascript(buf, accType+"Execute", vExecute, val.numEntries());
            imageCheckboxJavascript(buf, accType+"Delete", vDelete, val.numEntries());
        }

    }



    private void buildGroupSelect(StringBuffer sb) {

    	Vector selected_gids = new Vector();
        Vector allgroups  = new Vector();
        Vector groups  = new Vector();
        NameValuePairs fromList = new NameValuePairs();
        NameValuePairs toList = new NameValuePairs();
        String filter = "";
        if( props == null) props = Manager.getProperties("ADMIN-UI");
        String maxGroups = props.getProperty("maxGroupList");
        int imaxGroups= 1000;
        try { imaxGroups = Integer.parseInt(maxGroups); }
        catch( Exception ex ) { imaxGroups = 1000 ; }
        try {
            Group _grp = null;
            selected_gids = usrAccount.theAutho.getTmpGroups();


              filter = usrAccount.theAutho.getGroupFilter();

              allgroups = BaseUIGlobals.securityMgr.listAllGroups();
              if( filter == null ) filter = "";
              if( filter.trim().length() > 0 ) groups = BaseUIGlobals.securityMgr.listGroups(filter);
              else                             groups = allgroups ;

              SessionInfo sessionInfo = (SessionInfo)wiz.session().getAttribute("SessionInfo");
              boolean editingUserIsSuper = sessionInfo.getAutho().getSuper();

              for (int j=0; j< groups.size(); j++) {
                  _grp = (Group)groups.elementAt(j);
                  if(!selected_gids.contains(_grp.getGroupid()) && !_grp.getGroupid().equals("as2admin") && !_grp.getGroupid().equals("uccnetuser")&& !_grp.getGroupid().equals("uccnetadmin")){
                	  if(_grp.getGroupid().equalsIgnoreCase("super") && !editingUserIsSuper){
                		  continue;  //we don't want to display the super user group for none super users.
                	  }
                    fromList.addElement( _grp.getGroupid() , _grp.getGroupName());
                  }
             }
             for (int j=0; j< allgroups.size(); j++) {
                _grp = (Group)allgroups.elementAt(j);
                if(selected_gids.contains(_grp.getGroupid()))
                    toList.addElement(_grp.getGroupid(), _grp.getGroupName());
             }

              fromList.sortStringValue(false);
              toList.sortStringValue(false);
            //}
        }catch (Exception ex) {
              BaseUIGlobals.out.logException("[AccountBean]", ex);
        }

        boolean usingNS = false ;
        int i_ns = -1;
        if( wiz.session() != null )
           i_ns = ((Integer)wiz.session().getAttribute("NS4Browser")).intValue();
        if( i_ns == 1 ) usingNS = true;
        buildMultiPicker( sb, fromList , toList, imaxGroups,
                          "filterdata", "byname", "groupname", filter,
                          "SelectGroups", "available", "assigned", "availlist", "assignlist", usingNS);
        buildMultiPickerJScript( sb );

    }


    /**
     * The method for building the html , containg all the account info
     * for the wizard confirm page
     * @param buf StringBuffer to append to
     */
    private void buildConfirm(StringBuffer buf) {
    	buf.append("<table cellpadding=0 cellspacing=0 border=0 width=520>\n");
        String className = "whiteStripe";
        String val = "";

        buf.append("<tr>");
        startStripeCell(buf, "WizardInputText", "colspan=4");
        buf.append(langbean.getValue("AccountSettings"));
        buf.append("</td>\n");
        buf.append("</tr>\n");
        addHSpace(buf, "4");
        addHSpace(buf, "4", null, "1");
        addHSpace(buf, "4");
        spacerLine(buf);

        if(usrAccount != null && usrAccount.theAutho != null){
            buildConfirmRow( buf , "140", className, "ACCOUNT.userName", usrAccount.theAutho.getUserName(), true );

            int timeo = usrAccount.theAutho.getTimeout() ;
            if( timeo == 0 ) val = langbean.getValue("ACCOUNT.defaultTimeout");
            else val = timeFormat(usrAccount.theAutho.getTimeout() / 60);
            buildConfirmRow( buf , "140", className, "ACCOUNT.timeout", val, true );

            Vector v = usrAccount.theAutho.getTmpGroups();



            Vector vnames = new Vector();
            Vector vSubGrps = new Vector();
            ArrayList vperms = new ArrayList();
            int permSize = 0;
            usrAccount.theAutho.removeTmpSubGroups();
            Group grp = null;



            if (v!=null && v.size() > 0) {
                int z = v.size();
                Hashtable allPermissions = BaseUIGlobals.securityMgr.listAllPermissionsHash();
                HashSet myPermissions = new HashSet();
                String g;
                for (int i=0; i<z; i++) {
                    g = (String)v.elementAt(i);
                    //vnames.add(g);
                    if (!g.equals("false")) {
                        grp = BaseUIGlobals.securityMgr.getGroup( g );
                        if( grp != null ) {
						    vnames.add(grp.getGroupName());
                            usrAccount.theAutho.refreshGroupsForGroupWizard ( grp.getGroupid() ); // for each group, it will go out and get all subgroups.
                            String grpsPerms[] = grp.getPermIDsForGroup();
                            if( grpsPerms != null ){
                                String permission = null;
                                for( int j=0;j<grpsPerms.length ; j++ ){
                                    permission = (String) allPermissions.get( grpsPerms[j] );
                                    if ( !myPermissions.contains( grpsPerms[j] ) ) {
                                       permSize++;
                                    	myPermissions.add(grpsPerms[j]);
                                    }
                                }
                            }
                            // gets subgroups that were retrieved above.  then gets all the subgroup permissions for display
                            vSubGrps = usrAccount.theAutho.getTmpSubGroups();
                            if ( vSubGrps != null ) {
                                for (int a=0; a<vSubGrps.size(); a++) {
                                    grp = BaseUIGlobals.securityMgr.getGroup( (String)vSubGrps.elementAt(a) );
                                    if( grp != null ) {
                                        String grpSubPerms[] = grp.getPermIDsForGroup();
                                        if( grpSubPerms != null ) {
                                            String permission = null;
                                            for( int j=0;j<grpSubPerms.length ; j++ ) {
                                                permission = (String) allPermissions.get( grpSubPerms[j] );
                                                if ( !myPermissions.contains( grpSubPerms[j] ) ) {
                                                	permSize++;
                                                    myPermissions.add( grpSubPerms[j] );
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if( vnames.size() == 0 )
              buildConfirmRow( buf , "140", className, "ACCOUNT.userRole", "", true );
            else
              buildConfirmRow( buf , "140", className, "ACCOUNT.userRole", vnames.toString(), true );

// comment out for v3.3 rights framework - 1

            if(permSize == 0 ){
             buildConfirmRow( buf , "140", className, "ACCOUNT.userGroupPerm", "", true );
            }
            else
            {
             String count = Integer.toString(permSize);
             String grpPermission ="<a href=\"javascript:selectedPermissionsList('./Page?next=page.selectedGrpPermission')\" >"+count+"</a>";
             buildConfirmRow( buf , "140", className, "ACCOUNT.userGroupPerm", grpPermission, true, false );
            }
// end comment - 1

/*// uncomment this block for v3.3 rights framework - 1
            NameValuePairs nvpSub = usrAccount.theAutho.getTmpSubPermsWithRights();
            buildConfirmPermRow( buf , "140", className, "ACCOUNT.userGroupPerm", nvpSub, true );

            // builds line under group permissions
            spacerLine(buf);
            addHSpace(buf, "4", "ltspacer","1");
            spacerLine(buf);
*/// end uncomment - 1


            			int pSize = usrAccount.theAutho.getTmpPerms().size();
            			String ConfirmPerm =Integer.toString(pSize);

            			if(pSize == 0) {
            				ConfirmPerm = langbean.getValue("Label.NoneProvided");
            			}
                        else {
            	            ConfirmPerm = "<a href=\"javascript:selectedPermissionsList('./Page?next=page.selectedPermission')\" >"+ConfirmPerm+"</a>";
// comment out for v3.3 rights framework - 2
            	            buildConfirmRow( buf , "140", className, "ACCOUNT.userPerm", ConfirmPerm, true, false );
                        }

// end comment - 2

/*// uncomment this block for v3.3 rights framework - 2
                        NameValuePairs nvp = usrAccount.theAutho.getTmpPermsAddWithRights();
                        buildConfirmPermRow( buf , "140", className, "ACCOUNT.userPerm", nvp, true );
                        }
                        // builds line under permissions
                        spacerLine(buf);
                        addHSpace(buf, "4", "ltspacer","1");
                        spacerLine(buf);
*/// end uncomment - 2

            int access = usrAccount.getAccessibility();
             switch( access ){
                        case 2:  val = "as2_ui";
                                 break;
                        case 3:  val = "ds_ui";
                                 break;
                        case 4:  val = "dash_ui";
                                 break;
                        case 5:  val = "cdsp_ui";
                                 break;
                        case 1:
                        default:  val = "admin_ui";
            }
            buildConfirmRow( buf , "140", className, "ACCOUNT.userAccess", langbean.getValue(val), true );
            int theme = usrAccount.getTheme();
             switch( theme ){
                        case 1 : val = "theme_oper"; break ;
                        case 2:  val = "theme_participant"; break;
                        case 3:  val = "theme_ppt_sponsor"; break;
                        case 4:  val = "theme_sponsor"; break;
                        case 5:  val = "theme_aft"; break;
                        default:  val = "theme_default";
            }
            buildConfirmRow( buf , "140", className, "ACCOUNT.theme", langbean.getValue(val), true );

            buildConfirmRow( buf , "140", className, "ACCOUNT.FName", usrAccount.theAutho.getFName(), true );
            buildConfirmRow( buf , "140", className, "ACCOUNT.LName", usrAccount.theAutho.getLName(), true );
                        buildConfirmRow( buf , "140", className, "ACCOUNT.Email", usrAccount.theAutho.getEmail(), true );
                        buildConfirmRow( buf , "140", className, "ACCOUNT.Pager", usrAccount.theAutho.getPager(), true );
            buildConfirmRow( buf , "140", className, "ACCOUNT.ParentID", usrAccount.theAutho.getParentID(), true );

            AuthenticationProps ap = sm.getAuthentication(AuthenticationProps.DEFAULT_AUTHENTICATION_NAME + usrAccount.theAutho.getSecurityCode());
            String tmpStr = null;
            if (ap != null) {
                tmpStr = " [" + ap.display_name + "]";
            } else {
                tmpStr = " [" + AuthenticationProps.DEFAULT_LDAP_DISPLAY_NAME + "]";
            }
            buildConfirmRow( buf , "140", className, "Label.UserAuthType", usrAccount.theAutho.isLocallyAuthenticated()?(langbean.getValue("Label.AuthLocal") + tmpStr):(langbean.getValue("Label.AuthExternal") + tmpStr), true );


            String s = usrAccount.theAutho.getEntityID();
            // TD 165628 display ORGANIZATION_NAME instead ORGANIZATION_KEY
            if(s == null || s.length() == 0) {
               s = "";
            }else{
               try {
                 s = EntityUtil.findEntityNameByColumn("ORGANIZATION_KEY", s);
               } catch (Exception ex) {
                 BaseUIGlobals.out.logException("[AccountBean.buildConfirm]",ex);
	         s = "";
	       }
            }
            buildConfirmRow( buf , "140", className, "ACCOUNT.EntityID", s, true );
                        //Account Policy
            String str = usrAccount.theAutho.getPolicyID();
            if(str == null) {
                str = "";
            }else{
             PwdPolicy pwd = PwdPolicy.load(str);
             if(pwd != null)
                str = pwd.getPolicyname();
             else
                str="";
            }

            buildConfirmRow( buf , "140", className, "ACCOUNT.Policy", str, true );

            //Remote User Key
	    buildConfirmExt ( usrAccount, buf) ;

                        String LangLong = "";
                        LangLong = usrAccount.theAutho.getLang();
                        LangLong = LangBundle.getNameForCode(LangLong);
                        buildConfirmRow( buf , "140", className, "ACCOUNT.Language", LangLong, false );


        }
        else{
          buf.append("<tr><td>");
          buf.append(langbean.getValue("Label.noEditAvailable"));
          buf.append("</td></tr>");
        }


        spacerLine(buf);
        addHSpace(buf, "4");
        
/*
 * Dual Control - START
 */
 
        DualControlUtil dcu = new DualControlUtil();
        buf.append(dcu.buildDualControlSection(wiz.session()));
/*
* Dual Control - END
*/
        
        addHSpace(buf, "4", null, "20");

        buf.append("</table>");


    }

    private void buildConfirmPermRow( StringBuffer buf , String width, String className, String label, NameValuePairs nvp, boolean addSpacer ) {

    buf.append("<tr>");
    startStripeCell(buf, className, "width="+width);
    buf.append(langbean.getValue(label));
    buf.append("</td>\n");
    addVSpace(buf, "ltspacer", "1", null);
    addVSpace(buf, className, "5", null);
    startStripeCell(buf, className, null);
        if(nvp == null || nvp.numEntries() < 1) {
            buf.append(langbean.getValue("Label.notspecified"));
        } else {
            boolean flag = false;
            NameValue nv = null;
            Permission p = null;
            int right;
            for (int i=0; i<nvp.numEntries(); i++) {
                nv = nvp.getElement(i);
                p = (Permission)CacheManager.get("PermissionCache", nv.name);
                right = ((Integer)nv.value).intValue();
                buf.append("<table><tr>");
                startStripeCell(buf, className, "width=45");
                flag = usrAccount.theAutho.checkRight(right, Permission.READ);
                buf.append(flag?langbean.getValue("ACCOUNT.R"):"-");
                flag = usrAccount.theAutho.checkRight(right, Permission.WRITE);
                buf.append(flag?langbean.getValue("ACCOUNT.W"):"-");
                flag = usrAccount.theAutho.checkRight(right, Permission.EXECUTE);
                buf.append(flag?langbean.getValue("ACCOUNT.X"):"-");
                flag = usrAccount.theAutho.checkRight(right, Permission.DELETE);
                buf.append(flag?langbean.getValue("ACCOUNT.D"):"-");
                buf.append("</td><td>");
                buf.append(p.getPermission());
                buf.append("</td>\n</tr>\n</table>\n");
            }
        }
    buf.append("</td>");
    buf.append("</tr>\n");

    }




    /**
     * Generates a String representation of the object.
     * @return String
     */
    public String toString() {
         StringBuffer s = new StringBuffer();
         s.append("AccountBean Object:\n");
         return s.toString();
    }


    private String timeFormat(int timeout){
        int tHour, tMin;
        tHour = timeout / 60;
        tMin = timeout % 60;
        if (tHour > 0){
            return tHour + langbean.getValue(" hr ") + tMin + langbean.getValue(" min");
        }
        else{
            return tMin + langbean.getValue(" min");
        }
    }
    private void buildVMPickerHiddenFormData(StringBuffer buf){

        //code addition Manish Joddar manish_joddar_tw@comm.com 01/10/2006   -----start
        buf.append("<input type='hidden' name='direct_avail2select_transfer' value='false'>\n");
        buf.append("<input type='hidden' name='direct_select2avail_transfer' value='false'>\n");
        buf.append("<input type='hidden' name='right_transfer' value='false'>\n");
        buf.append("<input type='hidden' name='left_transfer' value='false'>\n");
        buf.append("<input type='hidden' name='avail_side' value=''>\n");
        buf.append("<input type='hidden' name='select_side' value=''>\n");
        buf.append("<input type='hidden' name='UI_CHECK_FLAG' value=''>\n");
        buf.append("<input type='hidden' name='window' value=''>\n");
         //code addition Manish Joddar manish_joddar_tw@stercomm.com 01/10/2006   -----end
    }

    private void buildMboxMultiPicker(StringBuffer buf, NameValuePairs availablePermisions, NameValuePairs selectedPermissions)
    {
		 Properties p = Manager.getProperties("ADMIN-UI");

	     int pos =  usrAccount.getPositionValue();
	     int position = usrAccount.getSelectBoxPositionValue();

	     String amb_height_val = p.getProperty("MAX_AVAILABLE_MAILBOX_HEIGHT");
  	     String smb_height_val = p.getProperty("MAX_SELECTED_MAILBOX_HEIGHT");
  	     int num = usrAccount.getNumberValue();
	     int number =  usrAccount.getSelectBoxNumberValue();

	     String url = "./AccountWizard?wizType=UpdateAccount&wizObjType=4&action=accPermEdit&wizardname=UpdateAccount&WizardAction=search";

	     super.buildVerticalMultiPicker(buf, pos, num, position, number, amb_height_val, smb_height_val,
	    		 availablePermisions, selectedPermissions, BaseUIGlobals.MAX_MAILBOX_LIST_SIZE,"SelectPerm", "available",
	        		"assigned", "availlist", "assignlist", url);

        buildMultiPickerJScript(buf);
    }


    public String retrievePermissions(){

    	Vector v = usrAccount.theAutho.getTmpPerms();
        Vector vnames = new Vector();
        String confirmPerm = null;
        if (v!=null && v.size() > 0) {
           int z = v.size();
           Permission prm = null;
           String p;

           if ( z > 10 ) { // More than 10 database calls in a loop is too slow
               Hashtable allPermissions = BaseUIGlobals.securityMgr.listAllPermissionsHash();
               for ( Iterator it = v.iterator(); it.hasNext(); ) {
                   p = (String) it.next();
                   if ( ! p.equals("false")) {
                    vnames.add(allPermissions.get(p)); // Get the permission name using it's id
                   }
               }
           } else {
               for (int i=0; i<z; i++) {
                   p = (String)v.elementAt(i);
                   if (!p.equals("false")) {
                      prm = BaseUIGlobals.securityMgr.getPermission( p );
                      vnames.add(prm.getPermission());
                   }
                }
           }
        }

        if(vnames.toString().length() < 3) confirmPerm = langbean.getValue("Label.NoneProvided");
        else confirmPerm = vnames.toString();
        return confirmPerm;



    }

	public  Vector retrieveGroupPermissions(){
    	Vector v = usrAccount.theAutho.getTmpGroups();
    	Vector vnames = new Vector();
        Vector vperms = new Vector();
        Vector vSubGrps = new Vector();
        usrAccount.theAutho.removeTmpSubGroups();
        Group grp = null;

       if (v!=null && v.size() > 0) {
            int z = v.size();
            Hashtable allPermissions = BaseUIGlobals.securityMgr.listAllPermissionsHash();
            HashSet myPermissions = new HashSet();
            String g;
            for (int i=0; i<z; i++) {
                g = (String)v.elementAt(i);
                if (!g.equals("false")) {
                    grp = BaseUIGlobals.securityMgr.getGroup( g );
                    if( grp != null ) {
                        usrAccount.theAutho.refreshGroupsForGroupWizard ( grp.getGroupid() ); // for each group, it will go out and get all subgroups.
                        vnames.add(grp.getGroupName());
                        String grpsPerms[] = grp.getPermIDsForGroup();
                        if( grpsPerms != null ){
                            String permission = null;
                            for( int j=0;j<grpsPerms.length ; j++ ){
                                permission = (String) allPermissions.get( grpsPerms[j] );
                                if ( !myPermissions.contains( grpsPerms[j] ) ) {
                                    vperms.add(permission);
                                    myPermissions.add(grpsPerms[j]);
                                }
                            }
                        }
                        // gets subgroups that were retrieved above.  then gets all the subgroup permissions for display
                        vSubGrps = usrAccount.theAutho.getTmpSubGroups();
                        if ( vSubGrps != null ) {
                            for (int a=0; a<vSubGrps.size(); a++) {
                                grp = BaseUIGlobals.securityMgr.getGroup( (String)vSubGrps.elementAt(a) );
                                if( grp != null ) {
                                    String grpSubPerms[] = grp.getPermIDsForGroup();
                                    if( grpSubPerms != null ) {
                                        String permission = null;
                                        for( int j=0;j<grpSubPerms.length ; j++ ) {
                                            permission = (String) allPermissions.get( grpSubPerms[j] );
                                            if ( !myPermissions.contains( grpSubPerms[j] ) ) {
                                                vperms.add(permission);
                                                myPermissions.add( grpSubPerms[j] );
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        vSubGrps = usrAccount.theAutho.getTmpSubGroups();
        for (int c=0; c<vSubGrps.size(); c++) {
            grp = BaseUIGlobals.securityMgr.getGroup( (String)vSubGrps.elementAt(c) );
            if ( v.contains( (String)grp.getGroupid() ) ) {
                v.remove( (String)grp.getGroupid() );
                vnames.remove( (String)grp.getGroupName() );
            }
        }

    return vperms;
    }
    private void buildFilter(StringBuffer s, String filterTitle, String filterLabel1,
    										 String filterName1, String filterValue1,
    										 String filterLabel2, String filterName2,
    										 String filterValue2, NameValuePairs filter2Options,
    										 int filterWidth)
    {

        if( filterTitle == null ) filterTitle = "";
        if( filterLabel1 == null ) filterLabel1 = "";
        if( filterName1 == null ) filterName1= "name";
        if( filterValue1 == null ) filterValue1 = "";
        if( filterLabel2 == null ) filterLabel2 = "";
        if( filterName2 == null ) filterName2= "type";
        if( filterValue2 == null ) filterValue2 = "";
        getVerticalFilterButtonsScript(s, true);
        s.append("<table width=\"70%\" border=\"0\" cellspacing=\"2\" cellpadding=\"0\" height=\"67\">");
        s.append("<tr>");
        s.append("<td height='1'><img src='./images/plc-holder.gif' border=0 height='1' ></td>");
        s.append("</tr>");

        s.append("<tr>");
        s.append("<td valign='top'>");
        s.append("<table border=0 cellpadding=0 cellspacing=0 valign='top' width=300>");

        //<!-- search -->
        if( filterTitle.trim().length() > 0 ){
            s.append("<tr><td colspan=3 nowrap class='WizardInputText' valign='bottom'>");
            s.append(langbean.getValue(filterTitle));
            s.append(":</td></tr>\n");
        }
        //s.append("<tr><td colspan=2 height=15><img src='./images/plc-holder.gif' height=15>&nbsp;</td></tr>\n");
        s.append("<tr>\n");
        s.append("<td  align='right'  valign='center'  nowrap>");
        s.append(langbean.getValue(filterLabel1));
        if( filterLabel1.trim().length() > 0 )
            s.append(":&nbsp;&nbsp;</td>\n");
        else s.append("&nbsp;&nbsp;</td>\n");
        s.append("<td align=left class=whiteStripe valign='bottom'><input type=text name='" + filterName1 + "' value='");
        s.append(filterValue1);
        // fix to Bug#7418
        s.append("' onKeyPress='submitFilter();'");
        s.append("' size='");
        s.append( filterWidth );
        s.append("' maxlength=249></td>\n");
        s.append("<TD align='right'  valign='center'  nowrap>&nbsp;</td></tr>");

        s.append("<tr>\n");
        s.append("<td  align='right'  valign='center'  nowrap>");
        s.append(langbean.getValue(filterLabel2));
        if( filterLabel2.trim().length() > 0 )
            s.append(":&nbsp;&nbsp;</td>\n");
        else s.append("&nbsp;&nbsp;</td>\n");
        s.append("<td align=left class=whiteStripe valign='bottom'>");
        buildSelectList(s,filterName2,filter2Options,filterValue2,true);
        s.append("</td>\n");
        s.append("<TD align=left class=whiteStripe >&nbsp;&nbsp;<A href=\"javascript:document.wizform.submit()\"");
        s.append("onClick=\"return isReady(document.wizform,'Search',");
        if( this.pageno != null )
            s.append(pageno);
        else s.append(1);

        s.append(",'');\"");

        s.append("onmouseover=\"chgButton('Filter','FilterOver'); window.status=''; return true;\"");
        s.append("onmouseout=\"chgButton('Filter','FilterOff'); window.status=''; return true;\"");
        s.append("onmousedown=\"chgButton('Filter','FilterDown'); return true;\">");
        makeImage(s, "images.filter", null, null, "Filter", "align='center'");
        s.append("</a></td></tr>");

        s.append("</table>\n");
        s.append("</td>\n");
        s.append("</tr>\n");

        //<!-- End of search -->


          s.append("<tr>");
          s.append("<td height='1'><img src='./images/plc-holder.gif' border=0 height='1' ></td>");
          s.append("</tr>");
          s.append("</table>");
      }

}

