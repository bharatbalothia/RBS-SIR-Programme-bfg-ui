package ic2.ui.db;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sterlingcommerce.woodstock.util.frame.jdbc.JDBCService;

@SuppressWarnings({"deprecation"})
public abstract class GISPoolConnection implements Connection {
	private static final Logger logger = Logger.getLogger(DBUtils.class);
	private Connection conn;
	
	public GISPoolConnection(Connection conn){
		this.conn=conn;
	}
	
	public int getHoldability() throws SQLException {
		// TODO Auto-generated method stub
		return conn.getHoldability();
		//return 0;
	}

	public int getTransactionIsolation() throws SQLException {
		// TODO Auto-generated method stub
		return conn.getTransactionIsolation();
		//return 0;
	}

	public void clearWarnings() throws SQLException {
		// TODO Auto-generated method stub
		conn.clearWarnings();

	}

	public void close() throws SQLException {
		// TODO Auto-generated method stub
		logger.debug("GISPoolConnection: freeing connection (not closing)");
		JDBCService.freeConnection(conn);
		
	}

	public void commit() throws SQLException {
		// TODO Auto-generated method stub
		conn.commit();
	}

	public void rollback() throws SQLException {
		// TODO Auto-generated method stub
		conn.rollback();
	}

	public boolean getAutoCommit() throws SQLException {
		// TODO Auto-generated method stub
		//return false;
		return conn.getAutoCommit();
	}

	public boolean isClosed() throws SQLException {
		// TODO Auto-generated method stub
		//return false;
		return conn.isClosed();
	}

	public boolean isReadOnly() throws SQLException {
		// TODO Auto-generated method stub
		//return false;
		return conn.isReadOnly();
	}

	public void setHoldability(int holdability) throws SQLException {
		// TODO Auto-generated method stub
		conn.setHoldability(holdability);
	}

	public void setTransactionIsolation(int level) throws SQLException {
		// TODO Auto-generated method stub
		conn.setTransactionIsolation(level);

	}

	public void setAutoCommit(boolean autoCommit) throws SQLException {
		// TODO Auto-generated method stub
		conn.setAutoCommit(autoCommit);
	}

	public void setReadOnly(boolean readOnly) throws SQLException {
		// TODO Auto-generated method stub
		conn.setReadOnly(readOnly);
	}

	public String getCatalog() throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.getCatalog();
	}

	public void setCatalog(String catalog) throws SQLException {
		// TODO Auto-generated method stub
		conn.setCatalog(catalog);
	}

	public DatabaseMetaData getMetaData() throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.getMetaData();
	}

	public SQLWarning getWarnings() throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.getWarnings();
	}

	public Savepoint setSavepoint() throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.setSavepoint();
	}

	public void releaseSavepoint(Savepoint savepoint) throws SQLException {
		// TODO Auto-generated method stub
		conn.releaseSavepoint(savepoint);
	}

	public void rollback(Savepoint savepoint) throws SQLException {
		// TODO Auto-generated method stub
		conn.rollback(savepoint);
	}

	public Statement createStatement() throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.createStatement();
	}

	public Statement createStatement(int resultSetType, int resultSetConcurrency)
			throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.createStatement(resultSetType, resultSetConcurrency);
	}

	public Statement createStatement(int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.createStatement(resultSetType,resultSetConcurrency,resultSetHoldability);
	}

	@SuppressWarnings("unchecked")
	public Map getTypeMap() throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.getTypeMap();
	}

	public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
		// TODO Auto-generated method stub
		conn.setTypeMap(map);
	}

	public String nativeSQL(String sql) throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.nativeSQL(sql);
	}

	public CallableStatement prepareCall(String sql) throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.prepareCall(sql);
	}

	public CallableStatement prepareCall(String sql, int resultSetType,
			int resultSetConcurrency) throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.prepareCall(sql, resultSetType,resultSetConcurrency);
	}

	public CallableStatement prepareCall(String sql, int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.prepareCall(sql,resultSetType,resultSetConcurrency, resultSetHoldability);
	}

	public PreparedStatement prepareStatement(String sql) throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.prepareStatement(sql);
	}

	public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
			throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.prepareStatement(sql, autoGeneratedKeys);
	}

	public PreparedStatement prepareStatement(String sql, int resultSetType,
			int resultSetConcurrency) throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.prepareStatement(sql,resultSetType,resultSetConcurrency);
	}

	public PreparedStatement prepareStatement(String sql, int resultSetType,
			int resultSetConcurrency, int resultSetHoldability)
			throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.prepareStatement(sql,resultSetType,resultSetConcurrency, resultSetHoldability);
	}

	public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
			throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.prepareStatement(sql, columnIndexes);
	}

	public Savepoint setSavepoint(String name) throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.setSavepoint(name);
	}

	public PreparedStatement prepareStatement(String sql, String[] columnNames)
			throws SQLException {
		// TODO Auto-generated method stub
		//return null;
		return conn.prepareStatement(sql,columnNames);
	}

}
