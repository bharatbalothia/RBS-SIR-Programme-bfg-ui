/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
**********************************************************************
* Current Version
* ================
* Revision:   		$LastChangedRevision$
* Date/time:  		$LastChangedDate$
**********************************************************************/
package com.stercomm.customers.rbs.sct.ui.dtoimpl;

import java.util.Date;

import org.apache.log4j.Logger;


import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.dto.Schedule;

/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 * @hibernate.class table="SCT_SCHEDULE"
 */
public class ScheduleImpl extends BaseHibernateBeanImpl implements Schedule{
	private static final long serialVersionUID = 1L;
	private static final Logger log = Logger.getLogger(ScheduleImpl.class);
	
	private Long scheduleId;
	private Entity entity;
	private Boolean isWindow = Boolean.TRUE;
	private Integer timestart = new Integer(0);
	private Integer windowEnd;
	private Integer windowInterval;
	private Integer transThreshold;
	private Boolean Active = Boolean.TRUE;
	private Date nextRun;
	private Date lastRun;
	private String filetype;
	
	/**
	 * @return the log
	 */
	public static Logger getLog() {
		return log;
	}
	/**
	 * @return the serialVersionUID
	 */
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	/**
	 * @return the active
	 * @hibernate.property column = "active"
	 */
	public Boolean getActive() {
		return Active;
	}
	/**
	 * @param active the active to set
	 */
	public void setActive(Boolean active) {
		Active = active;
	}
	/**
	 * @return the entity
	 * @hibernate.many-to-one column = "entity_Id" class = "com.stercomm.customers.rbs.sct.ui.dtoimpl.EntityImpl" cascade="save-update"
	 */
	public Entity getEntity() {
		return entity;
	}
	/**
	 * @param entityId the entityId to set
	 */
	public void setEntity(Entity entity) {
		this.entity = entity;
	}
	/**
	 * @return the window
	 * @hibernate.property column = "isWindow"
	 */
	public Boolean getIsWindow() {
		return isWindow;
	}
	/**
	 * @param isWindow the isWindow to set
	 */
	public void setIsWindow(Boolean isWindow) {
		this.isWindow = isWindow;
	}
	/**
	 * @return the lastRun
	 * @hibernate.property column = "lastRun"
	 */
	public Date getLastRun() {
		return lastRun;
	}
	/**
	 * @param lastRun the lastRun to set
	 */
	public void setLastRun(Date lastRun) {
		this.lastRun = lastRun;
	}
	/**
	 * @return the nextRun
	 * @hibernate.property column = "nextRun"
	 */
	public Date getNextRun() {
		return nextRun;
	}
	/**
	 * @param nextRun the nextRun to set
	 */
	public void setNextRun(Date nextRun) {
		this.nextRun = nextRun;
	}
	/**
	 * @return the scheduleId
	 * @hibernate.id column = "schedule_Id" generator-class = "sequence"
	 * @hibernate.generator-param name = "sequence" value = "SCT_SCHEDULE_IDSEQ"
	 */
	public Long getScheduleId() {
		return scheduleId;
	}
	/**
	 * @param scheduleId the scheduleId to set
	 */
	public void setScheduleId(Long scheduleId) {
		this.scheduleId = scheduleId;
	}
	/**
	 * @return the timestart
	 * @hibernate.property column = "timestart"
	 */
	public Integer getTimestart() {
		return timestart;
	}
	/**
	 * @param timestart the timestart to set
	 */
	public void setTimestart(Integer timestart) {
		this.timestart = timestart;
	}
	/**
	 * @return the transThreshold
	 * @hibernate.property column = "transThreshold"
	 */
	public Integer getTransThreshold() {
		return transThreshold;
	}
	/**
	 * @param transThreshold the transThreshold to set
	 */
	public void setTransThreshold(Integer transThreshold) {
		this.transThreshold = transThreshold;
	}
	/**
	 * @return the windowEnd
	 * @hibernate.property column = "windowEnd"
	 */
	public Integer getWindowEnd() {
		return windowEnd;
	}
	/**
	 * @param windowEnd the windowEnd to set
	 */
	public void setWindowEnd(Integer windowEnd) {
		this.windowEnd = windowEnd;
	}
	/**
	 * @return the windowInterval
	 * @hibernate.property column = "windowInterval"
	 */
	public Integer getWindowInterval() {
		return windowInterval;
	}
	/**
	 * @param windowInterval the windowInterval to set
	 */
	public void setWindowInterval(Integer windowInterval) {
		this.windowInterval = windowInterval;
	}
	
	/**
	 * @return the filetype
	 * @hibernate.property column = "filetype"
	 */
	public String getFiletype() {
		return filetype;
	}
	
	/**
	 * @param filetype the filetype to set
	 */
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}	
	
	
}
