package test;

//import org.apache.log4j.Logger;
import com.sterlingcommerce.woodstock.util.frame.Manager;

public class PropsTest {
	private static final long serialVersionUID = 1L;

	//private static final Logger log = Logger.getLogger(PropsTest.class);
	
	
	public static void main(String[] args) {
		Manager.getProperties();
		
	}
}
