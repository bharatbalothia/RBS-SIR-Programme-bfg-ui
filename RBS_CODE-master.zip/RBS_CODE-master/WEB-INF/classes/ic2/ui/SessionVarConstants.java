	package ic2.ui;

public class SessionVarConstants {
	
	public static final String GIS_USER_OBJECT = "GIS_LOGGED_IN_USER";
	public static final String GIS_USER_TIMEOUT = "timeout";
	public static final String GIS_USERNAME = "username";
	public static final String GIS_USER_FULLNAME = "fullName";
	
	public static final String TRACKING_SEARCH_BEAN = "TRACKING_SEARCH_BEAN";
	
	//Wizard session beans
	public static final String ADMIN_BEAN = "adminBean";
	
	public static final String CUSTOMER_BEAN = "customerBean";
	public static final String CUSTOMER_CONTACT_BEAN = "customerContact";
	
	public static final String CUSTOMER_FILTER_BEAN = "CUSTOMER_FILTER_BEAN";
	public static final String ROUTER_FILTER_BEAN = "ROUTER_FILTER_BEAN";
	public static final String CHANNEL_BEAN = "channelBean";
	public static final String ERROR_BEAN = "ERROR_BEAN";
	public static final String WAIT_KEY_MAP = "WAIT_KEY_MAP";
	public static final String EXTENSION_BEAN = "extension";
	public static final String ROUTER_BEAN = "router";
	public static final String SESSION_BEAN = "settingsBean";
	public static final String USER_BEAN = "user";
	public static final String FILE_TYPE_BEAN = "fileType";
	public static final String MAILBOX_BEAN = "mailbox";

}
