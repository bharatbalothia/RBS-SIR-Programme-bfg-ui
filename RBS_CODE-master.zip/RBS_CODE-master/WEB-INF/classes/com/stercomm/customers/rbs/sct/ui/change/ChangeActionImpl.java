package com.stercomm.customers.rbs.sct.ui.change;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;


public class ChangeActionImpl implements ChangeAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void commit() throws Exception {
		throw new UnsupportedOperationException();
	}

	public byte[] getObjectBytes() throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oout = new ObjectOutputStream(baos);
		oout.writeObject(this);
		oout.close();
		return baos.toByteArray();
	}

}
