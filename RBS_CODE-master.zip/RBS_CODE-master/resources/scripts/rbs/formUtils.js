function padLeadingChars(field, padToSize, padStr){
	while(field.value.length < padToSize){
		field.value = padStr+field.value;
	}
}


function selectAllCheckboxes(name){
	checkboxes = document.getElementsByName(name);
	for (var i=0; i<checkboxes.length; i++){
		if (checkboxes[i].disabled == false){
			checkboxes[i].checked='checked';
		}
	}
}

function deselectAllCheckboxes(name){
	checkboxes = document.getElementsByName(name);
	for (var i=0; i<checkboxes.length; i++){
		checkboxes[i].checked='';
	}
}

/*
 * functiom arrowclick_wide
 * assumes that the last row in the select list is a spacer row (to work around IE not handling min-with)
 * this function wraps the 'arrowclick' function, removing the spcer row, performing arrowclick, and then re-inserting
 * the spacer
 */
function arrowclick_wide(from, to){
	src = eval("document.getElementById('"+from+"')");
	target = eval("document.getElementById('"+to+"')");

	spacer1 = src.options[src.options.length-1];
	spacer2 = target.options[target.options.length-1];
	
	src.remove(src.options.length-1);
	target.remove(target.options.length-1);
	arrowclick(from, to);
	src.options[src.options.length] = spacer1;
	target.options[target.options.length] = spacer2;
}

/*
 * functiom Dblarrowclick_wide
 * assumes that the last row in the select list is a spacer row (to work around IE not handling min-with)
 * this function wraps the 'Dblarrowclick' function, removing the spcer row, performing Dblarrowclick, and then re-inserting
 * the spacer
 */
function Dblarrowclick_wide(from, to){
	src = eval("document.getElementById('"+from+"')");
	target = eval("document.getElementById('"+to+"')");

	spacer1 = src.options[src.options.length-1];
	spacer2 = target.options[target.options.length-1];
	
	src.remove(src.options.length-1);
	target.remove(target.options.length-1);
	Dblarrowclick(from, to);
	src.options[src.options.length] = spacer1;
	target.options[target.options.length] = spacer2;
}

function arrowclick(from, to){
	src = eval("document.getElementById('"+from+"')");
	target = eval("document.getElementById('"+to+"')");
	
	if (target.disabled == 0){
		//moveItemsFromSrc2Target(src, target);
		moveSelected(src, target);
	}
}

function Dblarrowclick(from, to){
	var src = eval("document.getElementById('"+from+"')");
	var target = eval("document.getElementById('"+to+"')");
	if (target.disabled == 0){
		//moveAllItemsFromSrc2Target(src, target);
		moveAll(src, target);
	}
	src = null;
	target = null;
}

function moveAll(from, to){
	for (var i=0; i<from.options.length; i++){
		from.options[i].selected=true;
	}
	moveSelected(from, to);
}

function moveSelected(from, to){
	var selected = new Array();
	for(var i=from.options.length-1; i>=0; i--){
		if (from.options[i].selected==true){
			selected[selected.length] = from.options[i];
			from.options[i]=null;
		}
	}
	
	for (var i=selected.length-1; i>=0; i--){
		to.options[to.options.length]=selected[i];
		to.options[to.options.length-1].selected=true;
	}
	selected = null;

}

/*
 * function trim(string)
 * returns the parameter String removing any start/trailing whitespace
 */
function trim(str) { 
	var startPattern = /^\s*/;
	var endPattern  = /\s*$/;
    var trimmed = str.replace(startPattern, '').replace(endPattern, ''); 
   	return trimmed;
} 


function toUpperCase(elementId){
	var element = document.getElementById(elementId);
	element.value = element.value.toUpperCase();
}


function copyArrayToSelectOptions(optionArray, selectCntl){
	for (var i=0; i<selectCntl.options.length; i++){
		selectCntl.options[i]=null;
	}
	for (var i=0; i<optionArray.length; i++){
		selectCntl.options[i] = optionArray[i];
	}
}

function hitEnter(strutsAction, validationMethod, e){ 
	if (checkEnter(e)){//checkEnter is a function in validators.js - returns false if enter is pressed
		return true;	
	}
	else{ 
		setStrutsAction(strutsAction); //function in struts.js
		if (validationMethod == null && validationMethod.length ==0){
			return true;	
		}
		else {
			return eval(validationMethod);
		}
	}
		
	
}
