/**
 * 
 */
package ic2.ui.struts.reports.actions;

import ic2.ui.SessionVarConstants;
import ic2.ui.WaitKey;
import ic2.ui.beans.reports.ReportRunnerBean;
import ic2.ui.beans.reports.ReportSettingsBean;
import ic2.ui.exception.IC2UIRuntimeException;
import ic2.ui.exception.IC2UIUnauthorizedException;
import ic2.ui.reports.ReportRunner;
import ic2.ui.struts.actions.IC2UIAction;
import ic2.ui.struts.reports.forms.ReportSearchForm;
import ic2.ui.utils.ReportLoader;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.stercomm.customers.webapps.resources.Constants;
import com.sterlingcommerce.woodstock.security.User;

/**
 * @author Ravi K Patel
 * created May 3, 2006
 */
public class ReportsRunAction extends IC2UIAction {
	private static final Logger logger = Logger.getLogger(ReportsRunAction.class);
	
		
	
	@SuppressWarnings("unchecked")
	public ActionForward start(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ReportSearchForm rform = (ReportSearchForm)form;
		
		Map<?, ?> reports = ReportLoader.getReports();
		ReportSettingsBean reportSettings = (ReportSettingsBean)reports.get(rform.getReportType());
		
		//RELEASE: remove if statement
		if (true){//AUTHORIZATION BLOCK
			User user = getGISUserObject(request);
			
			if (!user.hasPermission(reportSettings.getAuthorization())){
				String message = "User "+user.getUserName()+" does not have permission to run report '"+reportSettings.getName()+"'";
				logger.info(message+"..throwing an IC2UnauthorizedException");
				throw new IC2UIUnauthorizedException(message);
			}
		}
		
		ReportRunnerBean reportRunnerBean = new ReportRunnerBean();
		reportRunnerBean.setReportSettings(reportSettings);

		if(reportSettings.getUsedates()!=null && !reportSettings.getUsedates().equalsIgnoreCase("false")){
			reportRunnerBean.setReportEndDate(rform.getReportEndDate());
			reportRunnerBean.setReportStartDate(rform.getReportStartDate());
		}
		
		
		logger.debug("executing report:"+reportSettings.getName());
		String waitKey = WaitKey.getWaitKey();
		HttpSession session =  request.getSession();
		User u = (User)session.getAttribute(Constants.GIS_USER_OBJECT);
		ReportRunner runner = new ReportRunner(reportRunnerBean, request, u.getUserName());
		
		Thread t = new Thread(runner);
		t.start();
		Map waitKeyMap = (Map)request.getSession().getAttribute(SessionVarConstants.WAIT_KEY_MAP);
		waitKeyMap.put(waitKey, runner);
		request.setAttribute("waitKey", waitKey);
		return mapping.findForward("wait");
	}
	
	public ActionForward wait(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String waitKey = request.getParameter("waitKey");
		Map<?, ?> waitKeyMap = (Map<?, ?>)request.getSession().getAttribute(SessionVarConstants.WAIT_KEY_MAP);
		ReportRunner runner = (ReportRunner)waitKeyMap.get(waitKey);
		switch (runner.getStatus()){
		case ReportRunner.FAILURE: logger.fatal("ReportRunner threw an exception", runner.getException()); throw runner.getException();
		case ReportRunner.RUNNING: logger.debug("ReportRunner in RUNNING status");request.setAttribute("waitKey", waitKey); return mapping.findForward("wait");
		case ReportRunner.WAITING: logger.debug("ReportRunner in WAITING status"); request.setAttribute("waitKey", waitKey); return mapping.findForward("wait");
		case ReportRunner.SUCCESS: logger.debug("ReportRunner in SUCCESS status"); return doSuccess(mapping, form, request, response); 
		default: throw new IC2UIRuntimeException("ReportRunner has an unknown status");
		}	
		
		
	}
		
	private ActionForward doSuccess(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String waitKey = request.getParameter("waitKey");
		
		response.sendRedirect(request.getContextPath()+"/ic2Report.xls?waitKey="+waitKey);
		return mapping.findForward("viewReport");
	}
		
	
}
