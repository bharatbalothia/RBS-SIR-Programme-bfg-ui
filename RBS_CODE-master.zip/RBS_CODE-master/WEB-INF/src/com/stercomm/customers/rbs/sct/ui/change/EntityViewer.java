package com.stercomm.customers.rbs.sct.ui.change;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.stercomm.customers.rbs.sct.ui.dao.EntityDAO;
import com.stercomm.customers.rbs.sct.ui.dto.Entity;
import com.stercomm.customers.rbs.sct.ui.dto.Schedule;
import com.stercomm.customers.webapps.util.hibernate.HibernateUtils;
import org.hibernate.Session;

@SuppressWarnings({"unchecked", "unused", "deprecation"})
public class EntityViewer implements ChangeViewer {

	private ChangeControl change;
	public final static String OBJECT_TYPE="Entity";

	public EntityViewer(){
	}

	public String getObjectType(){
		return OBJECT_TYPE;
	}

	public ChangeControl getChange() {
		return change;
	}

	public void setChange(ChangeControl change) {
		this.change = change;
	}

	public String getBeforeChangeLink(){
		String ret = "<a>None</a>";

		try {
			if(getChange()!=null && getChange().getObjectKey()!=null){
				//No before link for CREATE operation
				if(getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_DELETE) || getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_UPDATE)){
					StringBuffer sb = new StringBuffer();
					sb.append("<a href=\"javascript:openInfoWin(\'./entityView.do?id=");
					sb.append(URLEncoder.encode(getChange().getObjectKey()));
					sb.append("\', 850, 600);\" onmouseover=\"window.status=\'View Entity Information\'; return true;\" onmouseout=\"window.status=\'\'; return true;\">");
					sb.append(getChange().getResultMeta1());
					sb.append("</a>");
					ret = sb.toString();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			ret = "<a>Error displaying link</a>";
		}
		return ret;
	}

	public String getAfterChangeLink(){
		String ret = "<a>None</a>";

		try {
			if(getChange()!=null && getChange().getChangeID()!=null){
				//if operation is DELETE then there are no objects afterwards
				if(getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_CREATE) || getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_UPDATE)){
					StringBuffer sb = new StringBuffer();
					sb.append("<a href=\"javascript:openInfoWin(\'./entityView.do?change=true&id=");
					sb.append(URLEncoder.encode(getChange().getChangeID()));
					sb.append("\', 850, 600);\" onmouseover=\"window.status=\'View Entity Information\'; return true;\" onmouseout=\"window.status=\'\'; return true;\">");
					sb.append(getChange().getResultMeta1());
					sb.append("</a>");
					ret = sb.toString();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			ret = "<a>Error displaying link</a>";
		}
		return ret;
	}

	public String getDifferencesLink(){
		String ret = "<a></a>";

		try {
			if(getChange()!=null && getChange().getChangeID()!=null){
				//only for UPDATE
				if(getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_UPDATE)){
					StringBuffer sb = new StringBuffer();
					sb.append("<a href=\"javascript:openInfoWin(\'./diffView.do?&id=");
					sb.append(URLEncoder.encode(getChange().getChangeID()));
					sb.append("\', 850, 600);\" onmouseover=\"window.status=\'View Differences\'; return true;\" onmouseout=\"window.status=\'\'; return true;\">");
					sb.append("<img src=\"./resources/images/en/blue/blue_info_button.gif\" border=\"0\"  align=\"absbottom\"/>");
					sb.append("</a>");
					ret = sb.toString();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			ret = "<a>Error displaying link</a>";
		}
		return ret;
	}

	public List getDifferences(){

		List diff = null;
		//Only list diff for an UPDATE
		try {
			if(getChange()!=null && getChange().getOperation().equalsIgnoreCase(ChangeConstants.OPERATION_UPDATE)){
				EntityDAO entityDAO = new EntityDAO(getHibernateSession());
				Integer entityId = new Integer(getChange().getObjectKey());
				Entity eBefore = entityDAO.getEntity(entityId);
				Entity eAfter = entityDAO.getNewInstance(getChange());

				diff=new ArrayList();
				diff.add(new DiffViewer("Entity", eBefore.getEntity(), eAfter.getEntity()));
				diff.add(new DiffViewer("Service", eBefore.getService(), eAfter.getService()));
				diff.add(new DiffViewer("RequestorDN", eBefore.getRequestorDN(), eAfter.getRequestorDN()));
				diff.add(new DiffViewer("ResponderDN", eBefore.getResponderDN(), eAfter.getResponderDN()));
				diff.add(new DiffViewer("Service Name", eBefore.getServiceName(), eAfter.getServiceName()));
				diff.add(new DiffViewer("Request Type", eBefore.getRequestType(), eAfter.getRequestType()));
				diff.add(new DiffViewer("SnF", eBefore.getSnF(), eAfter.getSnF()));
				diff.add(new DiffViewer("Trace", eBefore.getTrace(), eAfter.getTrace()));
				diff.add(new DiffViewer("Delivery Notification", eBefore.getDeliveryNotification(), eAfter.getDeliveryNotification()));
				diff.add(new DiffViewer("Delivery Notification DN", eBefore.getDeliveryNotifDN(), eAfter.getDeliveryNotifDN()));
				diff.add(new DiffViewer("Delivery Notification RT", eBefore.getDeliveryNotifRT(), eAfter.getDeliveryNotifRT()));
				diff.add(new DiffViewer("Non-Repudiation", eBefore.getNonRepudiation(), eAfter.getNonRepudiation()));
				diff.add(new DiffViewer("Request Reference", eBefore.getRequestRef(), eAfter.getRequestRef()));
				diff.add(new DiffViewer("File Description", eBefore.getFileDesc(), eAfter.getFileDesc()));
				diff.add(new DiffViewer("File Info", eBefore.getFileInfo(), eAfter.getFileInfo()));
				diff.add(new DiffViewer("Transfer Description", eBefore.getTransferDesc(), eAfter.getTransferDesc()));
				diff.add(new DiffViewer("Transfer Info", eBefore.getTransferInfo(), eAfter.getTransferInfo()));
				diff.add(new DiffViewer("Compression", eBefore.getCompression(), eAfter.getCompression()));
				diff.add(new DiffViewer("Mailbox Path In", eBefore.getMailboxPathIn(), eAfter.getMailboxPathIn()));
				diff.add(new DiffViewer("Mailbox Path Out", eBefore.getMailboxPathOut(), eAfter.getMailboxPathOut()));
				diff.add(new DiffViewer("MQ Queue In", eBefore.getMqQueueIn(), eAfter.getMqQueueIn()));
				diff.add(new DiffViewer("MQ Queue Out", eBefore.getMqQueueOut(), eAfter.getMqQueueOut()));
				diff.add(new DiffViewer("Max Transfers per bulk", eBefore.getMaxTransfersPerBulk(), eAfter.getMaxTransfersPerBulk()));
				diff.add(new DiffViewer("Max Bulks per file", eBefore.getMaxBulksPerFile(), eAfter.getMaxBulksPerFile()));
				diff.add(new DiffViewer("Start of day (minutes)", eBefore.getStartOfDay(), eAfter.getStartOfDay()));
				diff.add(new DiffViewer("End of day (minutes)", eBefore.getEndOfDay(), eAfter.getEndOfDay()));
				diff.add(new DiffViewer("CD Node", eBefore.getCdNode(), eAfter.getCdNode()));
				diff.add(new DiffViewer("IDF WTO Msg ID", eBefore.getIdfWTOMsgId(), eAfter.getIdfWTOMsgId()));
				diff.add(new DiffViewer("CDF WTO Msg ID", eBefore.getCdfWTOMsgId(), eAfter.getCdfWTOMsgId()));
				diff.add(new DiffViewer("SDF WTO Msg ID", eBefore.getSdfWTOMsgId(), eAfter.getSdfWTOMsgId()));
				diff.add(new DiffViewer("RSF WTO Msg ID", eBefore.getRsfWTOMsgId(), eAfter.getRsfWTOMsgId()));
				diff.add(new DiffViewer("DNF WTO Msg ID", eBefore.getDnfWTOMsgId(), eAfter.getDnfWTOMsgId()));
				diff.add(new DiffViewer("DVF WTO Msg ID", eBefore.getDvfWTOMsgId(), eAfter.getDvfWTOMsgId()));
				diff.add(new DiffViewer("MSR WTO Msg ID", eBefore.getMsrWTOMsgId(), eAfter.getMsrWTOMsgId()));
				diff.add(new DiffViewer("PSR WTO Msg ID", eBefore.getPsrWTOMsgId(), eAfter.getPsrWTOMsgId()));
				diff.add(new DiffViewer("DRR WTO Msg ID", eBefore.getDrrWTOMsgId(), eAfter.getDrrWTOMsgId()));
				diff.add(new DiffViewer("RTF WTO Msg ID", eBefore.getRtfWTOMsgId(), eAfter.getRtfWTOMsgId()));
				diff.add(new DiffViewer("MBP WTO Msg ID", eBefore.getMbpWTOMsgId(), eAfter.getMbpWTOMsgId()));
				diff.add(new DiffViewer("MQ Host", eBefore.getMqHost(), eAfter.getMqHost()));
				diff.add(new DiffViewer("MQ Port", eBefore.getMqPort(), eAfter.getMqPort()));
				diff.add(new DiffViewer("MQ Queue Manager", eBefore.getMqQManager(), eAfter.getMqQManager()));
				diff.add(new DiffViewer("MQ Channel", eBefore.getMqChannel(), eAfter.getMqChannel()));
				diff.add(new DiffViewer("MQ Queue Name", eBefore.getMqQueueName(), eAfter.getMqQueueName()));
				diff.add(new DiffViewer("MQ Queue Binding", eBefore.getMqQueueBinding(), eAfter.getMqQueueBinding()));
				diff.add(new DiffViewer("MQ Queue Context", eBefore.getMqQueueContext(), eAfter.getMqQueueContext()));
				diff.add(new DiffViewer("MQ Debug", eBefore.getMqDebug(), eAfter.getMqDebug()));
				diff.add(new DiffViewer("MQ SSL Options", eBefore.getMqSSLoptions(), eAfter.getMqSSLoptions()));
				diff.add(new DiffViewer("MQ SSL Ciphers", eBefore.getMqSSLciphers(), eAfter.getMqSSLciphers()));
				diff.add(new DiffViewer("MQ SSL Key Cert ID", eBefore.getMqSSLkey(), eAfter.getMqSSLkey()));
				diff.add(new DiffViewer("MQ SSL CA Cert IDs", eBefore.getMqSSLcaCert(), eAfter.getMqSSLcaCert()));
				diff.add(new DiffViewer("Inbound RequestorDN", eBefore.getInboundRequestorDN(), eAfter.getInboundRequestorDN()));
				diff.add(new DiffViewer("Inbound ResponderDN", eBefore.getInboundResponderDN(), eAfter.getInboundResponderDN()));
				diff.add(new DiffViewer("Inbound Service Name", eBefore.getInboundService(), eAfter.getInboundService()));
				diff.add(new DiffViewer("Inbound Request Type", eBefore.getInboundType(), eAfter.getInboundType()));
				diff.add(new DiffViewer("Pause Inbound", eBefore.getPauseInbound(), eAfter.getPauseInbound()));
				diff.add(new DiffViewer("Pause Outbound", eBefore.getPauseOutbound(), eAfter.getPauseOutbound()));

				List schBefore = eBefore.getSchedules();
				List schAfter = eAfter.getSchedules();
				diff.add(new DiffViewer("Number of schedules", schBefore==null?0:schBefore.size(), schAfter==null?0:schAfter.size()));

				HashMap allSch = null;
				ArrayList schIDS = null;
				if(schBefore!=null){
					Iterator ibSch = schBefore.iterator();
					while(ibSch.hasNext()){
						if(allSch==null){
							allSch = new HashMap();
						}
						if(schIDS==null){
							schIDS=new ArrayList();
						}
						Schedule s = (Schedule)ibSch.next();
						allSch.put("before"+s.getScheduleId(), s);
						if(!schIDS.contains(s.getScheduleId())){
							schIDS.add(s.getScheduleId());
						}
		
					}
				}
				int newindex=0;
				if(schAfter!=null){
					Iterator iaSch = schAfter.iterator();
					while(iaSch.hasNext()){
						if(allSch==null){
							allSch = new HashMap();
						}
						if(schIDS==null){
							schIDS=new ArrayList();
						}
						Schedule s = (Schedule)iaSch.next();
						if(s.getScheduleId()==null){
							//new schedules don't have an ID so we will create one starting from 1000
							int j = 1000+newindex;
							allSch.put("after"+j, s);
							if(!schIDS.contains(Long.valueOf(String.valueOf(j)))){
								schIDS.add(Long.valueOf(String.valueOf(j)));
							}
						} else {
							allSch.put("after"+s.getScheduleId(), s);
							if(!schIDS.contains(s.getScheduleId())){
								schIDS.add(s.getScheduleId());
							}
						}
						allSch.put("after"+s.getScheduleId(), s);
						newindex++;
						
					}
				}
				
				if(schIDS!=null && allSch!=null){
					Iterator ids = schIDS.iterator();
					while(ids.hasNext()){
						Long id = (Long)ids.next();
						if(id!=null){
							Schedule bs = (Schedule)allSch.get("before"+id.toString());
							Schedule as = (Schedule)allSch.get("after"+id.toString());
							if(bs==null){
								if(as!=null){
									diff.add(new DiffViewer("Schedule Type (new)", "", as.getIsWindow().booleanValue()?"Window":"Daily"));
									diff.add(new DiffViewer("Schedule Start Time (new)", null, as.getTimestart()));
									diff.add(new DiffViewer("Schedule Window Interval (new)", null, as.getWindowInterval()));
									diff.add(new DiffViewer("Schedule Window End (new)", null, as.getWindowEnd()));
								}								
							}
							if(as==null){
								if(bs!=null){
									diff.add(new DiffViewer("Schedule Type (deleted)", bs.getIsWindow().booleanValue()?"Window":"Daily", ""));
									diff.add(new DiffViewer("Schedule Start Time (deleted)", bs.getTimestart(), null));
									diff.add(new DiffViewer("Schedule Window Interval (deleted)", bs.getWindowInterval(), null));
									diff.add(new DiffViewer("Schedule Window End (deleted)", bs.getWindowEnd(), null));
								}								
							}
							if(as!=null && bs!=null){
								diff.add(new DiffViewer("Schedule Type ("+id.toString()+")", bs.getIsWindow().booleanValue()?"Window":"Daily", as.getIsWindow().booleanValue()?"Window":"Daily"));
								diff.add(new DiffViewer("Schedule Start Time ("+id.toString()+")", bs.getTimestart(), as.getTimestart()));
								diff.add(new DiffViewer("Schedule Window Interval ("+id.toString()+")", bs.getWindowInterval(), as.getWindowInterval()));
								diff.add(new DiffViewer("Schedule Window End ("+id.toString()+")", bs.getWindowEnd(), as.getWindowEnd()));
							}
						}
					}
				}

				//private List schedules = new ArrayList();
				//private List deletedSchedules = new ArrayList();


			}
		}catch(Exception e){
			e.printStackTrace();
		}

		return diff;
	}


	private Session getHibernateSession(){
		Session hibernateSession = HibernateUtils.getSession();
		return  hibernateSession;
	}







}
