package com.stercomm.customers.rbs.sct.ui.actions;

import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.w3c.dom.Document;

import com.stercomm.customers.rbs.sct.ui.dto.FileAuthRequest;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuth;
import com.stercomm.customers.rbs.sct.ui.fileauth.FileAuthUsers;
import com.stercomm.customers.rbs.sct.ui.xapi.FBXAPIBase;
import com.stercomm.customers.rbs.sct.ui.xapi.FileGatewayXAPI;
import com.sterlingcommerce.woodstock.dmi.visibility.event.AFCDmiVisEventFactory;
import com.sterlingcommerce.woodstock.event.ExceptionLevel;
import com.sterlingcommerce.woodstock.util.BaseUtil;
import com.yantra.yfc.util.YFCException;

/**
 * @author <a href="mailto:matt.bradley@uk.ibm.com">Matt Bradley</a>
 *
 */
public class FileAuthRequestSubmitAction extends BaseFileAuthRequestWizardAction {
	private static final long serialVersionUID = 1L;

	private static final int EXPIRY_DELAY_DAYS = 7;//7 days

	private static final Logger log = Logger.getLogger(FileAuthRequestSubmitAction.class);

	public ActionForward create(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		log.debug("FileAuthRequestSubmitAction.create()");
		FileAuthRequest far =null;
		ActionErrors errors = new ActionErrors();

		try {

			far = this.getFileAuthRequest(request);

			//maybe put this in the DAO commit()

			FileAuth fa = new FileAuth();
			fa.setAction(FileAuth.validateAction(far.getFileAction()));
			fa.setFileKey(far.getFileKey());
			fa.setRequestor(this.getGisUsername(request));
			fa.setRequestorComments(far.getRequestorComments());
			Calendar cal = Calendar.getInstance();
			fa.setDateRequested(new Date(cal.getTime().getTime()));	
			cal.add(Calendar.DAY_OF_MONTH, EXPIRY_DELAY_DAYS);
			fa.setDateExpired(new Date(cal.getTime().getTime()));		
			FileAuthUsers fau = new FileAuthUsers(fa.getFileAuthID(), far.getUsers());
			fau.insert();
			//users are in - now add the parent record
			fa.insert();

			AFCDmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, BaseUtil.createGUID(), System.currentTimeMillis(), getGisUsername(request), fa.getAction(), "File Authorisation Requested", String.valueOf(fa.getFileAuthID()), fa.getFileKey());

			request.setAttribute("faid", String.valueOf(fa.getFileAuthID()));
			return mapping.findForward("created");

		} catch (Exception e) {

			log.error("Error performing create action");
			log.error(e);
			saveErrors(request, errors);	
			request.getSession().setAttribute("fileAuthRequestBean", far);
			String eMsg = e.getMessage()==null?"None":e.getMessage().trim();
			request.setAttribute("exceptionMessage", "Exception message: " + eMsg);
			return mapping.findForward("error");

		}
	}

	public ActionForward approve(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		log.debug("FileAuthRequestSubmitAction.approve()");
		FileAuthRequest far =null;
		ActionErrors errors = new ActionErrors();

		try {

			far = this.getFileAuthRequest(request);

			FileAuth fa = far.getFileAuth();
			fa.approve(getGisUsername(request), far.getApproverComments());

			AFCDmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, BaseUtil.createGUID(), System.currentTimeMillis(), getGisUsername(request), fa.getAction(), "File Authorisation Approved", String.valueOf(fa.getFileAuthID()), fa.getFileKey());

			request.setAttribute("faid", String.valueOf(fa.getFileAuthID()));
			return mapping.findForward("approved");

		} catch (Exception e) {

			log.error("Error performing approve action");
			log.error(e);
			saveErrors(request, errors);	
			request.getSession().setAttribute("fileAuthRequestBean", far);
			String eMsg = e.getMessage()==null?"None":e.getMessage().trim();
			request.setAttribute("exceptionMessage", "Exception message: " + eMsg);
			return mapping.findForward("error");

		}
	}

	public ActionForward reject(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		log.debug("FileAuthRequestSubmitAction.reject()");
		FileAuthRequest far =null;
		ActionErrors errors = new ActionErrors();

		try {
			far = this.getFileAuthRequest(request);

			FileAuth fa = far.getFileAuth();
			fa.reject(getGisUsername(request), far.getApproverComments());

			AFCDmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, BaseUtil.createGUID(), System.currentTimeMillis(), getGisUsername(request), fa.getAction(), "File Authorisation Rejected", String.valueOf(fa.getFileAuthID()), fa.getFileKey());

			request.setAttribute("faid", String.valueOf(fa.getFileAuthID()));
			return mapping.findForward("rejected");

		} catch (Exception e) {

			log.error("Error performing reject action");
			log.error(e);
			saveErrors(request, errors);	
			request.getSession().setAttribute("fileAuthRequestBean", far);
			String eMsg = e.getMessage()==null?"None":e.getMessage().trim();
			request.setAttribute("exceptionMessage", "Exception message: " + eMsg);
			return mapping.findForward("error");

		}
	}

	public ActionForward complete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		log.debug("FileAuthRequestSubmitAction.complete()");

		FileAuthRequest far =null;
		ActionErrors errors = new ActionErrors();

		try {
			far = this.getFileAuthRequest(request);

			//DO THE ACTION HERE
			FileAuth fa = far.getFileAuth();

			try {
				if(fa.getAction().equalsIgnoreCase(FileAuth.ACTION_REPLAY)){
					String comment = "Replayed from File Authorisation #"+fa.getFileAuthID();
					Document replayDoc = FileGatewayXAPI.replayFgArrivedFile(fa.getFileKey(), null, comment);
					if(log.isDebugEnabled()){
						log.debug("Replay response: "+ FBXAPIBase.xmlToString(replayDoc));
					}
				}
			} catch (YFCException ye) {
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.complete.replay.error"));
				throw new Exception(ye.getAttribute("ErrorCode"));
			} catch (Exception e) {
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.complete.replay.error"));
				throw e;
			}
			try {
				if(fa.getAction().equalsIgnoreCase(FileAuth.ACTION_REDELIVER)){
					String comment = "Redelivered from File Authorisation #"+fa.getFileAuthID();
					Document redeliverDoc = FileGatewayXAPI.redeliverFgConsumerFile(fa.getFileKey(), comment);
					if(log.isDebugEnabled()){
						log.debug("Redeliver response: "+ FBXAPIBase.xmlToString(redeliverDoc));
					}
				}
			} catch (YFCException ye) {
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.complete.redeliver.error"));
				throw new Exception(ye.getAttribute("ErrorCode"));
			} catch (Exception e) {
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.complete.redeliver.error"));
				throw e;
			}
			try {
				if(fa.getAction().equalsIgnoreCase(FileAuth.ACTION_REVIEW)){
					Document reviewDoc = FileGatewayXAPI.manageFgArrivedFile(fa.getFileKey(), true);
					if(log.isDebugEnabled()){
						log.debug("Review response: "+ FBXAPIBase.xmlToString(reviewDoc));
					}
				}
			} catch (YFCException ye) {
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.complete.review.error"));
				throw new Exception(ye.getAttribute("ErrorCode"));
			} catch (Exception e) {
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.complete.review.error"));
				throw e;
			}
			try {
				if(fa.getAction().equalsIgnoreCase(FileAuth.ACTION_UNREVIEW)){
					Document unreviewDoc = FileGatewayXAPI.manageFgArrivedFile(fa.getFileKey(), false);
					if(log.isDebugEnabled()){
						log.debug("Unreview response: "+ FBXAPIBase.xmlToString(unreviewDoc));
					}

				}
			} catch (YFCException ye) {
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.complete.unreview.error"));
				throw new Exception(ye.getAttribute("ErrorCode"));
			} catch (Exception e) {
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionError("fileauth.msgs.complete.unreview.error"));
				throw e;
			}

			fa.complete(getGisUsername(request));
			AFCDmiVisEventFactory.fireAdminAuditEvent(6, ExceptionLevel.NORMAL, BaseUtil.createGUID(), System.currentTimeMillis(), getGisUsername(request), fa.getAction(), "File Authorisation Completed", String.valueOf(fa.getFileAuthID()), fa.getFileKey());

			request.setAttribute("faid", String.valueOf(fa.getFileAuthID()));
			return mapping.findForward("completed");

		} catch (Exception e) {

			//set as FAILED
			if(far!=null){
				FileAuth fa = far.getFileAuth();
				if(fa!=null){
					fa.failed();
				}
			}

			log.error("Error performing complete action");
			log.error(e);
			saveErrors(request, errors);	
			request.getSession().setAttribute("fileAuthRequestBean", far);
			String eMsg = e.getMessage()==null?"None":e.getMessage().trim();
			request.setAttribute("exceptionMessage", "Exception message: " + eMsg);
			return mapping.findForward("error");
		}
	}

	public ActionForward viewForm(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {

		log.debug("FileAuthRequestSubmitAction.viewForm()");
		FileAuthRequest far =null;
		ActionErrors errors = new ActionErrors();

		try {

			far = this.getFileAuthRequest(request);
			String faid = (String)request.getAttribute("faid");
			FileAuth fa = new FileAuth(Integer.parseInt(faid));
			FileAuthUsers fau = new FileAuthUsers(fa.getFileAuthID());
			far.setFileAuth(fa);
			far.setFileAuthUsers(fau.getFileAuthUsers());
			return super.viewForm(mapping, form, request, response);
		} catch (Exception e) {

			log.error("Error performing viewForm action");
			log.error(e);
			saveErrors(request, errors);	
			request.getSession().setAttribute("fileAuthRequestBean", far);
			String eMsg = e.getMessage()==null?"None":e.getMessage().trim();
			request.setAttribute("exceptionMessage", "Exception message: " + eMsg);
			return mapping.findForward("error");
			
		}
	}




}
