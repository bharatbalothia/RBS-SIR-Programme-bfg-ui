/*******************************************************************
 Copyright (c) 2007 Sterling Commerce, Inc. All Rights Reserved.

 ** Trade Secret Notice **

 This software, and the information and know-how it contains, is
 proprietary and confidential and constitutes valuable trade secrets
 of Sterling Commerce, Inc., its affiliated companies or its or
 their licensors, and may not be used for any unauthorized purpose
 or disclosed to others without the prior written permission of the
 applicable Sterling Commerce entity. This software and the
 information and know-how it contains have been provided
 pursuant to a license agreement which contains prohibitions
 against and/or restrictions on its copying, modification and use.
 Duplication, in whole or in part, if and when permitted, shall
 bear this notice and the Sterling Commerce, Inc. copyright
 legend. As and when provided to any governmental entity,
 government contractor or subcontractor subject to the FARs,
 this software is provided with RESTRICTED RIGHTS under
 Title 48 CFR 52.227-19.
 Further, as and when provided to any governmental entity,
 government contractor or subcontractor subject to DFARs,
 this software is provided pursuant to the customary
 Sterling Commerce license, as described in Title 48
 CFR 227-7202 with respect to commercial software and commercial
 software documentation.
 **********************************************************************
 * Current Version
 * ================
 * Revision:   		$LastChangedRevision$
 * Date/time:  		$LastChangedDate$
 **********************************************************************/
package com.stercomm.customers.rbs.sct.ui.actions;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.stercomm.customers.rbs.sct.ui.forms.EntityForm;



/**
 * @author <a href="mailto:ravi_patel@consultant.stercomm.com">Ravi K Patel</a>
 *
 */
public class EntityCDDetailsAction extends BaseEntityWizardAction {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(EntityCDDetailsAction.class);

	public ActionForward next(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.next(mapping,form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}
	}

	public ActionForward save(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.save(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}


	}

	public ActionForward entityCDDetails(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.entityCDDetails(mapping,form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}


	}
	public ActionForward entitySwift(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.entitySwift(mapping,form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}

	}
	public ActionForward confirm(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {

		if(validateForm(form, request)){
			return super.confirm(mapping, form, request, response);
		} else {
			return mapping.findForward("viewForm");
		}

	}
	/*
	 * Can't get ValidatorForm to work so doing it manually (MB)
	 */
	private boolean validateForm(ActionForm form, HttpServletRequest request){

		EntityForm entityForm = (EntityForm)form;
		ActionMessages messages = new ActionMessages();
		//MessageResources messageResources = getResources(request);
		boolean rtn=true;

		log.debug("Validating Entity[CD Details] form.");

		/*
		 * SDD ONLY
		 */
		if(entityForm.getService()!=null && entityForm.getService().equalsIgnoreCase("SDD")){
			//CD Node Check
			if(entityForm.getCdNode()==null || entityForm.getCdNode().equalsIgnoreCase("")){
				log.debug("CD Node is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.cdnode.required" ));
				rtn=false;
			}
			//IDF WTO Msg ID Check
			if(entityForm.getIdfWTOMsgId()==null || entityForm.getIdfWTOMsgId().equalsIgnoreCase("")){
				log.debug("IDF WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.idfmsgid.required" ));
				rtn=false;
			}
//			DNF WTO Msg ID Check
			if(entityForm.getDnfWTOMsgId()==null || entityForm.getDnfWTOMsgId().equalsIgnoreCase("")){
				log.debug("DNF WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.dnfmsgid.required" ));
				rtn=false;
			}
//			DVF WTO Msg ID Check
			if(entityForm.getDvfWTOMsgId()==null || entityForm.getDvfWTOMsgId().equalsIgnoreCase("")){
				log.debug("DVF WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.dvfmsgid.required" ));
				rtn=false;
			}
//			SDF WTO Msg ID Check
			if(entityForm.getSdfWTOMsgId()==null || entityForm.getSdfWTOMsgId().equalsIgnoreCase("")){
				log.debug("SDF WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.sdfmsgid.required" ));
				rtn=false;
			}
//			RSF WTO Msg ID Check
			if(entityForm.getRsfWTOMsgId()==null || entityForm.getRsfWTOMsgId().equalsIgnoreCase("")){
				log.debug("RSF WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.rsfmsgid.required" ));
				rtn=false;
			}
//			CDF WTO Msg ID Check
			if(entityForm.getCdfWTOMsgId()==null || entityForm.getCdfWTOMsgId().equalsIgnoreCase("")){
				log.debug("CDF WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.cdfmsgid.required" ));
				rtn=false;
			}
//			MSR WTO Msg ID Check
			if(entityForm.getMsrWTOMsgId()==null || entityForm.getMsrWTOMsgId().equalsIgnoreCase("")){
				log.debug("MSR WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.msrmsgid.required" ));
				rtn=false;
			}
//			PSR WTO Msg ID Check
			if(entityForm.getPsrWTOMsgId()==null || entityForm.getPsrWTOMsgId().equalsIgnoreCase("")){
				log.debug("PSR WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.psrmsgid.required" ));
				rtn=false;
			}
//			DRR WTO Msg ID Check
			if(entityForm.getDrrWTOMsgId()==null || entityForm.getDrrWTOMsgId().equalsIgnoreCase("")){
				log.debug("DRR WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.drrmsgid.required" ));
				rtn=false;
			}
//			RTF WTO Msg ID Check
			if(entityForm.getRtfWTOMsgId()==null || entityForm.getRtfWTOMsgId().equalsIgnoreCase("")){
				log.debug("RTF WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.rtfmsgid.required" ));
				rtn=false;
			}
//			MBP WTO Msg ID Check
			if(entityForm.getMbpWTOMsgId()==null || entityForm.getMbpWTOMsgId().equalsIgnoreCase("")){
				log.debug("MBP WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("sct.msgs.entity.mbpmsgid.required" ));
				rtn=false;
			}
		}
		
		/*
		 * ROI ONLY
		 */
		if(entityForm.getService()!=null && entityForm.getService().equalsIgnoreCase("ROI")){
			//CD Node Check
			if(entityForm.getCdNode()==null || entityForm.getCdNode().equalsIgnoreCase("")){
				log.debug("CD Node is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("roi.msgs.entity.cdnode.required" ));
				rtn=false;
			}
//			ACKNOWLEDGEMENT WTO Msg ID Check
			if(entityForm.getDvfWTOMsgId()==null || entityForm.getDvfWTOMsgId().equalsIgnoreCase("")){
				log.debug("DVF WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("roi.msgs.entity.dvfmsgid.required" ));
				rtn=false;
			}
//			DATA WTO Msg ID Check
			if(entityForm.getSdfWTOMsgId()==null || entityForm.getSdfWTOMsgId().equalsIgnoreCase("")){
				log.debug("SDF WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("roi.msgs.entity.sdfmsgid.required" ));
				rtn=false;
			}
//			DRR WTO Msg ID Check
			if(entityForm.getDrrWTOMsgId()==null || entityForm.getDrrWTOMsgId().equalsIgnoreCase("")){
				log.debug("DRR WTO Msg ID is required. Validation failed.");
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("roi.msgs.entity.drrmsgid.required" ));
				rtn=false;
			}
		}

		saveMessages(request, messages);
		return rtn;
	}
}
